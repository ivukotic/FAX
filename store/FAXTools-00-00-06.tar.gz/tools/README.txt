This package contains tools helpfull in using FAX to access data.
Programs are accessible after doing localSetupFAX.


