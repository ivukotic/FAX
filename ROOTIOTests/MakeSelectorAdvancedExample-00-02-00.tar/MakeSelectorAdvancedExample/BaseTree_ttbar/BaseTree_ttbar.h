//////////////////////////////////////////////////////////
// This class has been automatically generated on
// Thu Mar  8 11:33:11 2012 by ROOT version 5.28/00g
// from TChain physics/
//////////////////////////////////////////////////////////

#ifndef BaseTree_ttbar_h
#define BaseTree_ttbar_h

#include <TROOT.h>
#include <TChain.h>
#include <TFile.h>
#include <TSelector.h>

class BaseTree_ttbar : public TSelector {
public :
   TTree          *fChain;   //!pointer to the analyzed TTree or TChain

   // Declaration of leaf types
   UInt_t          trig_DB_SMK;
   UInt_t          trig_DB_L1PSK;
   UInt_t          trig_DB_HLTPSK;
   UInt_t          bunch_configID;
   UInt_t          RunNumber;
   UInt_t          EventNumber;
   UInt_t          timestamp;
   UInt_t          timestamp_ns;
   UInt_t          lbn;
   UInt_t          bcid;
   UInt_t          detmask0;
   UInt_t          detmask1;
   Float_t         actualIntPerXing;
   Float_t         averageIntPerXing;
   UInt_t          pixelFlags;
   UInt_t          sctFlags;
   UInt_t          trtFlags;
   UInt_t          larFlags;
   UInt_t          tileFlags;
   UInt_t          muonFlags;
   UInt_t          fwdFlags;
   UInt_t          coreFlags;
   UInt_t          pixelError;
   UInt_t          sctError;
   UInt_t          trtError;
   UInt_t          larError;
   UInt_t          tileError;
   UInt_t          muonError;
   UInt_t          fwdError;
   UInt_t          coreError;
   Int_t           el_n;
   vector<float>   *el_E;
   vector<float>   *el_Et;
   vector<float>   *el_pt;
   vector<float>   *el_m;
   vector<float>   *el_eta;
   vector<float>   *el_phi;
   vector<float>   *el_px;
   vector<float>   *el_py;
   vector<float>   *el_pz;
   vector<float>   *el_charge;
   vector<int>     *el_author;
   vector<unsigned int> *el_isEM;
   vector<unsigned int> *el_OQ;
   vector<int>     *el_convFlag;
   vector<int>     *el_isConv;
   vector<int>     *el_nConv;
   vector<int>     *el_nSingleTrackConv;
   vector<int>     *el_nDoubleTrackConv;
   vector<unsigned int> *el_OQRecalc;
   vector<int>     *el_loose;
   vector<int>     *el_looseIso;
   vector<int>     *el_medium;
   vector<int>     *el_mediumIso;
   vector<int>     *el_mediumWithoutTrack;
   vector<int>     *el_mediumIsoWithoutTrack;
   vector<int>     *el_tight;
   vector<int>     *el_tightIso;
   vector<int>     *el_tightWithoutTrack;
   vector<int>     *el_tightIsoWithoutTrack;
   vector<int>     *el_loosePP;
   vector<int>     *el_loosePPIso;
   vector<int>     *el_mediumPP;
   vector<int>     *el_mediumPPIso;
   vector<int>     *el_tightPP;
   vector<int>     *el_tightPPIso;
   vector<int>     *el_goodOQ;
   vector<float>   *el_Ethad;
   vector<float>   *el_Ethad1;
   vector<float>   *el_f1;
   vector<float>   *el_f1core;
   vector<float>   *el_Emins1;
   vector<float>   *el_fside;
   vector<float>   *el_Emax2;
   vector<float>   *el_ws3;
   vector<float>   *el_wstot;
   vector<float>   *el_emaxs1;
   vector<float>   *el_deltaEs;
   vector<float>   *el_E233;
   vector<float>   *el_E237;
   vector<float>   *el_E277;
   vector<float>   *el_weta2;
   vector<float>   *el_f3;
   vector<float>   *el_f3core;
   vector<float>   *el_rphiallcalo;
   vector<float>   *el_Etcone45;
   vector<float>   *el_Etcone15;
   vector<float>   *el_Etcone20;
   vector<float>   *el_Etcone25;
   vector<float>   *el_Etcone30;
   vector<float>   *el_Etcone35;
   vector<float>   *el_Etcone40;
   vector<float>   *el_ptcone20;
   vector<float>   *el_ptcone30;
   vector<float>   *el_ptcone40;
   vector<float>   *el_nucone20;
   vector<float>   *el_nucone30;
   vector<float>   *el_nucone40;
   vector<float>   *el_Etcone15_pt_corrected;
   vector<float>   *el_Etcone20_pt_corrected;
   vector<float>   *el_Etcone25_pt_corrected;
   vector<float>   *el_Etcone30_pt_corrected;
   vector<float>   *el_Etcone35_pt_corrected;
   vector<float>   *el_Etcone40_pt_corrected;
   vector<float>   *el_convanglematch;
   vector<float>   *el_convtrackmatch;
   vector<int>     *el_hasconv;
   vector<float>   *el_convvtxx;
   vector<float>   *el_convvtxy;
   vector<float>   *el_convvtxz;
   vector<float>   *el_Rconv;
   vector<float>   *el_zconv;
   vector<float>   *el_convvtxchi2;
   vector<float>   *el_pt1conv;
   vector<int>     *el_convtrk1nBLHits;
   vector<int>     *el_convtrk1nPixHits;
   vector<int>     *el_convtrk1nSCTHits;
   vector<int>     *el_convtrk1nTRTHits;
   vector<float>   *el_pt2conv;
   vector<int>     *el_convtrk2nBLHits;
   vector<int>     *el_convtrk2nPixHits;
   vector<int>     *el_convtrk2nSCTHits;
   vector<int>     *el_convtrk2nTRTHits;
   vector<float>   *el_ptconv;
   vector<float>   *el_pzconv;
   vector<float>   *el_pos7;
   vector<float>   *el_etacorrmag;
   vector<float>   *el_deltaeta1;
   vector<float>   *el_deltaeta2;
   vector<float>   *el_deltaphi2;
   vector<float>   *el_deltaphiRescaled;
   vector<float>   *el_deltaPhiRot;
   vector<float>   *el_expectHitInBLayer;
   vector<float>   *el_trackd0_physics;
   vector<float>   *el_etaSampling1;
   vector<float>   *el_reta;
   vector<float>   *el_rphi;
   vector<float>   *el_EtringnoisedR03sig2;
   vector<float>   *el_EtringnoisedR03sig3;
   vector<float>   *el_EtringnoisedR03sig4;
   vector<double>  *el_isolationlikelihoodjets;
   vector<double>  *el_isolationlikelihoodhqelectrons;
   vector<double>  *el_electronweight;
   vector<double>  *el_electronbgweight;
   vector<double>  *el_softeweight;
   vector<double>  *el_softebgweight;
   vector<double>  *el_neuralnet;
   vector<double>  *el_Hmatrix;
   vector<double>  *el_Hmatrix5;
   vector<double>  *el_adaboost;
   vector<double>  *el_softeneuralnet;
   vector<float>   *el_zvertex;
   vector<float>   *el_errz;
   vector<float>   *el_etap;
   vector<float>   *el_depth;
   vector<int>     *el_refittedTrack_n;
   vector<vector<int> > *el_refittedTrack_author;
   vector<vector<float> > *el_refittedTrack_chi2;
   vector<vector<int> > *el_refittedTrack_hasBrem;
   vector<vector<float> > *el_refittedTrack_bremRadius;
   vector<vector<float> > *el_refittedTrack_bremZ;
   vector<vector<float> > *el_refittedTrack_bremRadiusErr;
   vector<vector<float> > *el_refittedTrack_bremZErr;
   vector<vector<int> > *el_refittedTrack_bremFitStatus;
   vector<vector<float> > *el_refittedTrack_qoverp;
   vector<vector<float> > *el_refittedTrack_d0;
   vector<vector<float> > *el_refittedTrack_z0;
   vector<vector<float> > *el_refittedTrack_theta;
   vector<vector<float> > *el_refittedTrack_phi;
   vector<vector<float> > *el_refittedTrack_LMqoverp;
   vector<float>   *el_Es0;
   vector<float>   *el_etas0;
   vector<float>   *el_phis0;
   vector<float>   *el_Es1;
   vector<float>   *el_etas1;
   vector<float>   *el_phis1;
   vector<float>   *el_Es2;
   vector<float>   *el_etas2;
   vector<float>   *el_phis2;
   vector<float>   *el_Es3;
   vector<float>   *el_etas3;
   vector<float>   *el_phis3;
   vector<float>   *el_E_PreSamplerB;
   vector<float>   *el_E_EMB1;
   vector<float>   *el_E_EMB2;
   vector<float>   *el_E_EMB3;
   vector<float>   *el_E_PreSamplerE;
   vector<float>   *el_E_EME1;
   vector<float>   *el_E_EME2;
   vector<float>   *el_E_EME3;
   vector<float>   *el_E_HEC0;
   vector<float>   *el_E_HEC1;
   vector<float>   *el_E_HEC2;
   vector<float>   *el_E_HEC3;
   vector<float>   *el_E_TileBar0;
   vector<float>   *el_E_TileBar1;
   vector<float>   *el_E_TileBar2;
   vector<float>   *el_E_TileGap1;
   vector<float>   *el_E_TileGap2;
   vector<float>   *el_E_TileGap3;
   vector<float>   *el_E_TileExt0;
   vector<float>   *el_E_TileExt1;
   vector<float>   *el_E_TileExt2;
   vector<float>   *el_E_FCAL0;
   vector<float>   *el_E_FCAL1;
   vector<float>   *el_E_FCAL2;
   vector<float>   *el_cl_E;
   vector<float>   *el_cl_pt;
   vector<float>   *el_cl_eta;
   vector<float>   *el_cl_phi;
   vector<float>   *el_firstEdens;
   vector<float>   *el_cellmaxfrac;
   vector<float>   *el_longitudinal;
   vector<float>   *el_secondlambda;
   vector<float>   *el_lateral;
   vector<float>   *el_secondR;
   vector<float>   *el_centerlambda;
   vector<float>   *el_rawcl_Es0;
   vector<float>   *el_rawcl_etas0;
   vector<float>   *el_rawcl_phis0;
   vector<float>   *el_rawcl_Es1;
   vector<float>   *el_rawcl_etas1;
   vector<float>   *el_rawcl_phis1;
   vector<float>   *el_rawcl_Es2;
   vector<float>   *el_rawcl_etas2;
   vector<float>   *el_rawcl_phis2;
   vector<float>   *el_rawcl_Es3;
   vector<float>   *el_rawcl_etas3;
   vector<float>   *el_rawcl_phis3;
   vector<float>   *el_rawcl_E;
   vector<float>   *el_rawcl_pt;
   vector<float>   *el_rawcl_eta;
   vector<float>   *el_rawcl_phi;
   vector<float>   *el_trackd0;
   vector<float>   *el_trackz0;
   vector<float>   *el_trackphi;
   vector<float>   *el_tracktheta;
   vector<float>   *el_trackqoverp;
   vector<float>   *el_trackpt;
   vector<float>   *el_tracketa;
   vector<float>   *el_trackfitchi2;
   vector<int>     *el_trackfitndof;
   vector<int>     *el_nBLHits;
   vector<int>     *el_nPixHits;
   vector<int>     *el_nSCTHits;
   vector<int>     *el_nTRTHits;
   vector<int>     *el_nTRTHighTHits;
   vector<int>     *el_nPixHoles;
   vector<int>     *el_nSCTHoles;
   vector<int>     *el_nTRTHoles;
   vector<int>     *el_nBLSharedHits;
   vector<int>     *el_nPixSharedHits;
   vector<int>     *el_nSCTSharedHits;
   vector<int>     *el_nBLayerOutliers;
   vector<int>     *el_nPixelOutliers;
   vector<int>     *el_nSCTOutliers;
   vector<int>     *el_nTRTOutliers;
   vector<int>     *el_nTRTHighTOutliers;
   vector<int>     *el_expectBLayerHit;
   vector<int>     *el_nSiHits;
   vector<float>   *el_TRTHighTHitsRatio;
   vector<float>   *el_TRTHighTOutliersRatio;
   vector<float>   *el_pixeldEdx;
   vector<int>     *el_nGoodHitsPixeldEdx;
   vector<float>   *el_massPixeldEdx;
   vector<vector<float> > *el_likelihoodsPixeldEdx;
   vector<float>   *el_eProbabilityComb;
   vector<float>   *el_eProbabilityHT;
   vector<float>   *el_eProbabilityToT;
   vector<float>   *el_eProbabilityBrem;
   vector<float>   *el_vertweight;
   vector<float>   *el_vertx;
   vector<float>   *el_verty;
   vector<float>   *el_vertz;
   vector<float>   *el_trackd0beam;
   vector<float>   *el_trackz0beam;
   vector<float>   *el_tracksigd0beam;
   vector<float>   *el_tracksigz0beam;
   vector<float>   *el_trackd0pv;
   vector<float>   *el_trackz0pv;
   vector<float>   *el_tracksigd0pv;
   vector<float>   *el_tracksigz0pv;
   vector<float>   *el_trackIPEstimate_d0_biasedpvunbiased;
   vector<float>   *el_trackIPEstimate_z0_biasedpvunbiased;
   vector<float>   *el_trackIPEstimate_d0_unbiasedpvunbiased;
   vector<float>   *el_trackIPEstimate_z0_unbiasedpvunbiased;
   vector<float>   *el_trackIPEstimate_sigd0_biasedpvunbiased;
   vector<float>   *el_trackIPEstimate_sigz0_biasedpvunbiased;
   vector<float>   *el_trackIPEstimate_sigd0_unbiasedpvunbiased;
   vector<float>   *el_trackIPEstimate_sigz0_unbiasedpvunbiased;
   vector<int>     *el_hastrack;
   vector<float>   *el_deltaEmax2;
   vector<float>   *el_calibHitsShowerDepth;
   vector<unsigned int> *el_isIso;
   vector<float>   *el_mvaptcone20;
   vector<float>   *el_mvaptcone30;
   vector<float>   *el_mvaptcone40;
   vector<float>   *el_jet_dr;
   vector<float>   *el_jet_E;
   vector<float>   *el_jet_pt;
   vector<float>   *el_jet_m;
   vector<float>   *el_jet_eta;
   vector<float>   *el_jet_phi;
   vector<int>     *el_jet_matched;
   vector<float>   *el_Etcone40_ED_corrected;
   vector<float>   *el_Etcone40_corrected;
   vector<float>   *el_Etcone35_ED_corrected;
   vector<float>   *el_Etcone35_corrected;
   vector<float>   *el_Etcone30_ED_corrected;
   vector<float>   *el_Etcone30_corrected;
   vector<float>   *el_Etcone25_ED_corrected;
   vector<float>   *el_Etcone25_corrected;
   vector<float>   *el_Etcone20_ED_corrected;
   vector<float>   *el_Etcone20_corrected;
   vector<float>   *el_Etcone15_ED_corrected;
   vector<float>   *el_Etcone15_corrected;
   vector<float>   *el_EF_dr;
   vector<int>     *el_EF_index;
   vector<float>   *el_L2_dr;
   vector<int>     *el_L2_index;
   vector<float>   *el_L1_dr;
   vector<int>     *el_L1_index;
   Bool_t          EF_2b10_medium_4L1J10;
   Bool_t          EF_2b10_medium_4j30_a4tc_EFFS;
   Bool_t          EF_2b10_medium_L1JE100;
   Bool_t          EF_2b10_medium_L1JE140;
   Bool_t          EF_2b10_medium_L1_2J10J50;
   Bool_t          EF_2b10_medium_j75_j30_a4tc_EFFS;
   Bool_t          EF_2b15_medium_3L1J15;
   Bool_t          EF_2b20_medium_3L1J20;
   Bool_t          EF_2e10_medium;
   Bool_t          EF_2e10_medium_mu6;
   Bool_t          EF_2e12T_medium;
   Bool_t          EF_2e12_medium;
   Bool_t          EF_2e15_medium;
   Bool_t          EF_2e5_tight;
   Bool_t          EF_2e5_tight_Jpsi;
   Bool_t          EF_2g15_loose;
   Bool_t          EF_2g20_loose;
   Bool_t          EF_2j45_a4tc_EFFS_leadingmct100_xe40_medium_noMu;
   Bool_t          EF_2j55_a4tc_EFFS_leadingmct100_xe40_medium_noMu;
   Bool_t          EF_2mu10;
   Bool_t          EF_2mu10_empty;
   Bool_t          EF_2mu10_loose;
   Bool_t          EF_2mu10_loose_empty;
   Bool_t          EF_2mu10_loose_noOvlpRm;
   Bool_t          EF_2mu13_Zmumu_IDTrkNoCut;
   Bool_t          EF_2mu4;
   Bool_t          EF_2mu4_Bmumu;
   Bool_t          EF_2mu4_Bmumux;
   Bool_t          EF_2mu4_DiMu;
   Bool_t          EF_2mu4_DiMu_DY;
   Bool_t          EF_2mu4_DiMu_DY20;
   Bool_t          EF_2mu4_DiMu_DY_noVtx_noOS;
   Bool_t          EF_2mu4_DiMu_SiTrk;
   Bool_t          EF_2mu4_DiMu_noVtx_noOS;
   Bool_t          EF_2mu4_Jpsimumu;
   Bool_t          EF_2mu4_Jpsimumu_IDTrkNoCut;
   Bool_t          EF_2mu4_Upsimumu;
   Bool_t          EF_2mu4i_DiMu_DY;
   Bool_t          EF_2mu6;
   Bool_t          EF_2mu6_DiMu;
   Bool_t          EF_2mu6_MSonly_g10_loose;
   Bool_t          EF_2mu6_MSonly_g10_loose_nonfilled;
   Bool_t          EF_2mu6_NL;
   Bool_t          EF_2tau29T_medium1;
   Bool_t          EF_2tau29_medium1;
   Bool_t          EF_3b10_loose_4L1J10;
   Bool_t          EF_3b15_loose_4L1J15;
   Bool_t          EF_4j30_a4tc_EFFS;
   Bool_t          EF_b10_EFj10_a4tc_EFFS_IDTrkNoCut;
   Bool_t          EF_b10_IDTrkNoCut;
   Bool_t          EF_b10_medium_4j30_a4tc_EFFS;
   Bool_t          EF_b10_medium_EFxe25_noMu_L1JE140;
   Bool_t          EF_b10_tight_4L1J10;
   Bool_t          EF_b10_tight_L1JE140;
   Bool_t          EF_e10_medium;
   Bool_t          EF_e10_medium_2mu6;
   Bool_t          EF_e10_medium_mu10;
   Bool_t          EF_e10_medium_mu6;
   Bool_t          EF_e10_medium_mu6_topo_medium;
   Bool_t          EF_e11T_medium;
   Bool_t          EF_e11T_medium_2e6T_medium;
   Bool_t          EF_e11_etcut;
   Bool_t          EF_e12T_medium_mu6_topo_medium;
   Bool_t          EF_e12_medium;
   Bool_t          EF_e13_etcut_xs60_noMu;
   Bool_t          EF_e13_etcut_xs60_noMu_dphi2j10xe07;
   Bool_t          EF_e13_etcut_xs70_noMu;
   Bool_t          EF_e15_HLTtighter;
   Bool_t          EF_e15_medium;
   Bool_t          EF_e15_medium_e12_medium;
   Bool_t          EF_e15_medium_xe30_noMu;
   Bool_t          EF_e15_medium_xe40_noMu;
   Bool_t          EF_e15_medium_xe50_noMu;
   Bool_t          EF_e15_tight;
   Bool_t          EF_e20_etcut_xs60_noMu;
   Bool_t          EF_e20_etcut_xs60_noMu_dphi2j10xe07;
   Bool_t          EF_e20_loose;
   Bool_t          EF_e20_loose1;
   Bool_t          EF_e20_looseTrk;
   Bool_t          EF_e20_medium;
   Bool_t          EF_e20_medium1;
   Bool_t          EF_e20_medium2;
   Bool_t          EF_e20_medium_IDTrkNoCut;
   Bool_t          EF_e20_medium_SiTrk;
   Bool_t          EF_e20_medium_TRT;
   Bool_t          EF_e20_tight_e15_NoCut_Zee;
   Bool_t          EF_e22_etcut_xs60_noMu;
   Bool_t          EF_e22_etcut_xs60_noMu_dphi2j10xe07;
   Bool_t          EF_e22_loose;
   Bool_t          EF_e22_loose1;
   Bool_t          EF_e22_looseTrk;
   Bool_t          EF_e22_medium;
   Bool_t          EF_e22_medium1;
   Bool_t          EF_e22_medium2;
   Bool_t          EF_e22_medium_IDTrkNoCut;
   Bool_t          EF_e22_medium_SiTrk;
   Bool_t          EF_e22_medium_TRT;
   Bool_t          EF_e33_medium;
   Bool_t          EF_e35_medium;
   Bool_t          EF_e40_medium;
   Bool_t          EF_e45_medium;
   Bool_t          EF_e45_medium1;
   Bool_t          EF_e5_medium_mu6;
   Bool_t          EF_e5_medium_mu6_topo_medium;
   Bool_t          EF_e5_tight;
   Bool_t          EF_e5_tight_e14_etcut_Jpsi;
   Bool_t          EF_e5_tight_e4_etcut_Jpsi;
   Bool_t          EF_e5_tight_e4_etcut_Jpsi_SiTrk;
   Bool_t          EF_e5_tight_e4_etcut_Jpsi_TRT;
   Bool_t          EF_e5_tight_e5_NoCut;
   Bool_t          EF_e5_tight_e9_etcut_Jpsi;
   Bool_t          EF_e60_loose;
   Bool_t          EF_e6T_medium;
   Bool_t          EF_e7_tight_e14_etcut_Jpsi;
   Bool_t          EF_e9_tight_e5_tight_Jpsi;
   Bool_t          EF_eb_physics;
   Bool_t          EF_eb_physics_empty;
   Bool_t          EF_eb_physics_firstempty;
   Bool_t          EF_eb_physics_noL1PS;
   Bool_t          EF_eb_physics_unpaired_iso;
   Bool_t          EF_eb_physics_unpaired_noniso;
   Bool_t          EF_eb_random;
   Bool_t          EF_eb_random_empty;
   Bool_t          EF_eb_random_firstempty;
   Bool_t          EF_eb_random_unpaired_iso;
   Bool_t          EF_g100_etcut_g50_etcut;
   Bool_t          EF_g10_NoCut_cosmic;
   Bool_t          EF_g11_etcut;
   Bool_t          EF_g11_etcut_larcalib;
   Bool_t          EF_g150_etcut;
   Bool_t          EF_g15_loose;
   Bool_t          EF_g15_loose_larcalib;
   Bool_t          EF_g20_etcut;
   Bool_t          EF_g20_etcut_xe30_noMu;
   Bool_t          EF_g20_loose;
   Bool_t          EF_g20_loose_larcalib;
   Bool_t          EF_g40_loose;
   Bool_t          EF_g40_loose_EFxe40_noMu;
   Bool_t          EF_g40_loose_larcalib;
   Bool_t          EF_g40_loose_xe45_medium_noMu;
   Bool_t          EF_g40_loose_xe55_medium_noMu;
   Bool_t          EF_g40_tight;
   Bool_t          EF_g40_tight_b10_medium;
   Bool_t          EF_g5_NoCut_cosmic;
   Bool_t          EF_g60_loose;
   Bool_t          EF_g60_loose_larcalib;
   Bool_t          EF_g80_loose;
   Bool_t          EF_g80_loose_larcalib;
   Bool_t          EF_j100_a4tc_EFFS;
   Bool_t          EF_j100_a4tc_EFFS_ht350;
   Bool_t          EF_j100_a4tc_EFFS_ht400;
   Bool_t          EF_j100_a4tc_EFFS_ht500;
   Bool_t          EF_j10_a4tc_EFFS;
   Bool_t          EF_j10_a4tc_EFFS_1vx;
   Bool_t          EF_j135_a4tc_EFFS;
   Bool_t          EF_j135_a4tc_EFFS_ht500;
   Bool_t          EF_j135_j30_a4tc_EFFS_dphi04;
   Bool_t          EF_j15_a4tc_EFFS;
   Bool_t          EF_j180_a4tc_EFFS;
   Bool_t          EF_j180_j30_a4tc_EFFS_dphi04;
   Bool_t          EF_j20_a4tc_EFFS;
   Bool_t          EF_j240_a10tc_EFFS;
   Bool_t          EF_j240_a4tc_EFFS;
   Bool_t          EF_j240_a4tc_EFFS_l2cleanph;
   Bool_t          EF_j30_a4tc_EFFS;
   Bool_t          EF_j30_a4tc_EFFS_l2cleanph;
   Bool_t          EF_j30_eta13_a4tc_EFFS_EFxe30_noMu_empty;
   Bool_t          EF_j30_eta13_a4tc_EFFS_EFxe30_noMu_firstempty;
   Bool_t          EF_j30_fj30_a4tc_EFFS;
   Bool_t          EF_j320_a10tc_EFFS;
   Bool_t          EF_j320_a4tc_EFFS;
   Bool_t          EF_j35_a4tc_EFFS_L1TAU_HVtrk;
   Bool_t          EF_j35_a4tc_EFFS_L1TAU_HVtrk_cosmic;
   Bool_t          EF_j35_a4tc_EFFS_L1TAU_HVtrk_firstempty;
   Bool_t          EF_j35_a4tc_EFFS_L1TAU_HVtrk_unpaired_iso;
   Bool_t          EF_j35_a4tc_EFFS_L1TAU_HVtrk_unpaired_noniso;
   Bool_t          EF_j40_a4tc_EFFS;
   Bool_t          EF_j40_fj40_a4tc_EFFS;
   Bool_t          EF_j425_a10tc_EFFS;
   Bool_t          EF_j425_a4tc_EFFS;
   Bool_t          EF_j50_eta13_a4tc_EFFS_EFxe50_noMu_empty;
   Bool_t          EF_j50_eta13_a4tc_EFFS_EFxe50_noMu_firstempty;
   Bool_t          EF_j50_eta25_a4tc_EFFS_EFxe50_noMu_empty;
   Bool_t          EF_j50_eta25_a4tc_EFFS_EFxe50_noMu_firstempty;
   Bool_t          EF_j55_a4tc_EFFS;
   Bool_t          EF_j55_a4tc_EFFS_xe55_medium_noMu_dphi2j30xe10;
   Bool_t          EF_j55_a4tc_EFFS_xe55_medium_noMu_dphi2j30xe10_l2cleancons;
   Bool_t          EF_j55_fj55_a4tc_EFFS;
   Bool_t          EF_j65_a4tc_EFFS_xe65_noMu_dphi2j30xe10;
   Bool_t          EF_j75_2j30_a4tc_EFFS_ht350;
   Bool_t          EF_j75_a4tc_EFFS;
   Bool_t          EF_j75_a4tc_EFFS_xe40_loose_noMu;
   Bool_t          EF_j75_a4tc_EFFS_xe45_loose_noMu;
   Bool_t          EF_j75_a4tc_EFFS_xe55_loose_noMu;
   Bool_t          EF_j75_a4tc_EFFS_xe55_noMu;
   Bool_t          EF_j75_a4tc_EFFS_xe55_noMu_l2cleancons;
   Bool_t          EF_j75_fj75_a4tc_EFFS;
   Bool_t          EF_j75_j30_a4tc_EFFS_anymct150;
   Bool_t          EF_j75_j30_a4tc_EFFS_anymct175;
   Bool_t          EF_j80_a4tc_EFFS_xe60_noMu;
   Bool_t          EF_mu0_empty_NoAlg;
   Bool_t          EF_mu0_firstempty_NoAlg;
   Bool_t          EF_mu0_unpaired_iso_NoAlg;
   Bool_t          EF_mu10;
   Bool_t          EF_mu10_Jpsimumu;
   Bool_t          EF_mu10_NL;
   Bool_t          EF_mu10_Upsimumu_FS;
   Bool_t          EF_mu10_Upsimumu_tight_FS;
   Bool_t          EF_mu10_loose;
   Bool_t          EF_mu10_muCombTag_NoEF;
   Bool_t          EF_mu11_empty_NoAlg;
   Bool_t          EF_mu13;
   Bool_t          EF_mu13_MG;
   Bool_t          EF_mu13_muCombTag_NoEF;
   Bool_t          EF_mu15;
   Bool_t          EF_mu15_mu10_EFFS;
   Bool_t          EF_mu15_mu10_EFFS_medium;
   Bool_t          EF_mu15_mu10_EFFS_tight;
   Bool_t          EF_mu15_xe30_noMu;
   Bool_t          EF_mu15i;
   Bool_t          EF_mu15i_medium;
   Bool_t          EF_mu18;
   Bool_t          EF_mu18_L1J10;
   Bool_t          EF_mu18_MG;
   Bool_t          EF_mu18_MG_L1J10;
   Bool_t          EF_mu18_MG_medium;
   Bool_t          EF_mu18_medium;
   Bool_t          EF_mu20;
   Bool_t          EF_mu20_IDTrkNoCut;
   Bool_t          EF_mu20_IDTrkNoCut_ManyVx;
   Bool_t          EF_mu20_MG;
   Bool_t          EF_mu20_MG_medium;
   Bool_t          EF_mu20_empty;
   Bool_t          EF_mu20_medium;
   Bool_t          EF_mu20_mu10_EFFS_tight;
   Bool_t          EF_mu20_muCombTag_NoEF;
   Bool_t          EF_mu20i;
   Bool_t          EF_mu20i_medium;
   Bool_t          EF_mu22;
   Bool_t          EF_mu22_MG;
   Bool_t          EF_mu22_MG_medium;
   Bool_t          EF_mu22_medium;
   Bool_t          EF_mu24_MG_medium;
   Bool_t          EF_mu24_MG_tight;
   Bool_t          EF_mu24_medium;
   Bool_t          EF_mu24_tight;
   Bool_t          EF_mu30_MG_medium;
   Bool_t          EF_mu30_MG_tight;
   Bool_t          EF_mu30_medium;
   Bool_t          EF_mu30_tight;
   Bool_t          EF_mu4;
   Bool_t          EF_mu40_MSonly_barrel;
   Bool_t          EF_mu40_MSonly_barrel_medium;
   Bool_t          EF_mu40_MSonly_empty;
   Bool_t          EF_mu40_MSonly_tight;
   Bool_t          EF_mu40_MSonly_tight_L1MU11;
   Bool_t          EF_mu40_MSonly_tighter;
   Bool_t          EF_mu40_slow;
   Bool_t          EF_mu40_slow_empty;
   Bool_t          EF_mu40_slow_medium;
   Bool_t          EF_mu40_slow_outOfTime;
   Bool_t          EF_mu40_slow_outOfTime_medium;
   Bool_t          EF_mu4_DiMu;
   Bool_t          EF_mu4_DiMu_FS_noOS;
   Bool_t          EF_mu4_Jpsimumu;
   Bool_t          EF_mu4_L1J10_matched;
   Bool_t          EF_mu4_L1J15_matched;
   Bool_t          EF_mu4_L1J20_matched;
   Bool_t          EF_mu4_L1J30_matched;
   Bool_t          EF_mu4_L1J50_matched;
   Bool_t          EF_mu4_L1J75_matched;
   Bool_t          EF_mu4_L1MU11_MSonly_cosmic;
   Bool_t          EF_mu4_L1MU11_cosmic;
   Bool_t          EF_mu4_MSonly_cosmic;
   Bool_t          EF_mu4_Trk_Jpsi;
   Bool_t          EF_mu4_Trk_Upsi_FS;
   Bool_t          EF_mu4_Upsimumu_FS;
   Bool_t          EF_mu4_Upsimumu_SiTrk_FS;
   Bool_t          EF_mu4_Upsimumu_tight_FS;
   Bool_t          EF_mu4_cosmic;
   Bool_t          EF_mu4_j10_a4tc_EFFS;
   Bool_t          EF_mu4_j10_a4tc_EFFS_matched;
   Bool_t          EF_mu4_j135_a4tc_EFFS_L1matched;
   Bool_t          EF_mu4_j180_a4tc_EFFS_L1matched;
   Bool_t          EF_mu4_j45_a4tc_EFFS_xe45_loose_noMu;
   Bool_t          EF_mu4imu6i_DiMu_DY;
   Bool_t          EF_mu4imu6i_DiMu_DY14_noVtx_noOS;
   Bool_t          EF_mu4mu6_Bmumu;
   Bool_t          EF_mu4mu6_Bmumux;
   Bool_t          EF_mu4mu6_DiMu;
   Bool_t          EF_mu4mu6_DiMu_DY20;
   Bool_t          EF_mu4mu6_DiMu_noVtx_noOS;
   Bool_t          EF_mu4mu6_Jpsimumu;
   Bool_t          EF_mu4mu6_Upsimumu;
   Bool_t          EF_mu6;
   Bool_t          EF_mu6_DiMu_noOS;
   Bool_t          EF_mu6_Jpsimumu;
   Bool_t          EF_mu6_Jpsimumu_SiTrk;
   Bool_t          EF_mu6_Jpsimumu_tight;
   Bool_t          EF_mu6_Trk_Jpsi_loose;
   Bool_t          EF_tau100_medium;
   Bool_t          EF_tau125_medium;
   Bool_t          EF_tau125_medium1;
   Bool_t          EF_tau16_IDTrkNoCut;
   Bool_t          EF_tau16_loose;
   Bool_t          EF_tau16_loose_e15_medium;
   Bool_t          EF_tau16_loose_mu10;
   Bool_t          EF_tau16_loose_mu15;
   Bool_t          EF_tau16_medium;
   Bool_t          EF_tau16_medium_mu10;
   Bool_t          EF_tau20T_medium;
   Bool_t          EF_tau20T_medium_e15_medium;
   Bool_t          EF_tau20T_medium_mu15;
   Bool_t          EF_tau20_medium;
   Bool_t          EF_tau20_medium1;
   Bool_t          EF_tau20_medium_e15_medium;
   Bool_t          EF_tau20_medium_mu15;
   Bool_t          EF_tau29T_medium;
   Bool_t          EF_tau29T_medium1_tau20T_medium1;
   Bool_t          EF_tau29T_medium1_xs45_loose_noMu_3L1J10;
   Bool_t          EF_tau29T_medium_xs75_loose_noMu;
   Bool_t          EF_tau29T_medium_xs75_noMu;
   Bool_t          EF_tau29_loose;
   Bool_t          EF_tau29_loose1;
   Bool_t          EF_tau29_loose1_xs45_loose_noMu_3L1J10;
   Bool_t          EF_tau29_loose_xs45_loose_noMu_3L1J10;
   Bool_t          EF_tau29_loose_xs70_loose_noMu;
   Bool_t          EF_tau29_loose_xs80_loose_noMu;
   Bool_t          EF_tau29_medium;
   Bool_t          EF_tau29_medium1;
   Bool_t          EF_tau29_medium1_tau20_medium1;
   Bool_t          EF_tau29_medium1_xs45_loose_noMu_3L1J10;
   Bool_t          EF_tau29_medium_xe35_noMu;
   Bool_t          EF_tau29_medium_xe40_loose_noMu;
   Bool_t          EF_tau29_medium_xs70_noMu;
   Bool_t          EF_tau29_medium_xs75_noMu;
   Bool_t          EF_tau50_IDTrkNoCut;
   Bool_t          EF_tau50_medium;
   Bool_t          EF_tau84_loose;
   Bool_t          EF_tauNoCut;
   Bool_t          EF_tauNoCut_L1TAU50;
   Bool_t          EF_tauNoCut_cosmic;
   Bool_t          EF_xe20_noMu;
   Bool_t          EF_xe30_noMu;
   Bool_t          EF_xe40_noMu;
   Bool_t          EF_xe50_noMu;
   Bool_t          EF_xe60_noMu;
   Bool_t          EF_xe60_tight_noMu;
   Bool_t          EF_xe60_verytight_noMu;
   Bool_t          EF_xe70_noMu;
   Bool_t          EF_xe70_tight_noMu;
   Bool_t          EF_xe80_noMu;
   Bool_t          EF_xe90_noMu;
   Bool_t          L1_2EM10;
   Bool_t          L1_2EM14;
   Bool_t          L1_2EM3;
   Bool_t          L1_2EM3_EM12;
   Bool_t          L1_2EM3_EM7;
   Bool_t          L1_2EM5;
   Bool_t          L1_2EM5_EM10;
   Bool_t          L1_2EM5_MU6;
   Bool_t          L1_2EM5_NL;
   Bool_t          L1_2EM7;
   Bool_t          L1_2EM7_EM10;
   Bool_t          L1_2J20_XE20;
   Bool_t          L1_2J30_XE20;
   Bool_t          L1_2MU0;
   Bool_t          L1_2MU0_EMPTY;
   Bool_t          L1_2MU0_FIRSTEMPTY;
   Bool_t          L1_2MU0_MU6;
   Bool_t          L1_2MU10;
   Bool_t          L1_2MU6;
   Bool_t          L1_2MU6_EMPTY;
   Bool_t          L1_2MU6_FIRSTEMPTY;
   Bool_t          L1_2MU6_NL;
   Bool_t          L1_2MU6_UNPAIRED_ISO;
   Bool_t          L1_2MU6_UNPAIRED_NONISO;
   Bool_t          L1_2TAU11;
   Bool_t          L1_2TAU11_EM10;
   Bool_t          L1_2TAU11_TAU15;
   Bool_t          L1_2TAU15;
   Bool_t          L1_2TAU15_TAU20;
   Bool_t          L1_2TAU6;
   Bool_t          L1_2TAU6_EM10;
   Bool_t          L1_2TAU8_EM10;
   Bool_t          L1_2TAU8_TAU11;
   Bool_t          L1_EM10;
   Bool_t          L1_EM10_MU6;
   Bool_t          L1_EM10_XE20;
   Bool_t          L1_EM10_XE30;
   Bool_t          L1_EM10_XS45;
   Bool_t          L1_EM10_XS50;
   Bool_t          L1_EM12;
   Bool_t          L1_EM14;
   Bool_t          L1_EM14_XE10;
   Bool_t          L1_EM14_XE20;
   Bool_t          L1_EM16;
   Bool_t          L1_EM3;
   Bool_t          L1_EM30;
   Bool_t          L1_EM3_EMPTY;
   Bool_t          L1_EM3_FIRSTEMPTY;
   Bool_t          L1_EM3_MU0;
   Bool_t          L1_EM3_MU6;
   Bool_t          L1_EM3_UNPAIRED_ISO;
   Bool_t          L1_EM3_UNPAIRED_NONISO;
   Bool_t          L1_EM5;
   Bool_t          L1_EM5_2MU6;
   Bool_t          L1_EM5_EMPTY;
   Bool_t          L1_EM5_MU10;
   Bool_t          L1_EM5_MU6;
   Bool_t          L1_EM7;
   Bool_t          L1_J30_XE35;
   Bool_t          L1_J30_XE40;
   Bool_t          L1_J50_XE20;
   Bool_t          L1_J50_XE30;
   Bool_t          L1_J50_XE35;
   Bool_t          L1_MU0;
   Bool_t          L1_MU0_EMPTY;
   Bool_t          L1_MU0_FIRSTEMPTY;
   Bool_t          L1_MU0_J10;
   Bool_t          L1_MU0_J15;
   Bool_t          L1_MU0_J15_EMPTY;
   Bool_t          L1_MU0_J15_FIRSTEMPTY;
   Bool_t          L1_MU0_J15_UNPAIRED_ISO;
   Bool_t          L1_MU0_J15_UNPAIRED_NONISO;
   Bool_t          L1_MU0_J20_XE20;
   Bool_t          L1_MU0_J30;
   Bool_t          L1_MU0_J50;
   Bool_t          L1_MU0_J75;
   Bool_t          L1_MU0_UNPAIRED_ISO;
   Bool_t          L1_MU0_UNPAIRED_NONISO;
   Bool_t          L1_MU10;
   Bool_t          L1_MU10_EMPTY;
   Bool_t          L1_MU10_FIRSTEMPTY;
   Bool_t          L1_MU10_J10;
   Bool_t          L1_MU10_UNPAIRED_ISO;
   Bool_t          L1_MU10_XE20;
   Bool_t          L1_MU11;
   Bool_t          L1_MU11_EMPTY;
   Bool_t          L1_MU15;
   Bool_t          L1_MU20;
   Bool_t          L1_MU20_FIRSTEMPTY;
   Bool_t          L1_MU6;
   Bool_t          L1_MU6_FIRSTEMPTY;
   Bool_t          L1_MU6_NL;
   Bool_t          L1_TAU11;
   Bool_t          L1_TAU11_2J10_J20_XE20;
   Bool_t          L1_TAU11_MU10;
   Bool_t          L1_TAU11_XE10_3J10;
   Bool_t          L1_TAU11_XE20;
   Bool_t          L1_TAU11_XS30;
   Bool_t          L1_TAU11_XS35;
   Bool_t          L1_TAU15;
   Bool_t          L1_TAU15_XE10_3J10;
   Bool_t          L1_TAU15_XE20;
   Bool_t          L1_TAU15_XS35;
   Bool_t          L1_TAU20;
   Bool_t          L1_TAU30;
   Bool_t          L1_TAU50;
   Bool_t          L1_TAU6;
   Bool_t          L1_TAU6_J50_XE20;
   Bool_t          L1_TAU6_MU10;
   Bool_t          L1_TAU6_XE10;
   Bool_t          L1_TAU8;
   Bool_t          L1_TAU8_EMPTY;
   Bool_t          L1_TAU8_FIRSTEMPTY;
   Bool_t          L1_TAU8_MU10;
   Bool_t          L1_TAU8_UNPAIRED_ISO;
   Bool_t          L1_TAU8_UNPAIRED_NONISO;
   Bool_t          L1_XE10;
   Bool_t          L1_XE20;
   Bool_t          L1_XE25;
   Bool_t          L1_XE30;
   Bool_t          L1_XE35;
   Bool_t          L1_XE40;
   Bool_t          L1_XE50;
   Bool_t          L1_XE60;
   Bool_t          L2_2b10_medium_4L1J10;
   Bool_t          L2_2b10_medium_4j25;
   Bool_t          L2_2b10_medium_L1JE100;
   Bool_t          L2_2b10_medium_L1JE140;
   Bool_t          L2_2b10_medium_L1_2J10J50;
   Bool_t          L2_2b10_medium_j70_j25;
   Bool_t          L2_2b15_medium_3L1J15;
   Bool_t          L2_2b20_medium_3L1J20;
   Bool_t          L2_2e10_medium;
   Bool_t          L2_2e10_medium_mu6;
   Bool_t          L2_2e12T_medium;
   Bool_t          L2_2e12_medium;
   Bool_t          L2_2e15_medium;
   Bool_t          L2_2e5_tight;
   Bool_t          L2_2e5_tight_Jpsi;
   Bool_t          L2_2g15_loose;
   Bool_t          L2_2g20_loose;
   Bool_t          L2_2j40_anymct100_xe20_medium_noMu;
   Bool_t          L2_2j50_anymct100_xe20_medium_noMu;
   Bool_t          L2_2mu10;
   Bool_t          L2_2mu10_empty;
   Bool_t          L2_2mu10_loose;
   Bool_t          L2_2mu10_loose_empty;
   Bool_t          L2_2mu10_loose_noOvlpRm;
   Bool_t          L2_2mu13_Zmumu_IDTrkNoCut;
   Bool_t          L2_2mu4;
   Bool_t          L2_2mu4_Bmumu;
   Bool_t          L2_2mu4_Bmumux;
   Bool_t          L2_2mu4_DiMu;
   Bool_t          L2_2mu4_DiMu_DY;
   Bool_t          L2_2mu4_DiMu_DY20;
   Bool_t          L2_2mu4_DiMu_DY_noVtx_noOS;
   Bool_t          L2_2mu4_DiMu_SiTrk;
   Bool_t          L2_2mu4_DiMu_noVtx_noOS;
   Bool_t          L2_2mu4_Jpsimumu;
   Bool_t          L2_2mu4_Jpsimumu_IDTrkNoCut;
   Bool_t          L2_2mu4_Upsimumu;
   Bool_t          L2_2mu4i_DiMu_DY;
   Bool_t          L2_2mu6;
   Bool_t          L2_2mu6_DiMu;
   Bool_t          L2_2mu6_MSonly_g10_loose;
   Bool_t          L2_2mu6_MSonly_g10_loose_nonfilled;
   Bool_t          L2_2mu6_NL;
   Bool_t          L2_2tau29T_medium1;
   Bool_t          L2_2tau29_medium1;
   Bool_t          L2_3b10_loose_4L1J10;
   Bool_t          L2_3b15_loose_4L1J15;
   Bool_t          L2_b10_IDTrkNoCut;
   Bool_t          L2_b10_medium_4j25;
   Bool_t          L2_b10_medium_EFxe25_noMu_L1JE140;
   Bool_t          L2_b10_tight_4L1J10;
   Bool_t          L2_b10_tight_L1JE140;
   Bool_t          L2_e10_medium;
   Bool_t          L2_e10_medium_2mu6;
   Bool_t          L2_e10_medium_mu10;
   Bool_t          L2_e10_medium_mu6;
   Bool_t          L2_e10_medium_mu6_topo_medium;
   Bool_t          L2_e11T_medium;
   Bool_t          L2_e11T_medium_2e6T_medium;
   Bool_t          L2_e11_etcut;
   Bool_t          L2_e12T_medium_mu6_topo_medium;
   Bool_t          L2_e12_medium;
   Bool_t          L2_e13_etcut_xs45_noMu;
   Bool_t          L2_e15_HLTtighter;
   Bool_t          L2_e15_medium;
   Bool_t          L2_e15_medium_e12_medium;
   Bool_t          L2_e15_medium_xe20_noMu;
   Bool_t          L2_e15_medium_xe30_noMu;
   Bool_t          L2_e15_medium_xe35_noMu;
   Bool_t          L2_e15_tight;
   Bool_t          L2_e20_etcut_xs45_noMu;
   Bool_t          L2_e20_loose;
   Bool_t          L2_e20_loose1;
   Bool_t          L2_e20_looseTrk;
   Bool_t          L2_e20_medium;
   Bool_t          L2_e20_medium1;
   Bool_t          L2_e20_medium2;
   Bool_t          L2_e20_medium_IDTrkNoCut;
   Bool_t          L2_e20_medium_SiTrk;
   Bool_t          L2_e20_medium_TRT;
   Bool_t          L2_e20_tight_e15_NoCut_Zee;
   Bool_t          L2_e22_etcut_xs45_noMu;
   Bool_t          L2_e22_loose;
   Bool_t          L2_e22_loose1;
   Bool_t          L2_e22_looseTrk;
   Bool_t          L2_e22_medium;
   Bool_t          L2_e22_medium1;
   Bool_t          L2_e22_medium2;
   Bool_t          L2_e22_medium_IDTrkNoCut;
   Bool_t          L2_e22_medium_SiTrk;
   Bool_t          L2_e22_medium_TRT;
   Bool_t          L2_e33_medium;
   Bool_t          L2_e35_medium;
   Bool_t          L2_e40_medium;
   Bool_t          L2_e45_medium;
   Bool_t          L2_e45_medium1;
   Bool_t          L2_e5_medium_mu6;
   Bool_t          L2_e5_medium_mu6_topo_medium;
   Bool_t          L2_e5_tight;
   Bool_t          L2_e5_tight_e14_etcut_Jpsi;
   Bool_t          L2_e5_tight_e4_etcut_Jpsi;
   Bool_t          L2_e5_tight_e4_etcut_Jpsi_SiTrk;
   Bool_t          L2_e5_tight_e4_etcut_Jpsi_TRT;
   Bool_t          L2_e5_tight_e5_NoCut;
   Bool_t          L2_e5_tight_e9_etcut_Jpsi;
   Bool_t          L2_e60_loose;
   Bool_t          L2_e6T_medium;
   Bool_t          L2_e7_tight_e14_etcut_Jpsi;
   Bool_t          L2_e9_tight_e5_tight_Jpsi;
   Bool_t          L2_eb_physics;
   Bool_t          L2_eb_physics_empty;
   Bool_t          L2_eb_physics_firstempty;
   Bool_t          L2_eb_physics_noL1PS;
   Bool_t          L2_eb_physics_unpaired_iso;
   Bool_t          L2_eb_physics_unpaired_noniso;
   Bool_t          L2_eb_random;
   Bool_t          L2_eb_random_empty;
   Bool_t          L2_eb_random_firstempty;
   Bool_t          L2_eb_random_unpaired_iso;
   Bool_t          L2_em3_empty_larcalib;
   Bool_t          L2_em5_empty_larcalib;
   Bool_t          L2_g100_etcut_g50_etcut;
   Bool_t          L2_g10_NoCut_cosmic;
   Bool_t          L2_g11_etcut;
   Bool_t          L2_g150_etcut;
   Bool_t          L2_g15_loose;
   Bool_t          L2_g20_etcut;
   Bool_t          L2_g20_etcut_xe30_noMu;
   Bool_t          L2_g20_loose;
   Bool_t          L2_g40_loose;
   Bool_t          L2_g40_loose_EFxe40_noMu;
   Bool_t          L2_g40_loose_xe30_medium_noMu;
   Bool_t          L2_g40_loose_xe35_medium_noMu;
   Bool_t          L2_g40_tight;
   Bool_t          L2_g40_tight_b10_medium;
   Bool_t          L2_g5_NoCut_cosmic;
   Bool_t          L2_g60_loose;
   Bool_t          L2_g80_loose;
   Bool_t          L2_j50_xe35_medium_noMu;
   Bool_t          L2_j50_xe35_medium_noMu_l2cleancons;
   Bool_t          L2_j60_xe45_noMu;
   Bool_t          L2_j70_xe20_loose_noMu;
   Bool_t          L2_j70_xe25_loose_noMu;
   Bool_t          L2_j70_xe35_noMu;
   Bool_t          L2_j70_xe35_noMu_l2cleancons;
   Bool_t          L2_j75_xe40_noMu;
   Bool_t          L2_mu0_cal_empty;
   Bool_t          L2_mu0_empty_NoAlg;
   Bool_t          L2_mu0_firstempty_NoAlg;
   Bool_t          L2_mu0_unpaired_iso_NoAlg;
   Bool_t          L2_mu10;
   Bool_t          L2_mu10_Jpsimumu;
   Bool_t          L2_mu10_NL;
   Bool_t          L2_mu10_Upsimumu_FS;
   Bool_t          L2_mu10_Upsimumu_tight_FS;
   Bool_t          L2_mu10_cal;
   Bool_t          L2_mu10_cal_medium;
   Bool_t          L2_mu10_loose;
   Bool_t          L2_mu10_muCombTag_NoEF;
   Bool_t          L2_mu11_empty_NoAlg;
   Bool_t          L2_mu13;
   Bool_t          L2_mu13_MG;
   Bool_t          L2_mu13_muCombTag_NoEF;
   Bool_t          L2_mu15;
   Bool_t          L2_mu15_medium;
   Bool_t          L2_mu15_tight;
   Bool_t          L2_mu15_xe20_noMu;
   Bool_t          L2_mu15i;
   Bool_t          L2_mu15i_medium;
   Bool_t          L2_mu18;
   Bool_t          L2_mu18_L1J10;
   Bool_t          L2_mu18_MG;
   Bool_t          L2_mu18_MG_L1J10;
   Bool_t          L2_mu18_MG_medium;
   Bool_t          L2_mu18_medium;
   Bool_t          L2_mu20;
   Bool_t          L2_mu20_IDTrkNoCut;
   Bool_t          L2_mu20_MG;
   Bool_t          L2_mu20_MG_medium;
   Bool_t          L2_mu20_empty;
   Bool_t          L2_mu20_medium;
   Bool_t          L2_mu20_muCombTag_NoEF;
   Bool_t          L2_mu20_tight;
   Bool_t          L2_mu20i;
   Bool_t          L2_mu20i_medium;
   Bool_t          L2_mu22;
   Bool_t          L2_mu22_MG;
   Bool_t          L2_mu22_MG_medium;
   Bool_t          L2_mu22_medium;
   Bool_t          L2_mu24_MG_medium;
   Bool_t          L2_mu24_MG_tight;
   Bool_t          L2_mu24_medium;
   Bool_t          L2_mu24_tight;
   Bool_t          L2_mu30_MG_medium;
   Bool_t          L2_mu30_MG_tight;
   Bool_t          L2_mu30_medium;
   Bool_t          L2_mu30_tight;
   Bool_t          L2_mu4;
   Bool_t          L2_mu40_MSonly_barrel;
   Bool_t          L2_mu40_MSonly_barrel_medium;
   Bool_t          L2_mu40_MSonly_empty;
   Bool_t          L2_mu40_MSonly_tight;
   Bool_t          L2_mu40_MSonly_tight_L1MU11;
   Bool_t          L2_mu40_MSonly_tighter;
   Bool_t          L2_mu40_slow;
   Bool_t          L2_mu40_slow_empty;
   Bool_t          L2_mu40_slow_medium;
   Bool_t          L2_mu40_slow_outOfTime;
   Bool_t          L2_mu40_slow_outOfTime_medium;
   Bool_t          L2_mu4_DiMu;
   Bool_t          L2_mu4_DiMu_FS_noOS;
   Bool_t          L2_mu4_Jpsimumu;
   Bool_t          L2_mu4_L1J10_matched;
   Bool_t          L2_mu4_L1J15_matched;
   Bool_t          L2_mu4_L1J20_matched;
   Bool_t          L2_mu4_L1J30_matched;
   Bool_t          L2_mu4_L1J50_matched;
   Bool_t          L2_mu4_L1J75_matched;
   Bool_t          L2_mu4_L1MU11_MSonly_cosmic;
   Bool_t          L2_mu4_L1MU11_cosmic;
   Bool_t          L2_mu4_MSonly_cosmic;
   Bool_t          L2_mu4_Trk_Jpsi;
   Bool_t          L2_mu4_Trk_Upsi_FS;
   Bool_t          L2_mu4_Upsimumu_FS;
   Bool_t          L2_mu4_Upsimumu_SiTrk_FS;
   Bool_t          L2_mu4_Upsimumu_tight_FS;
   Bool_t          L2_mu4_cosmic;
   Bool_t          L2_mu4_j10_a4tc_EFFS;
   Bool_t          L2_mu4_j40_xe20_loose_noMu;
   Bool_t          L2_mu4_j95_L1matched;
   Bool_t          L2_mu4imu6i_DiMu_DY;
   Bool_t          L2_mu4imu6i_DiMu_DY14_noVtx_noOS;
   Bool_t          L2_mu4mu6_Bmumu;
   Bool_t          L2_mu4mu6_Bmumux;
   Bool_t          L2_mu4mu6_DiMu;
   Bool_t          L2_mu4mu6_DiMu_DY20;
   Bool_t          L2_mu4mu6_DiMu_noVtx_noOS;
   Bool_t          L2_mu4mu6_Jpsimumu;
   Bool_t          L2_mu4mu6_Upsimumu;
   Bool_t          L2_mu6;
   Bool_t          L2_mu6_DiMu_noOS;
   Bool_t          L2_mu6_Jpsimumu;
   Bool_t          L2_mu6_Jpsimumu_SiTrk;
   Bool_t          L2_mu6_Jpsimumu_tight;
   Bool_t          L2_mu6_Trk_Jpsi_loose;
   Bool_t          L2_tau100_medium;
   Bool_t          L2_tau125_medium;
   Bool_t          L2_tau125_medium1;
   Bool_t          L2_tau16_IDTrkNoCut;
   Bool_t          L2_tau16_loose;
   Bool_t          L2_tau16_loose_e15_medium;
   Bool_t          L2_tau16_loose_mu10;
   Bool_t          L2_tau16_loose_mu15;
   Bool_t          L2_tau16_medium;
   Bool_t          L2_tau16_medium_mu10;
   Bool_t          L2_tau20T_medium;
   Bool_t          L2_tau20T_medium_e15_medium;
   Bool_t          L2_tau20T_medium_mu15;
   Bool_t          L2_tau20_medium;
   Bool_t          L2_tau20_medium1;
   Bool_t          L2_tau20_medium_e15_medium;
   Bool_t          L2_tau20_medium_mu15;
   Bool_t          L2_tau29T_medium;
   Bool_t          L2_tau29T_medium1_tau20T_medium1;
   Bool_t          L2_tau29T_medium1_xs20_noMu_3L1J10;
   Bool_t          L2_tau29T_medium_xs35_noMu;
   Bool_t          L2_tau29T_medium_xs50_noMu;
   Bool_t          L2_tau29_loose;
   Bool_t          L2_tau29_loose1;
   Bool_t          L2_tau29_loose1_xs20_noMu_3L1J10;
   Bool_t          L2_tau29_loose_xs20_noMu_3L1J10;
   Bool_t          L2_tau29_loose_xs35_noMu;
   Bool_t          L2_tau29_medium;
   Bool_t          L2_tau29_medium1;
   Bool_t          L2_tau29_medium1_tau20_medium1;
   Bool_t          L2_tau29_medium1_xs20_noMu_3L1J10;
   Bool_t          L2_tau29_medium_xe25_noMu;
   Bool_t          L2_tau29_medium_xe30_loose_noMu;
   Bool_t          L2_tau29_medium_xs50_noMu;
   Bool_t          L2_tau50_IDTrkNoCut;
   Bool_t          L2_tau50_medium;
   Bool_t          L2_tau84_loose;
   Bool_t          L2_tau8_empty_larcalib;
   Bool_t          L2_tauNoCut;
   Bool_t          L2_tauNoCut_L1TAU50;
   Bool_t          L2_tauNoCut_cosmic;
   Bool_t          L2_xe10_noMu;
   Bool_t          L2_xe20_noMu;
   Bool_t          L2_xe30_noMu;
   Bool_t          L2_xe35_noMu;
   Bool_t          L2_xe40_noMu;
   Bool_t          L2_xe45_noMu;
   Bool_t          L2_xe50_noMu;
   Bool_t          L2_xe55_noMu;
   Bool_t          L2_xe60_noMu;
   Bool_t          L2_xe70_noMu;
   Int_t           v0_n;
   vector<float>   *v0_ksMass;
   vector<float>   *v0_lambda1Mass;
   vector<float>   *v0_lambda2Mass;
   vector<float>   *v0_vertexProb;
   vector<float>   *v0_vertexChi2;
   vector<float>   *v0_ksPt;
   vector<float>   *v0_ksPx;
   vector<float>   *v0_ksPy;
   vector<float>   *v0_ksEta;
   vector<float>   *v0_ksPhi;
   vector<float>   *v0_ksMomentum;
   vector<float>   *v0_flightX;
   vector<float>   *v0_flightY;
   vector<float>   *v0_cosThetaPointing;
   vector<float>   *v0_totalFlightDistance;
   vector<float>   *v0_properDecayTime;
   vector<float>   *v0_properFlightDist;
   vector<float>   *v0_flightX_BS;
   vector<float>   *v0_flightY_BS;
   vector<float>   *v0_cosThetaPointing_BS;
   vector<float>   *v0_totalFlightDistance_BS;
   vector<float>   *v0_properDecayTime_BS;
   vector<float>   *v0_properFlightDist_BS;
   vector<float>   *v0_radius;
   vector<float>   *v0_thetaPiPlus;
   vector<float>   *v0_thetaPiMinus;
   vector<vector<float> > *v0_trk_L;
   vector<vector<float> > *v0_trk_T;
   vector<float>   *v0_thetaStarPiPlus;
   vector<float>   *v0_thetaStarPiMinus;
   vector<vector<float> > *v0_trkPt_SV;
   vector<vector<float> > *v0_trkEta_SV;
   vector<vector<float> > *v0_trkPhi_SV;
   vector<float>   *v0_x;
   vector<float>   *v0_y;
   vector<float>   *v0_z;
   vector<float>   *v0_err_x;
   vector<float>   *v0_err_y;
   vector<float>   *v0_err_z;
   vector<float>   *v0_cov_xy;
   vector<float>   *v0_cov_xz;
   vector<float>   *v0_cov_yz;
   vector<int>     *v0_type;
   vector<float>   *v0_chi2;
   vector<int>     *v0_ndof;
   vector<float>   *v0_px;
   vector<float>   *v0_py;
   vector<float>   *v0_pz;
   vector<float>   *v0_E;
   vector<float>   *v0_m;
   vector<int>     *v0_nTracks;
   vector<float>   *v0_sumPt;
   vector<int>     *v0_trk_n;
   vector<vector<float> > *v0_trk_weight;
   vector<vector<int> > *v0_trk_index;
   Int_t           ph_n;
   vector<float>   *ph_E;
   vector<float>   *ph_Et;
   vector<float>   *ph_pt;
   vector<float>   *ph_m;
   vector<float>   *ph_eta;
   vector<float>   *ph_phi;
   vector<float>   *ph_px;
   vector<float>   *ph_py;
   vector<float>   *ph_pz;
   vector<int>     *ph_author;
   vector<int>     *ph_isRecovered;
   vector<unsigned int> *ph_isEM;
   vector<unsigned int> *ph_OQ;
   vector<unsigned int> *ph_OQRecalc;
   vector<int>     *ph_convFlag;
   vector<int>     *ph_isConv;
   vector<int>     *ph_nConv;
   vector<int>     *ph_nSingleTrackConv;
   vector<int>     *ph_nDoubleTrackConv;
   vector<int>     *ph_loose;
   vector<int>     *ph_looseIso;
   vector<int>     *ph_tight;
   vector<int>     *ph_tightIso;
   vector<int>     *ph_looseAR;
   vector<int>     *ph_looseARIso;
   vector<int>     *ph_tightAR;
   vector<int>     *ph_tightARIso;
   vector<int>     *ph_goodOQ;
   vector<float>   *ph_Ethad;
   vector<float>   *ph_Ethad1;
   vector<float>   *ph_E033;
   vector<float>   *ph_f1;
   vector<float>   *ph_f1core;
   vector<float>   *ph_Emins1;
   vector<float>   *ph_fside;
   vector<float>   *ph_Emax2;
   vector<float>   *ph_ws3;
   vector<float>   *ph_wstot;
   vector<float>   *ph_E132;
   vector<float>   *ph_E1152;
   vector<float>   *ph_emaxs1;
   vector<float>   *ph_deltaEs;
   vector<float>   *ph_E233;
   vector<float>   *ph_E237;
   vector<float>   *ph_E277;
   vector<float>   *ph_weta2;
   vector<float>   *ph_f3;
   vector<float>   *ph_f3core;
   vector<float>   *ph_rphiallcalo;
   vector<float>   *ph_Etcone45;
   vector<float>   *ph_Etcone15;
   vector<float>   *ph_Etcone20;
   vector<float>   *ph_Etcone25;
   vector<float>   *ph_Etcone30;
   vector<float>   *ph_Etcone35;
   vector<float>   *ph_Etcone40;
   vector<float>   *ph_ptcone20;
   vector<float>   *ph_ptcone30;
   vector<float>   *ph_ptcone40;
   vector<float>   *ph_nucone20;
   vector<float>   *ph_nucone30;
   vector<float>   *ph_nucone40;
   vector<float>   *ph_Etcone15_pt_corrected;
   vector<float>   *ph_Etcone20_pt_corrected;
   vector<float>   *ph_Etcone25_pt_corrected;
   vector<float>   *ph_Etcone30_pt_corrected;
   vector<float>   *ph_Etcone35_pt_corrected;
   vector<float>   *ph_Etcone40_pt_corrected;
   vector<float>   *ph_convanglematch;
   vector<float>   *ph_convtrackmatch;
   vector<int>     *ph_hasconv;
   vector<float>   *ph_convvtxx;
   vector<float>   *ph_convvtxy;
   vector<float>   *ph_convvtxz;
   vector<float>   *ph_Rconv;
   vector<float>   *ph_zconv;
   vector<float>   *ph_convvtxchi2;
   vector<float>   *ph_pt1conv;
   vector<int>     *ph_convtrk1nBLHits;
   vector<int>     *ph_convtrk1nPixHits;
   vector<int>     *ph_convtrk1nSCTHits;
   vector<int>     *ph_convtrk1nTRTHits;
   vector<float>   *ph_pt2conv;
   vector<int>     *ph_convtrk2nBLHits;
   vector<int>     *ph_convtrk2nPixHits;
   vector<int>     *ph_convtrk2nSCTHits;
   vector<int>     *ph_convtrk2nTRTHits;
   vector<float>   *ph_ptconv;
   vector<float>   *ph_pzconv;
   vector<float>   *ph_reta;
   vector<float>   *ph_rphi;
   vector<float>   *ph_EtringnoisedR03sig2;
   vector<float>   *ph_EtringnoisedR03sig3;
   vector<float>   *ph_EtringnoisedR03sig4;
   vector<double>  *ph_isolationlikelihoodjets;
   vector<double>  *ph_isolationlikelihoodhqelectrons;
   vector<double>  *ph_loglikelihood;
   vector<double>  *ph_photonweight;
   vector<double>  *ph_photonbgweight;
   vector<double>  *ph_neuralnet;
   vector<double>  *ph_Hmatrix;
   vector<double>  *ph_Hmatrix5;
   vector<double>  *ph_adaboost;
   vector<float>   *ph_zvertex;
   vector<float>   *ph_errz;
   vector<float>   *ph_etap;
   vector<float>   *ph_depth;
   vector<float>   *ph_cl_E;
   vector<float>   *ph_cl_pt;
   vector<float>   *ph_cl_eta;
   vector<float>   *ph_cl_phi;
   vector<float>   *ph_Es0;
   vector<float>   *ph_etas0;
   vector<float>   *ph_phis0;
   vector<float>   *ph_Es1;
   vector<float>   *ph_etas1;
   vector<float>   *ph_phis1;
   vector<float>   *ph_Es2;
   vector<float>   *ph_etas2;
   vector<float>   *ph_phis2;
   vector<float>   *ph_Es3;
   vector<float>   *ph_etas3;
   vector<float>   *ph_phis3;
   vector<float>   *ph_rawcl_Es0;
   vector<float>   *ph_rawcl_etas0;
   vector<float>   *ph_rawcl_phis0;
   vector<float>   *ph_rawcl_Es1;
   vector<float>   *ph_rawcl_etas1;
   vector<float>   *ph_rawcl_phis1;
   vector<float>   *ph_rawcl_Es2;
   vector<float>   *ph_rawcl_etas2;
   vector<float>   *ph_rawcl_phis2;
   vector<float>   *ph_rawcl_Es3;
   vector<float>   *ph_rawcl_etas3;
   vector<float>   *ph_rawcl_phis3;
   vector<float>   *ph_rawcl_E;
   vector<float>   *ph_rawcl_pt;
   vector<float>   *ph_rawcl_eta;
   vector<float>   *ph_rawcl_phi;
   vector<float>   *ph_deltaEmax2;
   vector<float>   *ph_calibHitsShowerDepth;
   vector<unsigned int> *ph_isIso;
   vector<float>   *ph_mvaptcone20;
   vector<float>   *ph_mvaptcone30;
   vector<float>   *ph_mvaptcone40;
   vector<float>   *ph_topoEtcone20;
   vector<float>   *ph_topoEtcone40;
   vector<float>   *ph_topoEtcone60;
   vector<float>   *ph_jet_dr;
   vector<float>   *ph_jet_E;
   vector<float>   *ph_jet_pt;
   vector<float>   *ph_jet_m;
   vector<float>   *ph_jet_eta;
   vector<float>   *ph_jet_phi;
   vector<int>     *ph_jet_matched;
   vector<float>   *ph_convIP;
   vector<float>   *ph_convIPRev;
   vector<float>   *ph_ptIsolationCone;
   vector<float>   *ph_ptIsolationConePhAngle;
   vector<float>   *ph_Etcone40_ED_corrected;
   vector<float>   *ph_Etcone40_corrected;
   vector<float>   *ph_Etcone35_ED_corrected;
   vector<float>   *ph_Etcone35_corrected;
   vector<float>   *ph_Etcone30_ED_corrected;
   vector<float>   *ph_Etcone30_corrected;
   vector<float>   *ph_Etcone25_ED_corrected;
   vector<float>   *ph_Etcone25_corrected;
   vector<float>   *ph_Etcone20_ED_corrected;
   vector<float>   *ph_Etcone20_corrected;
   vector<float>   *ph_Etcone15_ED_corrected;
   vector<float>   *ph_Etcone15_corrected;
   vector<float>   *ph_topodr;
   vector<float>   *ph_topopt;
   vector<float>   *ph_topoeta;
   vector<float>   *ph_topophi;
   vector<int>     *ph_topomatched;
   vector<float>   *ph_topoEMdr;
   vector<float>   *ph_topoEMpt;
   vector<float>   *ph_topoEMeta;
   vector<float>   *ph_topoEMphi;
   vector<int>     *ph_topoEMmatched;
   vector<float>   *ph_EF_dr;
   vector<int>     *ph_EF_index;
   vector<float>   *ph_L2_dr;
   vector<int>     *ph_L2_index;
   vector<float>   *ph_L1_dr;
   vector<int>     *ph_L1_index;
   Int_t           mu_n;
   vector<float>   *mu_E;
   vector<float>   *mu_pt;
   vector<float>   *mu_m;
   vector<float>   *mu_eta;
   vector<float>   *mu_phi;
   vector<float>   *mu_px;
   vector<float>   *mu_py;
   vector<float>   *mu_pz;
   vector<float>   *mu_charge;
   vector<unsigned short> *mu_allauthor;
   vector<int>     *mu_author;
   vector<float>   *mu_beta;
   vector<float>   *mu_isMuonLikelihood;
   vector<float>   *mu_matchchi2;
   vector<int>     *mu_matchndof;
   vector<float>   *mu_etcone20;
   vector<float>   *mu_etcone30;
   vector<float>   *mu_etcone40;
   vector<float>   *mu_nucone20;
   vector<float>   *mu_nucone30;
   vector<float>   *mu_nucone40;
   vector<float>   *mu_ptcone20;
   vector<float>   *mu_ptcone30;
   vector<float>   *mu_ptcone40;
   vector<float>   *mu_energyLossPar;
   vector<float>   *mu_energyLossErr;
   vector<float>   *mu_etCore;
   vector<float>   *mu_energyLossType;
   vector<unsigned short> *mu_caloMuonIdTag;
   vector<double>  *mu_caloLRLikelihood;
   vector<int>     *mu_bestMatch;
   vector<int>     *mu_isStandAloneMuon;
   vector<int>     *mu_isCombinedMuon;
   vector<int>     *mu_isLowPtReconstructedMuon;
   vector<int>     *mu_isSegmentTaggedMuon;
   vector<int>     *mu_isCaloMuonId;
   vector<int>     *mu_alsoFoundByLowPt;
   vector<int>     *mu_alsoFoundByCaloMuonId;
   vector<int>     *mu_loose;
   vector<int>     *mu_medium;
   vector<int>     *mu_tight;
   vector<float>   *mu_d0_exPV;
   vector<float>   *mu_z0_exPV;
   vector<float>   *mu_phi_exPV;
   vector<float>   *mu_theta_exPV;
   vector<float>   *mu_qoverp_exPV;
   vector<float>   *mu_cb_d0_exPV;
   vector<float>   *mu_cb_z0_exPV;
   vector<float>   *mu_cb_phi_exPV;
   vector<float>   *mu_cb_theta_exPV;
   vector<float>   *mu_cb_qoverp_exPV;
   vector<float>   *mu_id_d0_exPV;
   vector<float>   *mu_id_z0_exPV;
   vector<float>   *mu_id_phi_exPV;
   vector<float>   *mu_id_theta_exPV;
   vector<float>   *mu_id_qoverp_exPV;
   vector<float>   *mu_me_d0_exPV;
   vector<float>   *mu_me_z0_exPV;
   vector<float>   *mu_me_phi_exPV;
   vector<float>   *mu_me_theta_exPV;
   vector<float>   *mu_me_qoverp_exPV;
   vector<float>   *mu_ie_d0_exPV;
   vector<float>   *mu_ie_z0_exPV;
   vector<float>   *mu_ie_phi_exPV;
   vector<float>   *mu_ie_theta_exPV;
   vector<float>   *mu_ie_qoverp_exPV;
   vector<vector<int> > *mu_SpaceTime_detID;
   vector<vector<float> > *mu_SpaceTime_t;
   vector<vector<float> > *mu_SpaceTime_tError;
   vector<vector<float> > *mu_SpaceTime_weight;
   vector<vector<float> > *mu_SpaceTime_x;
   vector<vector<float> > *mu_SpaceTime_y;
   vector<vector<float> > *mu_SpaceTime_z;
   vector<float>   *mu_cov_d0_exPV;
   vector<float>   *mu_cov_z0_exPV;
   vector<float>   *mu_cov_phi_exPV;
   vector<float>   *mu_cov_theta_exPV;
   vector<float>   *mu_cov_qoverp_exPV;
   vector<float>   *mu_cov_d0_z0_exPV;
   vector<float>   *mu_cov_d0_phi_exPV;
   vector<float>   *mu_cov_d0_theta_exPV;
   vector<float>   *mu_cov_d0_qoverp_exPV;
   vector<float>   *mu_cov_z0_phi_exPV;
   vector<float>   *mu_cov_z0_theta_exPV;
   vector<float>   *mu_cov_z0_qoverp_exPV;
   vector<float>   *mu_cov_phi_theta_exPV;
   vector<float>   *mu_cov_phi_qoverp_exPV;
   vector<float>   *mu_cov_theta_qoverp_exPV;
   vector<float>   *mu_id_cov_d0_exPV;
   vector<float>   *mu_id_cov_z0_exPV;
   vector<float>   *mu_id_cov_phi_exPV;
   vector<float>   *mu_id_cov_theta_exPV;
   vector<float>   *mu_id_cov_qoverp_exPV;
   vector<float>   *mu_id_cov_d0_z0_exPV;
   vector<float>   *mu_id_cov_d0_phi_exPV;
   vector<float>   *mu_id_cov_d0_theta_exPV;
   vector<float>   *mu_id_cov_d0_qoverp_exPV;
   vector<float>   *mu_id_cov_z0_phi_exPV;
   vector<float>   *mu_id_cov_z0_theta_exPV;
   vector<float>   *mu_id_cov_z0_qoverp_exPV;
   vector<float>   *mu_id_cov_phi_theta_exPV;
   vector<float>   *mu_id_cov_phi_qoverp_exPV;
   vector<float>   *mu_id_cov_theta_qoverp_exPV;
   vector<float>   *mu_me_cov_d0_exPV;
   vector<float>   *mu_me_cov_z0_exPV;
   vector<float>   *mu_me_cov_phi_exPV;
   vector<float>   *mu_me_cov_theta_exPV;
   vector<float>   *mu_me_cov_qoverp_exPV;
   vector<float>   *mu_me_cov_d0_z0_exPV;
   vector<float>   *mu_me_cov_d0_phi_exPV;
   vector<float>   *mu_me_cov_d0_theta_exPV;
   vector<float>   *mu_me_cov_d0_qoverp_exPV;
   vector<float>   *mu_me_cov_z0_phi_exPV;
   vector<float>   *mu_me_cov_z0_theta_exPV;
   vector<float>   *mu_me_cov_z0_qoverp_exPV;
   vector<float>   *mu_me_cov_phi_theta_exPV;
   vector<float>   *mu_me_cov_phi_qoverp_exPV;
   vector<float>   *mu_me_cov_theta_qoverp_exPV;
   vector<float>   *mu_ms_d0;
   vector<float>   *mu_ms_z0;
   vector<float>   *mu_ms_phi;
   vector<float>   *mu_ms_theta;
   vector<float>   *mu_ms_qoverp;
   vector<float>   *mu_id_d0;
   vector<float>   *mu_id_z0;
   vector<float>   *mu_id_phi;
   vector<float>   *mu_id_theta;
   vector<float>   *mu_id_qoverp;
   vector<float>   *mu_me_d0;
   vector<float>   *mu_me_z0;
   vector<float>   *mu_me_phi;
   vector<float>   *mu_me_theta;
   vector<float>   *mu_me_qoverp;
   vector<float>   *mu_ie_d0;
   vector<float>   *mu_ie_z0;
   vector<float>   *mu_ie_phi;
   vector<float>   *mu_ie_theta;
   vector<float>   *mu_ie_qoverp;
   vector<int>     *mu_nOutliersOnTrack;
   vector<int>     *mu_nBLHits;
   vector<int>     *mu_nPixHits;
   vector<int>     *mu_nSCTHits;
   vector<int>     *mu_nTRTHits;
   vector<int>     *mu_nTRTHighTHits;
   vector<int>     *mu_nBLSharedHits;
   vector<int>     *mu_nPixSharedHits;
   vector<int>     *mu_nPixHoles;
   vector<int>     *mu_nSCTSharedHits;
   vector<int>     *mu_nSCTHoles;
   vector<int>     *mu_nTRTOutliers;
   vector<int>     *mu_nTRTHighTOutliers;
   vector<int>     *mu_nGangedPixels;
   vector<int>     *mu_nPixelDeadSensors;
   vector<int>     *mu_nSCTDeadSensors;
   vector<int>     *mu_nTRTDeadStraws;
   vector<int>     *mu_expectBLayerHit;
   vector<int>     *mu_nMDTHits;
   vector<int>     *mu_nMDTHoles;
   vector<int>     *mu_nCSCEtaHits;
   vector<int>     *mu_nCSCEtaHoles;
   vector<int>     *mu_nCSCPhiHits;
   vector<int>     *mu_nCSCPhiHoles;
   vector<int>     *mu_nRPCEtaHits;
   vector<int>     *mu_nRPCEtaHoles;
   vector<int>     *mu_nRPCPhiHits;
   vector<int>     *mu_nRPCPhiHoles;
   vector<int>     *mu_nTGCEtaHits;
   vector<int>     *mu_nTGCEtaHoles;
   vector<int>     *mu_nTGCPhiHits;
   vector<int>     *mu_nTGCPhiHoles;
   vector<int>     *mu_nMDTBIHits;
   vector<int>     *mu_nMDTBMHits;
   vector<int>     *mu_nMDTBOHits;
   vector<int>     *mu_nMDTBEEHits;
   vector<int>     *mu_nMDTBIS78Hits;
   vector<int>     *mu_nMDTEIHits;
   vector<int>     *mu_nMDTEMHits;
   vector<int>     *mu_nMDTEOHits;
   vector<int>     *mu_nMDTEEHits;
   vector<int>     *mu_nRPCLayer1EtaHits;
   vector<int>     *mu_nRPCLayer2EtaHits;
   vector<int>     *mu_nRPCLayer3EtaHits;
   vector<int>     *mu_nRPCLayer1PhiHits;
   vector<int>     *mu_nRPCLayer2PhiHits;
   vector<int>     *mu_nRPCLayer3PhiHits;
   vector<int>     *mu_nTGCLayer1EtaHits;
   vector<int>     *mu_nTGCLayer2EtaHits;
   vector<int>     *mu_nTGCLayer3EtaHits;
   vector<int>     *mu_nTGCLayer4EtaHits;
   vector<int>     *mu_nTGCLayer1PhiHits;
   vector<int>     *mu_nTGCLayer2PhiHits;
   vector<int>     *mu_nTGCLayer3PhiHits;
   vector<int>     *mu_nTGCLayer4PhiHits;
   vector<int>     *mu_barrelSectors;
   vector<int>     *mu_endcapSectors;
   vector<float>   *mu_trackd0;
   vector<float>   *mu_trackz0;
   vector<float>   *mu_trackphi;
   vector<float>   *mu_tracktheta;
   vector<float>   *mu_trackqoverp;
   vector<float>   *mu_trackcov_d0;
   vector<float>   *mu_trackcov_z0;
   vector<float>   *mu_trackcov_phi;
   vector<float>   *mu_trackcov_theta;
   vector<float>   *mu_trackcov_qoverp;
   vector<float>   *mu_trackcov_d0_z0;
   vector<float>   *mu_trackcov_d0_phi;
   vector<float>   *mu_trackcov_d0_theta;
   vector<float>   *mu_trackcov_d0_qoverp;
   vector<float>   *mu_trackcov_z0_phi;
   vector<float>   *mu_trackcov_z0_theta;
   vector<float>   *mu_trackcov_z0_qoverp;
   vector<float>   *mu_trackcov_phi_theta;
   vector<float>   *mu_trackcov_phi_qoverp;
   vector<float>   *mu_trackcov_theta_qoverp;
   vector<float>   *mu_trackfitchi2;
   vector<int>     *mu_trackfitndof;
   vector<int>     *mu_hastrack;
   vector<float>   *mu_trackd0beam;
   vector<float>   *mu_trackz0beam;
   vector<float>   *mu_tracksigd0beam;
   vector<float>   *mu_tracksigz0beam;
   vector<float>   *mu_trackd0pv;
   vector<float>   *mu_trackz0pv;
   vector<float>   *mu_tracksigd0pv;
   vector<float>   *mu_tracksigz0pv;
   vector<float>   *mu_trackIPEstimate_d0_biasedpvunbiased;
   vector<float>   *mu_trackIPEstimate_z0_biasedpvunbiased;
   vector<float>   *mu_trackIPEstimate_d0_unbiasedpvunbiased;
   vector<float>   *mu_trackIPEstimate_z0_unbiasedpvunbiased;
   vector<float>   *mu_trackIPEstimate_sigd0_biasedpvunbiased;
   vector<float>   *mu_trackIPEstimate_sigz0_biasedpvunbiased;
   vector<float>   *mu_trackIPEstimate_sigd0_unbiasedpvunbiased;
   vector<float>   *mu_trackIPEstimate_sigz0_unbiasedpvunbiased;
   vector<float>   *mu_EFCB_dr;
   vector<int>     *mu_EFCB_index;
   vector<float>   *mu_EFMG_dr;
   vector<float>   *mu_EFME_dr;
   vector<int>     *mu_EFME_index;
   vector<float>   *mu_L2CB_dr;
   vector<int>     *mu_L2CB_index;
   vector<float>   *mu_L1_dr;
   vector<int>     *mu_L1_index;
   Int_t           tau_n;
   vector<float>   *tau_Et;
   vector<float>   *tau_pt;
   vector<float>   *tau_m;
   vector<float>   *tau_eta;
   vector<float>   *tau_phi;
   vector<float>   *tau_charge;
   vector<float>   *tau_BDTEleScore;
   vector<float>   *tau_BDTJetScore;
   vector<float>   *tau_likelihood;
   vector<float>   *tau_SafeLikelihood;
   vector<int>     *tau_electronVetoLoose;
   vector<int>     *tau_electronVetoMedium;
   vector<int>     *tau_electronVetoTight;
   vector<int>     *tau_muonVeto;
   vector<int>     *tau_tauCutLoose;
   vector<int>     *tau_tauCutMedium;
   vector<int>     *tau_tauCutTight;
   vector<int>     *tau_tauLlhLoose;
   vector<int>     *tau_tauLlhMedium;
   vector<int>     *tau_tauLlhTight;
   vector<int>     *tau_JetBDTSigLoose;
   vector<int>     *tau_JetBDTSigMedium;
   vector<int>     *tau_JetBDTSigTight;
   vector<int>     *tau_EleBDTLoose;
   vector<int>     *tau_EleBDTMedium;
   vector<int>     *tau_EleBDTTight;
   vector<int>     *tau_author;
   vector<int>     *tau_ROIword;
   vector<int>     *tau_nProng;
   vector<int>     *tau_numTrack;
   vector<int>     *tau_seedCalo_numTrack;
   vector<float>   *tau_etOverPtLeadTrk;
   vector<float>   *tau_ipZ0SinThetaSigLeadTrk;
   vector<float>   *tau_leadTrkPt;
   vector<int>     *tau_nLooseTrk;
   vector<int>     *tau_nLooseConvTrk;
   vector<int>     *tau_nProngLoose;
   vector<float>   *tau_ipSigLeadTrk;
   vector<float>   *tau_ipSigLeadLooseTrk;
   vector<float>   *tau_etOverPtLeadLooseTrk;
   vector<float>   *tau_leadLooseTrkPt;
   vector<float>   *tau_chrgLooseTrk;
   vector<float>   *tau_massTrkSys;
   vector<float>   *tau_trkWidth2;
   vector<float>   *tau_trFlightPathSig;
   vector<float>   *tau_etEflow;
   vector<float>   *tau_mEflow;
   vector<int>     *tau_nPi0;
   vector<float>   *tau_ele_E237E277;
   vector<float>   *tau_ele_PresamplerFraction;
   vector<float>   *tau_ele_ECALFirstFraction;
   vector<float>   *tau_seedCalo_EMRadius;
   vector<float>   *tau_seedCalo_hadRadius;
   vector<float>   *tau_seedCalo_etEMAtEMScale;
   vector<float>   *tau_seedCalo_etHadAtEMScale;
   vector<float>   *tau_seedCalo_isolFrac;
   vector<float>   *tau_seedCalo_centFrac;
   vector<float>   *tau_seedCalo_stripWidth2;
   vector<int>     *tau_seedCalo_nStrip;
   vector<float>   *tau_seedCalo_etEMCalib;
   vector<float>   *tau_seedCalo_etHadCalib;
   vector<float>   *tau_seedCalo_eta;
   vector<float>   *tau_seedCalo_phi;
   vector<float>   *tau_seedCalo_nIsolLooseTrk;
   vector<float>   *tau_seedCalo_trkAvgDist;
   vector<float>   *tau_seedCalo_trkRmsDist;
   vector<int>     *tau_numTopoClusters;
   vector<float>   *tau_numEffTopoClusters;
   vector<float>   *tau_topoInvMass;
   vector<float>   *tau_effTopoInvMass;
   vector<float>   *tau_topoMeanDeltaR;
   vector<float>   *tau_effTopoMeanDeltaR;
   vector<float>   *tau_numCells;
   vector<float>   *tau_seedTrk_EMRadius;
   vector<float>   *tau_seedTrk_isolFrac;
   vector<float>   *tau_seedTrk_etChrgHadOverSumTrkPt;
   vector<float>   *tau_seedTrk_isolFracWide;
   vector<float>   *tau_seedTrk_etHadAtEMScale;
   vector<float>   *tau_seedTrk_etEMAtEMScale;
   vector<float>   *tau_seedTrk_etEMCL;
   vector<float>   *tau_seedTrk_etChrgEM;
   vector<float>   *tau_seedTrk_etNeuEM;
   vector<float>   *tau_seedTrk_etResNeuEM;
   vector<float>   *tau_seedTrk_hadLeakEt;
   vector<float>   *tau_seedTrk_sumEMCellEtOverLeadTrkPt;
   vector<float>   *tau_seedTrk_secMaxStripEt;
   vector<float>   *tau_seedTrk_stripWidth2;
   vector<int>     *tau_seedTrk_nStrip;
   vector<float>   *tau_seedTrk_etChrgHad;
   vector<int>     *tau_seedTrk_nOtherCoreTrk;
   vector<int>     *tau_seedTrk_nIsolTrk;
   vector<float>   *tau_seedTrk_etIsolEM;
   vector<float>   *tau_seedTrk_etIsolHad;
   vector<float>   *tau_calcVars_etHad_EMScale_Pt3Trks;
   vector<float>   *tau_calcVars_etEM_EMScale_Pt3Trks;
   vector<float>   *tau_calcVars_ipSigLeadLooseTrk;
   vector<float>   *tau_calcVars_drMax;
   vector<float>   *tau_calcVars_drMin;
   vector<float>   *tau_calcVars_TRTHTOverLT_LeadTrk;
   vector<float>   *tau_calcVars_calRadius;
   vector<float>   *tau_calcVars_EMFractionAtEMScale;
   vector<float>   *tau_calcVars_lead2ClusterEOverAllClusterE;
   vector<float>   *tau_calcVars_lead3ClusterEOverAllClusterE;
   vector<float>   *tau_calcVars_caloIso;
   vector<float>   *tau_calcVars_trackIso;
   vector<float>   *tau_calcVars_caloIsoCorrected;
   vector<float>   *tau_calcVars_BDTSigTrans;
   vector<int>     *tau_calcVars_BDTLooseBkg;
   vector<int>     *tau_calcVars_BDTMediumBkg;
   vector<int>     *tau_calcVars_BDTTightBkg;
   vector<vector<float> > *tau_cluster_E;
   vector<vector<float> > *tau_cluster_eta;
   vector<vector<float> > *tau_cluster_phi;
   vector<unsigned int> *tau_cluster_n;
   vector<vector<float> > *tau_cluster_emfraction;
   vector<vector<float> > *tau_Pi0Cluster_pt;
   vector<vector<float> > *tau_Pi0Cluster_eta;
   vector<vector<float> > *tau_Pi0Cluster_phi;
   vector<float>   *tau_secvtx_x;
   vector<float>   *tau_secvtx_y;
   vector<float>   *tau_secvtx_z;
   vector<float>   *tau_secvtx_chiSquared;
   vector<float>   *tau_secvtx_numberDoF;
   vector<float>   *tau_jet_Et;
   vector<float>   *tau_jet_pt;
   vector<float>   *tau_jet_m;
   vector<float>   *tau_jet_eta;
   vector<float>   *tau_jet_phi;
   vector<int>     *tau_jet_SamplingMax;
   vector<float>   *tau_jet_fracSamplingMax;
   vector<float>   *tau_jet_emfrac;
   vector<float>   *tau_jet_GCWJES;
   vector<float>   *tau_jet_EMJES;
   vector<float>   *tau_jet_emscale_E;
   vector<float>   *tau_jet_emscale_pt;
   vector<float>   *tau_jet_emscale_m;
   vector<float>   *tau_jet_emscale_eta;
   vector<float>   *tau_jet_emscale_phi;
   vector<double>  *tau_jet_flavor_weight_TrackCounting2D;
   vector<double>  *tau_jet_flavor_weight_JetProb;
   vector<double>  *tau_jet_flavor_weight_IP1D;
   vector<double>  *tau_jet_flavor_weight_IP2D;
   vector<double>  *tau_jet_flavor_weight_IP3D;
   vector<double>  *tau_jet_flavor_weight_SV0;
   vector<double>  *tau_jet_flavor_weight_SV1;
   vector<double>  *tau_jet_flavor_weight_SV2;
   vector<double>  *tau_jet_flavor_weight_JetFitterTag;
   vector<double>  *tau_jet_flavor_weight_JetFitterCOMB;
   vector<double>  *tau_jet_flavor_weight_JetFitterTagNN;
   vector<double>  *tau_jet_flavor_weight_JetFitterCOMBNN;
   vector<double>  *tau_jet_flavor_weight_SoftMuonTag;
   vector<double>  *tau_jet_flavor_weight_SoftElectronTag;
   vector<double>  *tau_jet_flavor_weight_IP3DSV1;
   vector<int>     *tau_seedCalo_track_n;
   vector<int>     *tau_seedCalo_wideTrk_n;
   vector<int>     *tau_otherTrk_n;
   vector<float>   *tau_EF_dr;
   vector<float>   *tau_EF_E;
   vector<float>   *tau_EF_Et;
   vector<float>   *tau_EF_pt;
   vector<float>   *tau_EF_eta;
   vector<float>   *tau_EF_phi;
   vector<int>     *tau_EF_matched;
   vector<float>   *tau_L2_dr;
   vector<float>   *tau_L2_E;
   vector<float>   *tau_L2_Et;
   vector<float>   *tau_L2_pt;
   vector<float>   *tau_L2_eta;
   vector<float>   *tau_L2_phi;
   vector<int>     *tau_L2_matched;
   vector<float>   *tau_L1_dr;
   vector<float>   *tau_L1_Et;
   vector<float>   *tau_L1_pt;
   vector<float>   *tau_L1_eta;
   vector<float>   *tau_L1_phi;
   vector<int>     *tau_L1_matched;
   Int_t           trk_n;
   vector<float>   *trk_pt;
   vector<float>   *trk_eta;
   vector<float>   *trk_d0_wrtPV;
   vector<float>   *trk_z0_wrtPV;
   vector<float>   *trk_phi_wrtPV;
   vector<float>   *trk_theta_wrtPV;
   vector<float>   *trk_qoverp_wrtPV;
   vector<float>   *trk_err_d0_wrtPV;
   vector<float>   *trk_err_z0_wrtPV;
   vector<float>   *trk_err_phi_wrtPV;
   vector<float>   *trk_err_theta_wrtPV;
   vector<float>   *trk_err_qoverp_wrtPV;
   vector<float>   *trk_chi2;
   vector<int>     *trk_ndof;
   vector<int>     *trk_nBLHits;
   vector<int>     *trk_nPixHits;
   vector<int>     *trk_nSCTHits;
   vector<int>     *trk_nTRTHits;
   vector<int>     *trk_nTRTHighTHits;
   vector<int>     *trk_nPixHoles;
   vector<int>     *trk_nSCTHoles;
   vector<int>     *trk_nTRTHoles;
   vector<int>     *trk_nBLayerOutliers;
   vector<int>     *trk_nPixelOutliers;
   vector<int>     *trk_nSCTOutliers;
   vector<int>     *trk_nTRTOutliers;
   vector<int>     *trk_nTRTHighTOutliers;
   vector<int>     *trk_nContribPixelLayers;
   vector<int>     *trk_nGangedPixels;
   vector<int>     *trk_nGangedFlaggedFakes;
   vector<int>     *trk_nPixelDeadSensors;
   vector<int>     *trk_nPixelSpoiltHits;
   vector<int>     *trk_nSCTDoubleHoles;
   vector<int>     *trk_nSCTDeadSensors;
   vector<int>     *trk_nSCTSpoiltHits;
   vector<int>     *trk_nTRTDeadStraws;
   vector<int>     *trk_nTRTTubeHits;
   vector<int>     *trk_expectBLayerHit;
   vector<float>   *trk_20_trackIso;
   vector<float>   *trk_20_caloIso;
   vector<int>     *trk_20_nTrackIso;
   vector<float>   *trk_30_trackIso;
   vector<float>   *trk_30_caloIso;
   vector<int>     *trk_30_nTrackIso;
   vector<float>   *trk_40_trackIso;
   vector<float>   *trk_40_caloIso;
   vector<int>     *trk_40_nTrackIso;
   Int_t           jet_antiKtZ4Track_n;
   vector<float>   *jet_antiKtZ4Track_E;
   vector<float>   *jet_antiKtZ4Track_pt;
   vector<float>   *jet_antiKtZ4Track_m;
   vector<float>   *jet_antiKtZ4Track_eta;
   vector<float>   *jet_antiKtZ4Track_phi;
   vector<float>   *jet_antiKtZ4Track_EtaOrigin;
   vector<float>   *jet_antiKtZ4Track_PhiOrigin;
   vector<float>   *jet_antiKtZ4Track_MOrigin;
   vector<float>   *jet_antiKtZ4Track_EtaOriginEM;
   vector<float>   *jet_antiKtZ4Track_PhiOriginEM;
   vector<float>   *jet_antiKtZ4Track_MOriginEM;
   vector<float>   *jet_antiKtZ4Track_WIDTH;
   vector<float>   *jet_antiKtZ4Track_n90;
   vector<float>   *jet_antiKtZ4Track_Timing;
   vector<float>   *jet_antiKtZ4Track_LArQuality;
   vector<float>   *jet_antiKtZ4Track_nTrk;
   vector<float>   *jet_antiKtZ4Track_sumPtTrk;
   vector<float>   *jet_antiKtZ4Track_OriginIndex;
   vector<float>   *jet_antiKtZ4Track_HECQuality;
   vector<float>   *jet_antiKtZ4Track_NegativeE;
   vector<float>   *jet_antiKtZ4Track_AverageLArQF;
   vector<float>   *jet_antiKtZ4Track_YFlip12;
   vector<float>   *jet_antiKtZ4Track_YFlip23;
   vector<float>   *jet_antiKtZ4Track_BCH_CORR_CELL;
   vector<float>   *jet_antiKtZ4Track_BCH_CORR_DOTX;
   vector<float>   *jet_antiKtZ4Track_BCH_CORR_JET;
   vector<float>   *jet_antiKtZ4Track_BCH_CORR_JET_FORCELL;
   vector<float>   *jet_antiKtZ4Track_ENG_BAD_CELLS;
   vector<float>   *jet_antiKtZ4Track_N_BAD_CELLS;
   vector<float>   *jet_antiKtZ4Track_N_BAD_CELLS_CORR;
   vector<float>   *jet_antiKtZ4Track_BAD_CELLS_CORR_E;
   vector<float>   *jet_antiKtZ4Track_NumTowers;
   vector<int>     *jet_antiKtZ4Track_SamplingMax;
   vector<float>   *jet_antiKtZ4Track_fracSamplingMax;
   vector<float>   *jet_antiKtZ4Track_hecf;
   vector<float>   *jet_antiKtZ4Track_tgap3f;
   vector<int>     *jet_antiKtZ4Track_isUgly;
   vector<int>     *jet_antiKtZ4Track_isBadLoose;
   vector<int>     *jet_antiKtZ4Track_isBadMedium;
   vector<int>     *jet_antiKtZ4Track_isBadTight;
   vector<float>   *jet_antiKtZ4Track_emfrac;
   vector<float>   *jet_antiKtZ4Track_Offset;
   vector<float>   *jet_antiKtZ4Track_EMJES;
   vector<float>   *jet_antiKtZ4Track_EMJES_EtaCorr;
   vector<float>   *jet_antiKtZ4Track_EMJESnooffset;
   vector<float>   *jet_antiKtZ4Track_GCWJES;
   vector<float>   *jet_antiKtZ4Track_GCWJES_EtaCorr;
   vector<float>   *jet_antiKtZ4Track_CB;
   vector<float>   *jet_antiKtZ4Track_LCJES;
   vector<float>   *jet_antiKtZ4Track_emscale_E;
   vector<float>   *jet_antiKtZ4Track_emscale_pt;
   vector<float>   *jet_antiKtZ4Track_emscale_m;
   vector<float>   *jet_antiKtZ4Track_emscale_eta;
   vector<float>   *jet_antiKtZ4Track_emscale_phi;
   vector<float>   *jet_antiKtZ4Track_jvtx_x;
   vector<float>   *jet_antiKtZ4Track_jvtx_y;
   vector<float>   *jet_antiKtZ4Track_jvtx_z;
   vector<float>   *jet_antiKtZ4Track_jvtxf;
   vector<float>   *jet_antiKtZ4Track_flavor_weight_Comb;
   vector<float>   *jet_antiKtZ4Track_flavor_weight_IP2D;
   vector<float>   *jet_antiKtZ4Track_flavor_weight_IP3D;
   vector<float>   *jet_antiKtZ4Track_flavor_weight_SV0;
   vector<float>   *jet_antiKtZ4Track_flavor_weight_SV1;
   vector<float>   *jet_antiKtZ4Track_flavor_weight_SV2;
   vector<float>   *jet_antiKtZ4Track_flavor_weight_JetProb;
   vector<float>   *jet_antiKtZ4Track_flavor_weight_SoftMuonTag;
   vector<float>   *jet_antiKtZ4Track_flavor_weight_JetFitterTagNN;
   vector<float>   *jet_antiKtZ4Track_flavor_weight_JetFitterCOMBNN;
   vector<float>   *jet_antiKtZ4Track_flavor_weight_GbbNN;
   vector<int>     *jet_antiKtZ4Track_flavor_component_svp_isValid;
   vector<int>     *jet_antiKtZ4Track_flavor_component_svp_ntrkv;
   vector<int>     *jet_antiKtZ4Track_flavor_component_svp_ntrkj;
   vector<int>     *jet_antiKtZ4Track_flavor_component_svp_n2t;
   vector<float>   *jet_antiKtZ4Track_flavor_component_svp_mass;
   vector<float>   *jet_antiKtZ4Track_flavor_component_svp_efrc;
   vector<float>   *jet_antiKtZ4Track_flavor_component_svp_x;
   vector<float>   *jet_antiKtZ4Track_flavor_component_svp_y;
   vector<float>   *jet_antiKtZ4Track_flavor_component_svp_z;
   vector<float>   *jet_antiKtZ4Track_flavor_component_svp_err_x;
   vector<float>   *jet_antiKtZ4Track_flavor_component_svp_err_y;
   vector<float>   *jet_antiKtZ4Track_flavor_component_svp_err_z;
   vector<float>   *jet_antiKtZ4Track_flavor_component_svp_cov_xy;
   vector<float>   *jet_antiKtZ4Track_flavor_component_svp_cov_xz;
   vector<float>   *jet_antiKtZ4Track_flavor_component_svp_cov_yz;
   vector<float>   *jet_antiKtZ4Track_flavor_component_svp_chi2;
   vector<int>     *jet_antiKtZ4Track_flavor_component_svp_ndof;
   vector<int>     *jet_antiKtZ4Track_flavor_component_svp_ntrk;
   vector<int>     *jet_antiKtZ4Track_flavor_component_sv0p_isValid;
   vector<int>     *jet_antiKtZ4Track_flavor_component_sv0p_ntrkv;
   vector<int>     *jet_antiKtZ4Track_flavor_component_sv0p_ntrkj;
   vector<int>     *jet_antiKtZ4Track_flavor_component_sv0p_n2t;
   vector<float>   *jet_antiKtZ4Track_flavor_component_sv0p_mass;
   vector<float>   *jet_antiKtZ4Track_flavor_component_sv0p_efrc;
   vector<float>   *jet_antiKtZ4Track_flavor_component_sv0p_x;
   vector<float>   *jet_antiKtZ4Track_flavor_component_sv0p_y;
   vector<float>   *jet_antiKtZ4Track_flavor_component_sv0p_z;
   vector<float>   *jet_antiKtZ4Track_flavor_component_sv0p_err_x;
   vector<float>   *jet_antiKtZ4Track_flavor_component_sv0p_err_y;
   vector<float>   *jet_antiKtZ4Track_flavor_component_sv0p_err_z;
   vector<float>   *jet_antiKtZ4Track_flavor_component_sv0p_cov_xy;
   vector<float>   *jet_antiKtZ4Track_flavor_component_sv0p_cov_xz;
   vector<float>   *jet_antiKtZ4Track_flavor_component_sv0p_cov_yz;
   vector<float>   *jet_antiKtZ4Track_flavor_component_sv0p_chi2;
   vector<int>     *jet_antiKtZ4Track_flavor_component_sv0p_ndof;
   vector<int>     *jet_antiKtZ4Track_flavor_component_sv0p_ntrk;
   vector<vector<int> > *jet_antiKtZ4Track_flavor_assoctrk_index;
   vector<float>   *jet_antiKtZ4Track_el_dr;
   vector<int>     *jet_antiKtZ4Track_el_matched;
   vector<float>   *jet_antiKtZ4Track_mu_dr;
   vector<int>     *jet_antiKtZ4Track_mu_matched;
   vector<float>   *jet_antiKtZ4Track_L1_dr;
   vector<int>     *jet_antiKtZ4Track_L1_matched;
   vector<float>   *jet_antiKtZ4Track_L2_dr;
   vector<int>     *jet_antiKtZ4Track_L2_matched;
   vector<float>   *jet_antiKtZ4Track_EF_dr;
   vector<int>     *jet_antiKtZ4Track_EF_matched;
   Int_t           jet_n;
   vector<float>   *jet_E;
   vector<float>   *jet_pt;
   vector<float>   *jet_m;
   vector<float>   *jet_eta;
   vector<float>   *jet_phi;
   vector<float>   *jet_EtaOrigin;
   vector<float>   *jet_PhiOrigin;
   vector<float>   *jet_MOrigin;
   vector<float>   *jet_EtaOriginEM;
   vector<float>   *jet_PhiOriginEM;
   vector<float>   *jet_MOriginEM;
   vector<float>   *jet_WIDTH;
   vector<float>   *jet_n90;
   vector<float>   *jet_Timing;
   vector<float>   *jet_LArQuality;
   vector<float>   *jet_nTrk;
   vector<float>   *jet_sumPtTrk;
   vector<float>   *jet_OriginIndex;
   vector<float>   *jet_HECQuality;
   vector<float>   *jet_NegativeE;
   vector<float>   *jet_AverageLArQF;
   vector<float>   *jet_YFlip12;
   vector<float>   *jet_YFlip23;
   vector<float>   *jet_BCH_CORR_CELL;
   vector<float>   *jet_BCH_CORR_DOTX;
   vector<float>   *jet_BCH_CORR_JET;
   vector<float>   *jet_BCH_CORR_JET_FORCELL;
   vector<float>   *jet_ENG_BAD_CELLS;
   vector<float>   *jet_N_BAD_CELLS;
   vector<float>   *jet_N_BAD_CELLS_CORR;
   vector<float>   *jet_BAD_CELLS_CORR_E;
   vector<float>   *jet_NumTowers;
   vector<int>     *jet_SamplingMax;
   vector<float>   *jet_fracSamplingMax;
   vector<float>   *jet_hecf;
   vector<float>   *jet_tgap3f;
   vector<int>     *jet_isUgly;
   vector<int>     *jet_isBadLoose;
   vector<int>     *jet_isBadMedium;
   vector<int>     *jet_isBadTight;
   vector<float>   *jet_emfrac;
   vector<float>   *jet_Offset;
   vector<float>   *jet_EMJES;
   vector<float>   *jet_EMJES_EtaCorr;
   vector<float>   *jet_EMJESnooffset;
   vector<float>   *jet_GCWJES;
   vector<float>   *jet_GCWJES_EtaCorr;
   vector<float>   *jet_CB;
   vector<float>   *jet_LCJES;
   vector<float>   *jet_emscale_E;
   vector<float>   *jet_emscale_pt;
   vector<float>   *jet_emscale_m;
   vector<float>   *jet_emscale_eta;
   vector<float>   *jet_emscale_phi;
   vector<float>   *jet_jvtx_x;
   vector<float>   *jet_jvtx_y;
   vector<float>   *jet_jvtx_z;
   vector<float>   *jet_jvtxf;
   vector<float>   *jet_GSCFactorF;
   vector<float>   *jet_WidthFraction;
   vector<float>   *jet_e_PreSamplerB;
   vector<float>   *jet_e_EMB1;
   vector<float>   *jet_e_EMB2;
   vector<float>   *jet_e_EMB3;
   vector<float>   *jet_e_PreSamplerE;
   vector<float>   *jet_e_EME1;
   vector<float>   *jet_e_EME2;
   vector<float>   *jet_e_EME3;
   vector<float>   *jet_e_HEC0;
   vector<float>   *jet_e_HEC1;
   vector<float>   *jet_e_HEC2;
   vector<float>   *jet_e_HEC3;
   vector<float>   *jet_e_TileBar0;
   vector<float>   *jet_e_TileBar1;
   vector<float>   *jet_e_TileBar2;
   vector<float>   *jet_e_TileGap1;
   vector<float>   *jet_e_TileGap2;
   vector<float>   *jet_e_TileGap3;
   vector<float>   *jet_e_TileExt0;
   vector<float>   *jet_e_TileExt1;
   vector<float>   *jet_e_TileExt2;
   vector<float>   *jet_e_FCAL0;
   vector<float>   *jet_e_FCAL1;
   vector<float>   *jet_e_FCAL2;
   vector<float>   *jet_flavor_weight_Comb;
   vector<float>   *jet_flavor_weight_IP2D;
   vector<float>   *jet_flavor_weight_IP3D;
   vector<float>   *jet_flavor_weight_SV0;
   vector<float>   *jet_flavor_weight_SV1;
   vector<float>   *jet_flavor_weight_SV2;
   vector<float>   *jet_flavor_weight_JetProb;
   vector<float>   *jet_flavor_weight_SoftMuonTag;
   vector<float>   *jet_flavor_weight_JetFitterTagNN;
   vector<float>   *jet_flavor_weight_JetFitterCOMBNN;
   vector<float>   *jet_flavor_weight_GbbNN;
   vector<int>     *jet_flavor_component_svp_isValid;
   vector<int>     *jet_flavor_component_svp_ntrkv;
   vector<int>     *jet_flavor_component_svp_ntrkj;
   vector<int>     *jet_flavor_component_svp_n2t;
   vector<float>   *jet_flavor_component_svp_mass;
   vector<float>   *jet_flavor_component_svp_efrc;
   vector<float>   *jet_flavor_component_svp_x;
   vector<float>   *jet_flavor_component_svp_y;
   vector<float>   *jet_flavor_component_svp_z;
   vector<float>   *jet_flavor_component_svp_err_x;
   vector<float>   *jet_flavor_component_svp_err_y;
   vector<float>   *jet_flavor_component_svp_err_z;
   vector<float>   *jet_flavor_component_svp_cov_xy;
   vector<float>   *jet_flavor_component_svp_cov_xz;
   vector<float>   *jet_flavor_component_svp_cov_yz;
   vector<float>   *jet_flavor_component_svp_chi2;
   vector<int>     *jet_flavor_component_svp_ndof;
   vector<int>     *jet_flavor_component_svp_ntrk;
   vector<int>     *jet_flavor_component_sv0p_isValid;
   vector<int>     *jet_flavor_component_sv0p_ntrkv;
   vector<int>     *jet_flavor_component_sv0p_ntrkj;
   vector<int>     *jet_flavor_component_sv0p_n2t;
   vector<float>   *jet_flavor_component_sv0p_mass;
   vector<float>   *jet_flavor_component_sv0p_efrc;
   vector<float>   *jet_flavor_component_sv0p_x;
   vector<float>   *jet_flavor_component_sv0p_y;
   vector<float>   *jet_flavor_component_sv0p_z;
   vector<float>   *jet_flavor_component_sv0p_err_x;
   vector<float>   *jet_flavor_component_sv0p_err_y;
   vector<float>   *jet_flavor_component_sv0p_err_z;
   vector<float>   *jet_flavor_component_sv0p_cov_xy;
   vector<float>   *jet_flavor_component_sv0p_cov_xz;
   vector<float>   *jet_flavor_component_sv0p_cov_yz;
   vector<float>   *jet_flavor_component_sv0p_chi2;
   vector<int>     *jet_flavor_component_sv0p_ndof;
   vector<int>     *jet_flavor_component_sv0p_ntrk;
   vector<vector<int> > *jet_flavor_assoctrk_index;
   vector<float>   *jet_el_dr;
   vector<int>     *jet_el_matched;
   vector<float>   *jet_mu_dr;
   vector<int>     *jet_mu_matched;
   vector<float>   *jet_L1_dr;
   vector<int>     *jet_L1_matched;
   vector<float>   *jet_L2_dr;
   vector<int>     *jet_L2_matched;
   vector<float>   *jet_EF_dr;
   vector<int>     *jet_EF_matched;
   Int_t           jet_AntiKt4LCTopoJets_n;
   vector<float>   *jet_AntiKt4LCTopoJets_E;
   vector<float>   *jet_AntiKt4LCTopoJets_pt;
   vector<float>   *jet_AntiKt4LCTopoJets_m;
   vector<float>   *jet_AntiKt4LCTopoJets_eta;
   vector<float>   *jet_AntiKt4LCTopoJets_phi;
   vector<float>   *jet_AntiKt4LCTopoJets_EtaOrigin;
   vector<float>   *jet_AntiKt4LCTopoJets_PhiOrigin;
   vector<float>   *jet_AntiKt4LCTopoJets_MOrigin;
   vector<float>   *jet_AntiKt4LCTopoJets_EtaOriginEM;
   vector<float>   *jet_AntiKt4LCTopoJets_PhiOriginEM;
   vector<float>   *jet_AntiKt4LCTopoJets_MOriginEM;
   vector<float>   *jet_AntiKt4LCTopoJets_WIDTH;
   vector<float>   *jet_AntiKt4LCTopoJets_n90;
   vector<float>   *jet_AntiKt4LCTopoJets_Timing;
   vector<float>   *jet_AntiKt4LCTopoJets_LArQuality;
   vector<float>   *jet_AntiKt4LCTopoJets_nTrk;
   vector<float>   *jet_AntiKt4LCTopoJets_sumPtTrk;
   vector<float>   *jet_AntiKt4LCTopoJets_OriginIndex;
   vector<float>   *jet_AntiKt4LCTopoJets_HECQuality;
   vector<float>   *jet_AntiKt4LCTopoJets_NegativeE;
   vector<float>   *jet_AntiKt4LCTopoJets_AverageLArQF;
   vector<float>   *jet_AntiKt4LCTopoJets_YFlip12;
   vector<float>   *jet_AntiKt4LCTopoJets_YFlip23;
   vector<float>   *jet_AntiKt4LCTopoJets_BCH_CORR_CELL;
   vector<float>   *jet_AntiKt4LCTopoJets_BCH_CORR_DOTX;
   vector<float>   *jet_AntiKt4LCTopoJets_BCH_CORR_JET;
   vector<float>   *jet_AntiKt4LCTopoJets_BCH_CORR_JET_FORCELL;
   vector<float>   *jet_AntiKt4LCTopoJets_ENG_BAD_CELLS;
   vector<float>   *jet_AntiKt4LCTopoJets_N_BAD_CELLS;
   vector<float>   *jet_AntiKt4LCTopoJets_N_BAD_CELLS_CORR;
   vector<float>   *jet_AntiKt4LCTopoJets_BAD_CELLS_CORR_E;
   vector<float>   *jet_AntiKt4LCTopoJets_NumTowers;
   vector<int>     *jet_AntiKt4LCTopoJets_SamplingMax;
   vector<float>   *jet_AntiKt4LCTopoJets_fracSamplingMax;
   vector<float>   *jet_AntiKt4LCTopoJets_hecf;
   vector<float>   *jet_AntiKt4LCTopoJets_tgap3f;
   vector<int>     *jet_AntiKt4LCTopoJets_isUgly;
   vector<int>     *jet_AntiKt4LCTopoJets_isBadLoose;
   vector<int>     *jet_AntiKt4LCTopoJets_isBadMedium;
   vector<int>     *jet_AntiKt4LCTopoJets_isBadTight;
   vector<float>   *jet_AntiKt4LCTopoJets_emfrac;
   vector<float>   *jet_AntiKt4LCTopoJets_Offset;
   vector<float>   *jet_AntiKt4LCTopoJets_EMJES;
   vector<float>   *jet_AntiKt4LCTopoJets_EMJES_EtaCorr;
   vector<float>   *jet_AntiKt4LCTopoJets_EMJESnooffset;
   vector<float>   *jet_AntiKt4LCTopoJets_GCWJES;
   vector<float>   *jet_AntiKt4LCTopoJets_GCWJES_EtaCorr;
   vector<float>   *jet_AntiKt4LCTopoJets_CB;
   vector<float>   *jet_AntiKt4LCTopoJets_LCJES;
   vector<float>   *jet_AntiKt4LCTopoJets_emscale_E;
   vector<float>   *jet_AntiKt4LCTopoJets_emscale_pt;
   vector<float>   *jet_AntiKt4LCTopoJets_emscale_m;
   vector<float>   *jet_AntiKt4LCTopoJets_emscale_eta;
   vector<float>   *jet_AntiKt4LCTopoJets_emscale_phi;
   vector<float>   *jet_AntiKt4LCTopoJets_jvtx_x;
   vector<float>   *jet_AntiKt4LCTopoJets_jvtx_y;
   vector<float>   *jet_AntiKt4LCTopoJets_jvtx_z;
   vector<float>   *jet_AntiKt4LCTopoJets_jvtxf;
   vector<float>   *jet_AntiKt4LCTopoJets_GSCFactorF;
   vector<float>   *jet_AntiKt4LCTopoJets_WidthFraction;
   vector<float>   *jet_AntiKt4LCTopoJets_e_PreSamplerB;
   vector<float>   *jet_AntiKt4LCTopoJets_e_EMB1;
   vector<float>   *jet_AntiKt4LCTopoJets_e_EMB2;
   vector<float>   *jet_AntiKt4LCTopoJets_e_EMB3;
   vector<float>   *jet_AntiKt4LCTopoJets_e_PreSamplerE;
   vector<float>   *jet_AntiKt4LCTopoJets_e_EME1;
   vector<float>   *jet_AntiKt4LCTopoJets_e_EME2;
   vector<float>   *jet_AntiKt4LCTopoJets_e_EME3;
   vector<float>   *jet_AntiKt4LCTopoJets_e_HEC0;
   vector<float>   *jet_AntiKt4LCTopoJets_e_HEC1;
   vector<float>   *jet_AntiKt4LCTopoJets_e_HEC2;
   vector<float>   *jet_AntiKt4LCTopoJets_e_HEC3;
   vector<float>   *jet_AntiKt4LCTopoJets_e_TileBar0;
   vector<float>   *jet_AntiKt4LCTopoJets_e_TileBar1;
   vector<float>   *jet_AntiKt4LCTopoJets_e_TileBar2;
   vector<float>   *jet_AntiKt4LCTopoJets_e_TileGap1;
   vector<float>   *jet_AntiKt4LCTopoJets_e_TileGap2;
   vector<float>   *jet_AntiKt4LCTopoJets_e_TileGap3;
   vector<float>   *jet_AntiKt4LCTopoJets_e_TileExt0;
   vector<float>   *jet_AntiKt4LCTopoJets_e_TileExt1;
   vector<float>   *jet_AntiKt4LCTopoJets_e_TileExt2;
   vector<float>   *jet_AntiKt4LCTopoJets_e_FCAL0;
   vector<float>   *jet_AntiKt4LCTopoJets_e_FCAL1;
   vector<float>   *jet_AntiKt4LCTopoJets_e_FCAL2;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_weight_Comb;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_weight_IP2D;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_weight_IP3D;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_weight_SV0;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_weight_SV1;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_weight_SV2;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_weight_JetProb;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_weight_SoftMuonTag;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_weight_JetFitterTagNN;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_weight_JetFitterCOMBNN;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_weight_GbbNN;
   vector<int>     *jet_AntiKt4LCTopoJets_flavor_component_svp_isValid;
   vector<int>     *jet_AntiKt4LCTopoJets_flavor_component_svp_ntrkv;
   vector<int>     *jet_AntiKt4LCTopoJets_flavor_component_svp_ntrkj;
   vector<int>     *jet_AntiKt4LCTopoJets_flavor_component_svp_n2t;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_svp_mass;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_svp_efrc;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_svp_x;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_svp_y;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_svp_z;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_svp_err_x;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_svp_err_y;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_svp_err_z;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_svp_cov_xy;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_svp_cov_xz;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_svp_cov_yz;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_svp_chi2;
   vector<int>     *jet_AntiKt4LCTopoJets_flavor_component_svp_ndof;
   vector<int>     *jet_AntiKt4LCTopoJets_flavor_component_svp_ntrk;
   vector<int>     *jet_AntiKt4LCTopoJets_flavor_component_sv0p_isValid;
   vector<int>     *jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrkv;
   vector<int>     *jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrkj;
   vector<int>     *jet_AntiKt4LCTopoJets_flavor_component_sv0p_n2t;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_sv0p_mass;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_sv0p_efrc;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_sv0p_x;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_sv0p_y;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_sv0p_z;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_x;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_y;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_z;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_xy;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_xz;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_yz;
   vector<float>   *jet_AntiKt4LCTopoJets_flavor_component_sv0p_chi2;
   vector<int>     *jet_AntiKt4LCTopoJets_flavor_component_sv0p_ndof;
   vector<int>     *jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrk;
   vector<float>   *jet_AntiKt4LCTopoJets_el_dr;
   vector<int>     *jet_AntiKt4LCTopoJets_el_matched;
   vector<float>   *jet_AntiKt4LCTopoJets_mu_dr;
   vector<int>     *jet_AntiKt4LCTopoJets_mu_matched;
   vector<float>   *jet_AntiKt4LCTopoJets_L1_dr;
   vector<int>     *jet_AntiKt4LCTopoJets_L1_matched;
   vector<float>   *jet_AntiKt4LCTopoJets_L2_dr;
   vector<int>     *jet_AntiKt4LCTopoJets_L2_matched;
   vector<float>   *jet_AntiKt4LCTopoJets_EF_dr;
   vector<int>     *jet_AntiKt4LCTopoJets_EF_matched;
   Int_t           vxp_n;
   vector<float>   *vxp_x;
   vector<float>   *vxp_y;
   vector<float>   *vxp_z;
   vector<float>   *vxp_err_x;
   vector<float>   *vxp_err_y;
   vector<float>   *vxp_err_z;
   vector<float>   *vxp_cov_xy;
   vector<float>   *vxp_cov_xz;
   vector<float>   *vxp_cov_yz;
   vector<int>     *vxp_type;
   vector<float>   *vxp_chi2;
   vector<int>     *vxp_ndof;
   vector<float>   *vxp_px;
   vector<float>   *vxp_py;
   vector<float>   *vxp_pz;
   vector<float>   *vxp_E;
   vector<float>   *vxp_m;
   vector<int>     *vxp_nTracks;
   vector<float>   *vxp_sumPt;
   vector<int>     *vxp_trk_n;
   vector<vector<float> > *vxp_trk_weight;
   vector<vector<int> > *vxp_trk_index;
   Int_t           top_hfor_type;
   Float_t         MET_RefEle_em_tight_etx;
   Float_t         MET_RefEle_em_tight_ety;
   Float_t         MET_RefEle_em_tight_phi;
   Float_t         MET_RefEle_em_tight_et;
   Float_t         MET_RefEle_em_tight_sumet;
   Float_t         MET_RefEle_em_medium_etx;
   Float_t         MET_RefEle_em_medium_ety;
   Float_t         MET_RefEle_em_medium_phi;
   Float_t         MET_RefEle_em_medium_et;
   Float_t         MET_RefEle_em_medium_sumet;
   Float_t         MET_RefEle_em_loose_etx;
   Float_t         MET_RefEle_em_loose_ety;
   Float_t         MET_RefEle_em_loose_phi;
   Float_t         MET_RefEle_em_loose_et;
   Float_t         MET_RefEle_em_loose_sumet;
   Float_t         MET_RefEle_4lc_tight_etx;
   Float_t         MET_RefEle_4lc_tight_ety;
   Float_t         MET_RefEle_4lc_tight_phi;
   Float_t         MET_RefEle_4lc_tight_et;
   Float_t         MET_RefEle_4lc_tight_sumet;
   Float_t         MET_RefEle_4lc_medium_etx;
   Float_t         MET_RefEle_4lc_medium_ety;
   Float_t         MET_RefEle_4lc_medium_phi;
   Float_t         MET_RefEle_4lc_medium_et;
   Float_t         MET_RefEle_4lc_medium_sumet;
   Float_t         MET_RefEle_4lc_loose_etx;
   Float_t         MET_RefEle_4lc_loose_ety;
   Float_t         MET_RefEle_4lc_loose_phi;
   Float_t         MET_RefEle_4lc_loose_et;
   Float_t         MET_RefEle_4lc_loose_sumet;
   Float_t         MET_RefEle_em_medium_photon_etx;
   Float_t         MET_RefEle_em_medium_photon_ety;
   Float_t         MET_RefEle_em_medium_photon_phi;
   Float_t         MET_RefEle_em_medium_photon_et;
   Float_t         MET_RefEle_em_medium_photon_sumet;
   Float_t         MET_RefEle_em_tight_photon_etx;
   Float_t         MET_RefEle_em_tight_photon_ety;
   Float_t         MET_RefEle_em_tight_photon_phi;
   Float_t         MET_RefEle_em_tight_photon_et;
   Float_t         MET_RefEle_em_tight_photon_sumet;
   Float_t         MET_RefEle_4lc_tight_photon_etx;
   Float_t         MET_RefEle_4lc_tight_photon_ety;
   Float_t         MET_RefEle_4lc_tight_photon_phi;
   Float_t         MET_RefEle_4lc_tight_photon_et;
   Float_t         MET_RefEle_4lc_tight_photon_sumet;
   Float_t         MET_RefEle_4lc_medium_photon_etx;
   Float_t         MET_RefEle_4lc_medium_photon_ety;
   Float_t         MET_RefEle_4lc_medium_photon_phi;
   Float_t         MET_RefEle_4lc_medium_photon_et;
   Float_t         MET_RefEle_4lc_medium_photon_sumet;
   Float_t         MET_RefJet_em_tight_etx;
   Float_t         MET_RefJet_em_tight_ety;
   Float_t         MET_RefJet_em_tight_phi;
   Float_t         MET_RefJet_em_tight_et;
   Float_t         MET_RefJet_em_tight_sumet;
   Float_t         MET_RefJet_em_medium_etx;
   Float_t         MET_RefJet_em_medium_ety;
   Float_t         MET_RefJet_em_medium_phi;
   Float_t         MET_RefJet_em_medium_et;
   Float_t         MET_RefJet_em_medium_sumet;
   Float_t         MET_RefJet_em_loose_etx;
   Float_t         MET_RefJet_em_loose_ety;
   Float_t         MET_RefJet_em_loose_phi;
   Float_t         MET_RefJet_em_loose_et;
   Float_t         MET_RefJet_em_loose_sumet;
   Float_t         MET_RefJet_4lc_tight_etx;
   Float_t         MET_RefJet_4lc_tight_ety;
   Float_t         MET_RefJet_4lc_tight_phi;
   Float_t         MET_RefJet_4lc_tight_et;
   Float_t         MET_RefJet_4lc_tight_sumet;
   Float_t         MET_RefJet_4lc_medium_etx;
   Float_t         MET_RefJet_4lc_medium_ety;
   Float_t         MET_RefJet_4lc_medium_phi;
   Float_t         MET_RefJet_4lc_medium_et;
   Float_t         MET_RefJet_4lc_medium_sumet;
   Float_t         MET_RefJet_4lc_loose_etx;
   Float_t         MET_RefJet_4lc_loose_ety;
   Float_t         MET_RefJet_4lc_loose_phi;
   Float_t         MET_RefJet_4lc_loose_et;
   Float_t         MET_RefJet_4lc_loose_sumet;
   Float_t         MET_RefJet_em_medium_photon_etx;
   Float_t         MET_RefJet_em_medium_photon_ety;
   Float_t         MET_RefJet_em_medium_photon_phi;
   Float_t         MET_RefJet_em_medium_photon_et;
   Float_t         MET_RefJet_em_medium_photon_sumet;
   Float_t         MET_RefJet_em_tight_photon_etx;
   Float_t         MET_RefJet_em_tight_photon_ety;
   Float_t         MET_RefJet_em_tight_photon_phi;
   Float_t         MET_RefJet_em_tight_photon_et;
   Float_t         MET_RefJet_em_tight_photon_sumet;
   Float_t         MET_RefJet_4lc_tight_photon_etx;
   Float_t         MET_RefJet_4lc_tight_photon_ety;
   Float_t         MET_RefJet_4lc_tight_photon_phi;
   Float_t         MET_RefJet_4lc_tight_photon_et;
   Float_t         MET_RefJet_4lc_tight_photon_sumet;
   Float_t         MET_RefJet_4lc_medium_photon_etx;
   Float_t         MET_RefJet_4lc_medium_photon_ety;
   Float_t         MET_RefJet_4lc_medium_photon_phi;
   Float_t         MET_RefJet_4lc_medium_photon_et;
   Float_t         MET_RefJet_4lc_medium_photon_sumet;
   Float_t         MET_SoftJets_em_tight_etx;
   Float_t         MET_SoftJets_em_tight_ety;
   Float_t         MET_SoftJets_em_tight_phi;
   Float_t         MET_SoftJets_em_tight_et;
   Float_t         MET_SoftJets_em_tight_sumet;
   Float_t         MET_SoftJets_em_medium_etx;
   Float_t         MET_SoftJets_em_medium_ety;
   Float_t         MET_SoftJets_em_medium_phi;
   Float_t         MET_SoftJets_em_medium_et;
   Float_t         MET_SoftJets_em_medium_sumet;
   Float_t         MET_SoftJets_em_loose_etx;
   Float_t         MET_SoftJets_em_loose_ety;
   Float_t         MET_SoftJets_em_loose_phi;
   Float_t         MET_SoftJets_em_loose_et;
   Float_t         MET_SoftJets_em_loose_sumet;
   Float_t         MET_SoftJets_4lc_tight_etx;
   Float_t         MET_SoftJets_4lc_tight_ety;
   Float_t         MET_SoftJets_4lc_tight_phi;
   Float_t         MET_SoftJets_4lc_tight_et;
   Float_t         MET_SoftJets_4lc_tight_sumet;
   Float_t         MET_SoftJets_4lc_medium_etx;
   Float_t         MET_SoftJets_4lc_medium_ety;
   Float_t         MET_SoftJets_4lc_medium_phi;
   Float_t         MET_SoftJets_4lc_medium_et;
   Float_t         MET_SoftJets_4lc_medium_sumet;
   Float_t         MET_SoftJets_4lc_loose_etx;
   Float_t         MET_SoftJets_4lc_loose_ety;
   Float_t         MET_SoftJets_4lc_loose_phi;
   Float_t         MET_SoftJets_4lc_loose_et;
   Float_t         MET_SoftJets_4lc_loose_sumet;
   Float_t         MET_SoftJets_em_medium_photon_etx;
   Float_t         MET_SoftJets_em_medium_photon_ety;
   Float_t         MET_SoftJets_em_medium_photon_phi;
   Float_t         MET_SoftJets_em_medium_photon_et;
   Float_t         MET_SoftJets_em_medium_photon_sumet;
   Float_t         MET_SoftJets_em_tight_photon_etx;
   Float_t         MET_SoftJets_em_tight_photon_ety;
   Float_t         MET_SoftJets_em_tight_photon_phi;
   Float_t         MET_SoftJets_em_tight_photon_et;
   Float_t         MET_SoftJets_em_tight_photon_sumet;
   Float_t         MET_SoftJets_4lc_tight_photon_etx;
   Float_t         MET_SoftJets_4lc_tight_photon_ety;
   Float_t         MET_SoftJets_4lc_tight_photon_phi;
   Float_t         MET_SoftJets_4lc_tight_photon_et;
   Float_t         MET_SoftJets_4lc_tight_photon_sumet;
   Float_t         MET_SoftJets_4lc_medium_photon_etx;
   Float_t         MET_SoftJets_4lc_medium_photon_ety;
   Float_t         MET_SoftJets_4lc_medium_photon_phi;
   Float_t         MET_SoftJets_4lc_medium_photon_et;
   Float_t         MET_SoftJets_4lc_medium_photon_sumet;
   Float_t         MET_CellOut_em_tight_etx;
   Float_t         MET_CellOut_em_tight_ety;
   Float_t         MET_CellOut_em_tight_phi;
   Float_t         MET_CellOut_em_tight_et;
   Float_t         MET_CellOut_em_tight_sumet;
   Float_t         MET_CellOut_em_medium_etx;
   Float_t         MET_CellOut_em_medium_ety;
   Float_t         MET_CellOut_em_medium_phi;
   Float_t         MET_CellOut_em_medium_et;
   Float_t         MET_CellOut_em_medium_sumet;
   Float_t         MET_CellOut_em_loose_etx;
   Float_t         MET_CellOut_em_loose_ety;
   Float_t         MET_CellOut_em_loose_phi;
   Float_t         MET_CellOut_em_loose_et;
   Float_t         MET_CellOut_em_loose_sumet;
   Float_t         MET_CellOut_4lc_tight_etx;
   Float_t         MET_CellOut_4lc_tight_ety;
   Float_t         MET_CellOut_4lc_tight_phi;
   Float_t         MET_CellOut_4lc_tight_et;
   Float_t         MET_CellOut_4lc_tight_sumet;
   Float_t         MET_CellOut_4lc_medium_etx;
   Float_t         MET_CellOut_4lc_medium_ety;
   Float_t         MET_CellOut_4lc_medium_phi;
   Float_t         MET_CellOut_4lc_medium_et;
   Float_t         MET_CellOut_4lc_medium_sumet;
   Float_t         MET_CellOut_4lc_loose_etx;
   Float_t         MET_CellOut_4lc_loose_ety;
   Float_t         MET_CellOut_4lc_loose_phi;
   Float_t         MET_CellOut_4lc_loose_et;
   Float_t         MET_CellOut_4lc_loose_sumet;
   Float_t         MET_CellOut_em_medium_photon_etx;
   Float_t         MET_CellOut_em_medium_photon_ety;
   Float_t         MET_CellOut_em_medium_photon_phi;
   Float_t         MET_CellOut_em_medium_photon_et;
   Float_t         MET_CellOut_em_medium_photon_sumet;
   Float_t         MET_CellOut_em_tight_photon_etx;
   Float_t         MET_CellOut_em_tight_photon_ety;
   Float_t         MET_CellOut_em_tight_photon_phi;
   Float_t         MET_CellOut_em_tight_photon_et;
   Float_t         MET_CellOut_em_tight_photon_sumet;
   Float_t         MET_CellOut_4lc_tight_photon_etx;
   Float_t         MET_CellOut_4lc_tight_photon_ety;
   Float_t         MET_CellOut_4lc_tight_photon_phi;
   Float_t         MET_CellOut_4lc_tight_photon_et;
   Float_t         MET_CellOut_4lc_tight_photon_sumet;
   Float_t         MET_CellOut_4lc_medium_photon_etx;
   Float_t         MET_CellOut_4lc_medium_photon_ety;
   Float_t         MET_CellOut_4lc_medium_photon_phi;
   Float_t         MET_CellOut_4lc_medium_photon_et;
   Float_t         MET_CellOut_4lc_medium_photon_sumet;
   Float_t         MET_Muon_Isol_Muid_em_tight_etx;
   Float_t         MET_Muon_Isol_Muid_em_tight_ety;
   Float_t         MET_Muon_Isol_Muid_em_tight_phi;
   Float_t         MET_Muon_Isol_Muid_em_tight_et;
   Float_t         MET_Muon_Isol_Muid_em_tight_sumet;
   Float_t         MET_Muon_Isol_Muid_em_medium_etx;
   Float_t         MET_Muon_Isol_Muid_em_medium_ety;
   Float_t         MET_Muon_Isol_Muid_em_medium_phi;
   Float_t         MET_Muon_Isol_Muid_em_medium_et;
   Float_t         MET_Muon_Isol_Muid_em_medium_sumet;
   Float_t         MET_Muon_Isol_Muid_em_loose_etx;
   Float_t         MET_Muon_Isol_Muid_em_loose_ety;
   Float_t         MET_Muon_Isol_Muid_em_loose_phi;
   Float_t         MET_Muon_Isol_Muid_em_loose_et;
   Float_t         MET_Muon_Isol_Muid_em_loose_sumet;
   Float_t         MET_Muon_Isol_Muid_4lc_tight_etx;
   Float_t         MET_Muon_Isol_Muid_4lc_tight_ety;
   Float_t         MET_Muon_Isol_Muid_4lc_tight_phi;
   Float_t         MET_Muon_Isol_Muid_4lc_tight_et;
   Float_t         MET_Muon_Isol_Muid_4lc_tight_sumet;
   Float_t         MET_Muon_Isol_Muid_4lc_medium_etx;
   Float_t         MET_Muon_Isol_Muid_4lc_medium_ety;
   Float_t         MET_Muon_Isol_Muid_4lc_medium_phi;
   Float_t         MET_Muon_Isol_Muid_4lc_medium_et;
   Float_t         MET_Muon_Isol_Muid_4lc_medium_sumet;
   Float_t         MET_Muon_Isol_Muid_4lc_loose_etx;
   Float_t         MET_Muon_Isol_Muid_4lc_loose_ety;
   Float_t         MET_Muon_Isol_Muid_4lc_loose_phi;
   Float_t         MET_Muon_Isol_Muid_4lc_loose_et;
   Float_t         MET_Muon_Isol_Muid_4lc_loose_sumet;
   Float_t         MET_Muon_Isol_Muid_em_medium_photon_etx;
   Float_t         MET_Muon_Isol_Muid_em_medium_photon_ety;
   Float_t         MET_Muon_Isol_Muid_em_medium_photon_phi;
   Float_t         MET_Muon_Isol_Muid_em_medium_photon_et;
   Float_t         MET_Muon_Isol_Muid_em_medium_photon_sumet;
   Float_t         MET_Muon_Isol_Muid_em_tight_photon_etx;
   Float_t         MET_Muon_Isol_Muid_em_tight_photon_ety;
   Float_t         MET_Muon_Isol_Muid_em_tight_photon_phi;
   Float_t         MET_Muon_Isol_Muid_em_tight_photon_et;
   Float_t         MET_Muon_Isol_Muid_em_tight_photon_sumet;
   Float_t         MET_Muon_Isol_Muid_4lc_tight_photon_etx;
   Float_t         MET_Muon_Isol_Muid_4lc_tight_photon_ety;
   Float_t         MET_Muon_Isol_Muid_4lc_tight_photon_phi;
   Float_t         MET_Muon_Isol_Muid_4lc_tight_photon_et;
   Float_t         MET_Muon_Isol_Muid_4lc_tight_photon_sumet;
   Float_t         MET_Muon_Isol_Muid_4lc_medium_photon_etx;
   Float_t         MET_Muon_Isol_Muid_4lc_medium_photon_ety;
   Float_t         MET_Muon_Isol_Muid_4lc_medium_photon_phi;
   Float_t         MET_Muon_Isol_Muid_4lc_medium_photon_et;
   Float_t         MET_Muon_Isol_Muid_4lc_medium_photon_sumet;
   Float_t         MET_Muon_NonIsol_Muid_em_tight_etx;
   Float_t         MET_Muon_NonIsol_Muid_em_tight_ety;
   Float_t         MET_Muon_NonIsol_Muid_em_tight_phi;
   Float_t         MET_Muon_NonIsol_Muid_em_tight_et;
   Float_t         MET_Muon_NonIsol_Muid_em_tight_sumet;
   Float_t         MET_Muon_NonIsol_Muid_em_medium_etx;
   Float_t         MET_Muon_NonIsol_Muid_em_medium_ety;
   Float_t         MET_Muon_NonIsol_Muid_em_medium_phi;
   Float_t         MET_Muon_NonIsol_Muid_em_medium_et;
   Float_t         MET_Muon_NonIsol_Muid_em_medium_sumet;
   Float_t         MET_Muon_NonIsol_Muid_em_loose_etx;
   Float_t         MET_Muon_NonIsol_Muid_em_loose_ety;
   Float_t         MET_Muon_NonIsol_Muid_em_loose_phi;
   Float_t         MET_Muon_NonIsol_Muid_em_loose_et;
   Float_t         MET_Muon_NonIsol_Muid_em_loose_sumet;
   Float_t         MET_Muon_NonIsol_Muid_4lc_tight_etx;
   Float_t         MET_Muon_NonIsol_Muid_4lc_tight_ety;
   Float_t         MET_Muon_NonIsol_Muid_4lc_tight_phi;
   Float_t         MET_Muon_NonIsol_Muid_4lc_tight_et;
   Float_t         MET_Muon_NonIsol_Muid_4lc_tight_sumet;
   Float_t         MET_Muon_NonIsol_Muid_4lc_medium_etx;
   Float_t         MET_Muon_NonIsol_Muid_4lc_medium_ety;
   Float_t         MET_Muon_NonIsol_Muid_4lc_medium_phi;
   Float_t         MET_Muon_NonIsol_Muid_4lc_medium_et;
   Float_t         MET_Muon_NonIsol_Muid_4lc_medium_sumet;
   Float_t         MET_Muon_NonIsol_Muid_4lc_loose_etx;
   Float_t         MET_Muon_NonIsol_Muid_4lc_loose_ety;
   Float_t         MET_Muon_NonIsol_Muid_4lc_loose_phi;
   Float_t         MET_Muon_NonIsol_Muid_4lc_loose_et;
   Float_t         MET_Muon_NonIsol_Muid_4lc_loose_sumet;
   Float_t         MET_Muon_NonIsol_Muid_em_medium_photon_etx;
   Float_t         MET_Muon_NonIsol_Muid_em_medium_photon_ety;
   Float_t         MET_Muon_NonIsol_Muid_em_medium_photon_phi;
   Float_t         MET_Muon_NonIsol_Muid_em_medium_photon_et;
   Float_t         MET_Muon_NonIsol_Muid_em_medium_photon_sumet;
   Float_t         MET_Muon_NonIsol_Muid_em_tight_photon_etx;
   Float_t         MET_Muon_NonIsol_Muid_em_tight_photon_ety;
   Float_t         MET_Muon_NonIsol_Muid_em_tight_photon_phi;
   Float_t         MET_Muon_NonIsol_Muid_em_tight_photon_et;
   Float_t         MET_Muon_NonIsol_Muid_em_tight_photon_sumet;
   Float_t         MET_Muon_NonIsol_Muid_4lc_tight_photon_etx;
   Float_t         MET_Muon_NonIsol_Muid_4lc_tight_photon_ety;
   Float_t         MET_Muon_NonIsol_Muid_4lc_tight_photon_phi;
   Float_t         MET_Muon_NonIsol_Muid_4lc_tight_photon_et;
   Float_t         MET_Muon_NonIsol_Muid_4lc_tight_photon_sumet;
   Float_t         MET_Muon_NonIsol_Muid_4lc_medium_photon_etx;
   Float_t         MET_Muon_NonIsol_Muid_4lc_medium_photon_ety;
   Float_t         MET_Muon_NonIsol_Muid_4lc_medium_photon_phi;
   Float_t         MET_Muon_NonIsol_Muid_4lc_medium_photon_et;
   Float_t         MET_Muon_NonIsol_Muid_4lc_medium_photon_sumet;
   Float_t         MET_Muon_Total_Muid_em_tight_etx;
   Float_t         MET_Muon_Total_Muid_em_tight_ety;
   Float_t         MET_Muon_Total_Muid_em_tight_phi;
   Float_t         MET_Muon_Total_Muid_em_tight_et;
   Float_t         MET_Muon_Total_Muid_em_tight_sumet;
   Float_t         MET_Muon_Total_Muid_em_medium_etx;
   Float_t         MET_Muon_Total_Muid_em_medium_ety;
   Float_t         MET_Muon_Total_Muid_em_medium_phi;
   Float_t         MET_Muon_Total_Muid_em_medium_et;
   Float_t         MET_Muon_Total_Muid_em_medium_sumet;
   Float_t         MET_Muon_Total_Muid_em_loose_etx;
   Float_t         MET_Muon_Total_Muid_em_loose_ety;
   Float_t         MET_Muon_Total_Muid_em_loose_phi;
   Float_t         MET_Muon_Total_Muid_em_loose_et;
   Float_t         MET_Muon_Total_Muid_em_loose_sumet;
   Float_t         MET_Muon_Total_Muid_4lc_tight_etx;
   Float_t         MET_Muon_Total_Muid_4lc_tight_ety;
   Float_t         MET_Muon_Total_Muid_4lc_tight_phi;
   Float_t         MET_Muon_Total_Muid_4lc_tight_et;
   Float_t         MET_Muon_Total_Muid_4lc_tight_sumet;
   Float_t         MET_Muon_Total_Muid_4lc_medium_etx;
   Float_t         MET_Muon_Total_Muid_4lc_medium_ety;
   Float_t         MET_Muon_Total_Muid_4lc_medium_phi;
   Float_t         MET_Muon_Total_Muid_4lc_medium_et;
   Float_t         MET_Muon_Total_Muid_4lc_medium_sumet;
   Float_t         MET_Muon_Total_Muid_4lc_loose_etx;
   Float_t         MET_Muon_Total_Muid_4lc_loose_ety;
   Float_t         MET_Muon_Total_Muid_4lc_loose_phi;
   Float_t         MET_Muon_Total_Muid_4lc_loose_et;
   Float_t         MET_Muon_Total_Muid_4lc_loose_sumet;
   Float_t         MET_Muon_Total_Muid_em_medium_photon_etx;
   Float_t         MET_Muon_Total_Muid_em_medium_photon_ety;
   Float_t         MET_Muon_Total_Muid_em_medium_photon_phi;
   Float_t         MET_Muon_Total_Muid_em_medium_photon_et;
   Float_t         MET_Muon_Total_Muid_em_medium_photon_sumet;
   Float_t         MET_Muon_Total_Muid_em_tight_photon_etx;
   Float_t         MET_Muon_Total_Muid_em_tight_photon_ety;
   Float_t         MET_Muon_Total_Muid_em_tight_photon_phi;
   Float_t         MET_Muon_Total_Muid_em_tight_photon_et;
   Float_t         MET_Muon_Total_Muid_em_tight_photon_sumet;
   Float_t         MET_Muon_Total_Muid_4lc_tight_photon_etx;
   Float_t         MET_Muon_Total_Muid_4lc_tight_photon_ety;
   Float_t         MET_Muon_Total_Muid_4lc_tight_photon_phi;
   Float_t         MET_Muon_Total_Muid_4lc_tight_photon_et;
   Float_t         MET_Muon_Total_Muid_4lc_tight_photon_sumet;
   Float_t         MET_Muon_Total_Muid_4lc_medium_photon_etx;
   Float_t         MET_Muon_Total_Muid_4lc_medium_photon_ety;
   Float_t         MET_Muon_Total_Muid_4lc_medium_photon_phi;
   Float_t         MET_Muon_Total_Muid_4lc_medium_photon_et;
   Float_t         MET_Muon_Total_Muid_4lc_medium_photon_sumet;
   Float_t         MET_RefGamma_em_tight_etx;
   Float_t         MET_RefGamma_em_tight_ety;
   Float_t         MET_RefGamma_em_tight_phi;
   Float_t         MET_RefGamma_em_tight_et;
   Float_t         MET_RefGamma_em_tight_sumet;
   Float_t         MET_RefGamma_em_medium_etx;
   Float_t         MET_RefGamma_em_medium_ety;
   Float_t         MET_RefGamma_em_medium_phi;
   Float_t         MET_RefGamma_em_medium_et;
   Float_t         MET_RefGamma_em_medium_sumet;
   Float_t         MET_RefGamma_em_loose_etx;
   Float_t         MET_RefGamma_em_loose_ety;
   Float_t         MET_RefGamma_em_loose_phi;
   Float_t         MET_RefGamma_em_loose_et;
   Float_t         MET_RefGamma_em_loose_sumet;
   Float_t         MET_RefGamma_4lc_tight_etx;
   Float_t         MET_RefGamma_4lc_tight_ety;
   Float_t         MET_RefGamma_4lc_tight_phi;
   Float_t         MET_RefGamma_4lc_tight_et;
   Float_t         MET_RefGamma_4lc_tight_sumet;
   Float_t         MET_RefGamma_4lc_medium_etx;
   Float_t         MET_RefGamma_4lc_medium_ety;
   Float_t         MET_RefGamma_4lc_medium_phi;
   Float_t         MET_RefGamma_4lc_medium_et;
   Float_t         MET_RefGamma_4lc_medium_sumet;
   Float_t         MET_RefGamma_4lc_loose_etx;
   Float_t         MET_RefGamma_4lc_loose_ety;
   Float_t         MET_RefGamma_4lc_loose_phi;
   Float_t         MET_RefGamma_4lc_loose_et;
   Float_t         MET_RefGamma_4lc_loose_sumet;
   Float_t         MET_RefGamma_em_medium_photon_etx;
   Float_t         MET_RefGamma_em_medium_photon_ety;
   Float_t         MET_RefGamma_em_medium_photon_phi;
   Float_t         MET_RefGamma_em_medium_photon_et;
   Float_t         MET_RefGamma_em_medium_photon_sumet;
   Float_t         MET_RefGamma_em_tight_photon_etx;
   Float_t         MET_RefGamma_em_tight_photon_ety;
   Float_t         MET_RefGamma_em_tight_photon_phi;
   Float_t         MET_RefGamma_em_tight_photon_et;
   Float_t         MET_RefGamma_em_tight_photon_sumet;
   Float_t         MET_RefGamma_4lc_tight_photon_etx;
   Float_t         MET_RefGamma_4lc_tight_photon_ety;
   Float_t         MET_RefGamma_4lc_tight_photon_phi;
   Float_t         MET_RefGamma_4lc_tight_photon_et;
   Float_t         MET_RefGamma_4lc_tight_photon_sumet;
   Float_t         MET_RefGamma_4lc_medium_photon_etx;
   Float_t         MET_RefGamma_4lc_medium_photon_ety;
   Float_t         MET_RefGamma_4lc_medium_photon_phi;
   Float_t         MET_RefGamma_4lc_medium_photon_et;
   Float_t         MET_RefGamma_4lc_medium_photon_sumet;
   Float_t         MET_RefFinal_em_tight_etx;
   Float_t         MET_RefFinal_em_tight_ety;
   Float_t         MET_RefFinal_em_tight_phi;
   Float_t         MET_RefFinal_em_tight_et;
   Float_t         MET_RefFinal_em_tight_sumet;
   Float_t         MET_RefFinal_em_medium_etx;
   Float_t         MET_RefFinal_em_medium_ety;
   Float_t         MET_RefFinal_em_medium_phi;
   Float_t         MET_RefFinal_em_medium_et;
   Float_t         MET_RefFinal_em_medium_sumet;
   Float_t         MET_RefFinal_em_loose_etx;
   Float_t         MET_RefFinal_em_loose_ety;
   Float_t         MET_RefFinal_em_loose_phi;
   Float_t         MET_RefFinal_em_loose_et;
   Float_t         MET_RefFinal_em_loose_sumet;
   Float_t         MET_RefFinal_4lc_tight_etx;
   Float_t         MET_RefFinal_4lc_tight_ety;
   Float_t         MET_RefFinal_4lc_tight_phi;
   Float_t         MET_RefFinal_4lc_tight_et;
   Float_t         MET_RefFinal_4lc_tight_sumet;
   Float_t         MET_RefFinal_4lc_medium_etx;
   Float_t         MET_RefFinal_4lc_medium_ety;
   Float_t         MET_RefFinal_4lc_medium_phi;
   Float_t         MET_RefFinal_4lc_medium_et;
   Float_t         MET_RefFinal_4lc_medium_sumet;
   Float_t         MET_RefFinal_4lc_loose_etx;
   Float_t         MET_RefFinal_4lc_loose_ety;
   Float_t         MET_RefFinal_4lc_loose_phi;
   Float_t         MET_RefFinal_4lc_loose_et;
   Float_t         MET_RefFinal_4lc_loose_sumet;
   Float_t         MET_RefFinal_em_medium_photon_etx;
   Float_t         MET_RefFinal_em_medium_photon_ety;
   Float_t         MET_RefFinal_em_medium_photon_phi;
   Float_t         MET_RefFinal_em_medium_photon_et;
   Float_t         MET_RefFinal_em_medium_photon_sumet;
   Float_t         MET_RefFinal_em_tight_photon_etx;
   Float_t         MET_RefFinal_em_tight_photon_ety;
   Float_t         MET_RefFinal_em_tight_photon_phi;
   Float_t         MET_RefFinal_em_tight_photon_et;
   Float_t         MET_RefFinal_em_tight_photon_sumet;
   Float_t         MET_RefFinal_4lc_tight_photon_etx;
   Float_t         MET_RefFinal_4lc_tight_photon_ety;
   Float_t         MET_RefFinal_4lc_tight_photon_phi;
   Float_t         MET_RefFinal_4lc_tight_photon_et;
   Float_t         MET_RefFinal_4lc_tight_photon_sumet;
   Float_t         MET_RefFinal_4lc_medium_photon_etx;
   Float_t         MET_RefFinal_4lc_medium_photon_ety;
   Float_t         MET_RefFinal_4lc_medium_photon_phi;
   Float_t         MET_RefFinal_4lc_medium_photon_et;
   Float_t         MET_RefFinal_4lc_medium_photon_sumet;
   Float_t         MET_RefFinal_em_etx;
   Float_t         MET_RefFinal_em_ety;
   Float_t         MET_RefFinal_em_phi;
   Float_t         MET_RefFinal_em_et;
   Float_t         MET_RefFinal_em_sumet;
   Float_t         MET_RefFinal_etx;
   Float_t         MET_RefFinal_ety;
   Float_t         MET_RefFinal_phi;
   Float_t         MET_RefFinal_et;
   Float_t         MET_RefFinal_sumet;
   Int_t           el_MET_em_tight_n;
   vector<vector<float> > *el_MET_em_tight_wpx;
   vector<vector<float> > *el_MET_em_tight_wpy;
   vector<vector<float> > *el_MET_em_tight_wet;
   vector<vector<unsigned int> > *el_MET_em_tight_statusWord;
   Int_t           ph_MET_em_tight_n;
   vector<vector<float> > *ph_MET_em_tight_wpx;
   vector<vector<float> > *ph_MET_em_tight_wpy;
   vector<vector<float> > *ph_MET_em_tight_wet;
   vector<vector<unsigned int> > *ph_MET_em_tight_statusWord;
   Int_t           mu_staco_MET_em_tight_n;
   vector<vector<float> > *mu_staco_MET_em_tight_wpx;
   vector<vector<float> > *mu_staco_MET_em_tight_wpy;
   vector<vector<float> > *mu_staco_MET_em_tight_wet;
   vector<vector<unsigned int> > *mu_staco_MET_em_tight_statusWord;
   Int_t           mu_muid_MET_em_tight_n;
   vector<vector<float> > *mu_muid_MET_em_tight_wpx;
   vector<vector<float> > *mu_muid_MET_em_tight_wpy;
   vector<vector<float> > *mu_muid_MET_em_tight_wet;
   vector<vector<unsigned int> > *mu_muid_MET_em_tight_statusWord;
   Int_t           jet_em_tight_n;
   vector<vector<float> > *jet_em_tight_wpx;
   vector<vector<float> > *jet_em_tight_wpy;
   vector<vector<float> > *jet_em_tight_wet;
   vector<vector<unsigned int> > *jet_em_tight_statusWord;
   Int_t           el_MET_em_medium_n;
   vector<vector<float> > *el_MET_em_medium_wpx;
   vector<vector<float> > *el_MET_em_medium_wpy;
   vector<vector<float> > *el_MET_em_medium_wet;
   vector<vector<unsigned int> > *el_MET_em_medium_statusWord;
   Int_t           ph_MET_em_medium_n;
   vector<vector<float> > *ph_MET_em_medium_wpx;
   vector<vector<float> > *ph_MET_em_medium_wpy;
   vector<vector<float> > *ph_MET_em_medium_wet;
   vector<vector<unsigned int> > *ph_MET_em_medium_statusWord;
   Int_t           mu_staco_MET_em_medium_n;
   vector<vector<float> > *mu_staco_MET_em_medium_wpx;
   vector<vector<float> > *mu_staco_MET_em_medium_wpy;
   vector<vector<float> > *mu_staco_MET_em_medium_wet;
   vector<vector<unsigned int> > *mu_staco_MET_em_medium_statusWord;
   Int_t           mu_muid_MET_em_medium_n;
   vector<vector<float> > *mu_muid_MET_em_medium_wpx;
   vector<vector<float> > *mu_muid_MET_em_medium_wpy;
   vector<vector<float> > *mu_muid_MET_em_medium_wet;
   vector<vector<unsigned int> > *mu_muid_MET_em_medium_statusWord;
   Int_t           jet_em_medium_n;
   vector<vector<float> > *jet_em_medium_wpx;
   vector<vector<float> > *jet_em_medium_wpy;
   vector<vector<float> > *jet_em_medium_wet;
   vector<vector<unsigned int> > *jet_em_medium_statusWord;
   Int_t           el_MET_em_loose_n;
   vector<vector<float> > *el_MET_em_loose_wpx;
   vector<vector<float> > *el_MET_em_loose_wpy;
   vector<vector<float> > *el_MET_em_loose_wet;
   vector<vector<unsigned int> > *el_MET_em_loose_statusWord;
   Int_t           ph_MET_em_loose_n;
   vector<vector<float> > *ph_MET_em_loose_wpx;
   vector<vector<float> > *ph_MET_em_loose_wpy;
   vector<vector<float> > *ph_MET_em_loose_wet;
   vector<vector<unsigned int> > *ph_MET_em_loose_statusWord;
   Int_t           mu_staco_MET_em_loose_n;
   vector<vector<float> > *mu_staco_MET_em_loose_wpx;
   vector<vector<float> > *mu_staco_MET_em_loose_wpy;
   vector<vector<float> > *mu_staco_MET_em_loose_wet;
   vector<vector<unsigned int> > *mu_staco_MET_em_loose_statusWord;
   Int_t           mu_muid_MET_em_loose_n;
   vector<vector<float> > *mu_muid_MET_em_loose_wpx;
   vector<vector<float> > *mu_muid_MET_em_loose_wpy;
   vector<vector<float> > *mu_muid_MET_em_loose_wet;
   vector<vector<unsigned int> > *mu_muid_MET_em_loose_statusWord;
   Int_t           jet_em_loose_n;
   vector<vector<float> > *jet_em_loose_wpx;
   vector<vector<float> > *jet_em_loose_wpy;
   vector<vector<float> > *jet_em_loose_wet;
   vector<vector<unsigned int> > *jet_em_loose_statusWord;
   Int_t           el_MET_4lc_loose_n;
   vector<vector<float> > *el_MET_4lc_loose_wpx;
   vector<vector<float> > *el_MET_4lc_loose_wpy;
   vector<vector<float> > *el_MET_4lc_loose_wet;
   vector<vector<unsigned int> > *el_MET_4lc_loose_statusWord;
   Int_t           ph_MET_4lc_loose_n;
   vector<vector<float> > *ph_MET_4lc_loose_wpx;
   vector<vector<float> > *ph_MET_4lc_loose_wpy;
   vector<vector<float> > *ph_MET_4lc_loose_wet;
   vector<vector<unsigned int> > *ph_MET_4lc_loose_statusWord;
   Int_t           mu_staco_MET_4lc_loose_n;
   vector<vector<float> > *mu_staco_MET_4lc_loose_wpx;
   vector<vector<float> > *mu_staco_MET_4lc_loose_wpy;
   vector<vector<float> > *mu_staco_MET_4lc_loose_wet;
   vector<vector<unsigned int> > *mu_staco_MET_4lc_loose_statusWord;
   Int_t           mu_muid_MET_4lc_loose_n;
   vector<vector<float> > *mu_muid_MET_4lc_loose_wpx;
   vector<vector<float> > *mu_muid_MET_4lc_loose_wpy;
   vector<vector<float> > *mu_muid_MET_4lc_loose_wet;
   vector<vector<unsigned int> > *mu_muid_MET_4lc_loose_statusWord;
   Int_t           jet_AntiKt4LCTopoJets_4lc_loose_n;
   vector<vector<float> > *jet_AntiKt4LCTopoJets_4lc_loose_wpx;
   vector<vector<float> > *jet_AntiKt4LCTopoJets_4lc_loose_wpy;
   vector<vector<float> > *jet_AntiKt4LCTopoJets_4lc_loose_wet;
   vector<vector<unsigned int> > *jet_AntiKt4LCTopoJets_4lc_loose_statusWord;
   Int_t           el_MET_4lc_medium_n;
   vector<vector<float> > *el_MET_4lc_medium_wpx;
   vector<vector<float> > *el_MET_4lc_medium_wpy;
   vector<vector<float> > *el_MET_4lc_medium_wet;
   vector<vector<unsigned int> > *el_MET_4lc_medium_statusWord;
   Int_t           ph_MET_4lc_medium_n;
   vector<vector<float> > *ph_MET_4lc_medium_wpx;
   vector<vector<float> > *ph_MET_4lc_medium_wpy;
   vector<vector<float> > *ph_MET_4lc_medium_wet;
   vector<vector<unsigned int> > *ph_MET_4lc_medium_statusWord;
   Int_t           mu_staco_MET_4lc_medium_n;
   vector<vector<float> > *mu_staco_MET_4lc_medium_wpx;
   vector<vector<float> > *mu_staco_MET_4lc_medium_wpy;
   vector<vector<float> > *mu_staco_MET_4lc_medium_wet;
   vector<vector<unsigned int> > *mu_staco_MET_4lc_medium_statusWord;
   Int_t           mu_muid_MET_4lc_medium_n;
   vector<vector<float> > *mu_muid_MET_4lc_medium_wpx;
   vector<vector<float> > *mu_muid_MET_4lc_medium_wpy;
   vector<vector<float> > *mu_muid_MET_4lc_medium_wet;
   vector<vector<unsigned int> > *mu_muid_MET_4lc_medium_statusWord;
   Int_t           jet_AntiKt4LCTopoJets_4lc_medium_n;
   vector<vector<float> > *jet_AntiKt4LCTopoJets_4lc_medium_wpx;
   vector<vector<float> > *jet_AntiKt4LCTopoJets_4lc_medium_wpy;
   vector<vector<float> > *jet_AntiKt4LCTopoJets_4lc_medium_wet;
   vector<vector<unsigned int> > *jet_AntiKt4LCTopoJets_4lc_medium_statusWord;
   Int_t           el_MET_4lc_tight_n;
   vector<vector<float> > *el_MET_4lc_tight_wpx;
   vector<vector<float> > *el_MET_4lc_tight_wpy;
   vector<vector<float> > *el_MET_4lc_tight_wet;
   vector<vector<unsigned int> > *el_MET_4lc_tight_statusWord;
   Int_t           ph_MET_4lc_tight_n;
   vector<vector<float> > *ph_MET_4lc_tight_wpx;
   vector<vector<float> > *ph_MET_4lc_tight_wpy;
   vector<vector<float> > *ph_MET_4lc_tight_wet;
   vector<vector<unsigned int> > *ph_MET_4lc_tight_statusWord;
   Int_t           mu_staco_MET_4lc_tight_n;
   vector<vector<float> > *mu_staco_MET_4lc_tight_wpx;
   vector<vector<float> > *mu_staco_MET_4lc_tight_wpy;
   vector<vector<float> > *mu_staco_MET_4lc_tight_wet;
   vector<vector<unsigned int> > *mu_staco_MET_4lc_tight_statusWord;
   Int_t           mu_muid_MET_4lc_tight_n;
   vector<vector<float> > *mu_muid_MET_4lc_tight_wpx;
   vector<vector<float> > *mu_muid_MET_4lc_tight_wpy;
   vector<vector<float> > *mu_muid_MET_4lc_tight_wet;
   vector<vector<unsigned int> > *mu_muid_MET_4lc_tight_statusWord;
   Int_t           jet_AntiKt4LCTopoJets_4lc_tight_n;
   vector<vector<float> > *jet_AntiKt4LCTopoJets_4lc_tight_wpx;
   vector<vector<float> > *jet_AntiKt4LCTopoJets_4lc_tight_wpy;
   vector<vector<float> > *jet_AntiKt4LCTopoJets_4lc_tight_wet;
   vector<vector<unsigned int> > *jet_AntiKt4LCTopoJets_4lc_tight_statusWord;
   Int_t           el_MET_6lc_tight_n;
   vector<vector<float> > *el_MET_6lc_tight_wpx;
   vector<vector<float> > *el_MET_6lc_tight_wpy;
   vector<vector<float> > *el_MET_6lc_tight_wet;
   vector<vector<unsigned int> > *el_MET_6lc_tight_statusWord;
   Int_t           ph_MET_6lc_tight_n;
   vector<vector<float> > *ph_MET_6lc_tight_wpx;
   vector<vector<float> > *ph_MET_6lc_tight_wpy;
   vector<vector<float> > *ph_MET_6lc_tight_wet;
   vector<vector<unsigned int> > *ph_MET_6lc_tight_statusWord;
   Int_t           mu_staco_MET_6lc_tight_n;
   vector<vector<float> > *mu_staco_MET_6lc_tight_wpx;
   vector<vector<float> > *mu_staco_MET_6lc_tight_wpy;
   vector<vector<float> > *mu_staco_MET_6lc_tight_wet;
   vector<vector<unsigned int> > *mu_staco_MET_6lc_tight_statusWord;
   Int_t           mu_muid_MET_6lc_tight_n;
   vector<vector<float> > *mu_muid_MET_6lc_tight_wpx;
   vector<vector<float> > *mu_muid_MET_6lc_tight_wpy;
   vector<vector<float> > *mu_muid_MET_6lc_tight_wet;
   vector<vector<unsigned int> > *mu_muid_MET_6lc_tight_statusWord;
   Int_t           jet_AntiKt6LCTopoJets_6lc_tight_n;
   vector<vector<float> > *jet_AntiKt6LCTopoJets_6lc_tight_wpx;
   vector<vector<float> > *jet_AntiKt6LCTopoJets_6lc_tight_wpy;
   vector<vector<float> > *jet_AntiKt6LCTopoJets_6lc_tight_wet;
   vector<vector<unsigned int> > *jet_AntiKt6LCTopoJets_6lc_tight_statusWord;
   Int_t           el_MET_em_medium_photon_n;
   vector<vector<float> > *el_MET_em_medium_photon_wpx;
   vector<vector<float> > *el_MET_em_medium_photon_wpy;
   vector<vector<float> > *el_MET_em_medium_photon_wet;
   vector<vector<unsigned int> > *el_MET_em_medium_photon_statusWord;
   Int_t           ph_MET_em_medium_photon_n;
   vector<vector<float> > *ph_MET_em_medium_photon_wpx;
   vector<vector<float> > *ph_MET_em_medium_photon_wpy;
   vector<vector<float> > *ph_MET_em_medium_photon_wet;
   vector<vector<unsigned int> > *ph_MET_em_medium_photon_statusWord;
   Int_t           mu_staco_MET_em_medium_photon_n;
   vector<vector<float> > *mu_staco_MET_em_medium_photon_wpx;
   vector<vector<float> > *mu_staco_MET_em_medium_photon_wpy;
   vector<vector<float> > *mu_staco_MET_em_medium_photon_wet;
   vector<vector<unsigned int> > *mu_staco_MET_em_medium_photon_statusWord;
   Int_t           mu_muid_MET_em_medium_photon_n;
   vector<vector<float> > *mu_muid_MET_em_medium_photon_wpx;
   vector<vector<float> > *mu_muid_MET_em_medium_photon_wpy;
   vector<vector<float> > *mu_muid_MET_em_medium_photon_wet;
   vector<vector<unsigned int> > *mu_muid_MET_em_medium_photon_statusWord;
   Int_t           jet_em_medium_photon_n;
   vector<vector<float> > *jet_em_medium_photon_wpx;
   vector<vector<float> > *jet_em_medium_photon_wpy;
   vector<vector<float> > *jet_em_medium_photon_wet;
   vector<vector<unsigned int> > *jet_em_medium_photon_statusWord;
   Int_t           el_MET_em_tight_photon_n;
   vector<vector<float> > *el_MET_em_tight_photon_wpx;
   vector<vector<float> > *el_MET_em_tight_photon_wpy;
   vector<vector<float> > *el_MET_em_tight_photon_wet;
   vector<vector<unsigned int> > *el_MET_em_tight_photon_statusWord;
   Int_t           ph_MET_em_tight_photon_n;
   vector<vector<float> > *ph_MET_em_tight_photon_wpx;
   vector<vector<float> > *ph_MET_em_tight_photon_wpy;
   vector<vector<float> > *ph_MET_em_tight_photon_wet;
   vector<vector<unsigned int> > *ph_MET_em_tight_photon_statusWord;
   Int_t           mu_staco_MET_em_tight_photon_n;
   vector<vector<float> > *mu_staco_MET_em_tight_photon_wpx;
   vector<vector<float> > *mu_staco_MET_em_tight_photon_wpy;
   vector<vector<float> > *mu_staco_MET_em_tight_photon_wet;
   vector<vector<unsigned int> > *mu_staco_MET_em_tight_photon_statusWord;
   Int_t           mu_muid_MET_em_tight_photon_n;
   vector<vector<float> > *mu_muid_MET_em_tight_photon_wpx;
   vector<vector<float> > *mu_muid_MET_em_tight_photon_wpy;
   vector<vector<float> > *mu_muid_MET_em_tight_photon_wet;
   vector<vector<unsigned int> > *mu_muid_MET_em_tight_photon_statusWord;
   Int_t           jet_em_tight_photon_n;
   vector<vector<float> > *jet_em_tight_photon_wpx;
   vector<vector<float> > *jet_em_tight_photon_wpy;
   vector<vector<float> > *jet_em_tight_photon_wet;
   vector<vector<unsigned int> > *jet_em_tight_photon_statusWord;
   Int_t           el_MET_4lc_medium_photon_n;
   vector<vector<float> > *el_MET_4lc_medium_photon_wpx;
   vector<vector<float> > *el_MET_4lc_medium_photon_wpy;
   vector<vector<float> > *el_MET_4lc_medium_photon_wet;
   vector<vector<unsigned int> > *el_MET_4lc_medium_photon_statusWord;
   Int_t           ph_MET_4lc_medium_photon_n;
   vector<vector<float> > *ph_MET_4lc_medium_photon_wpx;
   vector<vector<float> > *ph_MET_4lc_medium_photon_wpy;
   vector<vector<float> > *ph_MET_4lc_medium_photon_wet;
   vector<vector<unsigned int> > *ph_MET_4lc_medium_photon_statusWord;
   Int_t           mu_staco_MET_4lc_medium_photon_n;
   vector<vector<float> > *mu_staco_MET_4lc_medium_photon_wpx;
   vector<vector<float> > *mu_staco_MET_4lc_medium_photon_wpy;
   vector<vector<float> > *mu_staco_MET_4lc_medium_photon_wet;
   vector<vector<unsigned int> > *mu_staco_MET_4lc_medium_photon_statusWord;
   Int_t           mu_muid_MET_4lc_medium_photon_n;
   vector<vector<float> > *mu_muid_MET_4lc_medium_photon_wpx;
   vector<vector<float> > *mu_muid_MET_4lc_medium_photon_wpy;
   vector<vector<float> > *mu_muid_MET_4lc_medium_photon_wet;
   vector<vector<unsigned int> > *mu_muid_MET_4lc_medium_photon_statusWord;
   Int_t           jet_AntiKt4LCTopoJets_4lc_medium_photon_n;
   vector<vector<float> > *jet_AntiKt4LCTopoJets_4lc_medium_photon_wpx;
   vector<vector<float> > *jet_AntiKt4LCTopoJets_4lc_medium_photon_wpy;
   vector<vector<float> > *jet_AntiKt4LCTopoJets_4lc_medium_photon_wet;
   vector<vector<unsigned int> > *jet_AntiKt4LCTopoJets_4lc_medium_photon_statusWord;
   Int_t           el_MET_4lc_tight_photon_n;
   vector<vector<float> > *el_MET_4lc_tight_photon_wpx;
   vector<vector<float> > *el_MET_4lc_tight_photon_wpy;
   vector<vector<float> > *el_MET_4lc_tight_photon_wet;
   vector<vector<unsigned int> > *el_MET_4lc_tight_photon_statusWord;
   Int_t           ph_MET_4lc_tight_photon_n;
   vector<vector<float> > *ph_MET_4lc_tight_photon_wpx;
   vector<vector<float> > *ph_MET_4lc_tight_photon_wpy;
   vector<vector<float> > *ph_MET_4lc_tight_photon_wet;
   vector<vector<unsigned int> > *ph_MET_4lc_tight_photon_statusWord;
   Int_t           mu_staco_MET_4lc_tight_photon_n;
   vector<vector<float> > *mu_staco_MET_4lc_tight_photon_wpx;
   vector<vector<float> > *mu_staco_MET_4lc_tight_photon_wpy;
   vector<vector<float> > *mu_staco_MET_4lc_tight_photon_wet;
   vector<vector<unsigned int> > *mu_staco_MET_4lc_tight_photon_statusWord;
   Int_t           mu_muid_MET_4lc_tight_photon_n;
   vector<vector<float> > *mu_muid_MET_4lc_tight_photon_wpx;
   vector<vector<float> > *mu_muid_MET_4lc_tight_photon_wpy;
   vector<vector<float> > *mu_muid_MET_4lc_tight_photon_wet;
   vector<vector<unsigned int> > *mu_muid_MET_4lc_tight_photon_statusWord;
   Int_t           jet_AntiKt4LCTopoJets_4lc_tight_photon_n;
   vector<vector<float> > *jet_AntiKt4LCTopoJets_4lc_tight_photon_wpx;
   vector<vector<float> > *jet_AntiKt4LCTopoJets_4lc_tight_photon_wpy;
   vector<vector<float> > *jet_AntiKt4LCTopoJets_4lc_tight_photon_wet;
   vector<vector<unsigned int> > *jet_AntiKt4LCTopoJets_4lc_tight_photon_statusWord;
   Int_t           mb_n;
   vector<float>   *mb_E;
   vector<float>   *mb_eta;
   vector<float>   *mb_phi;
   vector<float>   *mb_time;
   vector<int>     *mb_quality;
   vector<int>     *mb_type;
   vector<int>     *mb_module;
   vector<int>     *mb_channel;
   Float_t         mbtime_timeDiff;
   Float_t         mbtime_timeA;
   Float_t         mbtime_timeC;
   Int_t           mbtime_countA;
   Int_t           mbtime_countC;
   Bool_t          collcand_passCaloTime;
   Bool_t          collcand_passMBTSTime;
   Bool_t          collcand_passTrigger;
   Bool_t          collcand_pass;
   Bool_t          top_isElectronTriggerPassed;
   Bool_t          top_isMuonTriggerPassed;
   Bool_t          top_isEleMuOverlap;
   Float_t         topMET_etx;
   Float_t         topMET_ety;
   Float_t         topMET_phi;
   Float_t         topMET_et;
   Float_t         topMET_sumet;
   Int_t           topJet_n;
   vector<int>     *topJet_use;
   vector<int>     *topJet_inTrigger;
   vector<int>     *topJet_index;
   vector<int>     *topJet_overlap_jet_n;
   vector<vector<int> > *topJet_overlap_jet_index;
   vector<int>     *topJet_overlap_mu_n;
   vector<vector<int> > *topJet_overlap_mu_index;
   vector<int>     *topJet_overlap_tau_n;
   vector<vector<int> > *topJet_overlap_tau_index;
   Int_t           topMu_n;
   vector<int>     *topMu_use;
   vector<int>     *topMu_inTrigger;
   vector<int>     *topMu_index;
   vector<int>     *topMu_overlap_jet_n;
   vector<vector<int> > *topMu_overlap_jet_index;
   vector<int>     *topMu_overlap_mu_n;
   vector<vector<int> > *topMu_overlap_mu_index;
   vector<int>     *topMu_overlap_tau_n;
   vector<vector<int> > *topMu_overlap_tau_index;
   Int_t           topEl_n;
   vector<int>     *topEl_use;
   vector<int>     *topEl_inTrigger;
   vector<int>     *topEl_index;
   vector<int>     *topEl_overlap_jet_n;
   vector<vector<int> > *topEl_overlap_jet_index;
   vector<int>     *topEl_overlap_mu_n;
   vector<vector<int> > *topEl_overlap_mu_index;
   vector<int>     *topEl_overlap_tau_n;
   vector<vector<int> > *topEl_overlap_tau_index;
   Float_t         top_phMET_etx;
   Float_t         top_phMET_ety;
   Float_t         top_phMET_phi;
   Float_t         top_phMET_et;
   Float_t         top_phMET_sumet;
   Int_t           top_phJet_n;
   vector<int>     *top_phJet_use;
   vector<int>     *top_phJet_inTrigger;
   vector<int>     *top_phJet_index;
   vector<int>     *top_phJet_overlap_jet_n;
   vector<vector<int> > *top_phJet_overlap_jet_index;
   vector<int>     *top_phJet_overlap_mu_n;
   vector<vector<int> > *top_phJet_overlap_mu_index;
   vector<int>     *top_phJet_overlap_trk_n;
   vector<vector<int> > *top_phJet_overlap_trk_index;
   vector<int>     *top_phJet_overlap_tau_n;
   vector<vector<int> > *top_phJet_overlap_tau_index;
   Int_t           top_phMu_n;
   vector<int>     *top_phMu_use;
   vector<int>     *top_phMu_inTrigger;
   vector<int>     *top_phMu_index;
   vector<int>     *top_phMu_overlap_jet_n;
   vector<vector<int> > *top_phMu_overlap_jet_index;
   vector<int>     *top_phMu_overlap_mu_n;
   vector<vector<int> > *top_phMu_overlap_mu_index;
   vector<int>     *top_phMu_overlap_trk_n;
   vector<vector<int> > *top_phMu_overlap_trk_index;
   vector<int>     *top_phMu_overlap_tau_n;
   vector<vector<int> > *top_phMu_overlap_tau_index;
   Int_t           top_phEl_n;
   vector<int>     *top_phEl_use;
   vector<int>     *top_phEl_inTrigger;
   vector<int>     *top_phEl_index;
   vector<int>     *top_phEl_overlap_jet_n;
   vector<vector<int> > *top_phEl_overlap_jet_index;
   vector<int>     *top_phEl_overlap_mu_n;
   vector<vector<int> > *top_phEl_overlap_mu_index;
   vector<int>     *top_phEl_overlap_trk_n;
   vector<vector<int> > *top_phEl_overlap_trk_index;
   vector<int>     *top_phEl_overlap_tau_n;
   vector<vector<int> > *top_phEl_overlap_tau_index;
   Int_t           top_phPh_n;
   vector<int>     *top_phPh_use;
   vector<int>     *top_phPh_inTrigger;
   vector<int>     *top_phPh_index;
   vector<int>     *top_phPh_overlap_jet_n;
   vector<vector<int> > *top_phPh_overlap_jet_index;
   vector<int>     *top_phPh_overlap_mu_n;
   vector<vector<int> > *top_phPh_overlap_mu_index;
   vector<int>     *top_phPh_overlap_trk_n;
   vector<vector<int> > *top_phPh_overlap_trk_index;
   vector<int>     *top_phPh_overlap_tau_n;
   vector<vector<int> > *top_phPh_overlap_tau_index;
   Int_t           trig_Nav_n;
   vector<short>   *trig_Nav_chain_ChainId;
   vector<vector<int> > *trig_Nav_chain_RoIType;
   vector<vector<int> > *trig_Nav_chain_RoIIndex;
   Int_t           trig_RoI_L2_b_n;
   vector<short>   *trig_RoI_L2_b_type;
   vector<short>   *trig_RoI_L2_b_active;
   vector<short>   *trig_RoI_L2_b_lastStep;
   vector<short>   *trig_RoI_L2_b_TENumber;
   vector<short>   *trig_RoI_L2_b_roiNumber;
   vector<int>     *trig_RoI_L2_b_Jet_ROI;
   vector<int>     *trig_RoI_L2_b_Jet_ROIStatus;
   vector<int>     *trig_RoI_L2_b_Muon_ROI;
   vector<int>     *trig_RoI_L2_b_Muon_ROIStatus;
   vector<vector<int> > *trig_RoI_L2_b_TrigL2BjetContainer;
   vector<vector<int> > *trig_RoI_L2_b_TrigL2BjetContainerStatus;
   vector<vector<int> > *trig_RoI_L2_b_TrigInDetTrackCollection_TrigSiTrack_Jet;
   vector<vector<int> > *trig_RoI_L2_b_TrigInDetTrackCollection_TrigSiTrack_JetStatus;
   vector<vector<int> > *trig_RoI_L2_b_TrigInDetTrackCollection_TrigIDSCAN_Jet;
   vector<vector<int> > *trig_RoI_L2_b_TrigInDetTrackCollection_TrigIDSCAN_JetStatus;
   Int_t           trig_RoI_EF_b_n;
   vector<short>   *trig_RoI_EF_b_type;
   vector<short>   *trig_RoI_EF_b_active;
   vector<short>   *trig_RoI_EF_b_lastStep;
   vector<short>   *trig_RoI_EF_b_TENumber;
   vector<short>   *trig_RoI_EF_b_roiNumber;
   vector<int>     *trig_RoI_EF_b_Jet_ROI;
   vector<int>     *trig_RoI_EF_b_Jet_ROIStatus;
   vector<int>     *trig_RoI_EF_b_Muon_ROI;
   vector<int>     *trig_RoI_EF_b_Muon_ROIStatus;
   vector<vector<int> > *trig_RoI_EF_b_TrigEFBjetContainer;
   vector<vector<int> > *trig_RoI_EF_b_TrigEFBjetContainerStatus;
   vector<vector<int> > *trig_RoI_EF_b_Rec__TrackParticleContainer;
   vector<vector<int> > *trig_RoI_EF_b_Rec__TrackParticleContainerStatus;
   Int_t           trig_L1_jet_n;
   vector<float>   *trig_L1_jet_eta;
   vector<float>   *trig_L1_jet_phi;
   vector<vector<string> > *trig_L1_jet_thrNames;
   vector<vector<float> > *trig_L1_jet_thrValues;
   vector<unsigned int> *trig_L1_jet_thrPattern;
   vector<float>   *trig_L1_jet_et4x4;
   vector<float>   *trig_L1_jet_et6x6;
   vector<float>   *trig_L1_jet_et8x8;
   vector<unsigned int> *trig_L1_jet_RoIWord;
   vector<unsigned int> *trig_L1_TAV;
   vector<short>   *trig_L2_passedPhysics;
   vector<short>   *trig_EF_passedPhysics;
   vector<unsigned int> *trig_L1_TBP;
   vector<unsigned int> *trig_L1_TAP;
   vector<short>   *trig_L2_passedRaw;
   vector<short>   *trig_EF_passedRaw;
   Bool_t          trig_L2_truncated;
   Bool_t          trig_EF_truncated;
   vector<short>   *trig_L2_resurrected;
   vector<short>   *trig_EF_resurrected;
   vector<short>   *trig_L2_passedThrough;
   vector<short>   *trig_EF_passedThrough;
   Int_t           trig_L2_bjet_n;
   vector<int>     *trig_L2_bjet_roiId;
   vector<int>     *trig_L2_bjet_valid;
   vector<float>   *trig_L2_bjet_prmVtx;
   vector<float>   *trig_L2_bjet_pt;
   vector<float>   *trig_L2_bjet_eta;
   vector<float>   *trig_L2_bjet_phi;
   vector<float>   *trig_L2_bjet_xComb;
   vector<float>   *trig_L2_bjet_xIP1D;
   vector<float>   *trig_L2_bjet_xIP2D;
   vector<float>   *trig_L2_bjet_xIP3D;
   vector<float>   *trig_L2_bjet_xCHI2;
   vector<float>   *trig_L2_bjet_xSV;
   vector<float>   *trig_L2_bjet_xMVtx;
   vector<float>   *trig_L2_bjet_xEVtx;
   vector<float>   *trig_L2_bjet_xNVtx;
   vector<float>   *trig_L2_bjet_BSx;
   vector<float>   *trig_L2_bjet_BSy;
   vector<float>   *trig_L2_bjet_BSz;
   vector<float>   *trig_L2_bjet_sBSx;
   vector<float>   *trig_L2_bjet_sBSy;
   vector<float>   *trig_L2_bjet_sBSz;
   vector<float>   *trig_L2_bjet_sBSxy;
   vector<float>   *trig_L2_bjet_BTiltXZ;
   vector<float>   *trig_L2_bjet_BTiltYZ;
   vector<int>     *trig_L2_bjet_BSstatus;
   Int_t           trig_EF_bjet_n;
   vector<int>     *trig_EF_bjet_roiId;
   vector<int>     *trig_EF_bjet_valid;
   vector<float>   *trig_EF_bjet_prmVtx;
   vector<float>   *trig_EF_bjet_pt;
   vector<float>   *trig_EF_bjet_eta;
   vector<float>   *trig_EF_bjet_phi;
   vector<float>   *trig_EF_bjet_xComb;
   vector<float>   *trig_EF_bjet_xIP1D;
   vector<float>   *trig_EF_bjet_xIP2D;
   vector<float>   *trig_EF_bjet_xIP3D;
   vector<float>   *trig_EF_bjet_xCHI2;
   vector<float>   *trig_EF_bjet_xSV;
   vector<float>   *trig_EF_bjet_xMVtx;
   vector<float>   *trig_EF_bjet_xEVtx;
   vector<float>   *trig_EF_bjet_xNVtx;
   Int_t           trig_EF_pv_n;
   vector<float>   *trig_EF_pv_x;
   vector<float>   *trig_EF_pv_y;
   vector<float>   *trig_EF_pv_z;
   vector<int>     *trig_EF_pv_type;
   vector<float>   *trig_EF_pv_err_x;
   vector<float>   *trig_EF_pv_err_y;
   vector<float>   *trig_EF_pv_err_z;
   Int_t           trig_L1_mu_n;
   vector<float>   *trig_L1_mu_pt;
   vector<float>   *trig_L1_mu_eta;
   vector<float>   *trig_L1_mu_phi;
   vector<string>  *trig_L1_mu_thrName;
   vector<short>   *trig_L1_mu_thrNumber;
   vector<short>   *trig_L1_mu_RoINumber;
   vector<short>   *trig_L1_mu_sectorAddress;
   vector<int>     *trig_L1_mu_firstCandidate;
   vector<int>     *trig_L1_mu_moreCandInRoI;
   vector<int>     *trig_L1_mu_moreCandInSector;
   vector<short>   *trig_L1_mu_source;
   vector<short>   *trig_L1_mu_hemisphere;
   vector<short>   *trig_L1_mu_charge;
   vector<int>     *trig_L1_mu_vetoed;
   Int_t           trig_L2_combmuonfeature_n;
   vector<float>   *trig_L2_combmuonfeature_pt;
   vector<float>   *trig_L2_combmuonfeature_eta;
   vector<float>   *trig_L2_combmuonfeature_phi;
   vector<float>   *trig_L2_combmuonfeature_sigma_pt;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu10;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu10_empty;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu10_loose;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu10_loose_empty;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu10_loose_noOvlpRm;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu13_Zmumu_IDTrkNoCut;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu4;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu4_Bmumu;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu4_Bmumux;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu4_DiMu;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu4_DiMu_DY;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu4_DiMu_DY20;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu4_DiMu_DY_noVtx_noOS;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu4_DiMu_SiTrk;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu4_DiMu_noVtx_noOS;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu4_Jpsimumu;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu4_Jpsimumu_IDTrkNoCut;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu4_Upsimumu;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu4i_DiMu_DY;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu6;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu6_DiMu;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu6_MSonly_g10_loose;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu6_MSonly_g10_loose_nonfilled;
   vector<int>     *trig_L2_combmuonfeature_L2_2mu6_NL;
   vector<int>     *trig_L2_combmuonfeature_L2_mu0_cal_empty;
   vector<int>     *trig_L2_combmuonfeature_L2_mu0_empty_NoAlg;
   vector<int>     *trig_L2_combmuonfeature_L2_mu0_firstempty_NoAlg;
   vector<int>     *trig_L2_combmuonfeature_L2_mu0_unpaired_iso_NoAlg;
   vector<int>     *trig_L2_combmuonfeature_L2_mu10;
   vector<int>     *trig_L2_combmuonfeature_L2_mu10_Jpsimumu;
   vector<int>     *trig_L2_combmuonfeature_L2_mu10_NL;
   vector<int>     *trig_L2_combmuonfeature_L2_mu10_Upsimumu_FS;
   vector<int>     *trig_L2_combmuonfeature_L2_mu10_Upsimumu_tight_FS;
   vector<int>     *trig_L2_combmuonfeature_L2_mu10_cal;
   vector<int>     *trig_L2_combmuonfeature_L2_mu10_cal_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu10_loose;
   vector<int>     *trig_L2_combmuonfeature_L2_mu10_muCombTag_NoEF;
   vector<int>     *trig_L2_combmuonfeature_L2_mu11_empty_NoAlg;
   vector<int>     *trig_L2_combmuonfeature_L2_mu13;
   vector<int>     *trig_L2_combmuonfeature_L2_mu13_MG;
   vector<int>     *trig_L2_combmuonfeature_L2_mu13_muCombTag_NoEF;
   vector<int>     *trig_L2_combmuonfeature_L2_mu15;
   vector<int>     *trig_L2_combmuonfeature_L2_mu15_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu15_tight;
   vector<int>     *trig_L2_combmuonfeature_L2_mu15_xe20_noMu;
   vector<int>     *trig_L2_combmuonfeature_L2_mu15i;
   vector<int>     *trig_L2_combmuonfeature_L2_mu15i_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu18;
   vector<int>     *trig_L2_combmuonfeature_L2_mu18_L1J10;
   vector<int>     *trig_L2_combmuonfeature_L2_mu18_MG;
   vector<int>     *trig_L2_combmuonfeature_L2_mu18_MG_L1J10;
   vector<int>     *trig_L2_combmuonfeature_L2_mu18_MG_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu18_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu20;
   vector<int>     *trig_L2_combmuonfeature_L2_mu20_IDTrkNoCut;
   vector<int>     *trig_L2_combmuonfeature_L2_mu20_MG;
   vector<int>     *trig_L2_combmuonfeature_L2_mu20_MG_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu20_empty;
   vector<int>     *trig_L2_combmuonfeature_L2_mu20_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu20_muCombTag_NoEF;
   vector<int>     *trig_L2_combmuonfeature_L2_mu20_tight;
   vector<int>     *trig_L2_combmuonfeature_L2_mu20i;
   vector<int>     *trig_L2_combmuonfeature_L2_mu20i_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu22;
   vector<int>     *trig_L2_combmuonfeature_L2_mu22_MG;
   vector<int>     *trig_L2_combmuonfeature_L2_mu22_MG_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu22_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu24_MG_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu24_MG_tight;
   vector<int>     *trig_L2_combmuonfeature_L2_mu24_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu24_tight;
   vector<int>     *trig_L2_combmuonfeature_L2_mu30_MG_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu30_MG_tight;
   vector<int>     *trig_L2_combmuonfeature_L2_mu30_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu30_tight;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4;
   vector<int>     *trig_L2_combmuonfeature_L2_mu40_MSonly_barrel;
   vector<int>     *trig_L2_combmuonfeature_L2_mu40_MSonly_barrel_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu40_MSonly_empty;
   vector<int>     *trig_L2_combmuonfeature_L2_mu40_MSonly_tight;
   vector<int>     *trig_L2_combmuonfeature_L2_mu40_MSonly_tight_L1MU11;
   vector<int>     *trig_L2_combmuonfeature_L2_mu40_MSonly_tighter;
   vector<int>     *trig_L2_combmuonfeature_L2_mu40_slow;
   vector<int>     *trig_L2_combmuonfeature_L2_mu40_slow_empty;
   vector<int>     *trig_L2_combmuonfeature_L2_mu40_slow_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu40_slow_outOfTime;
   vector<int>     *trig_L2_combmuonfeature_L2_mu40_slow_outOfTime_medium;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_DiMu;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_DiMu_FS_noOS;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_Jpsimumu;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_L1J10_matched;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_L1J15_matched;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_L1J20_matched;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_L1J30_matched;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_L1J50_matched;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_L1J75_matched;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_L1MU11_MSonly_cosmic;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_L1MU11_cosmic;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_MSonly_cosmic;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_Trk_Jpsi;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_Trk_Upsi_FS;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_Upsimumu_FS;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_Upsimumu_SiTrk_FS;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_Upsimumu_tight_FS;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_cosmic;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_j10_a4tc_EFFS;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_j40_xe20_loose_noMu;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4_j95_L1matched;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4imu6i_DiMu_DY;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4imu6i_DiMu_DY14_noVtx_noOS;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4mu6_Bmumu;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4mu6_Bmumux;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4mu6_DiMu;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4mu6_DiMu_DY20;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4mu6_DiMu_noVtx_noOS;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4mu6_Jpsimumu;
   vector<int>     *trig_L2_combmuonfeature_L2_mu4mu6_Upsimumu;
   vector<int>     *trig_L2_combmuonfeature_L2_mu6;
   vector<int>     *trig_L2_combmuonfeature_L2_mu6_DiMu_noOS;
   vector<int>     *trig_L2_combmuonfeature_L2_mu6_Jpsimumu;
   vector<int>     *trig_L2_combmuonfeature_L2_mu6_Jpsimumu_SiTrk;
   vector<int>     *trig_L2_combmuonfeature_L2_mu6_Jpsimumu_tight;
   vector<int>     *trig_L2_combmuonfeature_L2_mu6_Trk_Jpsi_loose;
   vector<float>   *trig_L2_combmuonfeature_mf_pt;
   vector<float>   *trig_L2_combmuonfeature_mf_eta;
   vector<float>   *trig_L2_combmuonfeature_mf_phi;
   vector<int>     *trig_L2_combmuonfeature_mf_mf;
   vector<int>     *trig_L2_combmuonfeature_idtrk_algorithmId;
   vector<short>   *trig_L2_combmuonfeature_idtrk_trackStatus;
   vector<float>   *trig_L2_combmuonfeature_idtrk_chi2Ndof;
   vector<int>     *trig_L2_combmuonfeature_idtrk_nStrawHits;
   vector<int>     *trig_L2_combmuonfeature_idtrk_nHighThrHits;
   vector<int>     *trig_L2_combmuonfeature_idtrk_nPixelSpacePoints;
   vector<int>     *trig_L2_combmuonfeature_idtrk_nSCT_SpacePoints;
   vector<float>   *trig_L2_combmuonfeature_idtrk_idtrkfitpar_a0;
   vector<float>   *trig_L2_combmuonfeature_idtrk_idtrkfitpar_z0;
   vector<float>   *trig_L2_combmuonfeature_idtrk_idtrkfitpar_phi0;
   vector<float>   *trig_L2_combmuonfeature_idtrk_idtrkfitpar_eta;
   vector<float>   *trig_L2_combmuonfeature_idtrk_idtrkfitpar_pt;
   vector<int>     *trig_L2_combmuonfeature_idtrk_idtrkfitpar_hasidtrkfitpar;
   vector<int>     *trig_L2_combmuonfeature_idtrk_hasidtrk;
   Int_t           trig_EF_trigmuonef_n;
   vector<int>     *trig_EF_trigmuonef_EF_2mu10;
   vector<int>     *trig_EF_trigmuonef_EF_2mu10_empty;
   vector<int>     *trig_EF_trigmuonef_EF_2mu10_loose;
   vector<int>     *trig_EF_trigmuonef_EF_2mu10_loose_empty;
   vector<int>     *trig_EF_trigmuonef_EF_2mu10_loose_noOvlpRm;
   vector<int>     *trig_EF_trigmuonef_EF_2mu13_Zmumu_IDTrkNoCut;
   vector<int>     *trig_EF_trigmuonef_EF_2mu4;
   vector<int>     *trig_EF_trigmuonef_EF_2mu4_Bmumu;
   vector<int>     *trig_EF_trigmuonef_EF_2mu4_Bmumux;
   vector<int>     *trig_EF_trigmuonef_EF_2mu4_DiMu;
   vector<int>     *trig_EF_trigmuonef_EF_2mu4_DiMu_DY;
   vector<int>     *trig_EF_trigmuonef_EF_2mu4_DiMu_DY20;
   vector<int>     *trig_EF_trigmuonef_EF_2mu4_DiMu_DY_noVtx_noOS;
   vector<int>     *trig_EF_trigmuonef_EF_2mu4_DiMu_SiTrk;
   vector<int>     *trig_EF_trigmuonef_EF_2mu4_DiMu_noVtx_noOS;
   vector<int>     *trig_EF_trigmuonef_EF_2mu4_Jpsimumu;
   vector<int>     *trig_EF_trigmuonef_EF_2mu4_Jpsimumu_IDTrkNoCut;
   vector<int>     *trig_EF_trigmuonef_EF_2mu4_Upsimumu;
   vector<int>     *trig_EF_trigmuonef_EF_2mu4i_DiMu_DY;
   vector<int>     *trig_EF_trigmuonef_EF_2mu6;
   vector<int>     *trig_EF_trigmuonef_EF_2mu6_DiMu;
   vector<int>     *trig_EF_trigmuonef_EF_2mu6_MSonly_g10_loose;
   vector<int>     *trig_EF_trigmuonef_EF_2mu6_MSonly_g10_loose_nonfilled;
   vector<int>     *trig_EF_trigmuonef_EF_2mu6_NL;
   vector<int>     *trig_EF_trigmuonef_EF_mu0_empty_NoAlg;
   vector<int>     *trig_EF_trigmuonef_EF_mu0_firstempty_NoAlg;
   vector<int>     *trig_EF_trigmuonef_EF_mu0_unpaired_iso_NoAlg;
   vector<int>     *trig_EF_trigmuonef_EF_mu10;
   vector<int>     *trig_EF_trigmuonef_EF_mu10_Jpsimumu;
   vector<int>     *trig_EF_trigmuonef_EF_mu10_NL;
   vector<int>     *trig_EF_trigmuonef_EF_mu10_Upsimumu_FS;
   vector<int>     *trig_EF_trigmuonef_EF_mu10_Upsimumu_tight_FS;
   vector<int>     *trig_EF_trigmuonef_EF_mu10_loose;
   vector<int>     *trig_EF_trigmuonef_EF_mu10_muCombTag_NoEF;
   vector<int>     *trig_EF_trigmuonef_EF_mu11_empty_NoAlg;
   vector<int>     *trig_EF_trigmuonef_EF_mu13;
   vector<int>     *trig_EF_trigmuonef_EF_mu13_MG;
   vector<int>     *trig_EF_trigmuonef_EF_mu13_muCombTag_NoEF;
   vector<int>     *trig_EF_trigmuonef_EF_mu15;
   vector<int>     *trig_EF_trigmuonef_EF_mu15_mu10_EFFS;
   vector<int>     *trig_EF_trigmuonef_EF_mu15_mu10_EFFS_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu15_mu10_EFFS_tight;
   vector<int>     *trig_EF_trigmuonef_EF_mu15_xe30_noMu;
   vector<int>     *trig_EF_trigmuonef_EF_mu15i;
   vector<int>     *trig_EF_trigmuonef_EF_mu15i_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu18;
   vector<int>     *trig_EF_trigmuonef_EF_mu18_L1J10;
   vector<int>     *trig_EF_trigmuonef_EF_mu18_MG;
   vector<int>     *trig_EF_trigmuonef_EF_mu18_MG_L1J10;
   vector<int>     *trig_EF_trigmuonef_EF_mu18_MG_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu18_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu20;
   vector<int>     *trig_EF_trigmuonef_EF_mu20_IDTrkNoCut;
   vector<int>     *trig_EF_trigmuonef_EF_mu20_IDTrkNoCut_ManyVx;
   vector<int>     *trig_EF_trigmuonef_EF_mu20_MG;
   vector<int>     *trig_EF_trigmuonef_EF_mu20_MG_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu20_empty;
   vector<int>     *trig_EF_trigmuonef_EF_mu20_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu20_mu10_EFFS_tight;
   vector<int>     *trig_EF_trigmuonef_EF_mu20_muCombTag_NoEF;
   vector<int>     *trig_EF_trigmuonef_EF_mu20i;
   vector<int>     *trig_EF_trigmuonef_EF_mu20i_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu22;
   vector<int>     *trig_EF_trigmuonef_EF_mu22_MG;
   vector<int>     *trig_EF_trigmuonef_EF_mu22_MG_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu22_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu24_MG_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu24_MG_tight;
   vector<int>     *trig_EF_trigmuonef_EF_mu24_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu24_tight;
   vector<int>     *trig_EF_trigmuonef_EF_mu30_MG_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu30_MG_tight;
   vector<int>     *trig_EF_trigmuonef_EF_mu30_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu30_tight;
   vector<int>     *trig_EF_trigmuonef_EF_mu4;
   vector<int>     *trig_EF_trigmuonef_EF_mu40_MSonly_barrel;
   vector<int>     *trig_EF_trigmuonef_EF_mu40_MSonly_barrel_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu40_MSonly_empty;
   vector<int>     *trig_EF_trigmuonef_EF_mu40_MSonly_tight;
   vector<int>     *trig_EF_trigmuonef_EF_mu40_MSonly_tight_L1MU11;
   vector<int>     *trig_EF_trigmuonef_EF_mu40_MSonly_tighter;
   vector<int>     *trig_EF_trigmuonef_EF_mu40_slow;
   vector<int>     *trig_EF_trigmuonef_EF_mu40_slow_empty;
   vector<int>     *trig_EF_trigmuonef_EF_mu40_slow_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu40_slow_outOfTime;
   vector<int>     *trig_EF_trigmuonef_EF_mu40_slow_outOfTime_medium;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_DiMu;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_DiMu_FS_noOS;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_Jpsimumu;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_L1J10_matched;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_L1J15_matched;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_L1J20_matched;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_L1J30_matched;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_L1J50_matched;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_L1J75_matched;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_L1MU11_MSonly_cosmic;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_L1MU11_cosmic;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_MSonly_cosmic;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_Trk_Jpsi;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_Trk_Upsi_FS;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_Upsimumu_FS;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_Upsimumu_SiTrk_FS;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_Upsimumu_tight_FS;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_cosmic;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_j10_a4tc_EFFS;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_j10_a4tc_EFFS_matched;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_j135_a4tc_EFFS_L1matched;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_j180_a4tc_EFFS_L1matched;
   vector<int>     *trig_EF_trigmuonef_EF_mu4_j45_a4tc_EFFS_xe45_loose_noMu;
   vector<int>     *trig_EF_trigmuonef_EF_mu4imu6i_DiMu_DY;
   vector<int>     *trig_EF_trigmuonef_EF_mu4imu6i_DiMu_DY14_noVtx_noOS;
   vector<int>     *trig_EF_trigmuonef_EF_mu4mu6_Bmumu;
   vector<int>     *trig_EF_trigmuonef_EF_mu4mu6_Bmumux;
   vector<int>     *trig_EF_trigmuonef_EF_mu4mu6_DiMu;
   vector<int>     *trig_EF_trigmuonef_EF_mu4mu6_DiMu_DY20;
   vector<int>     *trig_EF_trigmuonef_EF_mu4mu6_DiMu_noVtx_noOS;
   vector<int>     *trig_EF_trigmuonef_EF_mu4mu6_Jpsimumu;
   vector<int>     *trig_EF_trigmuonef_EF_mu4mu6_Upsimumu;
   vector<int>     *trig_EF_trigmuonef_EF_mu6;
   vector<int>     *trig_EF_trigmuonef_EF_mu6_DiMu_noOS;
   vector<int>     *trig_EF_trigmuonef_EF_mu6_Jpsimumu;
   vector<int>     *trig_EF_trigmuonef_EF_mu6_Jpsimumu_SiTrk;
   vector<int>     *trig_EF_trigmuonef_EF_mu6_Jpsimumu_tight;
   vector<int>     *trig_EF_trigmuonef_EF_mu6_Trk_Jpsi_loose;
   vector<int>     *trig_EF_trigmuonef_track_n;
   vector<vector<int> > *trig_EF_trigmuonef_track_MuonType;
   vector<vector<float> > *trig_EF_trigmuonef_track_MS_pt;
   vector<vector<float> > *trig_EF_trigmuonef_track_MS_eta;
   vector<vector<float> > *trig_EF_trigmuonef_track_MS_phi;
   vector<vector<float> > *trig_EF_trigmuonef_track_MS_charge;
   vector<vector<float> > *trig_EF_trigmuonef_track_MS_d0;
   vector<vector<float> > *trig_EF_trigmuonef_track_MS_z0;
   vector<vector<float> > *trig_EF_trigmuonef_track_MS_chi2;
   vector<vector<float> > *trig_EF_trigmuonef_track_MS_chi2prob;
   vector<vector<float> > *trig_EF_trigmuonef_track_MS_posX;
   vector<vector<float> > *trig_EF_trigmuonef_track_MS_posY;
   vector<vector<float> > *trig_EF_trigmuonef_track_MS_posZ;
   vector<vector<int> > *trig_EF_trigmuonef_track_MS_hasMS;
   vector<vector<float> > *trig_EF_trigmuonef_track_SA_pt;
   vector<vector<float> > *trig_EF_trigmuonef_track_SA_eta;
   vector<vector<float> > *trig_EF_trigmuonef_track_SA_phi;
   vector<vector<float> > *trig_EF_trigmuonef_track_SA_charge;
   vector<vector<float> > *trig_EF_trigmuonef_track_SA_d0;
   vector<vector<float> > *trig_EF_trigmuonef_track_SA_z0;
   vector<vector<float> > *trig_EF_trigmuonef_track_SA_chi2;
   vector<vector<float> > *trig_EF_trigmuonef_track_SA_chi2prob;
   vector<vector<float> > *trig_EF_trigmuonef_track_SA_posX;
   vector<vector<float> > *trig_EF_trigmuonef_track_SA_posY;
   vector<vector<float> > *trig_EF_trigmuonef_track_SA_posZ;
   vector<vector<int> > *trig_EF_trigmuonef_track_SA_hasSA;
   vector<vector<float> > *trig_EF_trigmuonef_track_CB_pt;
   vector<vector<float> > *trig_EF_trigmuonef_track_CB_eta;
   vector<vector<float> > *trig_EF_trigmuonef_track_CB_phi;
   vector<vector<float> > *trig_EF_trigmuonef_track_CB_charge;
   vector<vector<float> > *trig_EF_trigmuonef_track_CB_d0;
   vector<vector<float> > *trig_EF_trigmuonef_track_CB_z0;
   vector<vector<float> > *trig_EF_trigmuonef_track_CB_chi2;
   vector<vector<float> > *trig_EF_trigmuonef_track_CB_chi2prob;
   vector<vector<float> > *trig_EF_trigmuonef_track_CB_posX;
   vector<vector<float> > *trig_EF_trigmuonef_track_CB_posY;
   vector<vector<float> > *trig_EF_trigmuonef_track_CB_posZ;
   vector<vector<float> > *trig_EF_trigmuonef_track_CB_matchChi2;
   vector<vector<int> > *trig_EF_trigmuonef_track_CB_hasCB;
   vector<string>  *trig_L1_esum_thrNames;
   Float_t         trig_L1_esum_ExMiss;
   Float_t         trig_L1_esum_EyMiss;
   Float_t         trig_L1_esum_energyT;
   Bool_t          trig_L1_esum_overflowX;
   Bool_t          trig_L1_esum_overflowY;
   Bool_t          trig_L1_esum_overflowT;
   UInt_t          trig_L1_esum_RoIWord0;
   UInt_t          trig_L1_esum_RoIWord1;
   UInt_t          trig_L1_esum_RoIWord2;
   Float_t         trig_L2_met_MEx;
   Float_t         trig_L2_met_MEy;
   Float_t         trig_L2_met_MEz;
   Float_t         trig_L2_met_sumEt;
   Float_t         trig_L2_met_sumE;
   Int_t           trig_L2_met_flag;
   vector<string>  *trig_L2_met_nameOfComponent;
   vector<float>   *trig_L2_met_MExComponent;
   vector<float>   *trig_L2_met_MEyComponent;
   vector<float>   *trig_L2_met_MEzComponent;
   vector<float>   *trig_L2_met_sumEtComponent;
   vector<float>   *trig_L2_met_sumEComponent;
   vector<float>   *trig_L2_met_componentCalib0;
   vector<float>   *trig_L2_met_componentCalib1;
   vector<short>   *trig_L2_met_sumOfSigns;
   vector<unsigned short> *trig_L2_met_usedChannels;
   vector<short>   *trig_L2_met_status;
   Float_t         trig_EF_met_MEx;
   Float_t         trig_EF_met_MEy;
   Float_t         trig_EF_met_MEz;
   Float_t         trig_EF_met_sumEt;
   Float_t         trig_EF_met_sumE;
   Int_t           trig_EF_met_flag;
   vector<string>  *trig_EF_met_nameOfComponent;
   vector<float>   *trig_EF_met_MExComponent;
   vector<float>   *trig_EF_met_MEyComponent;
   vector<float>   *trig_EF_met_MEzComponent;
   vector<float>   *trig_EF_met_sumEtComponent;
   vector<float>   *trig_EF_met_sumEComponent;
   vector<float>   *trig_EF_met_componentCalib0;
   vector<float>   *trig_EF_met_componentCalib1;
   vector<short>   *trig_EF_met_sumOfSigns;
   vector<unsigned short> *trig_EF_met_usedChannels;
   vector<short>   *trig_EF_met_status;
   Int_t           trig_L1_emtau_n;
   vector<float>   *trig_L1_emtau_eta;
   vector<float>   *trig_L1_emtau_phi;
   vector<vector<string> > *trig_L1_emtau_thrNames;
   vector<vector<float> > *trig_L1_emtau_thrValues;
   vector<float>   *trig_L1_emtau_core;
   vector<float>   *trig_L1_emtau_EMClus;
   vector<float>   *trig_L1_emtau_tauClus;
   vector<float>   *trig_L1_emtau_EMIsol;
   vector<float>   *trig_L1_emtau_hadIsol;
   vector<float>   *trig_L1_emtau_hadCore;
   vector<unsigned int> *trig_L1_emtau_thrPattern;
   vector<int>     *trig_L1_emtau_L1_2EM10;
   vector<int>     *trig_L1_emtau_L1_2EM14;
   vector<int>     *trig_L1_emtau_L1_2EM3;
   vector<int>     *trig_L1_emtau_L1_2EM3_EM12;
   vector<int>     *trig_L1_emtau_L1_2EM3_EM7;
   vector<int>     *trig_L1_emtau_L1_2EM5;
   vector<int>     *trig_L1_emtau_L1_2EM5_EM10;
   vector<int>     *trig_L1_emtau_L1_2EM5_MU6;
   vector<int>     *trig_L1_emtau_L1_2EM5_NL;
   vector<int>     *trig_L1_emtau_L1_2EM7;
   vector<int>     *trig_L1_emtau_L1_2EM7_EM10;
   vector<int>     *trig_L1_emtau_L1_EM10;
   vector<int>     *trig_L1_emtau_L1_EM10_MU6;
   vector<int>     *trig_L1_emtau_L1_EM10_XE20;
   vector<int>     *trig_L1_emtau_L1_EM10_XE30;
   vector<int>     *trig_L1_emtau_L1_EM10_XS45;
   vector<int>     *trig_L1_emtau_L1_EM10_XS50;
   vector<int>     *trig_L1_emtau_L1_EM12;
   vector<int>     *trig_L1_emtau_L1_EM14;
   vector<int>     *trig_L1_emtau_L1_EM14_XE10;
   vector<int>     *trig_L1_emtau_L1_EM14_XE20;
   vector<int>     *trig_L1_emtau_L1_EM16;
   vector<int>     *trig_L1_emtau_L1_EM3;
   vector<int>     *trig_L1_emtau_L1_EM30;
   vector<int>     *trig_L1_emtau_L1_EM3_EMPTY;
   vector<int>     *trig_L1_emtau_L1_EM3_FIRSTEMPTY;
   vector<int>     *trig_L1_emtau_L1_EM3_MU0;
   vector<int>     *trig_L1_emtau_L1_EM3_MU6;
   vector<int>     *trig_L1_emtau_L1_EM3_UNPAIRED_ISO;
   vector<int>     *trig_L1_emtau_L1_EM3_UNPAIRED_NONISO;
   vector<int>     *trig_L1_emtau_L1_EM5;
   vector<int>     *trig_L1_emtau_L1_EM5_2MU6;
   vector<int>     *trig_L1_emtau_L1_EM5_EMPTY;
   vector<int>     *trig_L1_emtau_L1_EM5_MU10;
   vector<int>     *trig_L1_emtau_L1_EM5_MU6;
   vector<int>     *trig_L1_emtau_L1_EM7;
   Int_t           trig_L2_el_n;
   vector<float>   *trig_L2_el_E;
   vector<float>   *trig_L2_el_Et;
   vector<float>   *trig_L2_el_pt;
   vector<float>   *trig_L2_el_eta;
   vector<float>   *trig_L2_el_phi;
   vector<int>     *trig_L2_el_RoIWord;
   vector<float>   *trig_L2_el_zvertex;
   vector<int>     *trig_L2_el_charge;
   vector<int>     *trig_L2_el_L2_2e10_medium;
   vector<int>     *trig_L2_el_L2_2e10_medium_mu6;
   vector<int>     *trig_L2_el_L2_2e12T_medium;
   vector<int>     *trig_L2_el_L2_2e12_medium;
   vector<int>     *trig_L2_el_L2_2e15_medium;
   vector<int>     *trig_L2_el_L2_2e5_tight;
   vector<int>     *trig_L2_el_L2_2e5_tight_Jpsi;
   vector<int>     *trig_L2_el_L2_e10_medium;
   vector<int>     *trig_L2_el_L2_e10_medium_2mu6;
   vector<int>     *trig_L2_el_L2_e10_medium_mu10;
   vector<int>     *trig_L2_el_L2_e10_medium_mu6;
   vector<int>     *trig_L2_el_L2_e10_medium_mu6_topo_medium;
   vector<int>     *trig_L2_el_L2_e11T_medium;
   vector<int>     *trig_L2_el_L2_e11T_medium_2e6T_medium;
   vector<int>     *trig_L2_el_L2_e11_etcut;
   vector<int>     *trig_L2_el_L2_e12T_medium_mu6_topo_medium;
   vector<int>     *trig_L2_el_L2_e12_medium;
   vector<int>     *trig_L2_el_L2_e13_etcut_xs45_noMu;
   vector<int>     *trig_L2_el_L2_e15_HLTtighter;
   vector<int>     *trig_L2_el_L2_e15_medium;
   vector<int>     *trig_L2_el_L2_e15_medium_e12_medium;
   vector<int>     *trig_L2_el_L2_e15_medium_xe20_noMu;
   vector<int>     *trig_L2_el_L2_e15_medium_xe30_noMu;
   vector<int>     *trig_L2_el_L2_e15_medium_xe35_noMu;
   vector<int>     *trig_L2_el_L2_e15_tight;
   vector<int>     *trig_L2_el_L2_e20_etcut_xs45_noMu;
   vector<int>     *trig_L2_el_L2_e20_loose;
   vector<int>     *trig_L2_el_L2_e20_loose1;
   vector<int>     *trig_L2_el_L2_e20_looseTrk;
   vector<int>     *trig_L2_el_L2_e20_medium;
   vector<int>     *trig_L2_el_L2_e20_medium1;
   vector<int>     *trig_L2_el_L2_e20_medium2;
   vector<int>     *trig_L2_el_L2_e20_medium_IDTrkNoCut;
   vector<int>     *trig_L2_el_L2_e20_medium_SiTrk;
   vector<int>     *trig_L2_el_L2_e20_medium_TRT;
   vector<int>     *trig_L2_el_L2_e20_tight_e15_NoCut_Zee;
   vector<int>     *trig_L2_el_L2_e22_etcut_xs45_noMu;
   vector<int>     *trig_L2_el_L2_e22_loose;
   vector<int>     *trig_L2_el_L2_e22_loose1;
   vector<int>     *trig_L2_el_L2_e22_looseTrk;
   vector<int>     *trig_L2_el_L2_e22_medium;
   vector<int>     *trig_L2_el_L2_e22_medium1;
   vector<int>     *trig_L2_el_L2_e22_medium2;
   vector<int>     *trig_L2_el_L2_e22_medium_IDTrkNoCut;
   vector<int>     *trig_L2_el_L2_e22_medium_SiTrk;
   vector<int>     *trig_L2_el_L2_e22_medium_TRT;
   vector<int>     *trig_L2_el_L2_e33_medium;
   vector<int>     *trig_L2_el_L2_e35_medium;
   vector<int>     *trig_L2_el_L2_e40_medium;
   vector<int>     *trig_L2_el_L2_e45_medium;
   vector<int>     *trig_L2_el_L2_e45_medium1;
   vector<int>     *trig_L2_el_L2_e5_medium_mu6;
   vector<int>     *trig_L2_el_L2_e5_medium_mu6_topo_medium;
   vector<int>     *trig_L2_el_L2_e5_tight;
   vector<int>     *trig_L2_el_L2_e5_tight_e14_etcut_Jpsi;
   vector<int>     *trig_L2_el_L2_e5_tight_e4_etcut_Jpsi;
   vector<int>     *trig_L2_el_L2_e5_tight_e4_etcut_Jpsi_SiTrk;
   vector<int>     *trig_L2_el_L2_e5_tight_e4_etcut_Jpsi_TRT;
   vector<int>     *trig_L2_el_L2_e5_tight_e5_NoCut;
   vector<int>     *trig_L2_el_L2_e5_tight_e9_etcut_Jpsi;
   vector<int>     *trig_L2_el_L2_e60_loose;
   vector<int>     *trig_L2_el_L2_e6T_medium;
   vector<int>     *trig_L2_el_L2_e7_tight_e14_etcut_Jpsi;
   vector<int>     *trig_L2_el_L2_e9_tight_e5_tight_Jpsi;
   vector<int>     *trig_L2_el_L2_eb_physics;
   vector<int>     *trig_L2_el_L2_eb_physics_empty;
   vector<int>     *trig_L2_el_L2_eb_physics_firstempty;
   vector<int>     *trig_L2_el_L2_eb_physics_noL1PS;
   vector<int>     *trig_L2_el_L2_eb_physics_unpaired_iso;
   vector<int>     *trig_L2_el_L2_eb_physics_unpaired_noniso;
   vector<int>     *trig_L2_el_L2_eb_random;
   vector<int>     *trig_L2_el_L2_eb_random_empty;
   vector<int>     *trig_L2_el_L2_eb_random_firstempty;
   vector<int>     *trig_L2_el_L2_eb_random_unpaired_iso;
   vector<int>     *trig_L2_el_L2_em3_empty_larcalib;
   vector<int>     *trig_L2_el_L2_em5_empty_larcalib;
   Int_t           trig_L2_ph_n;
   vector<float>   *trig_L2_ph_E;
   vector<float>   *trig_L2_ph_Et;
   vector<float>   *trig_L2_ph_pt;
   vector<float>   *trig_L2_ph_eta;
   vector<float>   *trig_L2_ph_phi;
   vector<int>     *trig_L2_ph_RoIWord;
   vector<int>     *trig_L2_ph_L2_2g15_loose;
   vector<int>     *trig_L2_ph_L2_2g20_loose;
   vector<int>     *trig_L2_ph_L2_g100_etcut_g50_etcut;
   vector<int>     *trig_L2_ph_L2_g10_NoCut_cosmic;
   vector<int>     *trig_L2_ph_L2_g11_etcut;
   vector<int>     *trig_L2_ph_L2_g150_etcut;
   vector<int>     *trig_L2_ph_L2_g15_loose;
   vector<int>     *trig_L2_ph_L2_g20_etcut;
   vector<int>     *trig_L2_ph_L2_g20_etcut_xe30_noMu;
   vector<int>     *trig_L2_ph_L2_g20_loose;
   vector<int>     *trig_L2_ph_L2_g40_loose;
   vector<int>     *trig_L2_ph_L2_g40_loose_EFxe40_noMu;
   vector<int>     *trig_L2_ph_L2_g40_loose_xe30_medium_noMu;
   vector<int>     *trig_L2_ph_L2_g40_loose_xe35_medium_noMu;
   vector<int>     *trig_L2_ph_L2_g40_tight;
   vector<int>     *trig_L2_ph_L2_g40_tight_b10_medium;
   vector<int>     *trig_L2_ph_L2_g5_NoCut_cosmic;
   vector<int>     *trig_L2_ph_L2_g60_loose;
   vector<int>     *trig_L2_ph_L2_g80_loose;
   Int_t           trig_L2_jet_n;
   vector<float>   *trig_L2_jet_E;
   vector<float>   *trig_L2_jet_eta;
   vector<float>   *trig_L2_jet_phi;
   vector<unsigned int> *trig_L2_jet_RoIWord;
   Int_t           trig_EF_el_n;
   vector<float>   *trig_EF_el_E;
   vector<float>   *trig_EF_el_Et;
   vector<float>   *trig_EF_el_pt;
   vector<float>   *trig_EF_el_m;
   vector<float>   *trig_EF_el_eta;
   vector<float>   *trig_EF_el_phi;
   vector<float>   *trig_EF_el_px;
   vector<float>   *trig_EF_el_py;
   vector<float>   *trig_EF_el_pz;
   vector<float>   *trig_EF_el_charge;
   vector<int>     *trig_EF_el_author;
   vector<unsigned int> *trig_EF_el_isEM;
   vector<int>     *trig_EF_el_loose;
   vector<int>     *trig_EF_el_looseIso;
   vector<int>     *trig_EF_el_medium;
   vector<int>     *trig_EF_el_mediumIso;
   vector<int>     *trig_EF_el_mediumWithoutTrack;
   vector<int>     *trig_EF_el_mediumIsoWithoutTrack;
   vector<int>     *trig_EF_el_tight;
   vector<int>     *trig_EF_el_tightIso;
   vector<int>     *trig_EF_el_tightWithoutTrack;
   vector<int>     *trig_EF_el_tightIsoWithoutTrack;
   vector<int>     *trig_EF_el_loosePP;
   vector<int>     *trig_EF_el_loosePPIso;
   vector<int>     *trig_EF_el_mediumPP;
   vector<int>     *trig_EF_el_mediumPPIso;
   vector<int>     *trig_EF_el_tightPP;
   vector<int>     *trig_EF_el_tightPPIso;
   vector<int>     *trig_EF_el_EF_2e10_medium;
   vector<int>     *trig_EF_el_EF_2e10_medium_mu6;
   vector<int>     *trig_EF_el_EF_2e12T_medium;
   vector<int>     *trig_EF_el_EF_2e12_medium;
   vector<int>     *trig_EF_el_EF_2e15_medium;
   vector<int>     *trig_EF_el_EF_2e5_tight;
   vector<int>     *trig_EF_el_EF_2e5_tight_Jpsi;
   vector<int>     *trig_EF_el_EF_e10_medium;
   vector<int>     *trig_EF_el_EF_e10_medium_2mu6;
   vector<int>     *trig_EF_el_EF_e10_medium_mu10;
   vector<int>     *trig_EF_el_EF_e10_medium_mu6;
   vector<int>     *trig_EF_el_EF_e10_medium_mu6_topo_medium;
   vector<int>     *trig_EF_el_EF_e11T_medium;
   vector<int>     *trig_EF_el_EF_e11T_medium_2e6T_medium;
   vector<int>     *trig_EF_el_EF_e11_etcut;
   vector<int>     *trig_EF_el_EF_e12T_medium_mu6_topo_medium;
   vector<int>     *trig_EF_el_EF_e12_medium;
   vector<int>     *trig_EF_el_EF_e13_etcut_xs60_noMu;
   vector<int>     *trig_EF_el_EF_e13_etcut_xs60_noMu_dphi2j10xe07;
   vector<int>     *trig_EF_el_EF_e13_etcut_xs70_noMu;
   vector<int>     *trig_EF_el_EF_e15_HLTtighter;
   vector<int>     *trig_EF_el_EF_e15_medium;
   vector<int>     *trig_EF_el_EF_e15_medium_e12_medium;
   vector<int>     *trig_EF_el_EF_e15_medium_xe30_noMu;
   vector<int>     *trig_EF_el_EF_e15_medium_xe40_noMu;
   vector<int>     *trig_EF_el_EF_e15_medium_xe50_noMu;
   vector<int>     *trig_EF_el_EF_e15_tight;
   vector<int>     *trig_EF_el_EF_e20_etcut_xs60_noMu;
   vector<int>     *trig_EF_el_EF_e20_etcut_xs60_noMu_dphi2j10xe07;
   vector<int>     *trig_EF_el_EF_e20_loose;
   vector<int>     *trig_EF_el_EF_e20_loose1;
   vector<int>     *trig_EF_el_EF_e20_looseTrk;
   vector<int>     *trig_EF_el_EF_e20_medium;
   vector<int>     *trig_EF_el_EF_e20_medium1;
   vector<int>     *trig_EF_el_EF_e20_medium2;
   vector<int>     *trig_EF_el_EF_e20_medium_IDTrkNoCut;
   vector<int>     *trig_EF_el_EF_e20_medium_SiTrk;
   vector<int>     *trig_EF_el_EF_e20_medium_TRT;
   vector<int>     *trig_EF_el_EF_e20_tight_e15_NoCut_Zee;
   vector<int>     *trig_EF_el_EF_e22_etcut_xs60_noMu;
   vector<int>     *trig_EF_el_EF_e22_etcut_xs60_noMu_dphi2j10xe07;
   vector<int>     *trig_EF_el_EF_e22_loose;
   vector<int>     *trig_EF_el_EF_e22_loose1;
   vector<int>     *trig_EF_el_EF_e22_looseTrk;
   vector<int>     *trig_EF_el_EF_e22_medium;
   vector<int>     *trig_EF_el_EF_e22_medium1;
   vector<int>     *trig_EF_el_EF_e22_medium2;
   vector<int>     *trig_EF_el_EF_e22_medium_IDTrkNoCut;
   vector<int>     *trig_EF_el_EF_e22_medium_SiTrk;
   vector<int>     *trig_EF_el_EF_e22_medium_TRT;
   vector<int>     *trig_EF_el_EF_e33_medium;
   vector<int>     *trig_EF_el_EF_e35_medium;
   vector<int>     *trig_EF_el_EF_e40_medium;
   vector<int>     *trig_EF_el_EF_e45_medium;
   vector<int>     *trig_EF_el_EF_e45_medium1;
   vector<int>     *trig_EF_el_EF_e5_medium_mu6;
   vector<int>     *trig_EF_el_EF_e5_medium_mu6_topo_medium;
   vector<int>     *trig_EF_el_EF_e5_tight;
   vector<int>     *trig_EF_el_EF_e5_tight_e14_etcut_Jpsi;
   vector<int>     *trig_EF_el_EF_e5_tight_e4_etcut_Jpsi;
   vector<int>     *trig_EF_el_EF_e5_tight_e4_etcut_Jpsi_SiTrk;
   vector<int>     *trig_EF_el_EF_e5_tight_e4_etcut_Jpsi_TRT;
   vector<int>     *trig_EF_el_EF_e5_tight_e5_NoCut;
   vector<int>     *trig_EF_el_EF_e5_tight_e9_etcut_Jpsi;
   vector<int>     *trig_EF_el_EF_e60_loose;
   vector<int>     *trig_EF_el_EF_e6T_medium;
   vector<int>     *trig_EF_el_EF_e7_tight_e14_etcut_Jpsi;
   vector<int>     *trig_EF_el_EF_e9_tight_e5_tight_Jpsi;
   vector<int>     *trig_EF_el_EF_eb_physics;
   vector<int>     *trig_EF_el_EF_eb_physics_empty;
   vector<int>     *trig_EF_el_EF_eb_physics_firstempty;
   vector<int>     *trig_EF_el_EF_eb_physics_noL1PS;
   vector<int>     *trig_EF_el_EF_eb_physics_unpaired_iso;
   vector<int>     *trig_EF_el_EF_eb_physics_unpaired_noniso;
   vector<int>     *trig_EF_el_EF_eb_random;
   vector<int>     *trig_EF_el_EF_eb_random_empty;
   vector<int>     *trig_EF_el_EF_eb_random_firstempty;
   vector<int>     *trig_EF_el_EF_eb_random_unpaired_iso;
   vector<float>   *trig_EF_el_vertweight;
   vector<int>     *trig_EF_el_hastrack;
   Int_t           trig_EF_ph_n;
   vector<float>   *trig_EF_ph_E;
   vector<float>   *trig_EF_ph_Et;
   vector<float>   *trig_EF_ph_pt;
   vector<float>   *trig_EF_ph_m;
   vector<float>   *trig_EF_ph_eta;
   vector<float>   *trig_EF_ph_phi;
   vector<float>   *trig_EF_ph_px;
   vector<float>   *trig_EF_ph_py;
   vector<float>   *trig_EF_ph_pz;
   vector<int>     *trig_EF_ph_EF_2g15_loose;
   vector<int>     *trig_EF_ph_EF_2g20_loose;
   vector<int>     *trig_EF_ph_EF_g100_etcut_g50_etcut;
   vector<int>     *trig_EF_ph_EF_g10_NoCut_cosmic;
   vector<int>     *trig_EF_ph_EF_g11_etcut;
   vector<int>     *trig_EF_ph_EF_g11_etcut_larcalib;
   vector<int>     *trig_EF_ph_EF_g150_etcut;
   vector<int>     *trig_EF_ph_EF_g15_loose;
   vector<int>     *trig_EF_ph_EF_g15_loose_larcalib;
   vector<int>     *trig_EF_ph_EF_g20_etcut;
   vector<int>     *trig_EF_ph_EF_g20_etcut_xe30_noMu;
   vector<int>     *trig_EF_ph_EF_g20_loose;
   vector<int>     *trig_EF_ph_EF_g20_loose_larcalib;
   vector<int>     *trig_EF_ph_EF_g40_loose;
   vector<int>     *trig_EF_ph_EF_g40_loose_EFxe40_noMu;
   vector<int>     *trig_EF_ph_EF_g40_loose_larcalib;
   vector<int>     *trig_EF_ph_EF_g40_loose_xe45_medium_noMu;
   vector<int>     *trig_EF_ph_EF_g40_loose_xe55_medium_noMu;
   vector<int>     *trig_EF_ph_EF_g40_tight;
   vector<int>     *trig_EF_ph_EF_g40_tight_b10_medium;
   vector<int>     *trig_EF_ph_EF_g5_NoCut_cosmic;
   vector<int>     *trig_EF_ph_EF_g60_loose;
   vector<int>     *trig_EF_ph_EF_g60_loose_larcalib;
   vector<int>     *trig_EF_ph_EF_g80_loose;
   vector<int>     *trig_EF_ph_EF_g80_loose_larcalib;
   vector<int>     *trig_EF_ph_author;
   vector<int>     *trig_EF_ph_isRecovered;
   vector<unsigned int> *trig_EF_ph_isEM;
   vector<int>     *trig_EF_ph_convFlag;
   vector<int>     *trig_EF_ph_isConv;
   vector<int>     *trig_EF_ph_nConv;
   vector<int>     *trig_EF_ph_nSingleTrackConv;
   vector<int>     *trig_EF_ph_nDoubleTrackConv;
   vector<int>     *trig_EF_ph_loose;
   vector<int>     *trig_EF_ph_looseIso;
   vector<int>     *trig_EF_ph_tight;
   vector<int>     *trig_EF_ph_tightIso;
   vector<int>     *trig_EF_ph_looseAR;
   vector<int>     *trig_EF_ph_looseARIso;
   vector<int>     *trig_EF_ph_tightAR;
   vector<int>     *trig_EF_ph_tightARIso;
   Int_t           trig_EF_jet_n;
   vector<float>   *trig_EF_jet_emscale_E;
   vector<float>   *trig_EF_jet_emscale_pt;
   vector<float>   *trig_EF_jet_emscale_m;
   vector<float>   *trig_EF_jet_emscale_eta;
   vector<float>   *trig_EF_jet_emscale_phi;
   vector<int>     *trig_EF_jet_EF_2b10_medium_4j30_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_2b10_medium_j75_j30_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_3j100_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_3j30_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_3j40_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_3j45_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_3j75_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_4j30_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_4j40_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_4j45_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_4j55_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_4j60_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_5j30_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_5j40_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_5j45_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_6j30_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_b10_medium_4j30_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_fj100_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_fj10_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_fj135_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_fj15_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_fj20_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_fj30_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_fj55_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_fj75_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j100_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j10_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j135_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j15_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j180_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j20_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j240_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j30_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j30_fj30_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j320_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j40_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j40_fj40_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j425_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j55_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j55_fj55_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j75_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_j75_fj75_a4tc_EFFS;
   vector<int>     *trig_EF_jet_EF_mu4_j10_a4tc_EFFS;

   // List of branches
   TBranch        *b_trig_DB_SMK;   //!
   TBranch        *b_trig_DB_L1PSK;   //!
   TBranch        *b_trig_DB_HLTPSK;   //!
   TBranch        *b_bunch_configID;   //!
   TBranch        *b_RunNumber;   //!
   TBranch        *b_EventNumber;   //!
   TBranch        *b_timestamp;   //!
   TBranch        *b_timestamp_ns;   //!
   TBranch        *b_lbn;   //!
   TBranch        *b_bcid;   //!
   TBranch        *b_detmask0;   //!
   TBranch        *b_detmask1;   //!
   TBranch        *b_actualIntPerXing;   //!
   TBranch        *b_averageIntPerXing;   //!
   TBranch        *b_pixelFlags;   //!
   TBranch        *b_sctFlags;   //!
   TBranch        *b_trtFlags;   //!
   TBranch        *b_larFlags;   //!
   TBranch        *b_tileFlags;   //!
   TBranch        *b_muonFlags;   //!
   TBranch        *b_fwdFlags;   //!
   TBranch        *b_coreFlags;   //!
   TBranch        *b_pixelError;   //!
   TBranch        *b_sctError;   //!
   TBranch        *b_trtError;   //!
   TBranch        *b_larError;   //!
   TBranch        *b_tileError;   //!
   TBranch        *b_muonError;   //!
   TBranch        *b_fwdError;   //!
   TBranch        *b_coreError;   //!
   TBranch        *b_el_n;   //!
   TBranch        *b_el_E;   //!
   TBranch        *b_el_Et;   //!
   TBranch        *b_el_pt;   //!
   TBranch        *b_el_m;   //!
   TBranch        *b_el_eta;   //!
   TBranch        *b_el_phi;   //!
   TBranch        *b_el_px;   //!
   TBranch        *b_el_py;   //!
   TBranch        *b_el_pz;   //!
   TBranch        *b_el_charge;   //!
   TBranch        *b_el_author;   //!
   TBranch        *b_el_isEM;   //!
   TBranch        *b_el_OQ;   //!
   TBranch        *b_el_convFlag;   //!
   TBranch        *b_el_isConv;   //!
   TBranch        *b_el_nConv;   //!
   TBranch        *b_el_nSingleTrackConv;   //!
   TBranch        *b_el_nDoubleTrackConv;   //!
   TBranch        *b_el_OQRecalc;   //!
   TBranch        *b_el_loose;   //!
   TBranch        *b_el_looseIso;   //!
   TBranch        *b_el_medium;   //!
   TBranch        *b_el_mediumIso;   //!
   TBranch        *b_el_mediumWithoutTrack;   //!
   TBranch        *b_el_mediumIsoWithoutTrack;   //!
   TBranch        *b_el_tight;   //!
   TBranch        *b_el_tightIso;   //!
   TBranch        *b_el_tightWithoutTrack;   //!
   TBranch        *b_el_tightIsoWithoutTrack;   //!
   TBranch        *b_el_loosePP;   //!
   TBranch        *b_el_loosePPIso;   //!
   TBranch        *b_el_mediumPP;   //!
   TBranch        *b_el_mediumPPIso;   //!
   TBranch        *b_el_tightPP;   //!
   TBranch        *b_el_tightPPIso;   //!
   TBranch        *b_el_goodOQ;   //!
   TBranch        *b_el_Ethad;   //!
   TBranch        *b_el_Ethad1;   //!
   TBranch        *b_el_f1;   //!
   TBranch        *b_el_f1core;   //!
   TBranch        *b_el_Emins1;   //!
   TBranch        *b_el_fside;   //!
   TBranch        *b_el_Emax2;   //!
   TBranch        *b_el_ws3;   //!
   TBranch        *b_el_wstot;   //!
   TBranch        *b_el_emaxs1;   //!
   TBranch        *b_el_deltaEs;   //!
   TBranch        *b_el_E233;   //!
   TBranch        *b_el_E237;   //!
   TBranch        *b_el_E277;   //!
   TBranch        *b_el_weta2;   //!
   TBranch        *b_el_f3;   //!
   TBranch        *b_el_f3core;   //!
   TBranch        *b_el_rphiallcalo;   //!
   TBranch        *b_el_Etcone45;   //!
   TBranch        *b_el_Etcone15;   //!
   TBranch        *b_el_Etcone20;   //!
   TBranch        *b_el_Etcone25;   //!
   TBranch        *b_el_Etcone30;   //!
   TBranch        *b_el_Etcone35;   //!
   TBranch        *b_el_Etcone40;   //!
   TBranch        *b_el_ptcone20;   //!
   TBranch        *b_el_ptcone30;   //!
   TBranch        *b_el_ptcone40;   //!
   TBranch        *b_el_nucone20;   //!
   TBranch        *b_el_nucone30;   //!
   TBranch        *b_el_nucone40;   //!
   TBranch        *b_el_Etcone15_pt_corrected;   //!
   TBranch        *b_el_Etcone20_pt_corrected;   //!
   TBranch        *b_el_Etcone25_pt_corrected;   //!
   TBranch        *b_el_Etcone30_pt_corrected;   //!
   TBranch        *b_el_Etcone35_pt_corrected;   //!
   TBranch        *b_el_Etcone40_pt_corrected;   //!
   TBranch        *b_el_convanglematch;   //!
   TBranch        *b_el_convtrackmatch;   //!
   TBranch        *b_el_hasconv;   //!
   TBranch        *b_el_convvtxx;   //!
   TBranch        *b_el_convvtxy;   //!
   TBranch        *b_el_convvtxz;   //!
   TBranch        *b_el_Rconv;   //!
   TBranch        *b_el_zconv;   //!
   TBranch        *b_el_convvtxchi2;   //!
   TBranch        *b_el_pt1conv;   //!
   TBranch        *b_el_convtrk1nBLHits;   //!
   TBranch        *b_el_convtrk1nPixHits;   //!
   TBranch        *b_el_convtrk1nSCTHits;   //!
   TBranch        *b_el_convtrk1nTRTHits;   //!
   TBranch        *b_el_pt2conv;   //!
   TBranch        *b_el_convtrk2nBLHits;   //!
   TBranch        *b_el_convtrk2nPixHits;   //!
   TBranch        *b_el_convtrk2nSCTHits;   //!
   TBranch        *b_el_convtrk2nTRTHits;   //!
   TBranch        *b_el_ptconv;   //!
   TBranch        *b_el_pzconv;   //!
   TBranch        *b_el_pos7;   //!
   TBranch        *b_el_etacorrmag;   //!
   TBranch        *b_el_deltaeta1;   //!
   TBranch        *b_el_deltaeta2;   //!
   TBranch        *b_el_deltaphi2;   //!
   TBranch        *b_el_deltaphiRescaled;   //!
   TBranch        *b_el_deltaPhiRot;   //!
   TBranch        *b_el_expectHitInBLayer;   //!
   TBranch        *b_el_trackd0_physics;   //!
   TBranch        *b_el_etaSampling1;   //!
   TBranch        *b_el_reta;   //!
   TBranch        *b_el_rphi;   //!
   TBranch        *b_el_EtringnoisedR03sig2;   //!
   TBranch        *b_el_EtringnoisedR03sig3;   //!
   TBranch        *b_el_EtringnoisedR03sig4;   //!
   TBranch        *b_el_isolationlikelihoodjets;   //!
   TBranch        *b_el_isolationlikelihoodhqelectrons;   //!
   TBranch        *b_el_electronweight;   //!
   TBranch        *b_el_electronbgweight;   //!
   TBranch        *b_el_softeweight;   //!
   TBranch        *b_el_softebgweight;   //!
   TBranch        *b_el_neuralnet;   //!
   TBranch        *b_el_Hmatrix;   //!
   TBranch        *b_el_Hmatrix5;   //!
   TBranch        *b_el_adaboost;   //!
   TBranch        *b_el_softeneuralnet;   //!
   TBranch        *b_el_zvertex;   //!
   TBranch        *b_el_errz;   //!
   TBranch        *b_el_etap;   //!
   TBranch        *b_el_depth;   //!
   TBranch        *b_el_refittedTrack_n;   //!
   TBranch        *b_el_refittedTrack_author;   //!
   TBranch        *b_el_refittedTrack_chi2;   //!
   TBranch        *b_el_refittedTrack_hasBrem;   //!
   TBranch        *b_el_refittedTrack_bremRadius;   //!
   TBranch        *b_el_refittedTrack_bremZ;   //!
   TBranch        *b_el_refittedTrack_bremRadiusErr;   //!
   TBranch        *b_el_refittedTrack_bremZErr;   //!
   TBranch        *b_el_refittedTrack_bremFitStatus;   //!
   TBranch        *b_el_refittedTrack_qoverp;   //!
   TBranch        *b_el_refittedTrack_d0;   //!
   TBranch        *b_el_refittedTrack_z0;   //!
   TBranch        *b_el_refittedTrack_theta;   //!
   TBranch        *b_el_refittedTrack_phi;   //!
   TBranch        *b_el_refittedTrack_LMqoverp;   //!
   TBranch        *b_el_Es0;   //!
   TBranch        *b_el_etas0;   //!
   TBranch        *b_el_phis0;   //!
   TBranch        *b_el_Es1;   //!
   TBranch        *b_el_etas1;   //!
   TBranch        *b_el_phis1;   //!
   TBranch        *b_el_Es2;   //!
   TBranch        *b_el_etas2;   //!
   TBranch        *b_el_phis2;   //!
   TBranch        *b_el_Es3;   //!
   TBranch        *b_el_etas3;   //!
   TBranch        *b_el_phis3;   //!
   TBranch        *b_el_E_PreSamplerB;   //!
   TBranch        *b_el_E_EMB1;   //!
   TBranch        *b_el_E_EMB2;   //!
   TBranch        *b_el_E_EMB3;   //!
   TBranch        *b_el_E_PreSamplerE;   //!
   TBranch        *b_el_E_EME1;   //!
   TBranch        *b_el_E_EME2;   //!
   TBranch        *b_el_E_EME3;   //!
   TBranch        *b_el_E_HEC0;   //!
   TBranch        *b_el_E_HEC1;   //!
   TBranch        *b_el_E_HEC2;   //!
   TBranch        *b_el_E_HEC3;   //!
   TBranch        *b_el_E_TileBar0;   //!
   TBranch        *b_el_E_TileBar1;   //!
   TBranch        *b_el_E_TileBar2;   //!
   TBranch        *b_el_E_TileGap1;   //!
   TBranch        *b_el_E_TileGap2;   //!
   TBranch        *b_el_E_TileGap3;   //!
   TBranch        *b_el_E_TileExt0;   //!
   TBranch        *b_el_E_TileExt1;   //!
   TBranch        *b_el_E_TileExt2;   //!
   TBranch        *b_el_E_FCAL0;   //!
   TBranch        *b_el_E_FCAL1;   //!
   TBranch        *b_el_E_FCAL2;   //!
   TBranch        *b_el_cl_E;   //!
   TBranch        *b_el_cl_pt;   //!
   TBranch        *b_el_cl_eta;   //!
   TBranch        *b_el_cl_phi;   //!
   TBranch        *b_el_firstEdens;   //!
   TBranch        *b_el_cellmaxfrac;   //!
   TBranch        *b_el_longitudinal;   //!
   TBranch        *b_el_secondlambda;   //!
   TBranch        *b_el_lateral;   //!
   TBranch        *b_el_secondR;   //!
   TBranch        *b_el_centerlambda;   //!
   TBranch        *b_el_rawcl_Es0;   //!
   TBranch        *b_el_rawcl_etas0;   //!
   TBranch        *b_el_rawcl_phis0;   //!
   TBranch        *b_el_rawcl_Es1;   //!
   TBranch        *b_el_rawcl_etas1;   //!
   TBranch        *b_el_rawcl_phis1;   //!
   TBranch        *b_el_rawcl_Es2;   //!
   TBranch        *b_el_rawcl_etas2;   //!
   TBranch        *b_el_rawcl_phis2;   //!
   TBranch        *b_el_rawcl_Es3;   //!
   TBranch        *b_el_rawcl_etas3;   //!
   TBranch        *b_el_rawcl_phis3;   //!
   TBranch        *b_el_rawcl_E;   //!
   TBranch        *b_el_rawcl_pt;   //!
   TBranch        *b_el_rawcl_eta;   //!
   TBranch        *b_el_rawcl_phi;   //!
   TBranch        *b_el_trackd0;   //!
   TBranch        *b_el_trackz0;   //!
   TBranch        *b_el_trackphi;   //!
   TBranch        *b_el_tracktheta;   //!
   TBranch        *b_el_trackqoverp;   //!
   TBranch        *b_el_trackpt;   //!
   TBranch        *b_el_tracketa;   //!
   TBranch        *b_el_trackfitchi2;   //!
   TBranch        *b_el_trackfitndof;   //!
   TBranch        *b_el_nBLHits;   //!
   TBranch        *b_el_nPixHits;   //!
   TBranch        *b_el_nSCTHits;   //!
   TBranch        *b_el_nTRTHits;   //!
   TBranch        *b_el_nTRTHighTHits;   //!
   TBranch        *b_el_nPixHoles;   //!
   TBranch        *b_el_nSCTHoles;   //!
   TBranch        *b_el_nTRTHoles;   //!
   TBranch        *b_el_nBLSharedHits;   //!
   TBranch        *b_el_nPixSharedHits;   //!
   TBranch        *b_el_nSCTSharedHits;   //!
   TBranch        *b_el_nBLayerOutliers;   //!
   TBranch        *b_el_nPixelOutliers;   //!
   TBranch        *b_el_nSCTOutliers;   //!
   TBranch        *b_el_nTRTOutliers;   //!
   TBranch        *b_el_nTRTHighTOutliers;   //!
   TBranch        *b_el_expectBLayerHit;   //!
   TBranch        *b_el_nSiHits;   //!
   TBranch        *b_el_TRTHighTHitsRatio;   //!
   TBranch        *b_el_TRTHighTOutliersRatio;   //!
   TBranch        *b_el_pixeldEdx;   //!
   TBranch        *b_el_nGoodHitsPixeldEdx;   //!
   TBranch        *b_el_massPixeldEdx;   //!
   TBranch        *b_el_likelihoodsPixeldEdx;   //!
   TBranch        *b_el_eProbabilityComb;   //!
   TBranch        *b_el_eProbabilityHT;   //!
   TBranch        *b_el_eProbabilityToT;   //!
   TBranch        *b_el_eProbabilityBrem;   //!
   TBranch        *b_el_vertweight;   //!
   TBranch        *b_el_vertx;   //!
   TBranch        *b_el_verty;   //!
   TBranch        *b_el_vertz;   //!
   TBranch        *b_el_trackd0beam;   //!
   TBranch        *b_el_trackz0beam;   //!
   TBranch        *b_el_tracksigd0beam;   //!
   TBranch        *b_el_tracksigz0beam;   //!
   TBranch        *b_el_trackd0pv;   //!
   TBranch        *b_el_trackz0pv;   //!
   TBranch        *b_el_tracksigd0pv;   //!
   TBranch        *b_el_tracksigz0pv;   //!
   TBranch        *b_el_trackIPEstimate_d0_biasedpvunbiased;   //!
   TBranch        *b_el_trackIPEstimate_z0_biasedpvunbiased;   //!
   TBranch        *b_el_trackIPEstimate_d0_unbiasedpvunbiased;   //!
   TBranch        *b_el_trackIPEstimate_z0_unbiasedpvunbiased;   //!
   TBranch        *b_el_trackIPEstimate_sigd0_biasedpvunbiased;   //!
   TBranch        *b_el_trackIPEstimate_sigz0_biasedpvunbiased;   //!
   TBranch        *b_el_trackIPEstimate_sigd0_unbiasedpvunbiased;   //!
   TBranch        *b_el_trackIPEstimate_sigz0_unbiasedpvunbiased;   //!
   TBranch        *b_el_hastrack;   //!
   TBranch        *b_el_deltaEmax2;   //!
   TBranch        *b_el_calibHitsShowerDepth;   //!
   TBranch        *b_el_isIso;   //!
   TBranch        *b_el_mvaptcone20;   //!
   TBranch        *b_el_mvaptcone30;   //!
   TBranch        *b_el_mvaptcone40;   //!
   TBranch        *b_el_jet_dr;   //!
   TBranch        *b_el_jet_E;   //!
   TBranch        *b_el_jet_pt;   //!
   TBranch        *b_el_jet_m;   //!
   TBranch        *b_el_jet_eta;   //!
   TBranch        *b_el_jet_phi;   //!
   TBranch        *b_el_jet_matched;   //!
   TBranch        *b_el_Etcone40_ED_corrected;   //!
   TBranch        *b_el_Etcone40_corrected;   //!
   TBranch        *b_el_Etcone35_ED_corrected;   //!
   TBranch        *b_el_Etcone35_corrected;   //!
   TBranch        *b_el_Etcone30_ED_corrected;   //!
   TBranch        *b_el_Etcone30_corrected;   //!
   TBranch        *b_el_Etcone25_ED_corrected;   //!
   TBranch        *b_el_Etcone25_corrected;   //!
   TBranch        *b_el_Etcone20_ED_corrected;   //!
   TBranch        *b_el_Etcone20_corrected;   //!
   TBranch        *b_el_Etcone15_ED_corrected;   //!
   TBranch        *b_el_Etcone15_corrected;   //!
   TBranch        *b_el_EF_dr;   //!
   TBranch        *b_el_EF_index;   //!
   TBranch        *b_el_L2_dr;   //!
   TBranch        *b_el_L2_index;   //!
   TBranch        *b_el_L1_dr;   //!
   TBranch        *b_el_L1_index;   //!
   TBranch        *b_EF_2b10_medium_4L1J10;   //!
   TBranch        *b_EF_2b10_medium_4j30_a4tc_EFFS;   //!
   TBranch        *b_EF_2b10_medium_L1JE100;   //!
   TBranch        *b_EF_2b10_medium_L1JE140;   //!
   TBranch        *b_EF_2b10_medium_L1_2J10J50;   //!
   TBranch        *b_EF_2b10_medium_j75_j30_a4tc_EFFS;   //!
   TBranch        *b_EF_2b15_medium_3L1J15;   //!
   TBranch        *b_EF_2b20_medium_3L1J20;   //!
   TBranch        *b_EF_2e10_medium;   //!
   TBranch        *b_EF_2e10_medium_mu6;   //!
   TBranch        *b_EF_2e12T_medium;   //!
   TBranch        *b_EF_2e12_medium;   //!
   TBranch        *b_EF_2e15_medium;   //!
   TBranch        *b_EF_2e5_tight;   //!
   TBranch        *b_EF_2e5_tight_Jpsi;   //!
   TBranch        *b_EF_2g15_loose;   //!
   TBranch        *b_EF_2g20_loose;   //!
   TBranch        *b_EF_2j45_a4tc_EFFS_leadingmct100_xe40_medium_noMu;   //!
   TBranch        *b_EF_2j55_a4tc_EFFS_leadingmct100_xe40_medium_noMu;   //!
   TBranch        *b_EF_2mu10;   //!
   TBranch        *b_EF_2mu10_empty;   //!
   TBranch        *b_EF_2mu10_loose;   //!
   TBranch        *b_EF_2mu10_loose_empty;   //!
   TBranch        *b_EF_2mu10_loose_noOvlpRm;   //!
   TBranch        *b_EF_2mu13_Zmumu_IDTrkNoCut;   //!
   TBranch        *b_EF_2mu4;   //!
   TBranch        *b_EF_2mu4_Bmumu;   //!
   TBranch        *b_EF_2mu4_Bmumux;   //!
   TBranch        *b_EF_2mu4_DiMu;   //!
   TBranch        *b_EF_2mu4_DiMu_DY;   //!
   TBranch        *b_EF_2mu4_DiMu_DY20;   //!
   TBranch        *b_EF_2mu4_DiMu_DY_noVtx_noOS;   //!
   TBranch        *b_EF_2mu4_DiMu_SiTrk;   //!
   TBranch        *b_EF_2mu4_DiMu_noVtx_noOS;   //!
   TBranch        *b_EF_2mu4_Jpsimumu;   //!
   TBranch        *b_EF_2mu4_Jpsimumu_IDTrkNoCut;   //!
   TBranch        *b_EF_2mu4_Upsimumu;   //!
   TBranch        *b_EF_2mu4i_DiMu_DY;   //!
   TBranch        *b_EF_2mu6;   //!
   TBranch        *b_EF_2mu6_DiMu;   //!
   TBranch        *b_EF_2mu6_MSonly_g10_loose;   //!
   TBranch        *b_EF_2mu6_MSonly_g10_loose_nonfilled;   //!
   TBranch        *b_EF_2mu6_NL;   //!
   TBranch        *b_EF_2tau29T_medium1;   //!
   TBranch        *b_EF_2tau29_medium1;   //!
   TBranch        *b_EF_3b10_loose_4L1J10;   //!
   TBranch        *b_EF_3b15_loose_4L1J15;   //!
   TBranch        *b_EF_4j30_a4tc_EFFS;   //!
   TBranch        *b_EF_b10_EFj10_a4tc_EFFS_IDTrkNoCut;   //!
   TBranch        *b_EF_b10_IDTrkNoCut;   //!
   TBranch        *b_EF_b10_medium_4j30_a4tc_EFFS;   //!
   TBranch        *b_EF_b10_medium_EFxe25_noMu_L1JE140;   //!
   TBranch        *b_EF_b10_tight_4L1J10;   //!
   TBranch        *b_EF_b10_tight_L1JE140;   //!
   TBranch        *b_EF_e10_medium;   //!
   TBranch        *b_EF_e10_medium_2mu6;   //!
   TBranch        *b_EF_e10_medium_mu10;   //!
   TBranch        *b_EF_e10_medium_mu6;   //!
   TBranch        *b_EF_e10_medium_mu6_topo_medium;   //!
   TBranch        *b_EF_e11T_medium;   //!
   TBranch        *b_EF_e11T_medium_2e6T_medium;   //!
   TBranch        *b_EF_e11_etcut;   //!
   TBranch        *b_EF_e12T_medium_mu6_topo_medium;   //!
   TBranch        *b_EF_e12_medium;   //!
   TBranch        *b_EF_e13_etcut_xs60_noMu;   //!
   TBranch        *b_EF_e13_etcut_xs60_noMu_dphi2j10xe07;   //!
   TBranch        *b_EF_e13_etcut_xs70_noMu;   //!
   TBranch        *b_EF_e15_HLTtighter;   //!
   TBranch        *b_EF_e15_medium;   //!
   TBranch        *b_EF_e15_medium_e12_medium;   //!
   TBranch        *b_EF_e15_medium_xe30_noMu;   //!
   TBranch        *b_EF_e15_medium_xe40_noMu;   //!
   TBranch        *b_EF_e15_medium_xe50_noMu;   //!
   TBranch        *b_EF_e15_tight;   //!
   TBranch        *b_EF_e20_etcut_xs60_noMu;   //!
   TBranch        *b_EF_e20_etcut_xs60_noMu_dphi2j10xe07;   //!
   TBranch        *b_EF_e20_loose;   //!
   TBranch        *b_EF_e20_loose1;   //!
   TBranch        *b_EF_e20_looseTrk;   //!
   TBranch        *b_EF_e20_medium;   //!
   TBranch        *b_EF_e20_medium1;   //!
   TBranch        *b_EF_e20_medium2;   //!
   TBranch        *b_EF_e20_medium_IDTrkNoCut;   //!
   TBranch        *b_EF_e20_medium_SiTrk;   //!
   TBranch        *b_EF_e20_medium_TRT;   //!
   TBranch        *b_EF_e20_tight_e15_NoCut_Zee;   //!
   TBranch        *b_EF_e22_etcut_xs60_noMu;   //!
   TBranch        *b_EF_e22_etcut_xs60_noMu_dphi2j10xe07;   //!
   TBranch        *b_EF_e22_loose;   //!
   TBranch        *b_EF_e22_loose1;   //!
   TBranch        *b_EF_e22_looseTrk;   //!
   TBranch        *b_EF_e22_medium;   //!
   TBranch        *b_EF_e22_medium1;   //!
   TBranch        *b_EF_e22_medium2;   //!
   TBranch        *b_EF_e22_medium_IDTrkNoCut;   //!
   TBranch        *b_EF_e22_medium_SiTrk;   //!
   TBranch        *b_EF_e22_medium_TRT;   //!
   TBranch        *b_EF_e33_medium;   //!
   TBranch        *b_EF_e35_medium;   //!
   TBranch        *b_EF_e40_medium;   //!
   TBranch        *b_EF_e45_medium;   //!
   TBranch        *b_EF_e45_medium1;   //!
   TBranch        *b_EF_e5_medium_mu6;   //!
   TBranch        *b_EF_e5_medium_mu6_topo_medium;   //!
   TBranch        *b_EF_e5_tight;   //!
   TBranch        *b_EF_e5_tight_e14_etcut_Jpsi;   //!
   TBranch        *b_EF_e5_tight_e4_etcut_Jpsi;   //!
   TBranch        *b_EF_e5_tight_e4_etcut_Jpsi_SiTrk;   //!
   TBranch        *b_EF_e5_tight_e4_etcut_Jpsi_TRT;   //!
   TBranch        *b_EF_e5_tight_e5_NoCut;   //!
   TBranch        *b_EF_e5_tight_e9_etcut_Jpsi;   //!
   TBranch        *b_EF_e60_loose;   //!
   TBranch        *b_EF_e6T_medium;   //!
   TBranch        *b_EF_e7_tight_e14_etcut_Jpsi;   //!
   TBranch        *b_EF_e9_tight_e5_tight_Jpsi;   //!
   TBranch        *b_EF_eb_physics;   //!
   TBranch        *b_EF_eb_physics_empty;   //!
   TBranch        *b_EF_eb_physics_firstempty;   //!
   TBranch        *b_EF_eb_physics_noL1PS;   //!
   TBranch        *b_EF_eb_physics_unpaired_iso;   //!
   TBranch        *b_EF_eb_physics_unpaired_noniso;   //!
   TBranch        *b_EF_eb_random;   //!
   TBranch        *b_EF_eb_random_empty;   //!
   TBranch        *b_EF_eb_random_firstempty;   //!
   TBranch        *b_EF_eb_random_unpaired_iso;   //!
   TBranch        *b_EF_g100_etcut_g50_etcut;   //!
   TBranch        *b_EF_g10_NoCut_cosmic;   //!
   TBranch        *b_EF_g11_etcut;   //!
   TBranch        *b_EF_g11_etcut_larcalib;   //!
   TBranch        *b_EF_g150_etcut;   //!
   TBranch        *b_EF_g15_loose;   //!
   TBranch        *b_EF_g15_loose_larcalib;   //!
   TBranch        *b_EF_g20_etcut;   //!
   TBranch        *b_EF_g20_etcut_xe30_noMu;   //!
   TBranch        *b_EF_g20_loose;   //!
   TBranch        *b_EF_g20_loose_larcalib;   //!
   TBranch        *b_EF_g40_loose;   //!
   TBranch        *b_EF_g40_loose_EFxe40_noMu;   //!
   TBranch        *b_EF_g40_loose_larcalib;   //!
   TBranch        *b_EF_g40_loose_xe45_medium_noMu;   //!
   TBranch        *b_EF_g40_loose_xe55_medium_noMu;   //!
   TBranch        *b_EF_g40_tight;   //!
   TBranch        *b_EF_g40_tight_b10_medium;   //!
   TBranch        *b_EF_g5_NoCut_cosmic;   //!
   TBranch        *b_EF_g60_loose;   //!
   TBranch        *b_EF_g60_loose_larcalib;   //!
   TBranch        *b_EF_g80_loose;   //!
   TBranch        *b_EF_g80_loose_larcalib;   //!
   TBranch        *b_EF_j100_a4tc_EFFS;   //!
   TBranch        *b_EF_j100_a4tc_EFFS_ht350;   //!
   TBranch        *b_EF_j100_a4tc_EFFS_ht400;   //!
   TBranch        *b_EF_j100_a4tc_EFFS_ht500;   //!
   TBranch        *b_EF_j10_a4tc_EFFS;   //!
   TBranch        *b_EF_j10_a4tc_EFFS_1vx;   //!
   TBranch        *b_EF_j135_a4tc_EFFS;   //!
   TBranch        *b_EF_j135_a4tc_EFFS_ht500;   //!
   TBranch        *b_EF_j135_j30_a4tc_EFFS_dphi04;   //!
   TBranch        *b_EF_j15_a4tc_EFFS;   //!
   TBranch        *b_EF_j180_a4tc_EFFS;   //!
   TBranch        *b_EF_j180_j30_a4tc_EFFS_dphi04;   //!
   TBranch        *b_EF_j20_a4tc_EFFS;   //!
   TBranch        *b_EF_j240_a10tc_EFFS;   //!
   TBranch        *b_EF_j240_a4tc_EFFS;   //!
   TBranch        *b_EF_j240_a4tc_EFFS_l2cleanph;   //!
   TBranch        *b_EF_j30_a4tc_EFFS;   //!
   TBranch        *b_EF_j30_a4tc_EFFS_l2cleanph;   //!
   TBranch        *b_EF_j30_eta13_a4tc_EFFS_EFxe30_noMu_empty;   //!
   TBranch        *b_EF_j30_eta13_a4tc_EFFS_EFxe30_noMu_firstempty;   //!
   TBranch        *b_EF_j30_fj30_a4tc_EFFS;   //!
   TBranch        *b_EF_j320_a10tc_EFFS;   //!
   TBranch        *b_EF_j320_a4tc_EFFS;   //!
   TBranch        *b_EF_j35_a4tc_EFFS_L1TAU_HVtrk;   //!
   TBranch        *b_EF_j35_a4tc_EFFS_L1TAU_HVtrk_cosmic;   //!
   TBranch        *b_EF_j35_a4tc_EFFS_L1TAU_HVtrk_firstempty;   //!
   TBranch        *b_EF_j35_a4tc_EFFS_L1TAU_HVtrk_unpaired_iso;   //!
   TBranch        *b_EF_j35_a4tc_EFFS_L1TAU_HVtrk_unpaired_noniso;   //!
   TBranch        *b_EF_j40_a4tc_EFFS;   //!
   TBranch        *b_EF_j40_fj40_a4tc_EFFS;   //!
   TBranch        *b_EF_j425_a10tc_EFFS;   //!
   TBranch        *b_EF_j425_a4tc_EFFS;   //!
   TBranch        *b_EF_j50_eta13_a4tc_EFFS_EFxe50_noMu_empty;   //!
   TBranch        *b_EF_j50_eta13_a4tc_EFFS_EFxe50_noMu_firstempty;   //!
   TBranch        *b_EF_j50_eta25_a4tc_EFFS_EFxe50_noMu_empty;   //!
   TBranch        *b_EF_j50_eta25_a4tc_EFFS_EFxe50_noMu_firstempty;   //!
   TBranch        *b_EF_j55_a4tc_EFFS;   //!
   TBranch        *b_EF_j55_a4tc_EFFS_xe55_medium_noMu_dphi2j30xe10;   //!
   TBranch        *b_EF_j55_a4tc_EFFS_xe55_medium_noMu_dphi2j30xe10_l2cleancons;   //!
   TBranch        *b_EF_j55_fj55_a4tc_EFFS;   //!
   TBranch        *b_EF_j65_a4tc_EFFS_xe65_noMu_dphi2j30xe10;   //!
   TBranch        *b_EF_j75_2j30_a4tc_EFFS_ht350;   //!
   TBranch        *b_EF_j75_a4tc_EFFS;   //!
   TBranch        *b_EF_j75_a4tc_EFFS_xe40_loose_noMu;   //!
   TBranch        *b_EF_j75_a4tc_EFFS_xe45_loose_noMu;   //!
   TBranch        *b_EF_j75_a4tc_EFFS_xe55_loose_noMu;   //!
   TBranch        *b_EF_j75_a4tc_EFFS_xe55_noMu;   //!
   TBranch        *b_EF_j75_a4tc_EFFS_xe55_noMu_l2cleancons;   //!
   TBranch        *b_EF_j75_fj75_a4tc_EFFS;   //!
   TBranch        *b_EF_j75_j30_a4tc_EFFS_anymct150;   //!
   TBranch        *b_EF_j75_j30_a4tc_EFFS_anymct175;   //!
   TBranch        *b_EF_j80_a4tc_EFFS_xe60_noMu;   //!
   TBranch        *b_EF_mu0_empty_NoAlg;   //!
   TBranch        *b_EF_mu0_firstempty_NoAlg;   //!
   TBranch        *b_EF_mu0_unpaired_iso_NoAlg;   //!
   TBranch        *b_EF_mu10;   //!
   TBranch        *b_EF_mu10_Jpsimumu;   //!
   TBranch        *b_EF_mu10_NL;   //!
   TBranch        *b_EF_mu10_Upsimumu_FS;   //!
   TBranch        *b_EF_mu10_Upsimumu_tight_FS;   //!
   TBranch        *b_EF_mu10_loose;   //!
   TBranch        *b_EF_mu10_muCombTag_NoEF;   //!
   TBranch        *b_EF_mu11_empty_NoAlg;   //!
   TBranch        *b_EF_mu13;   //!
   TBranch        *b_EF_mu13_MG;   //!
   TBranch        *b_EF_mu13_muCombTag_NoEF;   //!
   TBranch        *b_EF_mu15;   //!
   TBranch        *b_EF_mu15_mu10_EFFS;   //!
   TBranch        *b_EF_mu15_mu10_EFFS_medium;   //!
   TBranch        *b_EF_mu15_mu10_EFFS_tight;   //!
   TBranch        *b_EF_mu15_xe30_noMu;   //!
   TBranch        *b_EF_mu15i;   //!
   TBranch        *b_EF_mu15i_medium;   //!
   TBranch        *b_EF_mu18;   //!
   TBranch        *b_EF_mu18_L1J10;   //!
   TBranch        *b_EF_mu18_MG;   //!
   TBranch        *b_EF_mu18_MG_L1J10;   //!
   TBranch        *b_EF_mu18_MG_medium;   //!
   TBranch        *b_EF_mu18_medium;   //!
   TBranch        *b_EF_mu20;   //!
   TBranch        *b_EF_mu20_IDTrkNoCut;   //!
   TBranch        *b_EF_mu20_IDTrkNoCut_ManyVx;   //!
   TBranch        *b_EF_mu20_MG;   //!
   TBranch        *b_EF_mu20_MG_medium;   //!
   TBranch        *b_EF_mu20_empty;   //!
   TBranch        *b_EF_mu20_medium;   //!
   TBranch        *b_EF_mu20_mu10_EFFS_tight;   //!
   TBranch        *b_EF_mu20_muCombTag_NoEF;   //!
   TBranch        *b_EF_mu20i;   //!
   TBranch        *b_EF_mu20i_medium;   //!
   TBranch        *b_EF_mu22;   //!
   TBranch        *b_EF_mu22_MG;   //!
   TBranch        *b_EF_mu22_MG_medium;   //!
   TBranch        *b_EF_mu22_medium;   //!
   TBranch        *b_EF_mu24_MG_medium;   //!
   TBranch        *b_EF_mu24_MG_tight;   //!
   TBranch        *b_EF_mu24_medium;   //!
   TBranch        *b_EF_mu24_tight;   //!
   TBranch        *b_EF_mu30_MG_medium;   //!
   TBranch        *b_EF_mu30_MG_tight;   //!
   TBranch        *b_EF_mu30_medium;   //!
   TBranch        *b_EF_mu30_tight;   //!
   TBranch        *b_EF_mu4;   //!
   TBranch        *b_EF_mu40_MSonly_barrel;   //!
   TBranch        *b_EF_mu40_MSonly_barrel_medium;   //!
   TBranch        *b_EF_mu40_MSonly_empty;   //!
   TBranch        *b_EF_mu40_MSonly_tight;   //!
   TBranch        *b_EF_mu40_MSonly_tight_L1MU11;   //!
   TBranch        *b_EF_mu40_MSonly_tighter;   //!
   TBranch        *b_EF_mu40_slow;   //!
   TBranch        *b_EF_mu40_slow_empty;   //!
   TBranch        *b_EF_mu40_slow_medium;   //!
   TBranch        *b_EF_mu40_slow_outOfTime;   //!
   TBranch        *b_EF_mu40_slow_outOfTime_medium;   //!
   TBranch        *b_EF_mu4_DiMu;   //!
   TBranch        *b_EF_mu4_DiMu_FS_noOS;   //!
   TBranch        *b_EF_mu4_Jpsimumu;   //!
   TBranch        *b_EF_mu4_L1J10_matched;   //!
   TBranch        *b_EF_mu4_L1J15_matched;   //!
   TBranch        *b_EF_mu4_L1J20_matched;   //!
   TBranch        *b_EF_mu4_L1J30_matched;   //!
   TBranch        *b_EF_mu4_L1J50_matched;   //!
   TBranch        *b_EF_mu4_L1J75_matched;   //!
   TBranch        *b_EF_mu4_L1MU11_MSonly_cosmic;   //!
   TBranch        *b_EF_mu4_L1MU11_cosmic;   //!
   TBranch        *b_EF_mu4_MSonly_cosmic;   //!
   TBranch        *b_EF_mu4_Trk_Jpsi;   //!
   TBranch        *b_EF_mu4_Trk_Upsi_FS;   //!
   TBranch        *b_EF_mu4_Upsimumu_FS;   //!
   TBranch        *b_EF_mu4_Upsimumu_SiTrk_FS;   //!
   TBranch        *b_EF_mu4_Upsimumu_tight_FS;   //!
   TBranch        *b_EF_mu4_cosmic;   //!
   TBranch        *b_EF_mu4_j10_a4tc_EFFS;   //!
   TBranch        *b_EF_mu4_j10_a4tc_EFFS_matched;   //!
   TBranch        *b_EF_mu4_j135_a4tc_EFFS_L1matched;   //!
   TBranch        *b_EF_mu4_j180_a4tc_EFFS_L1matched;   //!
   TBranch        *b_EF_mu4_j45_a4tc_EFFS_xe45_loose_noMu;   //!
   TBranch        *b_EF_mu4imu6i_DiMu_DY;   //!
   TBranch        *b_EF_mu4imu6i_DiMu_DY14_noVtx_noOS;   //!
   TBranch        *b_EF_mu4mu6_Bmumu;   //!
   TBranch        *b_EF_mu4mu6_Bmumux;   //!
   TBranch        *b_EF_mu4mu6_DiMu;   //!
   TBranch        *b_EF_mu4mu6_DiMu_DY20;   //!
   TBranch        *b_EF_mu4mu6_DiMu_noVtx_noOS;   //!
   TBranch        *b_EF_mu4mu6_Jpsimumu;   //!
   TBranch        *b_EF_mu4mu6_Upsimumu;   //!
   TBranch        *b_EF_mu6;   //!
   TBranch        *b_EF_mu6_DiMu_noOS;   //!
   TBranch        *b_EF_mu6_Jpsimumu;   //!
   TBranch        *b_EF_mu6_Jpsimumu_SiTrk;   //!
   TBranch        *b_EF_mu6_Jpsimumu_tight;   //!
   TBranch        *b_EF_mu6_Trk_Jpsi_loose;   //!
   TBranch        *b_EF_tau100_medium;   //!
   TBranch        *b_EF_tau125_medium;   //!
   TBranch        *b_EF_tau125_medium1;   //!
   TBranch        *b_EF_tau16_IDTrkNoCut;   //!
   TBranch        *b_EF_tau16_loose;   //!
   TBranch        *b_EF_tau16_loose_e15_medium;   //!
   TBranch        *b_EF_tau16_loose_mu10;   //!
   TBranch        *b_EF_tau16_loose_mu15;   //!
   TBranch        *b_EF_tau16_medium;   //!
   TBranch        *b_EF_tau16_medium_mu10;   //!
   TBranch        *b_EF_tau20T_medium;   //!
   TBranch        *b_EF_tau20T_medium_e15_medium;   //!
   TBranch        *b_EF_tau20T_medium_mu15;   //!
   TBranch        *b_EF_tau20_medium;   //!
   TBranch        *b_EF_tau20_medium1;   //!
   TBranch        *b_EF_tau20_medium_e15_medium;   //!
   TBranch        *b_EF_tau20_medium_mu15;   //!
   TBranch        *b_EF_tau29T_medium;   //!
   TBranch        *b_EF_tau29T_medium1_tau20T_medium1;   //!
   TBranch        *b_EF_tau29T_medium1_xs45_loose_noMu_3L1J10;   //!
   TBranch        *b_EF_tau29T_medium_xs75_loose_noMu;   //!
   TBranch        *b_EF_tau29T_medium_xs75_noMu;   //!
   TBranch        *b_EF_tau29_loose;   //!
   TBranch        *b_EF_tau29_loose1;   //!
   TBranch        *b_EF_tau29_loose1_xs45_loose_noMu_3L1J10;   //!
   TBranch        *b_EF_tau29_loose_xs45_loose_noMu_3L1J10;   //!
   TBranch        *b_EF_tau29_loose_xs70_loose_noMu;   //!
   TBranch        *b_EF_tau29_loose_xs80_loose_noMu;   //!
   TBranch        *b_EF_tau29_medium;   //!
   TBranch        *b_EF_tau29_medium1;   //!
   TBranch        *b_EF_tau29_medium1_tau20_medium1;   //!
   TBranch        *b_EF_tau29_medium1_xs45_loose_noMu_3L1J10;   //!
   TBranch        *b_EF_tau29_medium_xe35_noMu;   //!
   TBranch        *b_EF_tau29_medium_xe40_loose_noMu;   //!
   TBranch        *b_EF_tau29_medium_xs70_noMu;   //!
   TBranch        *b_EF_tau29_medium_xs75_noMu;   //!
   TBranch        *b_EF_tau50_IDTrkNoCut;   //!
   TBranch        *b_EF_tau50_medium;   //!
   TBranch        *b_EF_tau84_loose;   //!
   TBranch        *b_EF_tauNoCut;   //!
   TBranch        *b_EF_tauNoCut_L1TAU50;   //!
   TBranch        *b_EF_tauNoCut_cosmic;   //!
   TBranch        *b_EF_xe20_noMu;   //!
   TBranch        *b_EF_xe30_noMu;   //!
   TBranch        *b_EF_xe40_noMu;   //!
   TBranch        *b_EF_xe50_noMu;   //!
   TBranch        *b_EF_xe60_noMu;   //!
   TBranch        *b_EF_xe60_tight_noMu;   //!
   TBranch        *b_EF_xe60_verytight_noMu;   //!
   TBranch        *b_EF_xe70_noMu;   //!
   TBranch        *b_EF_xe70_tight_noMu;   //!
   TBranch        *b_EF_xe80_noMu;   //!
   TBranch        *b_EF_xe90_noMu;   //!
   TBranch        *b_L1_2EM10;   //!
   TBranch        *b_L1_2EM14;   //!
   TBranch        *b_L1_2EM3;   //!
   TBranch        *b_L1_2EM3_EM12;   //!
   TBranch        *b_L1_2EM3_EM7;   //!
   TBranch        *b_L1_2EM5;   //!
   TBranch        *b_L1_2EM5_EM10;   //!
   TBranch        *b_L1_2EM5_MU6;   //!
   TBranch        *b_L1_2EM5_NL;   //!
   TBranch        *b_L1_2EM7;   //!
   TBranch        *b_L1_2EM7_EM10;   //!
   TBranch        *b_L1_2J20_XE20;   //!
   TBranch        *b_L1_2J30_XE20;   //!
   TBranch        *b_L1_2MU0;   //!
   TBranch        *b_L1_2MU0_EMPTY;   //!
   TBranch        *b_L1_2MU0_FIRSTEMPTY;   //!
   TBranch        *b_L1_2MU0_MU6;   //!
   TBranch        *b_L1_2MU10;   //!
   TBranch        *b_L1_2MU6;   //!
   TBranch        *b_L1_2MU6_EMPTY;   //!
   TBranch        *b_L1_2MU6_FIRSTEMPTY;   //!
   TBranch        *b_L1_2MU6_NL;   //!
   TBranch        *b_L1_2MU6_UNPAIRED_ISO;   //!
   TBranch        *b_L1_2MU6_UNPAIRED_NONISO;   //!
   TBranch        *b_L1_2TAU11;   //!
   TBranch        *b_L1_2TAU11_EM10;   //!
   TBranch        *b_L1_2TAU11_TAU15;   //!
   TBranch        *b_L1_2TAU15;   //!
   TBranch        *b_L1_2TAU15_TAU20;   //!
   TBranch        *b_L1_2TAU6;   //!
   TBranch        *b_L1_2TAU6_EM10;   //!
   TBranch        *b_L1_2TAU8_EM10;   //!
   TBranch        *b_L1_2TAU8_TAU11;   //!
   TBranch        *b_L1_EM10;   //!
   TBranch        *b_L1_EM10_MU6;   //!
   TBranch        *b_L1_EM10_XE20;   //!
   TBranch        *b_L1_EM10_XE30;   //!
   TBranch        *b_L1_EM10_XS45;   //!
   TBranch        *b_L1_EM10_XS50;   //!
   TBranch        *b_L1_EM12;   //!
   TBranch        *b_L1_EM14;   //!
   TBranch        *b_L1_EM14_XE10;   //!
   TBranch        *b_L1_EM14_XE20;   //!
   TBranch        *b_L1_EM16;   //!
   TBranch        *b_L1_EM3;   //!
   TBranch        *b_L1_EM30;   //!
   TBranch        *b_L1_EM3_EMPTY;   //!
   TBranch        *b_L1_EM3_FIRSTEMPTY;   //!
   TBranch        *b_L1_EM3_MU0;   //!
   TBranch        *b_L1_EM3_MU6;   //!
   TBranch        *b_L1_EM3_UNPAIRED_ISO;   //!
   TBranch        *b_L1_EM3_UNPAIRED_NONISO;   //!
   TBranch        *b_L1_EM5;   //!
   TBranch        *b_L1_EM5_2MU6;   //!
   TBranch        *b_L1_EM5_EMPTY;   //!
   TBranch        *b_L1_EM5_MU10;   //!
   TBranch        *b_L1_EM5_MU6;   //!
   TBranch        *b_L1_EM7;   //!
   TBranch        *b_L1_J30_XE35;   //!
   TBranch        *b_L1_J30_XE40;   //!
   TBranch        *b_L1_J50_XE20;   //!
   TBranch        *b_L1_J50_XE30;   //!
   TBranch        *b_L1_J50_XE35;   //!
   TBranch        *b_L1_MU0;   //!
   TBranch        *b_L1_MU0_EMPTY;   //!
   TBranch        *b_L1_MU0_FIRSTEMPTY;   //!
   TBranch        *b_L1_MU0_J10;   //!
   TBranch        *b_L1_MU0_J15;   //!
   TBranch        *b_L1_MU0_J15_EMPTY;   //!
   TBranch        *b_L1_MU0_J15_FIRSTEMPTY;   //!
   TBranch        *b_L1_MU0_J15_UNPAIRED_ISO;   //!
   TBranch        *b_L1_MU0_J15_UNPAIRED_NONISO;   //!
   TBranch        *b_L1_MU0_J20_XE20;   //!
   TBranch        *b_L1_MU0_J30;   //!
   TBranch        *b_L1_MU0_J50;   //!
   TBranch        *b_L1_MU0_J75;   //!
   TBranch        *b_L1_MU0_UNPAIRED_ISO;   //!
   TBranch        *b_L1_MU0_UNPAIRED_NONISO;   //!
   TBranch        *b_L1_MU10;   //!
   TBranch        *b_L1_MU10_EMPTY;   //!
   TBranch        *b_L1_MU10_FIRSTEMPTY;   //!
   TBranch        *b_L1_MU10_J10;   //!
   TBranch        *b_L1_MU10_UNPAIRED_ISO;   //!
   TBranch        *b_L1_MU10_XE20;   //!
   TBranch        *b_L1_MU11;   //!
   TBranch        *b_L1_MU11_EMPTY;   //!
   TBranch        *b_L1_MU15;   //!
   TBranch        *b_L1_MU20;   //!
   TBranch        *b_L1_MU20_FIRSTEMPTY;   //!
   TBranch        *b_L1_MU6;   //!
   TBranch        *b_L1_MU6_FIRSTEMPTY;   //!
   TBranch        *b_L1_MU6_NL;   //!
   TBranch        *b_L1_TAU11;   //!
   TBranch        *b_L1_TAU11_2J10_J20_XE20;   //!
   TBranch        *b_L1_TAU11_MU10;   //!
   TBranch        *b_L1_TAU11_XE10_3J10;   //!
   TBranch        *b_L1_TAU11_XE20;   //!
   TBranch        *b_L1_TAU11_XS30;   //!
   TBranch        *b_L1_TAU11_XS35;   //!
   TBranch        *b_L1_TAU15;   //!
   TBranch        *b_L1_TAU15_XE10_3J10;   //!
   TBranch        *b_L1_TAU15_XE20;   //!
   TBranch        *b_L1_TAU15_XS35;   //!
   TBranch        *b_L1_TAU20;   //!
   TBranch        *b_L1_TAU30;   //!
   TBranch        *b_L1_TAU50;   //!
   TBranch        *b_L1_TAU6;   //!
   TBranch        *b_L1_TAU6_J50_XE20;   //!
   TBranch        *b_L1_TAU6_MU10;   //!
   TBranch        *b_L1_TAU6_XE10;   //!
   TBranch        *b_L1_TAU8;   //!
   TBranch        *b_L1_TAU8_EMPTY;   //!
   TBranch        *b_L1_TAU8_FIRSTEMPTY;   //!
   TBranch        *b_L1_TAU8_MU10;   //!
   TBranch        *b_L1_TAU8_UNPAIRED_ISO;   //!
   TBranch        *b_L1_TAU8_UNPAIRED_NONISO;   //!
   TBranch        *b_L1_XE10;   //!
   TBranch        *b_L1_XE20;   //!
   TBranch        *b_L1_XE25;   //!
   TBranch        *b_L1_XE30;   //!
   TBranch        *b_L1_XE35;   //!
   TBranch        *b_L1_XE40;   //!
   TBranch        *b_L1_XE50;   //!
   TBranch        *b_L1_XE60;   //!
   TBranch        *b_L2_2b10_medium_4L1J10;   //!
   TBranch        *b_L2_2b10_medium_4j25;   //!
   TBranch        *b_L2_2b10_medium_L1JE100;   //!
   TBranch        *b_L2_2b10_medium_L1JE140;   //!
   TBranch        *b_L2_2b10_medium_L1_2J10J50;   //!
   TBranch        *b_L2_2b10_medium_j70_j25;   //!
   TBranch        *b_L2_2b15_medium_3L1J15;   //!
   TBranch        *b_L2_2b20_medium_3L1J20;   //!
   TBranch        *b_L2_2e10_medium;   //!
   TBranch        *b_L2_2e10_medium_mu6;   //!
   TBranch        *b_L2_2e12T_medium;   //!
   TBranch        *b_L2_2e12_medium;   //!
   TBranch        *b_L2_2e15_medium;   //!
   TBranch        *b_L2_2e5_tight;   //!
   TBranch        *b_L2_2e5_tight_Jpsi;   //!
   TBranch        *b_L2_2g15_loose;   //!
   TBranch        *b_L2_2g20_loose;   //!
   TBranch        *b_L2_2j40_anymct100_xe20_medium_noMu;   //!
   TBranch        *b_L2_2j50_anymct100_xe20_medium_noMu;   //!
   TBranch        *b_L2_2mu10;   //!
   TBranch        *b_L2_2mu10_empty;   //!
   TBranch        *b_L2_2mu10_loose;   //!
   TBranch        *b_L2_2mu10_loose_empty;   //!
   TBranch        *b_L2_2mu10_loose_noOvlpRm;   //!
   TBranch        *b_L2_2mu13_Zmumu_IDTrkNoCut;   //!
   TBranch        *b_L2_2mu4;   //!
   TBranch        *b_L2_2mu4_Bmumu;   //!
   TBranch        *b_L2_2mu4_Bmumux;   //!
   TBranch        *b_L2_2mu4_DiMu;   //!
   TBranch        *b_L2_2mu4_DiMu_DY;   //!
   TBranch        *b_L2_2mu4_DiMu_DY20;   //!
   TBranch        *b_L2_2mu4_DiMu_DY_noVtx_noOS;   //!
   TBranch        *b_L2_2mu4_DiMu_SiTrk;   //!
   TBranch        *b_L2_2mu4_DiMu_noVtx_noOS;   //!
   TBranch        *b_L2_2mu4_Jpsimumu;   //!
   TBranch        *b_L2_2mu4_Jpsimumu_IDTrkNoCut;   //!
   TBranch        *b_L2_2mu4_Upsimumu;   //!
   TBranch        *b_L2_2mu4i_DiMu_DY;   //!
   TBranch        *b_L2_2mu6;   //!
   TBranch        *b_L2_2mu6_DiMu;   //!
   TBranch        *b_L2_2mu6_MSonly_g10_loose;   //!
   TBranch        *b_L2_2mu6_MSonly_g10_loose_nonfilled;   //!
   TBranch        *b_L2_2mu6_NL;   //!
   TBranch        *b_L2_2tau29T_medium1;   //!
   TBranch        *b_L2_2tau29_medium1;   //!
   TBranch        *b_L2_3b10_loose_4L1J10;   //!
   TBranch        *b_L2_3b15_loose_4L1J15;   //!
   TBranch        *b_L2_b10_IDTrkNoCut;   //!
   TBranch        *b_L2_b10_medium_4j25;   //!
   TBranch        *b_L2_b10_medium_EFxe25_noMu_L1JE140;   //!
   TBranch        *b_L2_b10_tight_4L1J10;   //!
   TBranch        *b_L2_b10_tight_L1JE140;   //!
   TBranch        *b_L2_e10_medium;   //!
   TBranch        *b_L2_e10_medium_2mu6;   //!
   TBranch        *b_L2_e10_medium_mu10;   //!
   TBranch        *b_L2_e10_medium_mu6;   //!
   TBranch        *b_L2_e10_medium_mu6_topo_medium;   //!
   TBranch        *b_L2_e11T_medium;   //!
   TBranch        *b_L2_e11T_medium_2e6T_medium;   //!
   TBranch        *b_L2_e11_etcut;   //!
   TBranch        *b_L2_e12T_medium_mu6_topo_medium;   //!
   TBranch        *b_L2_e12_medium;   //!
   TBranch        *b_L2_e13_etcut_xs45_noMu;   //!
   TBranch        *b_L2_e15_HLTtighter;   //!
   TBranch        *b_L2_e15_medium;   //!
   TBranch        *b_L2_e15_medium_e12_medium;   //!
   TBranch        *b_L2_e15_medium_xe20_noMu;   //!
   TBranch        *b_L2_e15_medium_xe30_noMu;   //!
   TBranch        *b_L2_e15_medium_xe35_noMu;   //!
   TBranch        *b_L2_e15_tight;   //!
   TBranch        *b_L2_e20_etcut_xs45_noMu;   //!
   TBranch        *b_L2_e20_loose;   //!
   TBranch        *b_L2_e20_loose1;   //!
   TBranch        *b_L2_e20_looseTrk;   //!
   TBranch        *b_L2_e20_medium;   //!
   TBranch        *b_L2_e20_medium1;   //!
   TBranch        *b_L2_e20_medium2;   //!
   TBranch        *b_L2_e20_medium_IDTrkNoCut;   //!
   TBranch        *b_L2_e20_medium_SiTrk;   //!
   TBranch        *b_L2_e20_medium_TRT;   //!
   TBranch        *b_L2_e20_tight_e15_NoCut_Zee;   //!
   TBranch        *b_L2_e22_etcut_xs45_noMu;   //!
   TBranch        *b_L2_e22_loose;   //!
   TBranch        *b_L2_e22_loose1;   //!
   TBranch        *b_L2_e22_looseTrk;   //!
   TBranch        *b_L2_e22_medium;   //!
   TBranch        *b_L2_e22_medium1;   //!
   TBranch        *b_L2_e22_medium2;   //!
   TBranch        *b_L2_e22_medium_IDTrkNoCut;   //!
   TBranch        *b_L2_e22_medium_SiTrk;   //!
   TBranch        *b_L2_e22_medium_TRT;   //!
   TBranch        *b_L2_e33_medium;   //!
   TBranch        *b_L2_e35_medium;   //!
   TBranch        *b_L2_e40_medium;   //!
   TBranch        *b_L2_e45_medium;   //!
   TBranch        *b_L2_e45_medium1;   //!
   TBranch        *b_L2_e5_medium_mu6;   //!
   TBranch        *b_L2_e5_medium_mu6_topo_medium;   //!
   TBranch        *b_L2_e5_tight;   //!
   TBranch        *b_L2_e5_tight_e14_etcut_Jpsi;   //!
   TBranch        *b_L2_e5_tight_e4_etcut_Jpsi;   //!
   TBranch        *b_L2_e5_tight_e4_etcut_Jpsi_SiTrk;   //!
   TBranch        *b_L2_e5_tight_e4_etcut_Jpsi_TRT;   //!
   TBranch        *b_L2_e5_tight_e5_NoCut;   //!
   TBranch        *b_L2_e5_tight_e9_etcut_Jpsi;   //!
   TBranch        *b_L2_e60_loose;   //!
   TBranch        *b_L2_e6T_medium;   //!
   TBranch        *b_L2_e7_tight_e14_etcut_Jpsi;   //!
   TBranch        *b_L2_e9_tight_e5_tight_Jpsi;   //!
   TBranch        *b_L2_eb_physics;   //!
   TBranch        *b_L2_eb_physics_empty;   //!
   TBranch        *b_L2_eb_physics_firstempty;   //!
   TBranch        *b_L2_eb_physics_noL1PS;   //!
   TBranch        *b_L2_eb_physics_unpaired_iso;   //!
   TBranch        *b_L2_eb_physics_unpaired_noniso;   //!
   TBranch        *b_L2_eb_random;   //!
   TBranch        *b_L2_eb_random_empty;   //!
   TBranch        *b_L2_eb_random_firstempty;   //!
   TBranch        *b_L2_eb_random_unpaired_iso;   //!
   TBranch        *b_L2_em3_empty_larcalib;   //!
   TBranch        *b_L2_em5_empty_larcalib;   //!
   TBranch        *b_L2_g100_etcut_g50_etcut;   //!
   TBranch        *b_L2_g10_NoCut_cosmic;   //!
   TBranch        *b_L2_g11_etcut;   //!
   TBranch        *b_L2_g150_etcut;   //!
   TBranch        *b_L2_g15_loose;   //!
   TBranch        *b_L2_g20_etcut;   //!
   TBranch        *b_L2_g20_etcut_xe30_noMu;   //!
   TBranch        *b_L2_g20_loose;   //!
   TBranch        *b_L2_g40_loose;   //!
   TBranch        *b_L2_g40_loose_EFxe40_noMu;   //!
   TBranch        *b_L2_g40_loose_xe30_medium_noMu;   //!
   TBranch        *b_L2_g40_loose_xe35_medium_noMu;   //!
   TBranch        *b_L2_g40_tight;   //!
   TBranch        *b_L2_g40_tight_b10_medium;   //!
   TBranch        *b_L2_g5_NoCut_cosmic;   //!
   TBranch        *b_L2_g60_loose;   //!
   TBranch        *b_L2_g80_loose;   //!
   TBranch        *b_L2_j50_xe35_medium_noMu;   //!
   TBranch        *b_L2_j50_xe35_medium_noMu_l2cleancons;   //!
   TBranch        *b_L2_j60_xe45_noMu;   //!
   TBranch        *b_L2_j70_xe20_loose_noMu;   //!
   TBranch        *b_L2_j70_xe25_loose_noMu;   //!
   TBranch        *b_L2_j70_xe35_noMu;   //!
   TBranch        *b_L2_j70_xe35_noMu_l2cleancons;   //!
   TBranch        *b_L2_j75_xe40_noMu;   //!
   TBranch        *b_L2_mu0_cal_empty;   //!
   TBranch        *b_L2_mu0_empty_NoAlg;   //!
   TBranch        *b_L2_mu0_firstempty_NoAlg;   //!
   TBranch        *b_L2_mu0_unpaired_iso_NoAlg;   //!
   TBranch        *b_L2_mu10;   //!
   TBranch        *b_L2_mu10_Jpsimumu;   //!
   TBranch        *b_L2_mu10_NL;   //!
   TBranch        *b_L2_mu10_Upsimumu_FS;   //!
   TBranch        *b_L2_mu10_Upsimumu_tight_FS;   //!
   TBranch        *b_L2_mu10_cal;   //!
   TBranch        *b_L2_mu10_cal_medium;   //!
   TBranch        *b_L2_mu10_loose;   //!
   TBranch        *b_L2_mu10_muCombTag_NoEF;   //!
   TBranch        *b_L2_mu11_empty_NoAlg;   //!
   TBranch        *b_L2_mu13;   //!
   TBranch        *b_L2_mu13_MG;   //!
   TBranch        *b_L2_mu13_muCombTag_NoEF;   //!
   TBranch        *b_L2_mu15;   //!
   TBranch        *b_L2_mu15_medium;   //!
   TBranch        *b_L2_mu15_tight;   //!
   TBranch        *b_L2_mu15_xe20_noMu;   //!
   TBranch        *b_L2_mu15i;   //!
   TBranch        *b_L2_mu15i_medium;   //!
   TBranch        *b_L2_mu18;   //!
   TBranch        *b_L2_mu18_L1J10;   //!
   TBranch        *b_L2_mu18_MG;   //!
   TBranch        *b_L2_mu18_MG_L1J10;   //!
   TBranch        *b_L2_mu18_MG_medium;   //!
   TBranch        *b_L2_mu18_medium;   //!
   TBranch        *b_L2_mu20;   //!
   TBranch        *b_L2_mu20_IDTrkNoCut;   //!
   TBranch        *b_L2_mu20_MG;   //!
   TBranch        *b_L2_mu20_MG_medium;   //!
   TBranch        *b_L2_mu20_empty;   //!
   TBranch        *b_L2_mu20_medium;   //!
   TBranch        *b_L2_mu20_muCombTag_NoEF;   //!
   TBranch        *b_L2_mu20_tight;   //!
   TBranch        *b_L2_mu20i;   //!
   TBranch        *b_L2_mu20i_medium;   //!
   TBranch        *b_L2_mu22;   //!
   TBranch        *b_L2_mu22_MG;   //!
   TBranch        *b_L2_mu22_MG_medium;   //!
   TBranch        *b_L2_mu22_medium;   //!
   TBranch        *b_L2_mu24_MG_medium;   //!
   TBranch        *b_L2_mu24_MG_tight;   //!
   TBranch        *b_L2_mu24_medium;   //!
   TBranch        *b_L2_mu24_tight;   //!
   TBranch        *b_L2_mu30_MG_medium;   //!
   TBranch        *b_L2_mu30_MG_tight;   //!
   TBranch        *b_L2_mu30_medium;   //!
   TBranch        *b_L2_mu30_tight;   //!
   TBranch        *b_L2_mu4;   //!
   TBranch        *b_L2_mu40_MSonly_barrel;   //!
   TBranch        *b_L2_mu40_MSonly_barrel_medium;   //!
   TBranch        *b_L2_mu40_MSonly_empty;   //!
   TBranch        *b_L2_mu40_MSonly_tight;   //!
   TBranch        *b_L2_mu40_MSonly_tight_L1MU11;   //!
   TBranch        *b_L2_mu40_MSonly_tighter;   //!
   TBranch        *b_L2_mu40_slow;   //!
   TBranch        *b_L2_mu40_slow_empty;   //!
   TBranch        *b_L2_mu40_slow_medium;   //!
   TBranch        *b_L2_mu40_slow_outOfTime;   //!
   TBranch        *b_L2_mu40_slow_outOfTime_medium;   //!
   TBranch        *b_L2_mu4_DiMu;   //!
   TBranch        *b_L2_mu4_DiMu_FS_noOS;   //!
   TBranch        *b_L2_mu4_Jpsimumu;   //!
   TBranch        *b_L2_mu4_L1J10_matched;   //!
   TBranch        *b_L2_mu4_L1J15_matched;   //!
   TBranch        *b_L2_mu4_L1J20_matched;   //!
   TBranch        *b_L2_mu4_L1J30_matched;   //!
   TBranch        *b_L2_mu4_L1J50_matched;   //!
   TBranch        *b_L2_mu4_L1J75_matched;   //!
   TBranch        *b_L2_mu4_L1MU11_MSonly_cosmic;   //!
   TBranch        *b_L2_mu4_L1MU11_cosmic;   //!
   TBranch        *b_L2_mu4_MSonly_cosmic;   //!
   TBranch        *b_L2_mu4_Trk_Jpsi;   //!
   TBranch        *b_L2_mu4_Trk_Upsi_FS;   //!
   TBranch        *b_L2_mu4_Upsimumu_FS;   //!
   TBranch        *b_L2_mu4_Upsimumu_SiTrk_FS;   //!
   TBranch        *b_L2_mu4_Upsimumu_tight_FS;   //!
   TBranch        *b_L2_mu4_cosmic;   //!
   TBranch        *b_L2_mu4_j10_a4tc_EFFS;   //!
   TBranch        *b_L2_mu4_j40_xe20_loose_noMu;   //!
   TBranch        *b_L2_mu4_j95_L1matched;   //!
   TBranch        *b_L2_mu4imu6i_DiMu_DY;   //!
   TBranch        *b_L2_mu4imu6i_DiMu_DY14_noVtx_noOS;   //!
   TBranch        *b_L2_mu4mu6_Bmumu;   //!
   TBranch        *b_L2_mu4mu6_Bmumux;   //!
   TBranch        *b_L2_mu4mu6_DiMu;   //!
   TBranch        *b_L2_mu4mu6_DiMu_DY20;   //!
   TBranch        *b_L2_mu4mu6_DiMu_noVtx_noOS;   //!
   TBranch        *b_L2_mu4mu6_Jpsimumu;   //!
   TBranch        *b_L2_mu4mu6_Upsimumu;   //!
   TBranch        *b_L2_mu6;   //!
   TBranch        *b_L2_mu6_DiMu_noOS;   //!
   TBranch        *b_L2_mu6_Jpsimumu;   //!
   TBranch        *b_L2_mu6_Jpsimumu_SiTrk;   //!
   TBranch        *b_L2_mu6_Jpsimumu_tight;   //!
   TBranch        *b_L2_mu6_Trk_Jpsi_loose;   //!
   TBranch        *b_L2_tau100_medium;   //!
   TBranch        *b_L2_tau125_medium;   //!
   TBranch        *b_L2_tau125_medium1;   //!
   TBranch        *b_L2_tau16_IDTrkNoCut;   //!
   TBranch        *b_L2_tau16_loose;   //!
   TBranch        *b_L2_tau16_loose_e15_medium;   //!
   TBranch        *b_L2_tau16_loose_mu10;   //!
   TBranch        *b_L2_tau16_loose_mu15;   //!
   TBranch        *b_L2_tau16_medium;   //!
   TBranch        *b_L2_tau16_medium_mu10;   //!
   TBranch        *b_L2_tau20T_medium;   //!
   TBranch        *b_L2_tau20T_medium_e15_medium;   //!
   TBranch        *b_L2_tau20T_medium_mu15;   //!
   TBranch        *b_L2_tau20_medium;   //!
   TBranch        *b_L2_tau20_medium1;   //!
   TBranch        *b_L2_tau20_medium_e15_medium;   //!
   TBranch        *b_L2_tau20_medium_mu15;   //!
   TBranch        *b_L2_tau29T_medium;   //!
   TBranch        *b_L2_tau29T_medium1_tau20T_medium1;   //!
   TBranch        *b_L2_tau29T_medium1_xs20_noMu_3L1J10;   //!
   TBranch        *b_L2_tau29T_medium_xs35_noMu;   //!
   TBranch        *b_L2_tau29T_medium_xs50_noMu;   //!
   TBranch        *b_L2_tau29_loose;   //!
   TBranch        *b_L2_tau29_loose1;   //!
   TBranch        *b_L2_tau29_loose1_xs20_noMu_3L1J10;   //!
   TBranch        *b_L2_tau29_loose_xs20_noMu_3L1J10;   //!
   TBranch        *b_L2_tau29_loose_xs35_noMu;   //!
   TBranch        *b_L2_tau29_medium;   //!
   TBranch        *b_L2_tau29_medium1;   //!
   TBranch        *b_L2_tau29_medium1_tau20_medium1;   //!
   TBranch        *b_L2_tau29_medium1_xs20_noMu_3L1J10;   //!
   TBranch        *b_L2_tau29_medium_xe25_noMu;   //!
   TBranch        *b_L2_tau29_medium_xe30_loose_noMu;   //!
   TBranch        *b_L2_tau29_medium_xs50_noMu;   //!
   TBranch        *b_L2_tau50_IDTrkNoCut;   //!
   TBranch        *b_L2_tau50_medium;   //!
   TBranch        *b_L2_tau84_loose;   //!
   TBranch        *b_L2_tau8_empty_larcalib;   //!
   TBranch        *b_L2_tauNoCut;   //!
   TBranch        *b_L2_tauNoCut_L1TAU50;   //!
   TBranch        *b_L2_tauNoCut_cosmic;   //!
   TBranch        *b_L2_xe10_noMu;   //!
   TBranch        *b_L2_xe20_noMu;   //!
   TBranch        *b_L2_xe30_noMu;   //!
   TBranch        *b_L2_xe35_noMu;   //!
   TBranch        *b_L2_xe40_noMu;   //!
   TBranch        *b_L2_xe45_noMu;   //!
   TBranch        *b_L2_xe50_noMu;   //!
   TBranch        *b_L2_xe55_noMu;   //!
   TBranch        *b_L2_xe60_noMu;   //!
   TBranch        *b_L2_xe70_noMu;   //!
   TBranch        *b_v0_n;   //!
   TBranch        *b_v0_ksMass;   //!
   TBranch        *b_v0_lambda1Mass;   //!
   TBranch        *b_v0_lambda2Mass;   //!
   TBranch        *b_v0_vertexProb;   //!
   TBranch        *b_v0_vertexChi2;   //!
   TBranch        *b_v0_ksPt;   //!
   TBranch        *b_v0_ksPx;   //!
   TBranch        *b_v0_ksPy;   //!
   TBranch        *b_v0_ksEta;   //!
   TBranch        *b_v0_ksPhi;   //!
   TBranch        *b_v0_ksMomentum;   //!
   TBranch        *b_v0_flightX;   //!
   TBranch        *b_v0_flightY;   //!
   TBranch        *b_v0_cosThetaPointing;   //!
   TBranch        *b_v0_totalFlightDistance;   //!
   TBranch        *b_v0_properDecayTime;   //!
   TBranch        *b_v0_properFlightDist;   //!
   TBranch        *b_v0_flightX_BS;   //!
   TBranch        *b_v0_flightY_BS;   //!
   TBranch        *b_v0_cosThetaPointing_BS;   //!
   TBranch        *b_v0_totalFlightDistance_BS;   //!
   TBranch        *b_v0_properDecayTime_BS;   //!
   TBranch        *b_v0_properFlightDist_BS;   //!
   TBranch        *b_v0_radius;   //!
   TBranch        *b_v0_thetaPiPlus;   //!
   TBranch        *b_v0_thetaPiMinus;   //!
   TBranch        *b_v0_trk_L;   //!
   TBranch        *b_v0_trk_T;   //!
   TBranch        *b_v0_thetaStarPiPlus;   //!
   TBranch        *b_v0_thetaStarPiMinus;   //!
   TBranch        *b_v0_trkPt_SV;   //!
   TBranch        *b_v0_trkEta_SV;   //!
   TBranch        *b_v0_trkPhi_SV;   //!
   TBranch        *b_v0_x;   //!
   TBranch        *b_v0_y;   //!
   TBranch        *b_v0_z;   //!
   TBranch        *b_v0_err_x;   //!
   TBranch        *b_v0_err_y;   //!
   TBranch        *b_v0_err_z;   //!
   TBranch        *b_v0_cov_xy;   //!
   TBranch        *b_v0_cov_xz;   //!
   TBranch        *b_v0_cov_yz;   //!
   TBranch        *b_v0_type;   //!
   TBranch        *b_v0_chi2;   //!
   TBranch        *b_v0_ndof;   //!
   TBranch        *b_v0_px;   //!
   TBranch        *b_v0_py;   //!
   TBranch        *b_v0_pz;   //!
   TBranch        *b_v0_E;   //!
   TBranch        *b_v0_m;   //!
   TBranch        *b_v0_nTracks;   //!
   TBranch        *b_v0_sumPt;   //!
   TBranch        *b_v0_trk_n;   //!
   TBranch        *b_v0_trk_weight;   //!
   TBranch        *b_v0_trk_index;   //!
   TBranch        *b_ph_n;   //!
   TBranch        *b_ph_E;   //!
   TBranch        *b_ph_Et;   //!
   TBranch        *b_ph_pt;   //!
   TBranch        *b_ph_m;   //!
   TBranch        *b_ph_eta;   //!
   TBranch        *b_ph_phi;   //!
   TBranch        *b_ph_px;   //!
   TBranch        *b_ph_py;   //!
   TBranch        *b_ph_pz;   //!
   TBranch        *b_ph_author;   //!
   TBranch        *b_ph_isRecovered;   //!
   TBranch        *b_ph_isEM;   //!
   TBranch        *b_ph_OQ;   //!
   TBranch        *b_ph_OQRecalc;   //!
   TBranch        *b_ph_convFlag;   //!
   TBranch        *b_ph_isConv;   //!
   TBranch        *b_ph_nConv;   //!
   TBranch        *b_ph_nSingleTrackConv;   //!
   TBranch        *b_ph_nDoubleTrackConv;   //!
   TBranch        *b_ph_loose;   //!
   TBranch        *b_ph_looseIso;   //!
   TBranch        *b_ph_tight;   //!
   TBranch        *b_ph_tightIso;   //!
   TBranch        *b_ph_looseAR;   //!
   TBranch        *b_ph_looseARIso;   //!
   TBranch        *b_ph_tightAR;   //!
   TBranch        *b_ph_tightARIso;   //!
   TBranch        *b_ph_goodOQ;   //!
   TBranch        *b_ph_Ethad;   //!
   TBranch        *b_ph_Ethad1;   //!
   TBranch        *b_ph_E033;   //!
   TBranch        *b_ph_f1;   //!
   TBranch        *b_ph_f1core;   //!
   TBranch        *b_ph_Emins1;   //!
   TBranch        *b_ph_fside;   //!
   TBranch        *b_ph_Emax2;   //!
   TBranch        *b_ph_ws3;   //!
   TBranch        *b_ph_wstot;   //!
   TBranch        *b_ph_E132;   //!
   TBranch        *b_ph_E1152;   //!
   TBranch        *b_ph_emaxs1;   //!
   TBranch        *b_ph_deltaEs;   //!
   TBranch        *b_ph_E233;   //!
   TBranch        *b_ph_E237;   //!
   TBranch        *b_ph_E277;   //!
   TBranch        *b_ph_weta2;   //!
   TBranch        *b_ph_f3;   //!
   TBranch        *b_ph_f3core;   //!
   TBranch        *b_ph_rphiallcalo;   //!
   TBranch        *b_ph_Etcone45;   //!
   TBranch        *b_ph_Etcone15;   //!
   TBranch        *b_ph_Etcone20;   //!
   TBranch        *b_ph_Etcone25;   //!
   TBranch        *b_ph_Etcone30;   //!
   TBranch        *b_ph_Etcone35;   //!
   TBranch        *b_ph_Etcone40;   //!
   TBranch        *b_ph_ptcone20;   //!
   TBranch        *b_ph_ptcone30;   //!
   TBranch        *b_ph_ptcone40;   //!
   TBranch        *b_ph_nucone20;   //!
   TBranch        *b_ph_nucone30;   //!
   TBranch        *b_ph_nucone40;   //!
   TBranch        *b_ph_Etcone15_pt_corrected;   //!
   TBranch        *b_ph_Etcone20_pt_corrected;   //!
   TBranch        *b_ph_Etcone25_pt_corrected;   //!
   TBranch        *b_ph_Etcone30_pt_corrected;   //!
   TBranch        *b_ph_Etcone35_pt_corrected;   //!
   TBranch        *b_ph_Etcone40_pt_corrected;   //!
   TBranch        *b_ph_convanglematch;   //!
   TBranch        *b_ph_convtrackmatch;   //!
   TBranch        *b_ph_hasconv;   //!
   TBranch        *b_ph_convvtxx;   //!
   TBranch        *b_ph_convvtxy;   //!
   TBranch        *b_ph_convvtxz;   //!
   TBranch        *b_ph_Rconv;   //!
   TBranch        *b_ph_zconv;   //!
   TBranch        *b_ph_convvtxchi2;   //!
   TBranch        *b_ph_pt1conv;   //!
   TBranch        *b_ph_convtrk1nBLHits;   //!
   TBranch        *b_ph_convtrk1nPixHits;   //!
   TBranch        *b_ph_convtrk1nSCTHits;   //!
   TBranch        *b_ph_convtrk1nTRTHits;   //!
   TBranch        *b_ph_pt2conv;   //!
   TBranch        *b_ph_convtrk2nBLHits;   //!
   TBranch        *b_ph_convtrk2nPixHits;   //!
   TBranch        *b_ph_convtrk2nSCTHits;   //!
   TBranch        *b_ph_convtrk2nTRTHits;   //!
   TBranch        *b_ph_ptconv;   //!
   TBranch        *b_ph_pzconv;   //!
   TBranch        *b_ph_reta;   //!
   TBranch        *b_ph_rphi;   //!
   TBranch        *b_ph_EtringnoisedR03sig2;   //!
   TBranch        *b_ph_EtringnoisedR03sig3;   //!
   TBranch        *b_ph_EtringnoisedR03sig4;   //!
   TBranch        *b_ph_isolationlikelihoodjets;   //!
   TBranch        *b_ph_isolationlikelihoodhqelectrons;   //!
   TBranch        *b_ph_loglikelihood;   //!
   TBranch        *b_ph_photonweight;   //!
   TBranch        *b_ph_photonbgweight;   //!
   TBranch        *b_ph_neuralnet;   //!
   TBranch        *b_ph_Hmatrix;   //!
   TBranch        *b_ph_Hmatrix5;   //!
   TBranch        *b_ph_adaboost;   //!
   TBranch        *b_ph_zvertex;   //!
   TBranch        *b_ph_errz;   //!
   TBranch        *b_ph_etap;   //!
   TBranch        *b_ph_depth;   //!
   TBranch        *b_ph_cl_E;   //!
   TBranch        *b_ph_cl_pt;   //!
   TBranch        *b_ph_cl_eta;   //!
   TBranch        *b_ph_cl_phi;   //!
   TBranch        *b_ph_Es0;   //!
   TBranch        *b_ph_etas0;   //!
   TBranch        *b_ph_phis0;   //!
   TBranch        *b_ph_Es1;   //!
   TBranch        *b_ph_etas1;   //!
   TBranch        *b_ph_phis1;   //!
   TBranch        *b_ph_Es2;   //!
   TBranch        *b_ph_etas2;   //!
   TBranch        *b_ph_phis2;   //!
   TBranch        *b_ph_Es3;   //!
   TBranch        *b_ph_etas3;   //!
   TBranch        *b_ph_phis3;   //!
   TBranch        *b_ph_rawcl_Es0;   //!
   TBranch        *b_ph_rawcl_etas0;   //!
   TBranch        *b_ph_rawcl_phis0;   //!
   TBranch        *b_ph_rawcl_Es1;   //!
   TBranch        *b_ph_rawcl_etas1;   //!
   TBranch        *b_ph_rawcl_phis1;   //!
   TBranch        *b_ph_rawcl_Es2;   //!
   TBranch        *b_ph_rawcl_etas2;   //!
   TBranch        *b_ph_rawcl_phis2;   //!
   TBranch        *b_ph_rawcl_Es3;   //!
   TBranch        *b_ph_rawcl_etas3;   //!
   TBranch        *b_ph_rawcl_phis3;   //!
   TBranch        *b_ph_rawcl_E;   //!
   TBranch        *b_ph_rawcl_pt;   //!
   TBranch        *b_ph_rawcl_eta;   //!
   TBranch        *b_ph_rawcl_phi;   //!
   TBranch        *b_ph_deltaEmax2;   //!
   TBranch        *b_ph_calibHitsShowerDepth;   //!
   TBranch        *b_ph_isIso;   //!
   TBranch        *b_ph_mvaptcone20;   //!
   TBranch        *b_ph_mvaptcone30;   //!
   TBranch        *b_ph_mvaptcone40;   //!
   TBranch        *b_ph_topoEtcone20;   //!
   TBranch        *b_ph_topoEtcone40;   //!
   TBranch        *b_ph_topoEtcone60;   //!
   TBranch        *b_ph_jet_dr;   //!
   TBranch        *b_ph_jet_E;   //!
   TBranch        *b_ph_jet_pt;   //!
   TBranch        *b_ph_jet_m;   //!
   TBranch        *b_ph_jet_eta;   //!
   TBranch        *b_ph_jet_phi;   //!
   TBranch        *b_ph_jet_matched;   //!
   TBranch        *b_ph_convIP;   //!
   TBranch        *b_ph_convIPRev;   //!
   TBranch        *b_ph_ptIsolationCone;   //!
   TBranch        *b_ph_ptIsolationConePhAngle;   //!
   TBranch        *b_ph_Etcone40_ED_corrected;   //!
   TBranch        *b_ph_Etcone40_corrected;   //!
   TBranch        *b_ph_Etcone35_ED_corrected;   //!
   TBranch        *b_ph_Etcone35_corrected;   //!
   TBranch        *b_ph_Etcone30_ED_corrected;   //!
   TBranch        *b_ph_Etcone30_corrected;   //!
   TBranch        *b_ph_Etcone25_ED_corrected;   //!
   TBranch        *b_ph_Etcone25_corrected;   //!
   TBranch        *b_ph_Etcone20_ED_corrected;   //!
   TBranch        *b_ph_Etcone20_corrected;   //!
   TBranch        *b_ph_Etcone15_ED_corrected;   //!
   TBranch        *b_ph_Etcone15_corrected;   //!
   TBranch        *b_ph_topodr;   //!
   TBranch        *b_ph_topopt;   //!
   TBranch        *b_ph_topoeta;   //!
   TBranch        *b_ph_topophi;   //!
   TBranch        *b_ph_topomatched;   //!
   TBranch        *b_ph_topoEMdr;   //!
   TBranch        *b_ph_topoEMpt;   //!
   TBranch        *b_ph_topoEMeta;   //!
   TBranch        *b_ph_topoEMphi;   //!
   TBranch        *b_ph_topoEMmatched;   //!
   TBranch        *b_ph_EF_dr;   //!
   TBranch        *b_ph_EF_index;   //!
   TBranch        *b_ph_L2_dr;   //!
   TBranch        *b_ph_L2_index;   //!
   TBranch        *b_ph_L1_dr;   //!
   TBranch        *b_ph_L1_index;   //!
   TBranch        *b_mu_n;   //!
   TBranch        *b_mu_E;   //!
   TBranch        *b_mu_pt;   //!
   TBranch        *b_mu_m;   //!
   TBranch        *b_mu_eta;   //!
   TBranch        *b_mu_phi;   //!
   TBranch        *b_mu_px;   //!
   TBranch        *b_mu_py;   //!
   TBranch        *b_mu_pz;   //!
   TBranch        *b_mu_charge;   //!
   TBranch        *b_mu_allauthor;   //!
   TBranch        *b_mu_author;   //!
   TBranch        *b_mu_beta;   //!
   TBranch        *b_mu_isMuonLikelihood;   //!
   TBranch        *b_mu_matchchi2;   //!
   TBranch        *b_mu_matchndof;   //!
   TBranch        *b_mu_etcone20;   //!
   TBranch        *b_mu_etcone30;   //!
   TBranch        *b_mu_etcone40;   //!
   TBranch        *b_mu_nucone20;   //!
   TBranch        *b_mu_nucone30;   //!
   TBranch        *b_mu_nucone40;   //!
   TBranch        *b_mu_ptcone20;   //!
   TBranch        *b_mu_ptcone30;   //!
   TBranch        *b_mu_ptcone40;   //!
   TBranch        *b_mu_energyLossPar;   //!
   TBranch        *b_mu_energyLossErr;   //!
   TBranch        *b_mu_etCore;   //!
   TBranch        *b_mu_energyLossType;   //!
   TBranch        *b_mu_caloMuonIdTag;   //!
   TBranch        *b_mu_caloLRLikelihood;   //!
   TBranch        *b_mu_bestMatch;   //!
   TBranch        *b_mu_isStandAloneMuon;   //!
   TBranch        *b_mu_isCombinedMuon;   //!
   TBranch        *b_mu_isLowPtReconstructedMuon;   //!
   TBranch        *b_mu_isSegmentTaggedMuon;   //!
   TBranch        *b_mu_isCaloMuonId;   //!
   TBranch        *b_mu_alsoFoundByLowPt;   //!
   TBranch        *b_mu_alsoFoundByCaloMuonId;   //!
   TBranch        *b_mu_loose;   //!
   TBranch        *b_mu_medium;   //!
   TBranch        *b_mu_tight;   //!
   TBranch        *b_mu_d0_exPV;   //!
   TBranch        *b_mu_z0_exPV;   //!
   TBranch        *b_mu_phi_exPV;   //!
   TBranch        *b_mu_theta_exPV;   //!
   TBranch        *b_mu_qoverp_exPV;   //!
   TBranch        *b_mu_cb_d0_exPV;   //!
   TBranch        *b_mu_cb_z0_exPV;   //!
   TBranch        *b_mu_cb_phi_exPV;   //!
   TBranch        *b_mu_cb_theta_exPV;   //!
   TBranch        *b_mu_cb_qoverp_exPV;   //!
   TBranch        *b_mu_id_d0_exPV;   //!
   TBranch        *b_mu_id_z0_exPV;   //!
   TBranch        *b_mu_id_phi_exPV;   //!
   TBranch        *b_mu_id_theta_exPV;   //!
   TBranch        *b_mu_id_qoverp_exPV;   //!
   TBranch        *b_mu_me_d0_exPV;   //!
   TBranch        *b_mu_me_z0_exPV;   //!
   TBranch        *b_mu_me_phi_exPV;   //!
   TBranch        *b_mu_me_theta_exPV;   //!
   TBranch        *b_mu_me_qoverp_exPV;   //!
   TBranch        *b_mu_ie_d0_exPV;   //!
   TBranch        *b_mu_ie_z0_exPV;   //!
   TBranch        *b_mu_ie_phi_exPV;   //!
   TBranch        *b_mu_ie_theta_exPV;   //!
   TBranch        *b_mu_ie_qoverp_exPV;   //!
   TBranch        *b_mu_SpaceTime_detID;   //!
   TBranch        *b_mu_SpaceTime_t;   //!
   TBranch        *b_mu_SpaceTime_tError;   //!
   TBranch        *b_mu_SpaceTime_weight;   //!
   TBranch        *b_mu_SpaceTime_x;   //!
   TBranch        *b_mu_SpaceTime_y;   //!
   TBranch        *b_mu_SpaceTime_z;   //!
   TBranch        *b_mu_cov_d0_exPV;   //!
   TBranch        *b_mu_cov_z0_exPV;   //!
   TBranch        *b_mu_cov_phi_exPV;   //!
   TBranch        *b_mu_cov_theta_exPV;   //!
   TBranch        *b_mu_cov_qoverp_exPV;   //!
   TBranch        *b_mu_cov_d0_z0_exPV;   //!
   TBranch        *b_mu_cov_d0_phi_exPV;   //!
   TBranch        *b_mu_cov_d0_theta_exPV;   //!
   TBranch        *b_mu_cov_d0_qoverp_exPV;   //!
   TBranch        *b_mu_cov_z0_phi_exPV;   //!
   TBranch        *b_mu_cov_z0_theta_exPV;   //!
   TBranch        *b_mu_cov_z0_qoverp_exPV;   //!
   TBranch        *b_mu_cov_phi_theta_exPV;   //!
   TBranch        *b_mu_cov_phi_qoverp_exPV;   //!
   TBranch        *b_mu_cov_theta_qoverp_exPV;   //!
   TBranch        *b_mu_id_cov_d0_exPV;   //!
   TBranch        *b_mu_id_cov_z0_exPV;   //!
   TBranch        *b_mu_id_cov_phi_exPV;   //!
   TBranch        *b_mu_id_cov_theta_exPV;   //!
   TBranch        *b_mu_id_cov_qoverp_exPV;   //!
   TBranch        *b_mu_id_cov_d0_z0_exPV;   //!
   TBranch        *b_mu_id_cov_d0_phi_exPV;   //!
   TBranch        *b_mu_id_cov_d0_theta_exPV;   //!
   TBranch        *b_mu_id_cov_d0_qoverp_exPV;   //!
   TBranch        *b_mu_id_cov_z0_phi_exPV;   //!
   TBranch        *b_mu_id_cov_z0_theta_exPV;   //!
   TBranch        *b_mu_id_cov_z0_qoverp_exPV;   //!
   TBranch        *b_mu_id_cov_phi_theta_exPV;   //!
   TBranch        *b_mu_id_cov_phi_qoverp_exPV;   //!
   TBranch        *b_mu_id_cov_theta_qoverp_exPV;   //!
   TBranch        *b_mu_me_cov_d0_exPV;   //!
   TBranch        *b_mu_me_cov_z0_exPV;   //!
   TBranch        *b_mu_me_cov_phi_exPV;   //!
   TBranch        *b_mu_me_cov_theta_exPV;   //!
   TBranch        *b_mu_me_cov_qoverp_exPV;   //!
   TBranch        *b_mu_me_cov_d0_z0_exPV;   //!
   TBranch        *b_mu_me_cov_d0_phi_exPV;   //!
   TBranch        *b_mu_me_cov_d0_theta_exPV;   //!
   TBranch        *b_mu_me_cov_d0_qoverp_exPV;   //!
   TBranch        *b_mu_me_cov_z0_phi_exPV;   //!
   TBranch        *b_mu_me_cov_z0_theta_exPV;   //!
   TBranch        *b_mu_me_cov_z0_qoverp_exPV;   //!
   TBranch        *b_mu_me_cov_phi_theta_exPV;   //!
   TBranch        *b_mu_me_cov_phi_qoverp_exPV;   //!
   TBranch        *b_mu_me_cov_theta_qoverp_exPV;   //!
   TBranch        *b_mu_ms_d0;   //!
   TBranch        *b_mu_ms_z0;   //!
   TBranch        *b_mu_ms_phi;   //!
   TBranch        *b_mu_ms_theta;   //!
   TBranch        *b_mu_ms_qoverp;   //!
   TBranch        *b_mu_id_d0;   //!
   TBranch        *b_mu_id_z0;   //!
   TBranch        *b_mu_id_phi;   //!
   TBranch        *b_mu_id_theta;   //!
   TBranch        *b_mu_id_qoverp;   //!
   TBranch        *b_mu_me_d0;   //!
   TBranch        *b_mu_me_z0;   //!
   TBranch        *b_mu_me_phi;   //!
   TBranch        *b_mu_me_theta;   //!
   TBranch        *b_mu_me_qoverp;   //!
   TBranch        *b_mu_ie_d0;   //!
   TBranch        *b_mu_ie_z0;   //!
   TBranch        *b_mu_ie_phi;   //!
   TBranch        *b_mu_ie_theta;   //!
   TBranch        *b_mu_ie_qoverp;   //!
   TBranch        *b_mu_nOutliersOnTrack;   //!
   TBranch        *b_mu_nBLHits;   //!
   TBranch        *b_mu_nPixHits;   //!
   TBranch        *b_mu_nSCTHits;   //!
   TBranch        *b_mu_nTRTHits;   //!
   TBranch        *b_mu_nTRTHighTHits;   //!
   TBranch        *b_mu_nBLSharedHits;   //!
   TBranch        *b_mu_nPixSharedHits;   //!
   TBranch        *b_mu_nPixHoles;   //!
   TBranch        *b_mu_nSCTSharedHits;   //!
   TBranch        *b_mu_nSCTHoles;   //!
   TBranch        *b_mu_nTRTOutliers;   //!
   TBranch        *b_mu_nTRTHighTOutliers;   //!
   TBranch        *b_mu_nGangedPixels;   //!
   TBranch        *b_mu_nPixelDeadSensors;   //!
   TBranch        *b_mu_nSCTDeadSensors;   //!
   TBranch        *b_mu_nTRTDeadStraws;   //!
   TBranch        *b_mu_expectBLayerHit;   //!
   TBranch        *b_mu_nMDTHits;   //!
   TBranch        *b_mu_nMDTHoles;   //!
   TBranch        *b_mu_nCSCEtaHits;   //!
   TBranch        *b_mu_nCSCEtaHoles;   //!
   TBranch        *b_mu_nCSCPhiHits;   //!
   TBranch        *b_mu_nCSCPhiHoles;   //!
   TBranch        *b_mu_nRPCEtaHits;   //!
   TBranch        *b_mu_nRPCEtaHoles;   //!
   TBranch        *b_mu_nRPCPhiHits;   //!
   TBranch        *b_mu_nRPCPhiHoles;   //!
   TBranch        *b_mu_nTGCEtaHits;   //!
   TBranch        *b_mu_nTGCEtaHoles;   //!
   TBranch        *b_mu_nTGCPhiHits;   //!
   TBranch        *b_mu_nTGCPhiHoles;   //!
   TBranch        *b_mu_nMDTBIHits;   //!
   TBranch        *b_mu_nMDTBMHits;   //!
   TBranch        *b_mu_nMDTBOHits;   //!
   TBranch        *b_mu_nMDTBEEHits;   //!
   TBranch        *b_mu_nMDTBIS78Hits;   //!
   TBranch        *b_mu_nMDTEIHits;   //!
   TBranch        *b_mu_nMDTEMHits;   //!
   TBranch        *b_mu_nMDTEOHits;   //!
   TBranch        *b_mu_nMDTEEHits;   //!
   TBranch        *b_mu_nRPCLayer1EtaHits;   //!
   TBranch        *b_mu_nRPCLayer2EtaHits;   //!
   TBranch        *b_mu_nRPCLayer3EtaHits;   //!
   TBranch        *b_mu_nRPCLayer1PhiHits;   //!
   TBranch        *b_mu_nRPCLayer2PhiHits;   //!
   TBranch        *b_mu_nRPCLayer3PhiHits;   //!
   TBranch        *b_mu_nTGCLayer1EtaHits;   //!
   TBranch        *b_mu_nTGCLayer2EtaHits;   //!
   TBranch        *b_mu_nTGCLayer3EtaHits;   //!
   TBranch        *b_mu_nTGCLayer4EtaHits;   //!
   TBranch        *b_mu_nTGCLayer1PhiHits;   //!
   TBranch        *b_mu_nTGCLayer2PhiHits;   //!
   TBranch        *b_mu_nTGCLayer3PhiHits;   //!
   TBranch        *b_mu_nTGCLayer4PhiHits;   //!
   TBranch        *b_mu_barrelSectors;   //!
   TBranch        *b_mu_endcapSectors;   //!
   TBranch        *b_mu_trackd0;   //!
   TBranch        *b_mu_trackz0;   //!
   TBranch        *b_mu_trackphi;   //!
   TBranch        *b_mu_tracktheta;   //!
   TBranch        *b_mu_trackqoverp;   //!
   TBranch        *b_mu_trackcov_d0;   //!
   TBranch        *b_mu_trackcov_z0;   //!
   TBranch        *b_mu_trackcov_phi;   //!
   TBranch        *b_mu_trackcov_theta;   //!
   TBranch        *b_mu_trackcov_qoverp;   //!
   TBranch        *b_mu_trackcov_d0_z0;   //!
   TBranch        *b_mu_trackcov_d0_phi;   //!
   TBranch        *b_mu_trackcov_d0_theta;   //!
   TBranch        *b_mu_trackcov_d0_qoverp;   //!
   TBranch        *b_mu_trackcov_z0_phi;   //!
   TBranch        *b_mu_trackcov_z0_theta;   //!
   TBranch        *b_mu_trackcov_z0_qoverp;   //!
   TBranch        *b_mu_trackcov_phi_theta;   //!
   TBranch        *b_mu_trackcov_phi_qoverp;   //!
   TBranch        *b_mu_trackcov_theta_qoverp;   //!
   TBranch        *b_mu_trackfitchi2;   //!
   TBranch        *b_mu_trackfitndof;   //!
   TBranch        *b_mu_hastrack;   //!
   TBranch        *b_mu_trackd0beam;   //!
   TBranch        *b_mu_trackz0beam;   //!
   TBranch        *b_mu_tracksigd0beam;   //!
   TBranch        *b_mu_tracksigz0beam;   //!
   TBranch        *b_mu_trackd0pv;   //!
   TBranch        *b_mu_trackz0pv;   //!
   TBranch        *b_mu_tracksigd0pv;   //!
   TBranch        *b_mu_tracksigz0pv;   //!
   TBranch        *b_mu_trackIPEstimate_d0_biasedpvunbiased;   //!
   TBranch        *b_mu_trackIPEstimate_z0_biasedpvunbiased;   //!
   TBranch        *b_mu_trackIPEstimate_d0_unbiasedpvunbiased;   //!
   TBranch        *b_mu_trackIPEstimate_z0_unbiasedpvunbiased;   //!
   TBranch        *b_mu_trackIPEstimate_sigd0_biasedpvunbiased;   //!
   TBranch        *b_mu_trackIPEstimate_sigz0_biasedpvunbiased;   //!
   TBranch        *b_mu_trackIPEstimate_sigd0_unbiasedpvunbiased;   //!
   TBranch        *b_mu_trackIPEstimate_sigz0_unbiasedpvunbiased;   //!
   TBranch        *b_mu_EFCB_dr;   //!
   TBranch        *b_mu_EFCB_index;   //!
   TBranch        *b_mu_EFMG_dr;   //!
   TBranch        *b_mu_EFME_dr;   //!
   TBranch        *b_mu_EFME_index;   //!
   TBranch        *b_mu_L2CB_dr;   //!
   TBranch        *b_mu_L2CB_index;   //!
   TBranch        *b_mu_L1_dr;   //!
   TBranch        *b_mu_L1_index;   //!
   TBranch        *b_tau_n;   //!
   TBranch        *b_tau_Et;   //!
   TBranch        *b_tau_pt;   //!
   TBranch        *b_tau_m;   //!
   TBranch        *b_tau_eta;   //!
   TBranch        *b_tau_phi;   //!
   TBranch        *b_tau_charge;   //!
   TBranch        *b_tau_BDTEleScore;   //!
   TBranch        *b_tau_BDTJetScore;   //!
   TBranch        *b_tau_likelihood;   //!
   TBranch        *b_tau_SafeLikelihood;   //!
   TBranch        *b_tau_electronVetoLoose;   //!
   TBranch        *b_tau_electronVetoMedium;   //!
   TBranch        *b_tau_electronVetoTight;   //!
   TBranch        *b_tau_muonVeto;   //!
   TBranch        *b_tau_tauCutLoose;   //!
   TBranch        *b_tau_tauCutMedium;   //!
   TBranch        *b_tau_tauCutTight;   //!
   TBranch        *b_tau_tauLlhLoose;   //!
   TBranch        *b_tau_tauLlhMedium;   //!
   TBranch        *b_tau_tauLlhTight;   //!
   TBranch        *b_tau_JetBDTSigLoose;   //!
   TBranch        *b_tau_JetBDTSigMedium;   //!
   TBranch        *b_tau_JetBDTSigTight;   //!
   TBranch        *b_tau_EleBDTLoose;   //!
   TBranch        *b_tau_EleBDTMedium;   //!
   TBranch        *b_tau_EleBDTTight;   //!
   TBranch        *b_tau_author;   //!
   TBranch        *b_tau_ROIword;   //!
   TBranch        *b_tau_nProng;   //!
   TBranch        *b_tau_numTrack;   //!
   TBranch        *b_tau_seedCalo_numTrack;   //!
   TBranch        *b_tau_etOverPtLeadTrk;   //!
   TBranch        *b_tau_ipZ0SinThetaSigLeadTrk;   //!
   TBranch        *b_tau_leadTrkPt;   //!
   TBranch        *b_tau_nLooseTrk;   //!
   TBranch        *b_tau_nLooseConvTrk;   //!
   TBranch        *b_tau_nProngLoose;   //!
   TBranch        *b_tau_ipSigLeadTrk;   //!
   TBranch        *b_tau_ipSigLeadLooseTrk;   //!
   TBranch        *b_tau_etOverPtLeadLooseTrk;   //!
   TBranch        *b_tau_leadLooseTrkPt;   //!
   TBranch        *b_tau_chrgLooseTrk;   //!
   TBranch        *b_tau_massTrkSys;   //!
   TBranch        *b_tau_trkWidth2;   //!
   TBranch        *b_tau_trFlightPathSig;   //!
   TBranch        *b_tau_etEflow;   //!
   TBranch        *b_tau_mEflow;   //!
   TBranch        *b_tau_nPi0;   //!
   TBranch        *b_tau_ele_E237E277;   //!
   TBranch        *b_tau_ele_PresamplerFraction;   //!
   TBranch        *b_tau_ele_ECALFirstFraction;   //!
   TBranch        *b_tau_seedCalo_EMRadius;   //!
   TBranch        *b_tau_seedCalo_hadRadius;   //!
   TBranch        *b_tau_seedCalo_etEMAtEMScale;   //!
   TBranch        *b_tau_seedCalo_etHadAtEMScale;   //!
   TBranch        *b_tau_seedCalo_isolFrac;   //!
   TBranch        *b_tau_seedCalo_centFrac;   //!
   TBranch        *b_tau_seedCalo_stripWidth2;   //!
   TBranch        *b_tau_seedCalo_nStrip;   //!
   TBranch        *b_tau_seedCalo_etEMCalib;   //!
   TBranch        *b_tau_seedCalo_etHadCalib;   //!
   TBranch        *b_tau_seedCalo_eta;   //!
   TBranch        *b_tau_seedCalo_phi;   //!
   TBranch        *b_tau_seedCalo_nIsolLooseTrk;   //!
   TBranch        *b_tau_seedCalo_trkAvgDist;   //!
   TBranch        *b_tau_seedCalo_trkRmsDist;   //!
   TBranch        *b_tau_numTopoClusters;   //!
   TBranch        *b_tau_numEffTopoClusters;   //!
   TBranch        *b_tau_topoInvMass;   //!
   TBranch        *b_tau_effTopoInvMass;   //!
   TBranch        *b_tau_topoMeanDeltaR;   //!
   TBranch        *b_tau_effTopoMeanDeltaR;   //!
   TBranch        *b_tau_numCells;   //!
   TBranch        *b_tau_seedTrk_EMRadius;   //!
   TBranch        *b_tau_seedTrk_isolFrac;   //!
   TBranch        *b_tau_seedTrk_etChrgHadOverSumTrkPt;   //!
   TBranch        *b_tau_seedTrk_isolFracWide;   //!
   TBranch        *b_tau_seedTrk_etHadAtEMScale;   //!
   TBranch        *b_tau_seedTrk_etEMAtEMScale;   //!
   TBranch        *b_tau_seedTrk_etEMCL;   //!
   TBranch        *b_tau_seedTrk_etChrgEM;   //!
   TBranch        *b_tau_seedTrk_etNeuEM;   //!
   TBranch        *b_tau_seedTrk_etResNeuEM;   //!
   TBranch        *b_tau_seedTrk_hadLeakEt;   //!
   TBranch        *b_tau_seedTrk_sumEMCellEtOverLeadTrkPt;   //!
   TBranch        *b_tau_seedTrk_secMaxStripEt;   //!
   TBranch        *b_tau_seedTrk_stripWidth2;   //!
   TBranch        *b_tau_seedTrk_nStrip;   //!
   TBranch        *b_tau_seedTrk_etChrgHad;   //!
   TBranch        *b_tau_seedTrk_nOtherCoreTrk;   //!
   TBranch        *b_tau_seedTrk_nIsolTrk;   //!
   TBranch        *b_tau_seedTrk_etIsolEM;   //!
   TBranch        *b_tau_seedTrk_etIsolHad;   //!
   TBranch        *b_tau_calcVars_etHad_EMScale_Pt3Trks;   //!
   TBranch        *b_tau_calcVars_etEM_EMScale_Pt3Trks;   //!
   TBranch        *b_tau_calcVars_ipSigLeadLooseTrk;   //!
   TBranch        *b_tau_calcVars_drMax;   //!
   TBranch        *b_tau_calcVars_drMin;   //!
   TBranch        *b_tau_calcVars_TRTHTOverLT_LeadTrk;   //!
   TBranch        *b_tau_calcVars_calRadius;   //!
   TBranch        *b_tau_calcVars_EMFractionAtEMScale;   //!
   TBranch        *b_tau_calcVars_lead2ClusterEOverAllClusterE;   //!
   TBranch        *b_tau_calcVars_lead3ClusterEOverAllClusterE;   //!
   TBranch        *b_tau_calcVars_caloIso;   //!
   TBranch        *b_tau_calcVars_trackIso;   //!
   TBranch        *b_tau_calcVars_caloIsoCorrected;   //!
   TBranch        *b_tau_calcVars_BDTSigTrans;   //!
   TBranch        *b_tau_calcVars_BDTLooseBkg;   //!
   TBranch        *b_tau_calcVars_BDTMediumBkg;   //!
   TBranch        *b_tau_calcVars_BDTTightBkg;   //!
   TBranch        *b_tau_cluster_E;   //!
   TBranch        *b_tau_cluster_eta;   //!
   TBranch        *b_tau_cluster_phi;   //!
   TBranch        *b_tau_cluster_n;   //!
   TBranch        *b_tau_cluster_emfraction;   //!
   TBranch        *b_tau_Pi0Cluster_pt;   //!
   TBranch        *b_tau_Pi0Cluster_eta;   //!
   TBranch        *b_tau_Pi0Cluster_phi;   //!
   TBranch        *b_tau_secvtx_x;   //!
   TBranch        *b_tau_secvtx_y;   //!
   TBranch        *b_tau_secvtx_z;   //!
   TBranch        *b_tau_secvtx_chiSquared;   //!
   TBranch        *b_tau_secvtx_numberDoF;   //!
   TBranch        *b_tau_jet_Et;   //!
   TBranch        *b_tau_jet_pt;   //!
   TBranch        *b_tau_jet_m;   //!
   TBranch        *b_tau_jet_eta;   //!
   TBranch        *b_tau_jet_phi;   //!
   TBranch        *b_tau_jet_SamplingMax;   //!
   TBranch        *b_tau_jet_fracSamplingMax;   //!
   TBranch        *b_tau_jet_emfrac;   //!
   TBranch        *b_tau_jet_GCWJES;   //!
   TBranch        *b_tau_jet_EMJES;   //!
   TBranch        *b_tau_jet_emscale_E;   //!
   TBranch        *b_tau_jet_emscale_pt;   //!
   TBranch        *b_tau_jet_emscale_m;   //!
   TBranch        *b_tau_jet_emscale_eta;   //!
   TBranch        *b_tau_jet_emscale_phi;   //!
   TBranch        *b_tau_jet_flavor_weight_TrackCounting2D;   //!
   TBranch        *b_tau_jet_flavor_weight_JetProb;   //!
   TBranch        *b_tau_jet_flavor_weight_IP1D;   //!
   TBranch        *b_tau_jet_flavor_weight_IP2D;   //!
   TBranch        *b_tau_jet_flavor_weight_IP3D;   //!
   TBranch        *b_tau_jet_flavor_weight_SV0;   //!
   TBranch        *b_tau_jet_flavor_weight_SV1;   //!
   TBranch        *b_tau_jet_flavor_weight_SV2;   //!
   TBranch        *b_tau_jet_flavor_weight_JetFitterTag;   //!
   TBranch        *b_tau_jet_flavor_weight_JetFitterCOMB;   //!
   TBranch        *b_tau_jet_flavor_weight_JetFitterTagNN;   //!
   TBranch        *b_tau_jet_flavor_weight_JetFitterCOMBNN;   //!
   TBranch        *b_tau_jet_flavor_weight_SoftMuonTag;   //!
   TBranch        *b_tau_jet_flavor_weight_SoftElectronTag;   //!
   TBranch        *b_tau_jet_flavor_weight_IP3DSV1;   //!
   TBranch        *b_tau_seedCalo_track_n;   //!
   TBranch        *b_tau_seedCalo_wideTrk_n;   //!
   TBranch        *b_tau_otherTrk_n;   //!
   TBranch        *b_tau_EF_dr;   //!
   TBranch        *b_tau_EF_E;   //!
   TBranch        *b_tau_EF_Et;   //!
   TBranch        *b_tau_EF_pt;   //!
   TBranch        *b_tau_EF_eta;   //!
   TBranch        *b_tau_EF_phi;   //!
   TBranch        *b_tau_EF_matched;   //!
   TBranch        *b_tau_L2_dr;   //!
   TBranch        *b_tau_L2_E;   //!
   TBranch        *b_tau_L2_Et;   //!
   TBranch        *b_tau_L2_pt;   //!
   TBranch        *b_tau_L2_eta;   //!
   TBranch        *b_tau_L2_phi;   //!
   TBranch        *b_tau_L2_matched;   //!
   TBranch        *b_tau_L1_dr;   //!
   TBranch        *b_tau_L1_Et;   //!
   TBranch        *b_tau_L1_pt;   //!
   TBranch        *b_tau_L1_eta;   //!
   TBranch        *b_tau_L1_phi;   //!
   TBranch        *b_tau_L1_matched;   //!
   TBranch        *b_trk_n;   //!
   TBranch        *b_trk_pt;   //!
   TBranch        *b_trk_eta;   //!
   TBranch        *b_trk_d0_wrtPV;   //!
   TBranch        *b_trk_z0_wrtPV;   //!
   TBranch        *b_trk_phi_wrtPV;   //!
   TBranch        *b_trk_theta_wrtPV;   //!
   TBranch        *b_trk_qoverp_wrtPV;   //!
   TBranch        *b_trk_err_d0_wrtPV;   //!
   TBranch        *b_trk_err_z0_wrtPV;   //!
   TBranch        *b_trk_err_phi_wrtPV;   //!
   TBranch        *b_trk_err_theta_wrtPV;   //!
   TBranch        *b_trk_err_qoverp_wrtPV;   //!
   TBranch        *b_trk_chi2;   //!
   TBranch        *b_trk_ndof;   //!
   TBranch        *b_trk_nBLHits;   //!
   TBranch        *b_trk_nPixHits;   //!
   TBranch        *b_trk_nSCTHits;   //!
   TBranch        *b_trk_nTRTHits;   //!
   TBranch        *b_trk_nTRTHighTHits;   //!
   TBranch        *b_trk_nPixHoles;   //!
   TBranch        *b_trk_nSCTHoles;   //!
   TBranch        *b_trk_nTRTHoles;   //!
   TBranch        *b_trk_nBLayerOutliers;   //!
   TBranch        *b_trk_nPixelOutliers;   //!
   TBranch        *b_trk_nSCTOutliers;   //!
   TBranch        *b_trk_nTRTOutliers;   //!
   TBranch        *b_trk_nTRTHighTOutliers;   //!
   TBranch        *b_trk_nContribPixelLayers;   //!
   TBranch        *b_trk_nGangedPixels;   //!
   TBranch        *b_trk_nGangedFlaggedFakes;   //!
   TBranch        *b_trk_nPixelDeadSensors;   //!
   TBranch        *b_trk_nPixelSpoiltHits;   //!
   TBranch        *b_trk_nSCTDoubleHoles;   //!
   TBranch        *b_trk_nSCTDeadSensors;   //!
   TBranch        *b_trk_nSCTSpoiltHits;   //!
   TBranch        *b_trk_nTRTDeadStraws;   //!
   TBranch        *b_trk_nTRTTubeHits;   //!
   TBranch        *b_trk_expectBLayerHit;   //!
   TBranch        *b_trk_20_trackIso;   //!
   TBranch        *b_trk_20_caloIso;   //!
   TBranch        *b_trk_20_nTrackIso;   //!
   TBranch        *b_trk_30_trackIso;   //!
   TBranch        *b_trk_30_caloIso;   //!
   TBranch        *b_trk_30_nTrackIso;   //!
   TBranch        *b_trk_40_trackIso;   //!
   TBranch        *b_trk_40_caloIso;   //!
   TBranch        *b_trk_40_nTrackIso;   //!
   TBranch        *b_jet_antiKtZ4Track_n;   //!
   TBranch        *b_jet_antiKtZ4Track_E;   //!
   TBranch        *b_jet_antiKtZ4Track_pt;   //!
   TBranch        *b_jet_antiKtZ4Track_m;   //!
   TBranch        *b_jet_antiKtZ4Track_eta;   //!
   TBranch        *b_jet_antiKtZ4Track_phi;   //!
   TBranch        *b_jet_antiKtZ4Track_EtaOrigin;   //!
   TBranch        *b_jet_antiKtZ4Track_PhiOrigin;   //!
   TBranch        *b_jet_antiKtZ4Track_MOrigin;   //!
   TBranch        *b_jet_antiKtZ4Track_EtaOriginEM;   //!
   TBranch        *b_jet_antiKtZ4Track_PhiOriginEM;   //!
   TBranch        *b_jet_antiKtZ4Track_MOriginEM;   //!
   TBranch        *b_jet_antiKtZ4Track_WIDTH;   //!
   TBranch        *b_jet_antiKtZ4Track_n90;   //!
   TBranch        *b_jet_antiKtZ4Track_Timing;   //!
   TBranch        *b_jet_antiKtZ4Track_LArQuality;   //!
   TBranch        *b_jet_antiKtZ4Track_nTrk;   //!
   TBranch        *b_jet_antiKtZ4Track_sumPtTrk;   //!
   TBranch        *b_jet_antiKtZ4Track_OriginIndex;   //!
   TBranch        *b_jet_antiKtZ4Track_HECQuality;   //!
   TBranch        *b_jet_antiKtZ4Track_NegativeE;   //!
   TBranch        *b_jet_antiKtZ4Track_AverageLArQF;   //!
   TBranch        *b_jet_antiKtZ4Track_YFlip12;   //!
   TBranch        *b_jet_antiKtZ4Track_YFlip23;   //!
   TBranch        *b_jet_antiKtZ4Track_BCH_CORR_CELL;   //!
   TBranch        *b_jet_antiKtZ4Track_BCH_CORR_DOTX;   //!
   TBranch        *b_jet_antiKtZ4Track_BCH_CORR_JET;   //!
   TBranch        *b_jet_antiKtZ4Track_BCH_CORR_JET_FORCELL;   //!
   TBranch        *b_jet_antiKtZ4Track_ENG_BAD_CELLS;   //!
   TBranch        *b_jet_antiKtZ4Track_N_BAD_CELLS;   //!
   TBranch        *b_jet_antiKtZ4Track_N_BAD_CELLS_CORR;   //!
   TBranch        *b_jet_antiKtZ4Track_BAD_CELLS_CORR_E;   //!
   TBranch        *b_jet_antiKtZ4Track_NumTowers;   //!
   TBranch        *b_jet_antiKtZ4Track_SamplingMax;   //!
   TBranch        *b_jet_antiKtZ4Track_fracSamplingMax;   //!
   TBranch        *b_jet_antiKtZ4Track_hecf;   //!
   TBranch        *b_jet_antiKtZ4Track_tgap3f;   //!
   TBranch        *b_jet_antiKtZ4Track_isUgly;   //!
   TBranch        *b_jet_antiKtZ4Track_isBadLoose;   //!
   TBranch        *b_jet_antiKtZ4Track_isBadMedium;   //!
   TBranch        *b_jet_antiKtZ4Track_isBadTight;   //!
   TBranch        *b_jet_antiKtZ4Track_emfrac;   //!
   TBranch        *b_jet_antiKtZ4Track_Offset;   //!
   TBranch        *b_jet_antiKtZ4Track_EMJES;   //!
   TBranch        *b_jet_antiKtZ4Track_EMJES_EtaCorr;   //!
   TBranch        *b_jet_antiKtZ4Track_EMJESnooffset;   //!
   TBranch        *b_jet_antiKtZ4Track_GCWJES;   //!
   TBranch        *b_jet_antiKtZ4Track_GCWJES_EtaCorr;   //!
   TBranch        *b_jet_antiKtZ4Track_CB;   //!
   TBranch        *b_jet_antiKtZ4Track_LCJES;   //!
   TBranch        *b_jet_antiKtZ4Track_emscale_E;   //!
   TBranch        *b_jet_antiKtZ4Track_emscale_pt;   //!
   TBranch        *b_jet_antiKtZ4Track_emscale_m;   //!
   TBranch        *b_jet_antiKtZ4Track_emscale_eta;   //!
   TBranch        *b_jet_antiKtZ4Track_emscale_phi;   //!
   TBranch        *b_jet_antiKtZ4Track_jvtx_x;   //!
   TBranch        *b_jet_antiKtZ4Track_jvtx_y;   //!
   TBranch        *b_jet_antiKtZ4Track_jvtx_z;   //!
   TBranch        *b_jet_antiKtZ4Track_jvtxf;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_weight_Comb;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_weight_IP2D;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_weight_IP3D;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_weight_SV0;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_weight_SV1;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_weight_SV2;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_weight_JetProb;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_weight_SoftMuonTag;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_weight_JetFitterTagNN;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_weight_JetFitterCOMBNN;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_weight_GbbNN;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_isValid;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_ntrkv;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_ntrkj;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_n2t;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_mass;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_efrc;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_x;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_y;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_z;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_err_x;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_err_y;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_err_z;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_cov_xy;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_cov_xz;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_cov_yz;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_chi2;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_ndof;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_svp_ntrk;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_isValid;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_ntrkv;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_ntrkj;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_n2t;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_mass;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_efrc;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_x;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_y;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_z;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_err_x;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_err_y;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_err_z;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_cov_xy;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_cov_xz;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_cov_yz;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_chi2;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_ndof;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_component_sv0p_ntrk;   //!
   TBranch        *b_jet_antiKtZ4Track_flavor_assoctrk_index;   //!
   TBranch        *b_jet_antiKtZ4Track_el_dr;   //!
   TBranch        *b_jet_antiKtZ4Track_el_matched;   //!
   TBranch        *b_jet_antiKtZ4Track_mu_dr;   //!
   TBranch        *b_jet_antiKtZ4Track_mu_matched;   //!
   TBranch        *b_jet_antiKtZ4Track_L1_dr;   //!
   TBranch        *b_jet_antiKtZ4Track_L1_matched;   //!
   TBranch        *b_jet_antiKtZ4Track_L2_dr;   //!
   TBranch        *b_jet_antiKtZ4Track_L2_matched;   //!
   TBranch        *b_jet_antiKtZ4Track_EF_dr;   //!
   TBranch        *b_jet_antiKtZ4Track_EF_matched;   //!
   TBranch        *b_jet_n;   //!
   TBranch        *b_jet_E;   //!
   TBranch        *b_jet_pt;   //!
   TBranch        *b_jet_m;   //!
   TBranch        *b_jet_eta;   //!
   TBranch        *b_jet_phi;   //!
   TBranch        *b_jet_EtaOrigin;   //!
   TBranch        *b_jet_PhiOrigin;   //!
   TBranch        *b_jet_MOrigin;   //!
   TBranch        *b_jet_EtaOriginEM;   //!
   TBranch        *b_jet_PhiOriginEM;   //!
   TBranch        *b_jet_MOriginEM;   //!
   TBranch        *b_jet_WIDTH;   //!
   TBranch        *b_jet_n90;   //!
   TBranch        *b_jet_Timing;   //!
   TBranch        *b_jet_LArQuality;   //!
   TBranch        *b_jet_nTrk;   //!
   TBranch        *b_jet_sumPtTrk;   //!
   TBranch        *b_jet_OriginIndex;   //!
   TBranch        *b_jet_HECQuality;   //!
   TBranch        *b_jet_NegativeE;   //!
   TBranch        *b_jet_AverageLArQF;   //!
   TBranch        *b_jet_YFlip12;   //!
   TBranch        *b_jet_YFlip23;   //!
   TBranch        *b_jet_BCH_CORR_CELL;   //!
   TBranch        *b_jet_BCH_CORR_DOTX;   //!
   TBranch        *b_jet_BCH_CORR_JET;   //!
   TBranch        *b_jet_BCH_CORR_JET_FORCELL;   //!
   TBranch        *b_jet_ENG_BAD_CELLS;   //!
   TBranch        *b_jet_N_BAD_CELLS;   //!
   TBranch        *b_jet_N_BAD_CELLS_CORR;   //!
   TBranch        *b_jet_BAD_CELLS_CORR_E;   //!
   TBranch        *b_jet_NumTowers;   //!
   TBranch        *b_jet_SamplingMax;   //!
   TBranch        *b_jet_fracSamplingMax;   //!
   TBranch        *b_jet_hecf;   //!
   TBranch        *b_jet_tgap3f;   //!
   TBranch        *b_jet_isUgly;   //!
   TBranch        *b_jet_isBadLoose;   //!
   TBranch        *b_jet_isBadMedium;   //!
   TBranch        *b_jet_isBadTight;   //!
   TBranch        *b_jet_emfrac;   //!
   TBranch        *b_jet_Offset;   //!
   TBranch        *b_jet_EMJES;   //!
   TBranch        *b_jet_EMJES_EtaCorr;   //!
   TBranch        *b_jet_EMJESnooffset;   //!
   TBranch        *b_jet_GCWJES;   //!
   TBranch        *b_jet_GCWJES_EtaCorr;   //!
   TBranch        *b_jet_CB;   //!
   TBranch        *b_jet_LCJES;   //!
   TBranch        *b_jet_emscale_E;   //!
   TBranch        *b_jet_emscale_pt;   //!
   TBranch        *b_jet_emscale_m;   //!
   TBranch        *b_jet_emscale_eta;   //!
   TBranch        *b_jet_emscale_phi;   //!
   TBranch        *b_jet_jvtx_x;   //!
   TBranch        *b_jet_jvtx_y;   //!
   TBranch        *b_jet_jvtx_z;   //!
   TBranch        *b_jet_jvtxf;   //!
   TBranch        *b_jet_GSCFactorF;   //!
   TBranch        *b_jet_WidthFraction;   //!
   TBranch        *b_jet_e_PreSamplerB;   //!
   TBranch        *b_jet_e_EMB1;   //!
   TBranch        *b_jet_e_EMB2;   //!
   TBranch        *b_jet_e_EMB3;   //!
   TBranch        *b_jet_e_PreSamplerE;   //!
   TBranch        *b_jet_e_EME1;   //!
   TBranch        *b_jet_e_EME2;   //!
   TBranch        *b_jet_e_EME3;   //!
   TBranch        *b_jet_e_HEC0;   //!
   TBranch        *b_jet_e_HEC1;   //!
   TBranch        *b_jet_e_HEC2;   //!
   TBranch        *b_jet_e_HEC3;   //!
   TBranch        *b_jet_e_TileBar0;   //!
   TBranch        *b_jet_e_TileBar1;   //!
   TBranch        *b_jet_e_TileBar2;   //!
   TBranch        *b_jet_e_TileGap1;   //!
   TBranch        *b_jet_e_TileGap2;   //!
   TBranch        *b_jet_e_TileGap3;   //!
   TBranch        *b_jet_e_TileExt0;   //!
   TBranch        *b_jet_e_TileExt1;   //!
   TBranch        *b_jet_e_TileExt2;   //!
   TBranch        *b_jet_e_FCAL0;   //!
   TBranch        *b_jet_e_FCAL1;   //!
   TBranch        *b_jet_e_FCAL2;   //!
   TBranch        *b_jet_flavor_weight_Comb;   //!
   TBranch        *b_jet_flavor_weight_IP2D;   //!
   TBranch        *b_jet_flavor_weight_IP3D;   //!
   TBranch        *b_jet_flavor_weight_SV0;   //!
   TBranch        *b_jet_flavor_weight_SV1;   //!
   TBranch        *b_jet_flavor_weight_SV2;   //!
   TBranch        *b_jet_flavor_weight_JetProb;   //!
   TBranch        *b_jet_flavor_weight_SoftMuonTag;   //!
   TBranch        *b_jet_flavor_weight_JetFitterTagNN;   //!
   TBranch        *b_jet_flavor_weight_JetFitterCOMBNN;   //!
   TBranch        *b_jet_flavor_weight_GbbNN;   //!
   TBranch        *b_jet_flavor_component_svp_isValid;   //!
   TBranch        *b_jet_flavor_component_svp_ntrkv;   //!
   TBranch        *b_jet_flavor_component_svp_ntrkj;   //!
   TBranch        *b_jet_flavor_component_svp_n2t;   //!
   TBranch        *b_jet_flavor_component_svp_mass;   //!
   TBranch        *b_jet_flavor_component_svp_efrc;   //!
   TBranch        *b_jet_flavor_component_svp_x;   //!
   TBranch        *b_jet_flavor_component_svp_y;   //!
   TBranch        *b_jet_flavor_component_svp_z;   //!
   TBranch        *b_jet_flavor_component_svp_err_x;   //!
   TBranch        *b_jet_flavor_component_svp_err_y;   //!
   TBranch        *b_jet_flavor_component_svp_err_z;   //!
   TBranch        *b_jet_flavor_component_svp_cov_xy;   //!
   TBranch        *b_jet_flavor_component_svp_cov_xz;   //!
   TBranch        *b_jet_flavor_component_svp_cov_yz;   //!
   TBranch        *b_jet_flavor_component_svp_chi2;   //!
   TBranch        *b_jet_flavor_component_svp_ndof;   //!
   TBranch        *b_jet_flavor_component_svp_ntrk;   //!
   TBranch        *b_jet_flavor_component_sv0p_isValid;   //!
   TBranch        *b_jet_flavor_component_sv0p_ntrkv;   //!
   TBranch        *b_jet_flavor_component_sv0p_ntrkj;   //!
   TBranch        *b_jet_flavor_component_sv0p_n2t;   //!
   TBranch        *b_jet_flavor_component_sv0p_mass;   //!
   TBranch        *b_jet_flavor_component_sv0p_efrc;   //!
   TBranch        *b_jet_flavor_component_sv0p_x;   //!
   TBranch        *b_jet_flavor_component_sv0p_y;   //!
   TBranch        *b_jet_flavor_component_sv0p_z;   //!
   TBranch        *b_jet_flavor_component_sv0p_err_x;   //!
   TBranch        *b_jet_flavor_component_sv0p_err_y;   //!
   TBranch        *b_jet_flavor_component_sv0p_err_z;   //!
   TBranch        *b_jet_flavor_component_sv0p_cov_xy;   //!
   TBranch        *b_jet_flavor_component_sv0p_cov_xz;   //!
   TBranch        *b_jet_flavor_component_sv0p_cov_yz;   //!
   TBranch        *b_jet_flavor_component_sv0p_chi2;   //!
   TBranch        *b_jet_flavor_component_sv0p_ndof;   //!
   TBranch        *b_jet_flavor_component_sv0p_ntrk;   //!
   TBranch        *b_jet_flavor_assoctrk_index;   //!
   TBranch        *b_jet_el_dr;   //!
   TBranch        *b_jet_el_matched;   //!
   TBranch        *b_jet_mu_dr;   //!
   TBranch        *b_jet_mu_matched;   //!
   TBranch        *b_jet_L1_dr;   //!
   TBranch        *b_jet_L1_matched;   //!
   TBranch        *b_jet_L2_dr;   //!
   TBranch        *b_jet_L2_matched;   //!
   TBranch        *b_jet_EF_dr;   //!
   TBranch        *b_jet_EF_matched;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_n;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_E;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_pt;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_m;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_eta;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_phi;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_EtaOrigin;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_PhiOrigin;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_MOrigin;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_EtaOriginEM;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_PhiOriginEM;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_MOriginEM;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_WIDTH;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_n90;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_Timing;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_LArQuality;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_nTrk;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_sumPtTrk;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_OriginIndex;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_HECQuality;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_NegativeE;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_AverageLArQF;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_YFlip12;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_YFlip23;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_BCH_CORR_CELL;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_BCH_CORR_DOTX;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_BCH_CORR_JET;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_BCH_CORR_JET_FORCELL;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_ENG_BAD_CELLS;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_N_BAD_CELLS;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_N_BAD_CELLS_CORR;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_BAD_CELLS_CORR_E;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_NumTowers;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_SamplingMax;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_fracSamplingMax;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_hecf;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_tgap3f;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_isUgly;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_isBadLoose;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_isBadMedium;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_isBadTight;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_emfrac;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_Offset;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_EMJES;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_EMJES_EtaCorr;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_EMJESnooffset;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_GCWJES;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_GCWJES_EtaCorr;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_CB;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_LCJES;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_emscale_E;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_emscale_pt;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_emscale_m;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_emscale_eta;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_emscale_phi;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_jvtx_x;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_jvtx_y;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_jvtx_z;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_jvtxf;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_GSCFactorF;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_WidthFraction;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_PreSamplerB;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_EMB1;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_EMB2;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_EMB3;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_PreSamplerE;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_EME1;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_EME2;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_EME3;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_HEC0;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_HEC1;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_HEC2;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_HEC3;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_TileBar0;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_TileBar1;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_TileBar2;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_TileGap1;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_TileGap2;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_TileGap3;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_TileExt0;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_TileExt1;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_TileExt2;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_FCAL0;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_FCAL1;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_e_FCAL2;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_weight_Comb;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_weight_IP2D;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_weight_IP3D;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_weight_SV0;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_weight_SV1;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_weight_SV2;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_weight_JetProb;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_weight_SoftMuonTag;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_weight_JetFitterTagNN;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_weight_JetFitterCOMBNN;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_weight_GbbNN;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_isValid;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_ntrkv;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_ntrkj;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_n2t;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_mass;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_efrc;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_x;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_y;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_z;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_err_x;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_err_y;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_err_z;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_cov_xy;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_cov_xz;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_cov_yz;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_chi2;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_ndof;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_svp_ntrk;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_isValid;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrkv;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrkj;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_n2t;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_mass;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_efrc;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_x;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_y;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_z;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_x;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_y;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_z;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_xy;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_xz;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_yz;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_chi2;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_ndof;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrk;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_el_dr;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_el_matched;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_mu_dr;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_mu_matched;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_L1_dr;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_L1_matched;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_L2_dr;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_L2_matched;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_EF_dr;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_EF_matched;   //!
   TBranch        *b_vxp_n;   //!
   TBranch        *b_vxp_x;   //!
   TBranch        *b_vxp_y;   //!
   TBranch        *b_vxp_z;   //!
   TBranch        *b_vxp_err_x;   //!
   TBranch        *b_vxp_err_y;   //!
   TBranch        *b_vxp_err_z;   //!
   TBranch        *b_vxp_cov_xy;   //!
   TBranch        *b_vxp_cov_xz;   //!
   TBranch        *b_vxp_cov_yz;   //!
   TBranch        *b_vxp_type;   //!
   TBranch        *b_vxp_chi2;   //!
   TBranch        *b_vxp_ndof;   //!
   TBranch        *b_vxp_px;   //!
   TBranch        *b_vxp_py;   //!
   TBranch        *b_vxp_pz;   //!
   TBranch        *b_vxp_E;   //!
   TBranch        *b_vxp_m;   //!
   TBranch        *b_vxp_nTracks;   //!
   TBranch        *b_vxp_sumPt;   //!
   TBranch        *b_vxp_trk_n;   //!
   TBranch        *b_vxp_trk_weight;   //!
   TBranch        *b_vxp_trk_index;   //!
   TBranch        *b_top_hfor_type;   //!
   TBranch        *b_MET_RefEle_em_tight_etx;   //!
   TBranch        *b_MET_RefEle_em_tight_ety;   //!
   TBranch        *b_MET_RefEle_em_tight_phi;   //!
   TBranch        *b_MET_RefEle_em_tight_et;   //!
   TBranch        *b_MET_RefEle_em_tight_sumet;   //!
   TBranch        *b_MET_RefEle_em_medium_etx;   //!
   TBranch        *b_MET_RefEle_em_medium_ety;   //!
   TBranch        *b_MET_RefEle_em_medium_phi;   //!
   TBranch        *b_MET_RefEle_em_medium_et;   //!
   TBranch        *b_MET_RefEle_em_medium_sumet;   //!
   TBranch        *b_MET_RefEle_em_loose_etx;   //!
   TBranch        *b_MET_RefEle_em_loose_ety;   //!
   TBranch        *b_MET_RefEle_em_loose_phi;   //!
   TBranch        *b_MET_RefEle_em_loose_et;   //!
   TBranch        *b_MET_RefEle_em_loose_sumet;   //!
   TBranch        *b_MET_RefEle_4lc_tight_etx;   //!
   TBranch        *b_MET_RefEle_4lc_tight_ety;   //!
   TBranch        *b_MET_RefEle_4lc_tight_phi;   //!
   TBranch        *b_MET_RefEle_4lc_tight_et;   //!
   TBranch        *b_MET_RefEle_4lc_tight_sumet;   //!
   TBranch        *b_MET_RefEle_4lc_medium_etx;   //!
   TBranch        *b_MET_RefEle_4lc_medium_ety;   //!
   TBranch        *b_MET_RefEle_4lc_medium_phi;   //!
   TBranch        *b_MET_RefEle_4lc_medium_et;   //!
   TBranch        *b_MET_RefEle_4lc_medium_sumet;   //!
   TBranch        *b_MET_RefEle_4lc_loose_etx;   //!
   TBranch        *b_MET_RefEle_4lc_loose_ety;   //!
   TBranch        *b_MET_RefEle_4lc_loose_phi;   //!
   TBranch        *b_MET_RefEle_4lc_loose_et;   //!
   TBranch        *b_MET_RefEle_4lc_loose_sumet;   //!
   TBranch        *b_MET_RefEle_em_medium_photon_etx;   //!
   TBranch        *b_MET_RefEle_em_medium_photon_ety;   //!
   TBranch        *b_MET_RefEle_em_medium_photon_phi;   //!
   TBranch        *b_MET_RefEle_em_medium_photon_et;   //!
   TBranch        *b_MET_RefEle_em_medium_photon_sumet;   //!
   TBranch        *b_MET_RefEle_em_tight_photon_etx;   //!
   TBranch        *b_MET_RefEle_em_tight_photon_ety;   //!
   TBranch        *b_MET_RefEle_em_tight_photon_phi;   //!
   TBranch        *b_MET_RefEle_em_tight_photon_et;   //!
   TBranch        *b_MET_RefEle_em_tight_photon_sumet;   //!
   TBranch        *b_MET_RefEle_4lc_tight_photon_etx;   //!
   TBranch        *b_MET_RefEle_4lc_tight_photon_ety;   //!
   TBranch        *b_MET_RefEle_4lc_tight_photon_phi;   //!
   TBranch        *b_MET_RefEle_4lc_tight_photon_et;   //!
   TBranch        *b_MET_RefEle_4lc_tight_photon_sumet;   //!
   TBranch        *b_MET_RefEle_4lc_medium_photon_etx;   //!
   TBranch        *b_MET_RefEle_4lc_medium_photon_ety;   //!
   TBranch        *b_MET_RefEle_4lc_medium_photon_phi;   //!
   TBranch        *b_MET_RefEle_4lc_medium_photon_et;   //!
   TBranch        *b_MET_RefEle_4lc_medium_photon_sumet;   //!
   TBranch        *b_MET_RefJet_em_tight_etx;   //!
   TBranch        *b_MET_RefJet_em_tight_ety;   //!
   TBranch        *b_MET_RefJet_em_tight_phi;   //!
   TBranch        *b_MET_RefJet_em_tight_et;   //!
   TBranch        *b_MET_RefJet_em_tight_sumet;   //!
   TBranch        *b_MET_RefJet_em_medium_etx;   //!
   TBranch        *b_MET_RefJet_em_medium_ety;   //!
   TBranch        *b_MET_RefJet_em_medium_phi;   //!
   TBranch        *b_MET_RefJet_em_medium_et;   //!
   TBranch        *b_MET_RefJet_em_medium_sumet;   //!
   TBranch        *b_MET_RefJet_em_loose_etx;   //!
   TBranch        *b_MET_RefJet_em_loose_ety;   //!
   TBranch        *b_MET_RefJet_em_loose_phi;   //!
   TBranch        *b_MET_RefJet_em_loose_et;   //!
   TBranch        *b_MET_RefJet_em_loose_sumet;   //!
   TBranch        *b_MET_RefJet_4lc_tight_etx;   //!
   TBranch        *b_MET_RefJet_4lc_tight_ety;   //!
   TBranch        *b_MET_RefJet_4lc_tight_phi;   //!
   TBranch        *b_MET_RefJet_4lc_tight_et;   //!
   TBranch        *b_MET_RefJet_4lc_tight_sumet;   //!
   TBranch        *b_MET_RefJet_4lc_medium_etx;   //!
   TBranch        *b_MET_RefJet_4lc_medium_ety;   //!
   TBranch        *b_MET_RefJet_4lc_medium_phi;   //!
   TBranch        *b_MET_RefJet_4lc_medium_et;   //!
   TBranch        *b_MET_RefJet_4lc_medium_sumet;   //!
   TBranch        *b_MET_RefJet_4lc_loose_etx;   //!
   TBranch        *b_MET_RefJet_4lc_loose_ety;   //!
   TBranch        *b_MET_RefJet_4lc_loose_phi;   //!
   TBranch        *b_MET_RefJet_4lc_loose_et;   //!
   TBranch        *b_MET_RefJet_4lc_loose_sumet;   //!
   TBranch        *b_MET_RefJet_em_medium_photon_etx;   //!
   TBranch        *b_MET_RefJet_em_medium_photon_ety;   //!
   TBranch        *b_MET_RefJet_em_medium_photon_phi;   //!
   TBranch        *b_MET_RefJet_em_medium_photon_et;   //!
   TBranch        *b_MET_RefJet_em_medium_photon_sumet;   //!
   TBranch        *b_MET_RefJet_em_tight_photon_etx;   //!
   TBranch        *b_MET_RefJet_em_tight_photon_ety;   //!
   TBranch        *b_MET_RefJet_em_tight_photon_phi;   //!
   TBranch        *b_MET_RefJet_em_tight_photon_et;   //!
   TBranch        *b_MET_RefJet_em_tight_photon_sumet;   //!
   TBranch        *b_MET_RefJet_4lc_tight_photon_etx;   //!
   TBranch        *b_MET_RefJet_4lc_tight_photon_ety;   //!
   TBranch        *b_MET_RefJet_4lc_tight_photon_phi;   //!
   TBranch        *b_MET_RefJet_4lc_tight_photon_et;   //!
   TBranch        *b_MET_RefJet_4lc_tight_photon_sumet;   //!
   TBranch        *b_MET_RefJet_4lc_medium_photon_etx;   //!
   TBranch        *b_MET_RefJet_4lc_medium_photon_ety;   //!
   TBranch        *b_MET_RefJet_4lc_medium_photon_phi;   //!
   TBranch        *b_MET_RefJet_4lc_medium_photon_et;   //!
   TBranch        *b_MET_RefJet_4lc_medium_photon_sumet;   //!
   TBranch        *b_MET_SoftJets_em_tight_etx;   //!
   TBranch        *b_MET_SoftJets_em_tight_ety;   //!
   TBranch        *b_MET_SoftJets_em_tight_phi;   //!
   TBranch        *b_MET_SoftJets_em_tight_et;   //!
   TBranch        *b_MET_SoftJets_em_tight_sumet;   //!
   TBranch        *b_MET_SoftJets_em_medium_etx;   //!
   TBranch        *b_MET_SoftJets_em_medium_ety;   //!
   TBranch        *b_MET_SoftJets_em_medium_phi;   //!
   TBranch        *b_MET_SoftJets_em_medium_et;   //!
   TBranch        *b_MET_SoftJets_em_medium_sumet;   //!
   TBranch        *b_MET_SoftJets_em_loose_etx;   //!
   TBranch        *b_MET_SoftJets_em_loose_ety;   //!
   TBranch        *b_MET_SoftJets_em_loose_phi;   //!
   TBranch        *b_MET_SoftJets_em_loose_et;   //!
   TBranch        *b_MET_SoftJets_em_loose_sumet;   //!
   TBranch        *b_MET_SoftJets_4lc_tight_etx;   //!
   TBranch        *b_MET_SoftJets_4lc_tight_ety;   //!
   TBranch        *b_MET_SoftJets_4lc_tight_phi;   //!
   TBranch        *b_MET_SoftJets_4lc_tight_et;   //!
   TBranch        *b_MET_SoftJets_4lc_tight_sumet;   //!
   TBranch        *b_MET_SoftJets_4lc_medium_etx;   //!
   TBranch        *b_MET_SoftJets_4lc_medium_ety;   //!
   TBranch        *b_MET_SoftJets_4lc_medium_phi;   //!
   TBranch        *b_MET_SoftJets_4lc_medium_et;   //!
   TBranch        *b_MET_SoftJets_4lc_medium_sumet;   //!
   TBranch        *b_MET_SoftJets_4lc_loose_etx;   //!
   TBranch        *b_MET_SoftJets_4lc_loose_ety;   //!
   TBranch        *b_MET_SoftJets_4lc_loose_phi;   //!
   TBranch        *b_MET_SoftJets_4lc_loose_et;   //!
   TBranch        *b_MET_SoftJets_4lc_loose_sumet;   //!
   TBranch        *b_MET_SoftJets_em_medium_photon_etx;   //!
   TBranch        *b_MET_SoftJets_em_medium_photon_ety;   //!
   TBranch        *b_MET_SoftJets_em_medium_photon_phi;   //!
   TBranch        *b_MET_SoftJets_em_medium_photon_et;   //!
   TBranch        *b_MET_SoftJets_em_medium_photon_sumet;   //!
   TBranch        *b_MET_SoftJets_em_tight_photon_etx;   //!
   TBranch        *b_MET_SoftJets_em_tight_photon_ety;   //!
   TBranch        *b_MET_SoftJets_em_tight_photon_phi;   //!
   TBranch        *b_MET_SoftJets_em_tight_photon_et;   //!
   TBranch        *b_MET_SoftJets_em_tight_photon_sumet;   //!
   TBranch        *b_MET_SoftJets_4lc_tight_photon_etx;   //!
   TBranch        *b_MET_SoftJets_4lc_tight_photon_ety;   //!
   TBranch        *b_MET_SoftJets_4lc_tight_photon_phi;   //!
   TBranch        *b_MET_SoftJets_4lc_tight_photon_et;   //!
   TBranch        *b_MET_SoftJets_4lc_tight_photon_sumet;   //!
   TBranch        *b_MET_SoftJets_4lc_medium_photon_etx;   //!
   TBranch        *b_MET_SoftJets_4lc_medium_photon_ety;   //!
   TBranch        *b_MET_SoftJets_4lc_medium_photon_phi;   //!
   TBranch        *b_MET_SoftJets_4lc_medium_photon_et;   //!
   TBranch        *b_MET_SoftJets_4lc_medium_photon_sumet;   //!
   TBranch        *b_MET_CellOut_em_tight_etx;   //!
   TBranch        *b_MET_CellOut_em_tight_ety;   //!
   TBranch        *b_MET_CellOut_em_tight_phi;   //!
   TBranch        *b_MET_CellOut_em_tight_et;   //!
   TBranch        *b_MET_CellOut_em_tight_sumet;   //!
   TBranch        *b_MET_CellOut_em_medium_etx;   //!
   TBranch        *b_MET_CellOut_em_medium_ety;   //!
   TBranch        *b_MET_CellOut_em_medium_phi;   //!
   TBranch        *b_MET_CellOut_em_medium_et;   //!
   TBranch        *b_MET_CellOut_em_medium_sumet;   //!
   TBranch        *b_MET_CellOut_em_loose_etx;   //!
   TBranch        *b_MET_CellOut_em_loose_ety;   //!
   TBranch        *b_MET_CellOut_em_loose_phi;   //!
   TBranch        *b_MET_CellOut_em_loose_et;   //!
   TBranch        *b_MET_CellOut_em_loose_sumet;   //!
   TBranch        *b_MET_CellOut_4lc_tight_etx;   //!
   TBranch        *b_MET_CellOut_4lc_tight_ety;   //!
   TBranch        *b_MET_CellOut_4lc_tight_phi;   //!
   TBranch        *b_MET_CellOut_4lc_tight_et;   //!
   TBranch        *b_MET_CellOut_4lc_tight_sumet;   //!
   TBranch        *b_MET_CellOut_4lc_medium_etx;   //!
   TBranch        *b_MET_CellOut_4lc_medium_ety;   //!
   TBranch        *b_MET_CellOut_4lc_medium_phi;   //!
   TBranch        *b_MET_CellOut_4lc_medium_et;   //!
   TBranch        *b_MET_CellOut_4lc_medium_sumet;   //!
   TBranch        *b_MET_CellOut_4lc_loose_etx;   //!
   TBranch        *b_MET_CellOut_4lc_loose_ety;   //!
   TBranch        *b_MET_CellOut_4lc_loose_phi;   //!
   TBranch        *b_MET_CellOut_4lc_loose_et;   //!
   TBranch        *b_MET_CellOut_4lc_loose_sumet;   //!
   TBranch        *b_MET_CellOut_em_medium_photon_etx;   //!
   TBranch        *b_MET_CellOut_em_medium_photon_ety;   //!
   TBranch        *b_MET_CellOut_em_medium_photon_phi;   //!
   TBranch        *b_MET_CellOut_em_medium_photon_et;   //!
   TBranch        *b_MET_CellOut_em_medium_photon_sumet;   //!
   TBranch        *b_MET_CellOut_em_tight_photon_etx;   //!
   TBranch        *b_MET_CellOut_em_tight_photon_ety;   //!
   TBranch        *b_MET_CellOut_em_tight_photon_phi;   //!
   TBranch        *b_MET_CellOut_em_tight_photon_et;   //!
   TBranch        *b_MET_CellOut_em_tight_photon_sumet;   //!
   TBranch        *b_MET_CellOut_4lc_tight_photon_etx;   //!
   TBranch        *b_MET_CellOut_4lc_tight_photon_ety;   //!
   TBranch        *b_MET_CellOut_4lc_tight_photon_phi;   //!
   TBranch        *b_MET_CellOut_4lc_tight_photon_et;   //!
   TBranch        *b_MET_CellOut_4lc_tight_photon_sumet;   //!
   TBranch        *b_MET_CellOut_4lc_medium_photon_etx;   //!
   TBranch        *b_MET_CellOut_4lc_medium_photon_ety;   //!
   TBranch        *b_MET_CellOut_4lc_medium_photon_phi;   //!
   TBranch        *b_MET_CellOut_4lc_medium_photon_et;   //!
   TBranch        *b_MET_CellOut_4lc_medium_photon_sumet;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_tight_etx;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_tight_ety;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_tight_phi;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_tight_et;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_tight_sumet;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_medium_etx;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_medium_ety;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_medium_phi;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_medium_et;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_medium_sumet;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_loose_etx;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_loose_ety;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_loose_phi;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_loose_et;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_loose_sumet;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_tight_etx;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_tight_ety;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_tight_phi;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_tight_et;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_tight_sumet;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_medium_etx;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_medium_ety;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_medium_phi;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_medium_et;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_medium_sumet;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_loose_etx;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_loose_ety;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_loose_phi;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_loose_et;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_loose_sumet;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_medium_photon_etx;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_medium_photon_ety;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_medium_photon_phi;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_medium_photon_et;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_medium_photon_sumet;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_tight_photon_etx;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_tight_photon_ety;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_tight_photon_phi;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_tight_photon_et;   //!
   TBranch        *b_MET_Muon_Isol_Muid_em_tight_photon_sumet;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_tight_photon_etx;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_tight_photon_ety;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_tight_photon_phi;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_tight_photon_et;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_tight_photon_sumet;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_medium_photon_etx;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_medium_photon_ety;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_medium_photon_phi;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_medium_photon_et;   //!
   TBranch        *b_MET_Muon_Isol_Muid_4lc_medium_photon_sumet;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_tight_etx;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_tight_ety;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_tight_phi;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_tight_et;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_tight_sumet;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_medium_etx;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_medium_ety;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_medium_phi;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_medium_et;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_medium_sumet;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_loose_etx;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_loose_ety;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_loose_phi;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_loose_et;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_loose_sumet;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_tight_etx;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_tight_ety;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_tight_phi;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_tight_et;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_tight_sumet;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_medium_etx;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_medium_ety;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_medium_phi;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_medium_et;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_medium_sumet;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_loose_etx;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_loose_ety;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_loose_phi;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_loose_et;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_loose_sumet;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_medium_photon_etx;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_medium_photon_ety;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_medium_photon_phi;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_medium_photon_et;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_medium_photon_sumet;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_tight_photon_etx;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_tight_photon_ety;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_tight_photon_phi;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_tight_photon_et;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_em_tight_photon_sumet;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_tight_photon_etx;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_tight_photon_ety;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_tight_photon_phi;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_tight_photon_et;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_tight_photon_sumet;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_medium_photon_etx;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_medium_photon_ety;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_medium_photon_phi;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_medium_photon_et;   //!
   TBranch        *b_MET_Muon_NonIsol_Muid_4lc_medium_photon_sumet;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_tight_etx;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_tight_ety;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_tight_phi;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_tight_et;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_tight_sumet;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_medium_etx;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_medium_ety;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_medium_phi;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_medium_et;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_medium_sumet;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_loose_etx;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_loose_ety;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_loose_phi;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_loose_et;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_loose_sumet;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_tight_etx;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_tight_ety;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_tight_phi;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_tight_et;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_tight_sumet;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_medium_etx;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_medium_ety;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_medium_phi;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_medium_et;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_medium_sumet;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_loose_etx;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_loose_ety;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_loose_phi;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_loose_et;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_loose_sumet;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_medium_photon_etx;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_medium_photon_ety;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_medium_photon_phi;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_medium_photon_et;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_medium_photon_sumet;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_tight_photon_etx;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_tight_photon_ety;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_tight_photon_phi;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_tight_photon_et;   //!
   TBranch        *b_MET_Muon_Total_Muid_em_tight_photon_sumet;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_tight_photon_etx;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_tight_photon_ety;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_tight_photon_phi;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_tight_photon_et;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_tight_photon_sumet;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_medium_photon_etx;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_medium_photon_ety;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_medium_photon_phi;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_medium_photon_et;   //!
   TBranch        *b_MET_Muon_Total_Muid_4lc_medium_photon_sumet;   //!
   TBranch        *b_MET_RefGamma_em_tight_etx;   //!
   TBranch        *b_MET_RefGamma_em_tight_ety;   //!
   TBranch        *b_MET_RefGamma_em_tight_phi;   //!
   TBranch        *b_MET_RefGamma_em_tight_et;   //!
   TBranch        *b_MET_RefGamma_em_tight_sumet;   //!
   TBranch        *b_MET_RefGamma_em_medium_etx;   //!
   TBranch        *b_MET_RefGamma_em_medium_ety;   //!
   TBranch        *b_MET_RefGamma_em_medium_phi;   //!
   TBranch        *b_MET_RefGamma_em_medium_et;   //!
   TBranch        *b_MET_RefGamma_em_medium_sumet;   //!
   TBranch        *b_MET_RefGamma_em_loose_etx;   //!
   TBranch        *b_MET_RefGamma_em_loose_ety;   //!
   TBranch        *b_MET_RefGamma_em_loose_phi;   //!
   TBranch        *b_MET_RefGamma_em_loose_et;   //!
   TBranch        *b_MET_RefGamma_em_loose_sumet;   //!
   TBranch        *b_MET_RefGamma_4lc_tight_etx;   //!
   TBranch        *b_MET_RefGamma_4lc_tight_ety;   //!
   TBranch        *b_MET_RefGamma_4lc_tight_phi;   //!
   TBranch        *b_MET_RefGamma_4lc_tight_et;   //!
   TBranch        *b_MET_RefGamma_4lc_tight_sumet;   //!
   TBranch        *b_MET_RefGamma_4lc_medium_etx;   //!
   TBranch        *b_MET_RefGamma_4lc_medium_ety;   //!
   TBranch        *b_MET_RefGamma_4lc_medium_phi;   //!
   TBranch        *b_MET_RefGamma_4lc_medium_et;   //!
   TBranch        *b_MET_RefGamma_4lc_medium_sumet;   //!
   TBranch        *b_MET_RefGamma_4lc_loose_etx;   //!
   TBranch        *b_MET_RefGamma_4lc_loose_ety;   //!
   TBranch        *b_MET_RefGamma_4lc_loose_phi;   //!
   TBranch        *b_MET_RefGamma_4lc_loose_et;   //!
   TBranch        *b_MET_RefGamma_4lc_loose_sumet;   //!
   TBranch        *b_MET_RefGamma_em_medium_photon_etx;   //!
   TBranch        *b_MET_RefGamma_em_medium_photon_ety;   //!
   TBranch        *b_MET_RefGamma_em_medium_photon_phi;   //!
   TBranch        *b_MET_RefGamma_em_medium_photon_et;   //!
   TBranch        *b_MET_RefGamma_em_medium_photon_sumet;   //!
   TBranch        *b_MET_RefGamma_em_tight_photon_etx;   //!
   TBranch        *b_MET_RefGamma_em_tight_photon_ety;   //!
   TBranch        *b_MET_RefGamma_em_tight_photon_phi;   //!
   TBranch        *b_MET_RefGamma_em_tight_photon_et;   //!
   TBranch        *b_MET_RefGamma_em_tight_photon_sumet;   //!
   TBranch        *b_MET_RefGamma_4lc_tight_photon_etx;   //!
   TBranch        *b_MET_RefGamma_4lc_tight_photon_ety;   //!
   TBranch        *b_MET_RefGamma_4lc_tight_photon_phi;   //!
   TBranch        *b_MET_RefGamma_4lc_tight_photon_et;   //!
   TBranch        *b_MET_RefGamma_4lc_tight_photon_sumet;   //!
   TBranch        *b_MET_RefGamma_4lc_medium_photon_etx;   //!
   TBranch        *b_MET_RefGamma_4lc_medium_photon_ety;   //!
   TBranch        *b_MET_RefGamma_4lc_medium_photon_phi;   //!
   TBranch        *b_MET_RefGamma_4lc_medium_photon_et;   //!
   TBranch        *b_MET_RefGamma_4lc_medium_photon_sumet;   //!
   TBranch        *b_MET_RefFinal_em_tight_etx;   //!
   TBranch        *b_MET_RefFinal_em_tight_ety;   //!
   TBranch        *b_MET_RefFinal_em_tight_phi;   //!
   TBranch        *b_MET_RefFinal_em_tight_et;   //!
   TBranch        *b_MET_RefFinal_em_tight_sumet;   //!
   TBranch        *b_MET_RefFinal_em_medium_etx;   //!
   TBranch        *b_MET_RefFinal_em_medium_ety;   //!
   TBranch        *b_MET_RefFinal_em_medium_phi;   //!
   TBranch        *b_MET_RefFinal_em_medium_et;   //!
   TBranch        *b_MET_RefFinal_em_medium_sumet;   //!
   TBranch        *b_MET_RefFinal_em_loose_etx;   //!
   TBranch        *b_MET_RefFinal_em_loose_ety;   //!
   TBranch        *b_MET_RefFinal_em_loose_phi;   //!
   TBranch        *b_MET_RefFinal_em_loose_et;   //!
   TBranch        *b_MET_RefFinal_em_loose_sumet;   //!
   TBranch        *b_MET_RefFinal_4lc_tight_etx;   //!
   TBranch        *b_MET_RefFinal_4lc_tight_ety;   //!
   TBranch        *b_MET_RefFinal_4lc_tight_phi;   //!
   TBranch        *b_MET_RefFinal_4lc_tight_et;   //!
   TBranch        *b_MET_RefFinal_4lc_tight_sumet;   //!
   TBranch        *b_MET_RefFinal_4lc_medium_etx;   //!
   TBranch        *b_MET_RefFinal_4lc_medium_ety;   //!
   TBranch        *b_MET_RefFinal_4lc_medium_phi;   //!
   TBranch        *b_MET_RefFinal_4lc_medium_et;   //!
   TBranch        *b_MET_RefFinal_4lc_medium_sumet;   //!
   TBranch        *b_MET_RefFinal_4lc_loose_etx;   //!
   TBranch        *b_MET_RefFinal_4lc_loose_ety;   //!
   TBranch        *b_MET_RefFinal_4lc_loose_phi;   //!
   TBranch        *b_MET_RefFinal_4lc_loose_et;   //!
   TBranch        *b_MET_RefFinal_4lc_loose_sumet;   //!
   TBranch        *b_MET_RefFinal_em_medium_photon_etx;   //!
   TBranch        *b_MET_RefFinal_em_medium_photon_ety;   //!
   TBranch        *b_MET_RefFinal_em_medium_photon_phi;   //!
   TBranch        *b_MET_RefFinal_em_medium_photon_et;   //!
   TBranch        *b_MET_RefFinal_em_medium_photon_sumet;   //!
   TBranch        *b_MET_RefFinal_em_tight_photon_etx;   //!
   TBranch        *b_MET_RefFinal_em_tight_photon_ety;   //!
   TBranch        *b_MET_RefFinal_em_tight_photon_phi;   //!
   TBranch        *b_MET_RefFinal_em_tight_photon_et;   //!
   TBranch        *b_MET_RefFinal_em_tight_photon_sumet;   //!
   TBranch        *b_MET_RefFinal_4lc_tight_photon_etx;   //!
   TBranch        *b_MET_RefFinal_4lc_tight_photon_ety;   //!
   TBranch        *b_MET_RefFinal_4lc_tight_photon_phi;   //!
   TBranch        *b_MET_RefFinal_4lc_tight_photon_et;   //!
   TBranch        *b_MET_RefFinal_4lc_tight_photon_sumet;   //!
   TBranch        *b_MET_RefFinal_4lc_medium_photon_etx;   //!
   TBranch        *b_MET_RefFinal_4lc_medium_photon_ety;   //!
   TBranch        *b_MET_RefFinal_4lc_medium_photon_phi;   //!
   TBranch        *b_MET_RefFinal_4lc_medium_photon_et;   //!
   TBranch        *b_MET_RefFinal_4lc_medium_photon_sumet;   //!
   TBranch        *b_MET_RefFinal_em_etx;   //!
   TBranch        *b_MET_RefFinal_em_ety;   //!
   TBranch        *b_MET_RefFinal_em_phi;   //!
   TBranch        *b_MET_RefFinal_em_et;   //!
   TBranch        *b_MET_RefFinal_em_sumet;   //!
   TBranch        *b_MET_RefFinal_etx;   //!
   TBranch        *b_MET_RefFinal_ety;   //!
   TBranch        *b_MET_RefFinal_phi;   //!
   TBranch        *b_MET_RefFinal_et;   //!
   TBranch        *b_MET_RefFinal_sumet;   //!
   TBranch        *b_el_MET_em_tight_n;   //!
   TBranch        *b_el_MET_em_tight_wpx;   //!
   TBranch        *b_el_MET_em_tight_wpy;   //!
   TBranch        *b_el_MET_em_tight_wet;   //!
   TBranch        *b_el_MET_em_tight_statusWord;   //!
   TBranch        *b_ph_MET_em_tight_n;   //!
   TBranch        *b_ph_MET_em_tight_wpx;   //!
   TBranch        *b_ph_MET_em_tight_wpy;   //!
   TBranch        *b_ph_MET_em_tight_wet;   //!
   TBranch        *b_ph_MET_em_tight_statusWord;   //!
   TBranch        *b_mu_staco_MET_em_tight_n;   //!
   TBranch        *b_mu_staco_MET_em_tight_wpx;   //!
   TBranch        *b_mu_staco_MET_em_tight_wpy;   //!
   TBranch        *b_mu_staco_MET_em_tight_wet;   //!
   TBranch        *b_mu_staco_MET_em_tight_statusWord;   //!
   TBranch        *b_mu_muid_MET_em_tight_n;   //!
   TBranch        *b_mu_muid_MET_em_tight_wpx;   //!
   TBranch        *b_mu_muid_MET_em_tight_wpy;   //!
   TBranch        *b_mu_muid_MET_em_tight_wet;   //!
   TBranch        *b_mu_muid_MET_em_tight_statusWord;   //!
   TBranch        *b_jet_em_tight_n;   //!
   TBranch        *b_jet_em_tight_wpx;   //!
   TBranch        *b_jet_em_tight_wpy;   //!
   TBranch        *b_jet_em_tight_wet;   //!
   TBranch        *b_jet_em_tight_statusWord;   //!
   TBranch        *b_el_MET_em_medium_n;   //!
   TBranch        *b_el_MET_em_medium_wpx;   //!
   TBranch        *b_el_MET_em_medium_wpy;   //!
   TBranch        *b_el_MET_em_medium_wet;   //!
   TBranch        *b_el_MET_em_medium_statusWord;   //!
   TBranch        *b_ph_MET_em_medium_n;   //!
   TBranch        *b_ph_MET_em_medium_wpx;   //!
   TBranch        *b_ph_MET_em_medium_wpy;   //!
   TBranch        *b_ph_MET_em_medium_wet;   //!
   TBranch        *b_ph_MET_em_medium_statusWord;   //!
   TBranch        *b_mu_staco_MET_em_medium_n;   //!
   TBranch        *b_mu_staco_MET_em_medium_wpx;   //!
   TBranch        *b_mu_staco_MET_em_medium_wpy;   //!
   TBranch        *b_mu_staco_MET_em_medium_wet;   //!
   TBranch        *b_mu_staco_MET_em_medium_statusWord;   //!
   TBranch        *b_mu_muid_MET_em_medium_n;   //!
   TBranch        *b_mu_muid_MET_em_medium_wpx;   //!
   TBranch        *b_mu_muid_MET_em_medium_wpy;   //!
   TBranch        *b_mu_muid_MET_em_medium_wet;   //!
   TBranch        *b_mu_muid_MET_em_medium_statusWord;   //!
   TBranch        *b_jet_em_medium_n;   //!
   TBranch        *b_jet_em_medium_wpx;   //!
   TBranch        *b_jet_em_medium_wpy;   //!
   TBranch        *b_jet_em_medium_wet;   //!
   TBranch        *b_jet_em_medium_statusWord;   //!
   TBranch        *b_el_MET_em_loose_n;   //!
   TBranch        *b_el_MET_em_loose_wpx;   //!
   TBranch        *b_el_MET_em_loose_wpy;   //!
   TBranch        *b_el_MET_em_loose_wet;   //!
   TBranch        *b_el_MET_em_loose_statusWord;   //!
   TBranch        *b_ph_MET_em_loose_n;   //!
   TBranch        *b_ph_MET_em_loose_wpx;   //!
   TBranch        *b_ph_MET_em_loose_wpy;   //!
   TBranch        *b_ph_MET_em_loose_wet;   //!
   TBranch        *b_ph_MET_em_loose_statusWord;   //!
   TBranch        *b_mu_staco_MET_em_loose_n;   //!
   TBranch        *b_mu_staco_MET_em_loose_wpx;   //!
   TBranch        *b_mu_staco_MET_em_loose_wpy;   //!
   TBranch        *b_mu_staco_MET_em_loose_wet;   //!
   TBranch        *b_mu_staco_MET_em_loose_statusWord;   //!
   TBranch        *b_mu_muid_MET_em_loose_n;   //!
   TBranch        *b_mu_muid_MET_em_loose_wpx;   //!
   TBranch        *b_mu_muid_MET_em_loose_wpy;   //!
   TBranch        *b_mu_muid_MET_em_loose_wet;   //!
   TBranch        *b_mu_muid_MET_em_loose_statusWord;   //!
   TBranch        *b_jet_em_loose_n;   //!
   TBranch        *b_jet_em_loose_wpx;   //!
   TBranch        *b_jet_em_loose_wpy;   //!
   TBranch        *b_jet_em_loose_wet;   //!
   TBranch        *b_jet_em_loose_statusWord;   //!
   TBranch        *b_el_MET_4lc_loose_n;   //!
   TBranch        *b_el_MET_4lc_loose_wpx;   //!
   TBranch        *b_el_MET_4lc_loose_wpy;   //!
   TBranch        *b_el_MET_4lc_loose_wet;   //!
   TBranch        *b_el_MET_4lc_loose_statusWord;   //!
   TBranch        *b_ph_MET_4lc_loose_n;   //!
   TBranch        *b_ph_MET_4lc_loose_wpx;   //!
   TBranch        *b_ph_MET_4lc_loose_wpy;   //!
   TBranch        *b_ph_MET_4lc_loose_wet;   //!
   TBranch        *b_ph_MET_4lc_loose_statusWord;   //!
   TBranch        *b_mu_staco_MET_4lc_loose_n;   //!
   TBranch        *b_mu_staco_MET_4lc_loose_wpx;   //!
   TBranch        *b_mu_staco_MET_4lc_loose_wpy;   //!
   TBranch        *b_mu_staco_MET_4lc_loose_wet;   //!
   TBranch        *b_mu_staco_MET_4lc_loose_statusWord;   //!
   TBranch        *b_mu_muid_MET_4lc_loose_n;   //!
   TBranch        *b_mu_muid_MET_4lc_loose_wpx;   //!
   TBranch        *b_mu_muid_MET_4lc_loose_wpy;   //!
   TBranch        *b_mu_muid_MET_4lc_loose_wet;   //!
   TBranch        *b_mu_muid_MET_4lc_loose_statusWord;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_loose_n;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_loose_wpx;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_loose_wpy;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_loose_wet;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_loose_statusWord;   //!
   TBranch        *b_el_MET_4lc_medium_n;   //!
   TBranch        *b_el_MET_4lc_medium_wpx;   //!
   TBranch        *b_el_MET_4lc_medium_wpy;   //!
   TBranch        *b_el_MET_4lc_medium_wet;   //!
   TBranch        *b_el_MET_4lc_medium_statusWord;   //!
   TBranch        *b_ph_MET_4lc_medium_n;   //!
   TBranch        *b_ph_MET_4lc_medium_wpx;   //!
   TBranch        *b_ph_MET_4lc_medium_wpy;   //!
   TBranch        *b_ph_MET_4lc_medium_wet;   //!
   TBranch        *b_ph_MET_4lc_medium_statusWord;   //!
   TBranch        *b_mu_staco_MET_4lc_medium_n;   //!
   TBranch        *b_mu_staco_MET_4lc_medium_wpx;   //!
   TBranch        *b_mu_staco_MET_4lc_medium_wpy;   //!
   TBranch        *b_mu_staco_MET_4lc_medium_wet;   //!
   TBranch        *b_mu_staco_MET_4lc_medium_statusWord;   //!
   TBranch        *b_mu_muid_MET_4lc_medium_n;   //!
   TBranch        *b_mu_muid_MET_4lc_medium_wpx;   //!
   TBranch        *b_mu_muid_MET_4lc_medium_wpy;   //!
   TBranch        *b_mu_muid_MET_4lc_medium_wet;   //!
   TBranch        *b_mu_muid_MET_4lc_medium_statusWord;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_medium_n;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_medium_wpx;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_medium_wpy;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_medium_wet;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_medium_statusWord;   //!
   TBranch        *b_el_MET_4lc_tight_n;   //!
   TBranch        *b_el_MET_4lc_tight_wpx;   //!
   TBranch        *b_el_MET_4lc_tight_wpy;   //!
   TBranch        *b_el_MET_4lc_tight_wet;   //!
   TBranch        *b_el_MET_4lc_tight_statusWord;   //!
   TBranch        *b_ph_MET_4lc_tight_n;   //!
   TBranch        *b_ph_MET_4lc_tight_wpx;   //!
   TBranch        *b_ph_MET_4lc_tight_wpy;   //!
   TBranch        *b_ph_MET_4lc_tight_wet;   //!
   TBranch        *b_ph_MET_4lc_tight_statusWord;   //!
   TBranch        *b_mu_staco_MET_4lc_tight_n;   //!
   TBranch        *b_mu_staco_MET_4lc_tight_wpx;   //!
   TBranch        *b_mu_staco_MET_4lc_tight_wpy;   //!
   TBranch        *b_mu_staco_MET_4lc_tight_wet;   //!
   TBranch        *b_mu_staco_MET_4lc_tight_statusWord;   //!
   TBranch        *b_mu_muid_MET_4lc_tight_n;   //!
   TBranch        *b_mu_muid_MET_4lc_tight_wpx;   //!
   TBranch        *b_mu_muid_MET_4lc_tight_wpy;   //!
   TBranch        *b_mu_muid_MET_4lc_tight_wet;   //!
   TBranch        *b_mu_muid_MET_4lc_tight_statusWord;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_tight_n;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_tight_wpx;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_tight_wpy;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_tight_wet;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_tight_statusWord;   //!
   TBranch        *b_el_MET_6lc_tight_n;   //!
   TBranch        *b_el_MET_6lc_tight_wpx;   //!
   TBranch        *b_el_MET_6lc_tight_wpy;   //!
   TBranch        *b_el_MET_6lc_tight_wet;   //!
   TBranch        *b_el_MET_6lc_tight_statusWord;   //!
   TBranch        *b_ph_MET_6lc_tight_n;   //!
   TBranch        *b_ph_MET_6lc_tight_wpx;   //!
   TBranch        *b_ph_MET_6lc_tight_wpy;   //!
   TBranch        *b_ph_MET_6lc_tight_wet;   //!
   TBranch        *b_ph_MET_6lc_tight_statusWord;   //!
   TBranch        *b_mu_staco_MET_6lc_tight_n;   //!
   TBranch        *b_mu_staco_MET_6lc_tight_wpx;   //!
   TBranch        *b_mu_staco_MET_6lc_tight_wpy;   //!
   TBranch        *b_mu_staco_MET_6lc_tight_wet;   //!
   TBranch        *b_mu_staco_MET_6lc_tight_statusWord;   //!
   TBranch        *b_mu_muid_MET_6lc_tight_n;   //!
   TBranch        *b_mu_muid_MET_6lc_tight_wpx;   //!
   TBranch        *b_mu_muid_MET_6lc_tight_wpy;   //!
   TBranch        *b_mu_muid_MET_6lc_tight_wet;   //!
   TBranch        *b_mu_muid_MET_6lc_tight_statusWord;   //!
   TBranch        *b_jet_AntiKt6LCTopoJets_6lc_tight_n;   //!
   TBranch        *b_jet_AntiKt6LCTopoJets_6lc_tight_wpx;   //!
   TBranch        *b_jet_AntiKt6LCTopoJets_6lc_tight_wpy;   //!
   TBranch        *b_jet_AntiKt6LCTopoJets_6lc_tight_wet;   //!
   TBranch        *b_jet_AntiKt6LCTopoJets_6lc_tight_statusWord;   //!
   TBranch        *b_el_MET_em_medium_photon_n;   //!
   TBranch        *b_el_MET_em_medium_photon_wpx;   //!
   TBranch        *b_el_MET_em_medium_photon_wpy;   //!
   TBranch        *b_el_MET_em_medium_photon_wet;   //!
   TBranch        *b_el_MET_em_medium_photon_statusWord;   //!
   TBranch        *b_ph_MET_em_medium_photon_n;   //!
   TBranch        *b_ph_MET_em_medium_photon_wpx;   //!
   TBranch        *b_ph_MET_em_medium_photon_wpy;   //!
   TBranch        *b_ph_MET_em_medium_photon_wet;   //!
   TBranch        *b_ph_MET_em_medium_photon_statusWord;   //!
   TBranch        *b_mu_staco_MET_em_medium_photon_n;   //!
   TBranch        *b_mu_staco_MET_em_medium_photon_wpx;   //!
   TBranch        *b_mu_staco_MET_em_medium_photon_wpy;   //!
   TBranch        *b_mu_staco_MET_em_medium_photon_wet;   //!
   TBranch        *b_mu_staco_MET_em_medium_photon_statusWord;   //!
   TBranch        *b_mu_muid_MET_em_medium_photon_n;   //!
   TBranch        *b_mu_muid_MET_em_medium_photon_wpx;   //!
   TBranch        *b_mu_muid_MET_em_medium_photon_wpy;   //!
   TBranch        *b_mu_muid_MET_em_medium_photon_wet;   //!
   TBranch        *b_mu_muid_MET_em_medium_photon_statusWord;   //!
   TBranch        *b_jet_em_medium_photon_n;   //!
   TBranch        *b_jet_em_medium_photon_wpx;   //!
   TBranch        *b_jet_em_medium_photon_wpy;   //!
   TBranch        *b_jet_em_medium_photon_wet;   //!
   TBranch        *b_jet_em_medium_photon_statusWord;   //!
   TBranch        *b_el_MET_em_tight_photon_n;   //!
   TBranch        *b_el_MET_em_tight_photon_wpx;   //!
   TBranch        *b_el_MET_em_tight_photon_wpy;   //!
   TBranch        *b_el_MET_em_tight_photon_wet;   //!
   TBranch        *b_el_MET_em_tight_photon_statusWord;   //!
   TBranch        *b_ph_MET_em_tight_photon_n;   //!
   TBranch        *b_ph_MET_em_tight_photon_wpx;   //!
   TBranch        *b_ph_MET_em_tight_photon_wpy;   //!
   TBranch        *b_ph_MET_em_tight_photon_wet;   //!
   TBranch        *b_ph_MET_em_tight_photon_statusWord;   //!
   TBranch        *b_mu_staco_MET_em_tight_photon_n;   //!
   TBranch        *b_mu_staco_MET_em_tight_photon_wpx;   //!
   TBranch        *b_mu_staco_MET_em_tight_photon_wpy;   //!
   TBranch        *b_mu_staco_MET_em_tight_photon_wet;   //!
   TBranch        *b_mu_staco_MET_em_tight_photon_statusWord;   //!
   TBranch        *b_mu_muid_MET_em_tight_photon_n;   //!
   TBranch        *b_mu_muid_MET_em_tight_photon_wpx;   //!
   TBranch        *b_mu_muid_MET_em_tight_photon_wpy;   //!
   TBranch        *b_mu_muid_MET_em_tight_photon_wet;   //!
   TBranch        *b_mu_muid_MET_em_tight_photon_statusWord;   //!
   TBranch        *b_jet_em_tight_photon_n;   //!
   TBranch        *b_jet_em_tight_photon_wpx;   //!
   TBranch        *b_jet_em_tight_photon_wpy;   //!
   TBranch        *b_jet_em_tight_photon_wet;   //!
   TBranch        *b_jet_em_tight_photon_statusWord;   //!
   TBranch        *b_el_MET_4lc_medium_photon_n;   //!
   TBranch        *b_el_MET_4lc_medium_photon_wpx;   //!
   TBranch        *b_el_MET_4lc_medium_photon_wpy;   //!
   TBranch        *b_el_MET_4lc_medium_photon_wet;   //!
   TBranch        *b_el_MET_4lc_medium_photon_statusWord;   //!
   TBranch        *b_ph_MET_4lc_medium_photon_n;   //!
   TBranch        *b_ph_MET_4lc_medium_photon_wpx;   //!
   TBranch        *b_ph_MET_4lc_medium_photon_wpy;   //!
   TBranch        *b_ph_MET_4lc_medium_photon_wet;   //!
   TBranch        *b_ph_MET_4lc_medium_photon_statusWord;   //!
   TBranch        *b_mu_staco_MET_4lc_medium_photon_n;   //!
   TBranch        *b_mu_staco_MET_4lc_medium_photon_wpx;   //!
   TBranch        *b_mu_staco_MET_4lc_medium_photon_wpy;   //!
   TBranch        *b_mu_staco_MET_4lc_medium_photon_wet;   //!
   TBranch        *b_mu_staco_MET_4lc_medium_photon_statusWord;   //!
   TBranch        *b_mu_muid_MET_4lc_medium_photon_n;   //!
   TBranch        *b_mu_muid_MET_4lc_medium_photon_wpx;   //!
   TBranch        *b_mu_muid_MET_4lc_medium_photon_wpy;   //!
   TBranch        *b_mu_muid_MET_4lc_medium_photon_wet;   //!
   TBranch        *b_mu_muid_MET_4lc_medium_photon_statusWord;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_medium_photon_n;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_medium_photon_wpx;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_medium_photon_wpy;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_medium_photon_wet;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_medium_photon_statusWord;   //!
   TBranch        *b_el_MET_4lc_tight_photon_n;   //!
   TBranch        *b_el_MET_4lc_tight_photon_wpx;   //!
   TBranch        *b_el_MET_4lc_tight_photon_wpy;   //!
   TBranch        *b_el_MET_4lc_tight_photon_wet;   //!
   TBranch        *b_el_MET_4lc_tight_photon_statusWord;   //!
   TBranch        *b_ph_MET_4lc_tight_photon_n;   //!
   TBranch        *b_ph_MET_4lc_tight_photon_wpx;   //!
   TBranch        *b_ph_MET_4lc_tight_photon_wpy;   //!
   TBranch        *b_ph_MET_4lc_tight_photon_wet;   //!
   TBranch        *b_ph_MET_4lc_tight_photon_statusWord;   //!
   TBranch        *b_mu_staco_MET_4lc_tight_photon_n;   //!
   TBranch        *b_mu_staco_MET_4lc_tight_photon_wpx;   //!
   TBranch        *b_mu_staco_MET_4lc_tight_photon_wpy;   //!
   TBranch        *b_mu_staco_MET_4lc_tight_photon_wet;   //!
   TBranch        *b_mu_staco_MET_4lc_tight_photon_statusWord;   //!
   TBranch        *b_mu_muid_MET_4lc_tight_photon_n;   //!
   TBranch        *b_mu_muid_MET_4lc_tight_photon_wpx;   //!
   TBranch        *b_mu_muid_MET_4lc_tight_photon_wpy;   //!
   TBranch        *b_mu_muid_MET_4lc_tight_photon_wet;   //!
   TBranch        *b_mu_muid_MET_4lc_tight_photon_statusWord;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_tight_photon_n;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_tight_photon_wpx;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_tight_photon_wpy;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_tight_photon_wet;   //!
   TBranch        *b_jet_AntiKt4LCTopoJets_4lc_tight_photon_statusWord;   //!
   TBranch        *b_mb_n;   //!
   TBranch        *b_mb_E;   //!
   TBranch        *b_mb_eta;   //!
   TBranch        *b_mb_phi;   //!
   TBranch        *b_mb_time;   //!
   TBranch        *b_mb_quality;   //!
   TBranch        *b_mb_type;   //!
   TBranch        *b_mb_module;   //!
   TBranch        *b_mb_channel;   //!
   TBranch        *b_mbtime_timeDiff;   //!
   TBranch        *b_mbtime_timeA;   //!
   TBranch        *b_mbtime_timeC;   //!
   TBranch        *b_mbtime_countA;   //!
   TBranch        *b_mbtime_countC;   //!
   TBranch        *b_collcand_passCaloTime;   //!
   TBranch        *b_collcand_passMBTSTime;   //!
   TBranch        *b_collcand_passTrigger;   //!
   TBranch        *b_collcand_pass;   //!
   TBranch        *b_top_isElectronTriggerPassed;   //!
   TBranch        *b_top_isMuonTriggerPassed;   //!
   TBranch        *b_top_isEleMuOverlap;   //!
   TBranch        *b_topMET_etx;   //!
   TBranch        *b_topMET_ety;   //!
   TBranch        *b_topMET_phi;   //!
   TBranch        *b_topMET_et;   //!
   TBranch        *b_topMET_sumet;   //!
   TBranch        *b_topJet_n;   //!
   TBranch        *b_topJet_use;   //!
   TBranch        *b_topJet_inTrigger;   //!
   TBranch        *b_topJet_index;   //!
   TBranch        *b_topJet_overlap_jet_n;   //!
   TBranch        *b_topJet_overlap_jet_index;   //!
   TBranch        *b_topJet_overlap_mu_n;   //!
   TBranch        *b_topJet_overlap_mu_index;   //!
   TBranch        *b_topJet_overlap_tau_n;   //!
   TBranch        *b_topJet_overlap_tau_index;   //!
   TBranch        *b_topMu_n;   //!
   TBranch        *b_topMu_use;   //!
   TBranch        *b_topMu_inTrigger;   //!
   TBranch        *b_topMu_index;   //!
   TBranch        *b_topMu_overlap_jet_n;   //!
   TBranch        *b_topMu_overlap_jet_index;   //!
   TBranch        *b_topMu_overlap_mu_n;   //!
   TBranch        *b_topMu_overlap_mu_index;   //!
   TBranch        *b_topMu_overlap_tau_n;   //!
   TBranch        *b_topMu_overlap_tau_index;   //!
   TBranch        *b_topEl_n;   //!
   TBranch        *b_topEl_use;   //!
   TBranch        *b_topEl_inTrigger;   //!
   TBranch        *b_topEl_index;   //!
   TBranch        *b_topEl_overlap_jet_n;   //!
   TBranch        *b_topEl_overlap_jet_index;   //!
   TBranch        *b_topEl_overlap_mu_n;   //!
   TBranch        *b_topEl_overlap_mu_index;   //!
   TBranch        *b_topEl_overlap_tau_n;   //!
   TBranch        *b_topEl_overlap_tau_index;   //!
   TBranch        *b_top_phMET_etx;   //!
   TBranch        *b_top_phMET_ety;   //!
   TBranch        *b_top_phMET_phi;   //!
   TBranch        *b_top_phMET_et;   //!
   TBranch        *b_top_phMET_sumet;   //!
   TBranch        *b_top_phJet_n;   //!
   TBranch        *b_top_phJet_use;   //!
   TBranch        *b_top_phJet_inTrigger;   //!
   TBranch        *b_top_phJet_index;   //!
   TBranch        *b_top_phJet_overlap_jet_n;   //!
   TBranch        *b_top_phJet_overlap_jet_index;   //!
   TBranch        *b_top_phJet_overlap_mu_n;   //!
   TBranch        *b_top_phJet_overlap_mu_index;   //!
   TBranch        *b_top_phJet_overlap_trk_n;   //!
   TBranch        *b_top_phJet_overlap_trk_index;   //!
   TBranch        *b_top_phJet_overlap_tau_n;   //!
   TBranch        *b_top_phJet_overlap_tau_index;   //!
   TBranch        *b_top_phMu_n;   //!
   TBranch        *b_top_phMu_use;   //!
   TBranch        *b_top_phMu_inTrigger;   //!
   TBranch        *b_top_phMu_index;   //!
   TBranch        *b_top_phMu_overlap_jet_n;   //!
   TBranch        *b_top_phMu_overlap_jet_index;   //!
   TBranch        *b_top_phMu_overlap_mu_n;   //!
   TBranch        *b_top_phMu_overlap_mu_index;   //!
   TBranch        *b_top_phMu_overlap_trk_n;   //!
   TBranch        *b_top_phMu_overlap_trk_index;   //!
   TBranch        *b_top_phMu_overlap_tau_n;   //!
   TBranch        *b_top_phMu_overlap_tau_index;   //!
   TBranch        *b_top_phEl_n;   //!
   TBranch        *b_top_phEl_use;   //!
   TBranch        *b_top_phEl_inTrigger;   //!
   TBranch        *b_top_phEl_index;   //!
   TBranch        *b_top_phEl_overlap_jet_n;   //!
   TBranch        *b_top_phEl_overlap_jet_index;   //!
   TBranch        *b_top_phEl_overlap_mu_n;   //!
   TBranch        *b_top_phEl_overlap_mu_index;   //!
   TBranch        *b_top_phEl_overlap_trk_n;   //!
   TBranch        *b_top_phEl_overlap_trk_index;   //!
   TBranch        *b_top_phEl_overlap_tau_n;   //!
   TBranch        *b_top_phEl_overlap_tau_index;   //!
   TBranch        *b_top_phPh_n;   //!
   TBranch        *b_top_phPh_use;   //!
   TBranch        *b_top_phPh_inTrigger;   //!
   TBranch        *b_top_phPh_index;   //!
   TBranch        *b_top_phPh_overlap_jet_n;   //!
   TBranch        *b_top_phPh_overlap_jet_index;   //!
   TBranch        *b_top_phPh_overlap_mu_n;   //!
   TBranch        *b_top_phPh_overlap_mu_index;   //!
   TBranch        *b_top_phPh_overlap_trk_n;   //!
   TBranch        *b_top_phPh_overlap_trk_index;   //!
   TBranch        *b_top_phPh_overlap_tau_n;   //!
   TBranch        *b_top_phPh_overlap_tau_index;   //!
   TBranch        *b_trig_Nav_n;   //!
   TBranch        *b_trig_Nav_chain_ChainId;   //!
   TBranch        *b_trig_Nav_chain_RoIType;   //!
   TBranch        *b_trig_Nav_chain_RoIIndex;   //!
   TBranch        *b_trig_RoI_L2_b_n;   //!
   TBranch        *b_trig_RoI_L2_b_type;   //!
   TBranch        *b_trig_RoI_L2_b_active;   //!
   TBranch        *b_trig_RoI_L2_b_lastStep;   //!
   TBranch        *b_trig_RoI_L2_b_TENumber;   //!
   TBranch        *b_trig_RoI_L2_b_roiNumber;   //!
   TBranch        *b_trig_RoI_L2_b_Jet_ROI;   //!
   TBranch        *b_trig_RoI_L2_b_Jet_ROIStatus;   //!
   TBranch        *b_trig_RoI_L2_b_Muon_ROI;   //!
   TBranch        *b_trig_RoI_L2_b_Muon_ROIStatus;   //!
   TBranch        *b_trig_RoI_L2_b_TrigL2BjetContainer;   //!
   TBranch        *b_trig_RoI_L2_b_TrigL2BjetContainerStatus;   //!
   TBranch        *b_trig_RoI_L2_b_TrigInDetTrackCollection_TrigSiTrack_Jet;   //!
   TBranch        *b_trig_RoI_L2_b_TrigInDetTrackCollection_TrigSiTrack_JetStatus;   //!
   TBranch        *b_trig_RoI_L2_b_TrigInDetTrackCollection_TrigIDSCAN_Jet;   //!
   TBranch        *b_trig_RoI_L2_b_TrigInDetTrackCollection_TrigIDSCAN_JetStatus;   //!
   TBranch        *b_trig_RoI_EF_b_n;   //!
   TBranch        *b_trig_RoI_EF_b_type;   //!
   TBranch        *b_trig_RoI_EF_b_active;   //!
   TBranch        *b_trig_RoI_EF_b_lastStep;   //!
   TBranch        *b_trig_RoI_EF_b_TENumber;   //!
   TBranch        *b_trig_RoI_EF_b_roiNumber;   //!
   TBranch        *b_trig_RoI_EF_b_Jet_ROI;   //!
   TBranch        *b_trig_RoI_EF_b_Jet_ROIStatus;   //!
   TBranch        *b_trig_RoI_EF_b_Muon_ROI;   //!
   TBranch        *b_trig_RoI_EF_b_Muon_ROIStatus;   //!
   TBranch        *b_trig_RoI_EF_b_TrigEFBjetContainer;   //!
   TBranch        *b_trig_RoI_EF_b_TrigEFBjetContainerStatus;   //!
   TBranch        *b_trig_RoI_EF_b_Rec__TrackParticleContainer;   //!
   TBranch        *b_trig_RoI_EF_b_Rec__TrackParticleContainerStatus;   //!
   TBranch        *b_trig_L1_jet_n;   //!
   TBranch        *b_trig_L1_jet_eta;   //!
   TBranch        *b_trig_L1_jet_phi;   //!
   TBranch        *b_trig_L1_jet_thrNames;   //!
   TBranch        *b_trig_L1_jet_thrValues;   //!
   TBranch        *b_trig_L1_jet_thrPattern;   //!
   TBranch        *b_trig_L1_jet_et4x4;   //!
   TBranch        *b_trig_L1_jet_et6x6;   //!
   TBranch        *b_trig_L1_jet_et8x8;   //!
   TBranch        *b_trig_L1_jet_RoIWord;   //!
   TBranch        *b_trig_L1_TAV;   //!
   TBranch        *b_trig_L2_passedPhysics;   //!
   TBranch        *b_trig_EF_passedPhysics;   //!
   TBranch        *b_trig_L1_TBP;   //!
   TBranch        *b_trig_L1_TAP;   //!
   TBranch        *b_trig_L2_passedRaw;   //!
   TBranch        *b_trig_EF_passedRaw;   //!
   TBranch        *b_trig_L2_truncated;   //!
   TBranch        *b_trig_EF_truncated;   //!
   TBranch        *b_trig_L2_resurrected;   //!
   TBranch        *b_trig_EF_resurrected;   //!
   TBranch        *b_trig_L2_passedThrough;   //!
   TBranch        *b_trig_EF_passedThrough;   //!
   TBranch        *b_trig_L2_bjet_n;   //!
   TBranch        *b_trig_L2_bjet_roiId;   //!
   TBranch        *b_trig_L2_bjet_valid;   //!
   TBranch        *b_trig_L2_bjet_prmVtx;   //!
   TBranch        *b_trig_L2_bjet_pt;   //!
   TBranch        *b_trig_L2_bjet_eta;   //!
   TBranch        *b_trig_L2_bjet_phi;   //!
   TBranch        *b_trig_L2_bjet_xComb;   //!
   TBranch        *b_trig_L2_bjet_xIP1D;   //!
   TBranch        *b_trig_L2_bjet_xIP2D;   //!
   TBranch        *b_trig_L2_bjet_xIP3D;   //!
   TBranch        *b_trig_L2_bjet_xCHI2;   //!
   TBranch        *b_trig_L2_bjet_xSV;   //!
   TBranch        *b_trig_L2_bjet_xMVtx;   //!
   TBranch        *b_trig_L2_bjet_xEVtx;   //!
   TBranch        *b_trig_L2_bjet_xNVtx;   //!
   TBranch        *b_trig_L2_bjet_BSx;   //!
   TBranch        *b_trig_L2_bjet_BSy;   //!
   TBranch        *b_trig_L2_bjet_BSz;   //!
   TBranch        *b_trig_L2_bjet_sBSx;   //!
   TBranch        *b_trig_L2_bjet_sBSy;   //!
   TBranch        *b_trig_L2_bjet_sBSz;   //!
   TBranch        *b_trig_L2_bjet_sBSxy;   //!
   TBranch        *b_trig_L2_bjet_BTiltXZ;   //!
   TBranch        *b_trig_L2_bjet_BTiltYZ;   //!
   TBranch        *b_trig_L2_bjet_BSstatus;   //!
   TBranch        *b_trig_EF_bjet_n;   //!
   TBranch        *b_trig_EF_bjet_roiId;   //!
   TBranch        *b_trig_EF_bjet_valid;   //!
   TBranch        *b_trig_EF_bjet_prmVtx;   //!
   TBranch        *b_trig_EF_bjet_pt;   //!
   TBranch        *b_trig_EF_bjet_eta;   //!
   TBranch        *b_trig_EF_bjet_phi;   //!
   TBranch        *b_trig_EF_bjet_xComb;   //!
   TBranch        *b_trig_EF_bjet_xIP1D;   //!
   TBranch        *b_trig_EF_bjet_xIP2D;   //!
   TBranch        *b_trig_EF_bjet_xIP3D;   //!
   TBranch        *b_trig_EF_bjet_xCHI2;   //!
   TBranch        *b_trig_EF_bjet_xSV;   //!
   TBranch        *b_trig_EF_bjet_xMVtx;   //!
   TBranch        *b_trig_EF_bjet_xEVtx;   //!
   TBranch        *b_trig_EF_bjet_xNVtx;   //!
   TBranch        *b_trig_EF_pv_n;   //!
   TBranch        *b_trig_EF_pv_x;   //!
   TBranch        *b_trig_EF_pv_y;   //!
   TBranch        *b_trig_EF_pv_z;   //!
   TBranch        *b_trig_EF_pv_type;   //!
   TBranch        *b_trig_EF_pv_err_x;   //!
   TBranch        *b_trig_EF_pv_err_y;   //!
   TBranch        *b_trig_EF_pv_err_z;   //!
   TBranch        *b_trig_L1_mu_n;   //!
   TBranch        *b_trig_L1_mu_pt;   //!
   TBranch        *b_trig_L1_mu_eta;   //!
   TBranch        *b_trig_L1_mu_phi;   //!
   TBranch        *b_trig_L1_mu_thrName;   //!
   TBranch        *b_trig_L1_mu_thrNumber;   //!
   TBranch        *b_trig_L1_mu_RoINumber;   //!
   TBranch        *b_trig_L1_mu_sectorAddress;   //!
   TBranch        *b_trig_L1_mu_firstCandidate;   //!
   TBranch        *b_trig_L1_mu_moreCandInRoI;   //!
   TBranch        *b_trig_L1_mu_moreCandInSector;   //!
   TBranch        *b_trig_L1_mu_source;   //!
   TBranch        *b_trig_L1_mu_hemisphere;   //!
   TBranch        *b_trig_L1_mu_charge;   //!
   TBranch        *b_trig_L1_mu_vetoed;   //!
   TBranch        *b_trig_L2_combmuonfeature_n;   //!
   TBranch        *b_trig_L2_combmuonfeature_pt;   //!
   TBranch        *b_trig_L2_combmuonfeature_eta;   //!
   TBranch        *b_trig_L2_combmuonfeature_phi;   //!
   TBranch        *b_trig_L2_combmuonfeature_sigma_pt;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu10;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu10_empty;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu10_loose;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu10_loose_empty;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu10_loose_noOvlpRm;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu13_Zmumu_IDTrkNoCut;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu4;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu4_Bmumu;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu4_Bmumux;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu4_DiMu;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu4_DiMu_DY;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu4_DiMu_DY20;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu4_DiMu_DY_noVtx_noOS;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu4_DiMu_SiTrk;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu4_DiMu_noVtx_noOS;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu4_Jpsimumu;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu4_Jpsimumu_IDTrkNoCut;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu4_Upsimumu;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu4i_DiMu_DY;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu6;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu6_DiMu;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu6_MSonly_g10_loose;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu6_MSonly_g10_loose_nonfilled;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_2mu6_NL;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu0_cal_empty;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu0_empty_NoAlg;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu0_firstempty_NoAlg;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu0_unpaired_iso_NoAlg;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu10;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu10_Jpsimumu;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu10_NL;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu10_Upsimumu_FS;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu10_Upsimumu_tight_FS;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu10_cal;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu10_cal_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu10_loose;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu10_muCombTag_NoEF;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu11_empty_NoAlg;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu13;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu13_MG;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu13_muCombTag_NoEF;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu15;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu15_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu15_tight;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu15_xe20_noMu;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu15i;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu15i_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu18;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu18_L1J10;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu18_MG;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu18_MG_L1J10;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu18_MG_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu18_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu20;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu20_IDTrkNoCut;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu20_MG;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu20_MG_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu20_empty;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu20_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu20_muCombTag_NoEF;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu20_tight;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu20i;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu20i_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu22;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu22_MG;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu22_MG_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu22_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu24_MG_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu24_MG_tight;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu24_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu24_tight;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu30_MG_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu30_MG_tight;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu30_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu30_tight;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu40_MSonly_barrel;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu40_MSonly_barrel_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu40_MSonly_empty;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu40_MSonly_tight;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu40_MSonly_tight_L1MU11;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu40_MSonly_tighter;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu40_slow;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu40_slow_empty;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu40_slow_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu40_slow_outOfTime;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu40_slow_outOfTime_medium;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_DiMu;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_DiMu_FS_noOS;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_Jpsimumu;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_L1J10_matched;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_L1J15_matched;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_L1J20_matched;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_L1J30_matched;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_L1J50_matched;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_L1J75_matched;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_L1MU11_MSonly_cosmic;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_L1MU11_cosmic;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_MSonly_cosmic;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_Trk_Jpsi;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_Trk_Upsi_FS;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_Upsimumu_FS;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_Upsimumu_SiTrk_FS;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_Upsimumu_tight_FS;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_cosmic;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_j10_a4tc_EFFS;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_j40_xe20_loose_noMu;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4_j95_L1matched;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4imu6i_DiMu_DY;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4imu6i_DiMu_DY14_noVtx_noOS;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4mu6_Bmumu;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4mu6_Bmumux;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4mu6_DiMu;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4mu6_DiMu_DY20;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4mu6_DiMu_noVtx_noOS;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4mu6_Jpsimumu;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu4mu6_Upsimumu;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu6;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu6_DiMu_noOS;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu6_Jpsimumu;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu6_Jpsimumu_SiTrk;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu6_Jpsimumu_tight;   //!
   TBranch        *b_trig_L2_combmuonfeature_L2_mu6_Trk_Jpsi_loose;   //!
   TBranch        *b_trig_L2_combmuonfeature_mf_pt;   //!
   TBranch        *b_trig_L2_combmuonfeature_mf_eta;   //!
   TBranch        *b_trig_L2_combmuonfeature_mf_phi;   //!
   TBranch        *b_trig_L2_combmuonfeature_mf_mf;   //!
   TBranch        *b_trig_L2_combmuonfeature_idtrk_algorithmId;   //!
   TBranch        *b_trig_L2_combmuonfeature_idtrk_trackStatus;   //!
   TBranch        *b_trig_L2_combmuonfeature_idtrk_chi2Ndof;   //!
   TBranch        *b_trig_L2_combmuonfeature_idtrk_nStrawHits;   //!
   TBranch        *b_trig_L2_combmuonfeature_idtrk_nHighThrHits;   //!
   TBranch        *b_trig_L2_combmuonfeature_idtrk_nPixelSpacePoints;   //!
   TBranch        *b_trig_L2_combmuonfeature_idtrk_nSCT_SpacePoints;   //!
   TBranch        *b_trig_L2_combmuonfeature_idtrk_idtrkfitpar_a0;   //!
   TBranch        *b_trig_L2_combmuonfeature_idtrk_idtrkfitpar_z0;   //!
   TBranch        *b_trig_L2_combmuonfeature_idtrk_idtrkfitpar_phi0;   //!
   TBranch        *b_trig_L2_combmuonfeature_idtrk_idtrkfitpar_eta;   //!
   TBranch        *b_trig_L2_combmuonfeature_idtrk_idtrkfitpar_pt;   //!
   TBranch        *b_trig_L2_combmuonfeature_idtrk_idtrkfitpar_hasidtrkfitpar;   //!
   TBranch        *b_trig_L2_combmuonfeature_idtrk_hasidtrk;   //!
   TBranch        *b_trig_EF_trigmuonef_n;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu10;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu10_empty;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu10_loose;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu10_loose_empty;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu10_loose_noOvlpRm;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu13_Zmumu_IDTrkNoCut;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu4;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu4_Bmumu;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu4_Bmumux;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu4_DiMu;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu4_DiMu_DY;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu4_DiMu_DY20;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu4_DiMu_DY_noVtx_noOS;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu4_DiMu_SiTrk;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu4_DiMu_noVtx_noOS;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu4_Jpsimumu;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu4_Jpsimumu_IDTrkNoCut;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu4_Upsimumu;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu4i_DiMu_DY;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu6;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu6_DiMu;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu6_MSonly_g10_loose;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu6_MSonly_g10_loose_nonfilled;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_2mu6_NL;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu0_empty_NoAlg;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu0_firstempty_NoAlg;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu0_unpaired_iso_NoAlg;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu10;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu10_Jpsimumu;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu10_NL;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu10_Upsimumu_FS;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu10_Upsimumu_tight_FS;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu10_loose;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu10_muCombTag_NoEF;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu11_empty_NoAlg;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu13;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu13_MG;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu13_muCombTag_NoEF;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu15;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu15_mu10_EFFS;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu15_mu10_EFFS_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu15_mu10_EFFS_tight;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu15_xe30_noMu;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu15i;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu15i_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu18;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu18_L1J10;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu18_MG;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu18_MG_L1J10;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu18_MG_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu18_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu20;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu20_IDTrkNoCut;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu20_IDTrkNoCut_ManyVx;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu20_MG;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu20_MG_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu20_empty;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu20_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu20_mu10_EFFS_tight;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu20_muCombTag_NoEF;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu20i;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu20i_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu22;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu22_MG;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu22_MG_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu22_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu24_MG_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu24_MG_tight;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu24_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu24_tight;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu30_MG_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu30_MG_tight;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu30_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu30_tight;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu40_MSonly_barrel;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu40_MSonly_barrel_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu40_MSonly_empty;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu40_MSonly_tight;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu40_MSonly_tight_L1MU11;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu40_MSonly_tighter;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu40_slow;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu40_slow_empty;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu40_slow_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu40_slow_outOfTime;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu40_slow_outOfTime_medium;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_DiMu;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_DiMu_FS_noOS;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_Jpsimumu;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_L1J10_matched;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_L1J15_matched;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_L1J20_matched;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_L1J30_matched;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_L1J50_matched;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_L1J75_matched;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_L1MU11_MSonly_cosmic;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_L1MU11_cosmic;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_MSonly_cosmic;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_Trk_Jpsi;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_Trk_Upsi_FS;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_Upsimumu_FS;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_Upsimumu_SiTrk_FS;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_Upsimumu_tight_FS;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_cosmic;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_j10_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_j10_a4tc_EFFS_matched;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_j135_a4tc_EFFS_L1matched;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_j180_a4tc_EFFS_L1matched;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4_j45_a4tc_EFFS_xe45_loose_noMu;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4imu6i_DiMu_DY;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4imu6i_DiMu_DY14_noVtx_noOS;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4mu6_Bmumu;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4mu6_Bmumux;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4mu6_DiMu;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4mu6_DiMu_DY20;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4mu6_DiMu_noVtx_noOS;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4mu6_Jpsimumu;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu4mu6_Upsimumu;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu6;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu6_DiMu_noOS;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu6_Jpsimumu;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu6_Jpsimumu_SiTrk;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu6_Jpsimumu_tight;   //!
   TBranch        *b_trig_EF_trigmuonef_EF_mu6_Trk_Jpsi_loose;   //!
   TBranch        *b_trig_EF_trigmuonef_track_n;   //!
   TBranch        *b_trig_EF_trigmuonef_track_MuonType;   //!
   TBranch        *b_trig_EF_trigmuonef_track_MS_pt;   //!
   TBranch        *b_trig_EF_trigmuonef_track_MS_eta;   //!
   TBranch        *b_trig_EF_trigmuonef_track_MS_phi;   //!
   TBranch        *b_trig_EF_trigmuonef_track_MS_charge;   //!
   TBranch        *b_trig_EF_trigmuonef_track_MS_d0;   //!
   TBranch        *b_trig_EF_trigmuonef_track_MS_z0;   //!
   TBranch        *b_trig_EF_trigmuonef_track_MS_chi2;   //!
   TBranch        *b_trig_EF_trigmuonef_track_MS_chi2prob;   //!
   TBranch        *b_trig_EF_trigmuonef_track_MS_posX;   //!
   TBranch        *b_trig_EF_trigmuonef_track_MS_posY;   //!
   TBranch        *b_trig_EF_trigmuonef_track_MS_posZ;   //!
   TBranch        *b_trig_EF_trigmuonef_track_MS_hasMS;   //!
   TBranch        *b_trig_EF_trigmuonef_track_SA_pt;   //!
   TBranch        *b_trig_EF_trigmuonef_track_SA_eta;   //!
   TBranch        *b_trig_EF_trigmuonef_track_SA_phi;   //!
   TBranch        *b_trig_EF_trigmuonef_track_SA_charge;   //!
   TBranch        *b_trig_EF_trigmuonef_track_SA_d0;   //!
   TBranch        *b_trig_EF_trigmuonef_track_SA_z0;   //!
   TBranch        *b_trig_EF_trigmuonef_track_SA_chi2;   //!
   TBranch        *b_trig_EF_trigmuonef_track_SA_chi2prob;   //!
   TBranch        *b_trig_EF_trigmuonef_track_SA_posX;   //!
   TBranch        *b_trig_EF_trigmuonef_track_SA_posY;   //!
   TBranch        *b_trig_EF_trigmuonef_track_SA_posZ;   //!
   TBranch        *b_trig_EF_trigmuonef_track_SA_hasSA;   //!
   TBranch        *b_trig_EF_trigmuonef_track_CB_pt;   //!
   TBranch        *b_trig_EF_trigmuonef_track_CB_eta;   //!
   TBranch        *b_trig_EF_trigmuonef_track_CB_phi;   //!
   TBranch        *b_trig_EF_trigmuonef_track_CB_charge;   //!
   TBranch        *b_trig_EF_trigmuonef_track_CB_d0;   //!
   TBranch        *b_trig_EF_trigmuonef_track_CB_z0;   //!
   TBranch        *b_trig_EF_trigmuonef_track_CB_chi2;   //!
   TBranch        *b_trig_EF_trigmuonef_track_CB_chi2prob;   //!
   TBranch        *b_trig_EF_trigmuonef_track_CB_posX;   //!
   TBranch        *b_trig_EF_trigmuonef_track_CB_posY;   //!
   TBranch        *b_trig_EF_trigmuonef_track_CB_posZ;   //!
   TBranch        *b_trig_EF_trigmuonef_track_CB_matchChi2;   //!
   TBranch        *b_trig_EF_trigmuonef_track_CB_hasCB;   //!
   TBranch        *b_trig_L1_esum_thrNames;   //!
   TBranch        *b_trig_L1_esum_ExMiss;   //!
   TBranch        *b_trig_L1_esum_EyMiss;   //!
   TBranch        *b_trig_L1_esum_energyT;   //!
   TBranch        *b_trig_L1_esum_overflowX;   //!
   TBranch        *b_trig_L1_esum_overflowY;   //!
   TBranch        *b_trig_L1_esum_overflowT;   //!
   TBranch        *b_trig_L1_esum_RoIWord0;   //!
   TBranch        *b_trig_L1_esum_RoIWord1;   //!
   TBranch        *b_trig_L1_esum_RoIWord2;   //!
   TBranch        *b_trig_L2_met_MEx;   //!
   TBranch        *b_trig_L2_met_MEy;   //!
   TBranch        *b_trig_L2_met_MEz;   //!
   TBranch        *b_trig_L2_met_sumEt;   //!
   TBranch        *b_trig_L2_met_sumE;   //!
   TBranch        *b_trig_L2_met_flag;   //!
   TBranch        *b_trig_L2_met_nameOfComponent;   //!
   TBranch        *b_trig_L2_met_MExComponent;   //!
   TBranch        *b_trig_L2_met_MEyComponent;   //!
   TBranch        *b_trig_L2_met_MEzComponent;   //!
   TBranch        *b_trig_L2_met_sumEtComponent;   //!
   TBranch        *b_trig_L2_met_sumEComponent;   //!
   TBranch        *b_trig_L2_met_componentCalib0;   //!
   TBranch        *b_trig_L2_met_componentCalib1;   //!
   TBranch        *b_trig_L2_met_sumOfSigns;   //!
   TBranch        *b_trig_L2_met_usedChannels;   //!
   TBranch        *b_trig_L2_met_status;   //!
   TBranch        *b_trig_EF_met_MEx;   //!
   TBranch        *b_trig_EF_met_MEy;   //!
   TBranch        *b_trig_EF_met_MEz;   //!
   TBranch        *b_trig_EF_met_sumEt;   //!
   TBranch        *b_trig_EF_met_sumE;   //!
   TBranch        *b_trig_EF_met_flag;   //!
   TBranch        *b_trig_EF_met_nameOfComponent;   //!
   TBranch        *b_trig_EF_met_MExComponent;   //!
   TBranch        *b_trig_EF_met_MEyComponent;   //!
   TBranch        *b_trig_EF_met_MEzComponent;   //!
   TBranch        *b_trig_EF_met_sumEtComponent;   //!
   TBranch        *b_trig_EF_met_sumEComponent;   //!
   TBranch        *b_trig_EF_met_componentCalib0;   //!
   TBranch        *b_trig_EF_met_componentCalib1;   //!
   TBranch        *b_trig_EF_met_sumOfSigns;   //!
   TBranch        *b_trig_EF_met_usedChannels;   //!
   TBranch        *b_trig_EF_met_status;   //!
   TBranch        *b_trig_L1_emtau_n;   //!
   TBranch        *b_trig_L1_emtau_eta;   //!
   TBranch        *b_trig_L1_emtau_phi;   //!
   TBranch        *b_trig_L1_emtau_thrNames;   //!
   TBranch        *b_trig_L1_emtau_thrValues;   //!
   TBranch        *b_trig_L1_emtau_core;   //!
   TBranch        *b_trig_L1_emtau_EMClus;   //!
   TBranch        *b_trig_L1_emtau_tauClus;   //!
   TBranch        *b_trig_L1_emtau_EMIsol;   //!
   TBranch        *b_trig_L1_emtau_hadIsol;   //!
   TBranch        *b_trig_L1_emtau_hadCore;   //!
   TBranch        *b_trig_L1_emtau_thrPattern;   //!
   TBranch        *b_trig_L1_emtau_L1_2EM10;   //!
   TBranch        *b_trig_L1_emtau_L1_2EM14;   //!
   TBranch        *b_trig_L1_emtau_L1_2EM3;   //!
   TBranch        *b_trig_L1_emtau_L1_2EM3_EM12;   //!
   TBranch        *b_trig_L1_emtau_L1_2EM3_EM7;   //!
   TBranch        *b_trig_L1_emtau_L1_2EM5;   //!
   TBranch        *b_trig_L1_emtau_L1_2EM5_EM10;   //!
   TBranch        *b_trig_L1_emtau_L1_2EM5_MU6;   //!
   TBranch        *b_trig_L1_emtau_L1_2EM5_NL;   //!
   TBranch        *b_trig_L1_emtau_L1_2EM7;   //!
   TBranch        *b_trig_L1_emtau_L1_2EM7_EM10;   //!
   TBranch        *b_trig_L1_emtau_L1_EM10;   //!
   TBranch        *b_trig_L1_emtau_L1_EM10_MU6;   //!
   TBranch        *b_trig_L1_emtau_L1_EM10_XE20;   //!
   TBranch        *b_trig_L1_emtau_L1_EM10_XE30;   //!
   TBranch        *b_trig_L1_emtau_L1_EM10_XS45;   //!
   TBranch        *b_trig_L1_emtau_L1_EM10_XS50;   //!
   TBranch        *b_trig_L1_emtau_L1_EM12;   //!
   TBranch        *b_trig_L1_emtau_L1_EM14;   //!
   TBranch        *b_trig_L1_emtau_L1_EM14_XE10;   //!
   TBranch        *b_trig_L1_emtau_L1_EM14_XE20;   //!
   TBranch        *b_trig_L1_emtau_L1_EM16;   //!
   TBranch        *b_trig_L1_emtau_L1_EM3;   //!
   TBranch        *b_trig_L1_emtau_L1_EM30;   //!
   TBranch        *b_trig_L1_emtau_L1_EM3_EMPTY;   //!
   TBranch        *b_trig_L1_emtau_L1_EM3_FIRSTEMPTY;   //!
   TBranch        *b_trig_L1_emtau_L1_EM3_MU0;   //!
   TBranch        *b_trig_L1_emtau_L1_EM3_MU6;   //!
   TBranch        *b_trig_L1_emtau_L1_EM3_UNPAIRED_ISO;   //!
   TBranch        *b_trig_L1_emtau_L1_EM3_UNPAIRED_NONISO;   //!
   TBranch        *b_trig_L1_emtau_L1_EM5;   //!
   TBranch        *b_trig_L1_emtau_L1_EM5_2MU6;   //!
   TBranch        *b_trig_L1_emtau_L1_EM5_EMPTY;   //!
   TBranch        *b_trig_L1_emtau_L1_EM5_MU10;   //!
   TBranch        *b_trig_L1_emtau_L1_EM5_MU6;   //!
   TBranch        *b_trig_L1_emtau_L1_EM7;   //!
   TBranch        *b_trig_L2_el_n;   //!
   TBranch        *b_trig_L2_el_E;   //!
   TBranch        *b_trig_L2_el_Et;   //!
   TBranch        *b_trig_L2_el_pt;   //!
   TBranch        *b_trig_L2_el_eta;   //!
   TBranch        *b_trig_L2_el_phi;   //!
   TBranch        *b_trig_L2_el_RoIWord;   //!
   TBranch        *b_trig_L2_el_zvertex;   //!
   TBranch        *b_trig_L2_el_charge;   //!
   TBranch        *b_trig_L2_el_L2_2e10_medium;   //!
   TBranch        *b_trig_L2_el_L2_2e10_medium_mu6;   //!
   TBranch        *b_trig_L2_el_L2_2e12T_medium;   //!
   TBranch        *b_trig_L2_el_L2_2e12_medium;   //!
   TBranch        *b_trig_L2_el_L2_2e15_medium;   //!
   TBranch        *b_trig_L2_el_L2_2e5_tight;   //!
   TBranch        *b_trig_L2_el_L2_2e5_tight_Jpsi;   //!
   TBranch        *b_trig_L2_el_L2_e10_medium;   //!
   TBranch        *b_trig_L2_el_L2_e10_medium_2mu6;   //!
   TBranch        *b_trig_L2_el_L2_e10_medium_mu10;   //!
   TBranch        *b_trig_L2_el_L2_e10_medium_mu6;   //!
   TBranch        *b_trig_L2_el_L2_e10_medium_mu6_topo_medium;   //!
   TBranch        *b_trig_L2_el_L2_e11T_medium;   //!
   TBranch        *b_trig_L2_el_L2_e11T_medium_2e6T_medium;   //!
   TBranch        *b_trig_L2_el_L2_e11_etcut;   //!
   TBranch        *b_trig_L2_el_L2_e12T_medium_mu6_topo_medium;   //!
   TBranch        *b_trig_L2_el_L2_e12_medium;   //!
   TBranch        *b_trig_L2_el_L2_e13_etcut_xs45_noMu;   //!
   TBranch        *b_trig_L2_el_L2_e15_HLTtighter;   //!
   TBranch        *b_trig_L2_el_L2_e15_medium;   //!
   TBranch        *b_trig_L2_el_L2_e15_medium_e12_medium;   //!
   TBranch        *b_trig_L2_el_L2_e15_medium_xe20_noMu;   //!
   TBranch        *b_trig_L2_el_L2_e15_medium_xe30_noMu;   //!
   TBranch        *b_trig_L2_el_L2_e15_medium_xe35_noMu;   //!
   TBranch        *b_trig_L2_el_L2_e15_tight;   //!
   TBranch        *b_trig_L2_el_L2_e20_etcut_xs45_noMu;   //!
   TBranch        *b_trig_L2_el_L2_e20_loose;   //!
   TBranch        *b_trig_L2_el_L2_e20_loose1;   //!
   TBranch        *b_trig_L2_el_L2_e20_looseTrk;   //!
   TBranch        *b_trig_L2_el_L2_e20_medium;   //!
   TBranch        *b_trig_L2_el_L2_e20_medium1;   //!
   TBranch        *b_trig_L2_el_L2_e20_medium2;   //!
   TBranch        *b_trig_L2_el_L2_e20_medium_IDTrkNoCut;   //!
   TBranch        *b_trig_L2_el_L2_e20_medium_SiTrk;   //!
   TBranch        *b_trig_L2_el_L2_e20_medium_TRT;   //!
   TBranch        *b_trig_L2_el_L2_e20_tight_e15_NoCut_Zee;   //!
   TBranch        *b_trig_L2_el_L2_e22_etcut_xs45_noMu;   //!
   TBranch        *b_trig_L2_el_L2_e22_loose;   //!
   TBranch        *b_trig_L2_el_L2_e22_loose1;   //!
   TBranch        *b_trig_L2_el_L2_e22_looseTrk;   //!
   TBranch        *b_trig_L2_el_L2_e22_medium;   //!
   TBranch        *b_trig_L2_el_L2_e22_medium1;   //!
   TBranch        *b_trig_L2_el_L2_e22_medium2;   //!
   TBranch        *b_trig_L2_el_L2_e22_medium_IDTrkNoCut;   //!
   TBranch        *b_trig_L2_el_L2_e22_medium_SiTrk;   //!
   TBranch        *b_trig_L2_el_L2_e22_medium_TRT;   //!
   TBranch        *b_trig_L2_el_L2_e33_medium;   //!
   TBranch        *b_trig_L2_el_L2_e35_medium;   //!
   TBranch        *b_trig_L2_el_L2_e40_medium;   //!
   TBranch        *b_trig_L2_el_L2_e45_medium;   //!
   TBranch        *b_trig_L2_el_L2_e45_medium1;   //!
   TBranch        *b_trig_L2_el_L2_e5_medium_mu6;   //!
   TBranch        *b_trig_L2_el_L2_e5_medium_mu6_topo_medium;   //!
   TBranch        *b_trig_L2_el_L2_e5_tight;   //!
   TBranch        *b_trig_L2_el_L2_e5_tight_e14_etcut_Jpsi;   //!
   TBranch        *b_trig_L2_el_L2_e5_tight_e4_etcut_Jpsi;   //!
   TBranch        *b_trig_L2_el_L2_e5_tight_e4_etcut_Jpsi_SiTrk;   //!
   TBranch        *b_trig_L2_el_L2_e5_tight_e4_etcut_Jpsi_TRT;   //!
   TBranch        *b_trig_L2_el_L2_e5_tight_e5_NoCut;   //!
   TBranch        *b_trig_L2_el_L2_e5_tight_e9_etcut_Jpsi;   //!
   TBranch        *b_trig_L2_el_L2_e60_loose;   //!
   TBranch        *b_trig_L2_el_L2_e6T_medium;   //!
   TBranch        *b_trig_L2_el_L2_e7_tight_e14_etcut_Jpsi;   //!
   TBranch        *b_trig_L2_el_L2_e9_tight_e5_tight_Jpsi;   //!
   TBranch        *b_trig_L2_el_L2_eb_physics;   //!
   TBranch        *b_trig_L2_el_L2_eb_physics_empty;   //!
   TBranch        *b_trig_L2_el_L2_eb_physics_firstempty;   //!
   TBranch        *b_trig_L2_el_L2_eb_physics_noL1PS;   //!
   TBranch        *b_trig_L2_el_L2_eb_physics_unpaired_iso;   //!
   TBranch        *b_trig_L2_el_L2_eb_physics_unpaired_noniso;   //!
   TBranch        *b_trig_L2_el_L2_eb_random;   //!
   TBranch        *b_trig_L2_el_L2_eb_random_empty;   //!
   TBranch        *b_trig_L2_el_L2_eb_random_firstempty;   //!
   TBranch        *b_trig_L2_el_L2_eb_random_unpaired_iso;   //!
   TBranch        *b_trig_L2_el_L2_em3_empty_larcalib;   //!
   TBranch        *b_trig_L2_el_L2_em5_empty_larcalib;   //!
   TBranch        *b_trig_L2_ph_n;   //!
   TBranch        *b_trig_L2_ph_E;   //!
   TBranch        *b_trig_L2_ph_Et;   //!
   TBranch        *b_trig_L2_ph_pt;   //!
   TBranch        *b_trig_L2_ph_eta;   //!
   TBranch        *b_trig_L2_ph_phi;   //!
   TBranch        *b_trig_L2_ph_RoIWord;   //!
   TBranch        *b_trig_L2_ph_L2_2g15_loose;   //!
   TBranch        *b_trig_L2_ph_L2_2g20_loose;   //!
   TBranch        *b_trig_L2_ph_L2_g100_etcut_g50_etcut;   //!
   TBranch        *b_trig_L2_ph_L2_g10_NoCut_cosmic;   //!
   TBranch        *b_trig_L2_ph_L2_g11_etcut;   //!
   TBranch        *b_trig_L2_ph_L2_g150_etcut;   //!
   TBranch        *b_trig_L2_ph_L2_g15_loose;   //!
   TBranch        *b_trig_L2_ph_L2_g20_etcut;   //!
   TBranch        *b_trig_L2_ph_L2_g20_etcut_xe30_noMu;   //!
   TBranch        *b_trig_L2_ph_L2_g20_loose;   //!
   TBranch        *b_trig_L2_ph_L2_g40_loose;   //!
   TBranch        *b_trig_L2_ph_L2_g40_loose_EFxe40_noMu;   //!
   TBranch        *b_trig_L2_ph_L2_g40_loose_xe30_medium_noMu;   //!
   TBranch        *b_trig_L2_ph_L2_g40_loose_xe35_medium_noMu;   //!
   TBranch        *b_trig_L2_ph_L2_g40_tight;   //!
   TBranch        *b_trig_L2_ph_L2_g40_tight_b10_medium;   //!
   TBranch        *b_trig_L2_ph_L2_g5_NoCut_cosmic;   //!
   TBranch        *b_trig_L2_ph_L2_g60_loose;   //!
   TBranch        *b_trig_L2_ph_L2_g80_loose;   //!
   TBranch        *b_trig_L2_jet_n;   //!
   TBranch        *b_trig_L2_jet_E;   //!
   TBranch        *b_trig_L2_jet_eta;   //!
   TBranch        *b_trig_L2_jet_phi;   //!
   TBranch        *b_trig_L2_jet_RoIWord;   //!
   TBranch        *b_trig_EF_el_n;   //!
   TBranch        *b_trig_EF_el_E;   //!
   TBranch        *b_trig_EF_el_Et;   //!
   TBranch        *b_trig_EF_el_pt;   //!
   TBranch        *b_trig_EF_el_m;   //!
   TBranch        *b_trig_EF_el_eta;   //!
   TBranch        *b_trig_EF_el_phi;   //!
   TBranch        *b_trig_EF_el_px;   //!
   TBranch        *b_trig_EF_el_py;   //!
   TBranch        *b_trig_EF_el_pz;   //!
   TBranch        *b_trig_EF_el_charge;   //!
   TBranch        *b_trig_EF_el_author;   //!
   TBranch        *b_trig_EF_el_isEM;   //!
   TBranch        *b_trig_EF_el_loose;   //!
   TBranch        *b_trig_EF_el_looseIso;   //!
   TBranch        *b_trig_EF_el_medium;   //!
   TBranch        *b_trig_EF_el_mediumIso;   //!
   TBranch        *b_trig_EF_el_mediumWithoutTrack;   //!
   TBranch        *b_trig_EF_el_mediumIsoWithoutTrack;   //!
   TBranch        *b_trig_EF_el_tight;   //!
   TBranch        *b_trig_EF_el_tightIso;   //!
   TBranch        *b_trig_EF_el_tightWithoutTrack;   //!
   TBranch        *b_trig_EF_el_tightIsoWithoutTrack;   //!
   TBranch        *b_trig_EF_el_loosePP;   //!
   TBranch        *b_trig_EF_el_loosePPIso;   //!
   TBranch        *b_trig_EF_el_mediumPP;   //!
   TBranch        *b_trig_EF_el_mediumPPIso;   //!
   TBranch        *b_trig_EF_el_tightPP;   //!
   TBranch        *b_trig_EF_el_tightPPIso;   //!
   TBranch        *b_trig_EF_el_EF_2e10_medium;   //!
   TBranch        *b_trig_EF_el_EF_2e10_medium_mu6;   //!
   TBranch        *b_trig_EF_el_EF_2e12T_medium;   //!
   TBranch        *b_trig_EF_el_EF_2e12_medium;   //!
   TBranch        *b_trig_EF_el_EF_2e15_medium;   //!
   TBranch        *b_trig_EF_el_EF_2e5_tight;   //!
   TBranch        *b_trig_EF_el_EF_2e5_tight_Jpsi;   //!
   TBranch        *b_trig_EF_el_EF_e10_medium;   //!
   TBranch        *b_trig_EF_el_EF_e10_medium_2mu6;   //!
   TBranch        *b_trig_EF_el_EF_e10_medium_mu10;   //!
   TBranch        *b_trig_EF_el_EF_e10_medium_mu6;   //!
   TBranch        *b_trig_EF_el_EF_e10_medium_mu6_topo_medium;   //!
   TBranch        *b_trig_EF_el_EF_e11T_medium;   //!
   TBranch        *b_trig_EF_el_EF_e11T_medium_2e6T_medium;   //!
   TBranch        *b_trig_EF_el_EF_e11_etcut;   //!
   TBranch        *b_trig_EF_el_EF_e12T_medium_mu6_topo_medium;   //!
   TBranch        *b_trig_EF_el_EF_e12_medium;   //!
   TBranch        *b_trig_EF_el_EF_e13_etcut_xs60_noMu;   //!
   TBranch        *b_trig_EF_el_EF_e13_etcut_xs60_noMu_dphi2j10xe07;   //!
   TBranch        *b_trig_EF_el_EF_e13_etcut_xs70_noMu;   //!
   TBranch        *b_trig_EF_el_EF_e15_HLTtighter;   //!
   TBranch        *b_trig_EF_el_EF_e15_medium;   //!
   TBranch        *b_trig_EF_el_EF_e15_medium_e12_medium;   //!
   TBranch        *b_trig_EF_el_EF_e15_medium_xe30_noMu;   //!
   TBranch        *b_trig_EF_el_EF_e15_medium_xe40_noMu;   //!
   TBranch        *b_trig_EF_el_EF_e15_medium_xe50_noMu;   //!
   TBranch        *b_trig_EF_el_EF_e15_tight;   //!
   TBranch        *b_trig_EF_el_EF_e20_etcut_xs60_noMu;   //!
   TBranch        *b_trig_EF_el_EF_e20_etcut_xs60_noMu_dphi2j10xe07;   //!
   TBranch        *b_trig_EF_el_EF_e20_loose;   //!
   TBranch        *b_trig_EF_el_EF_e20_loose1;   //!
   TBranch        *b_trig_EF_el_EF_e20_looseTrk;   //!
   TBranch        *b_trig_EF_el_EF_e20_medium;   //!
   TBranch        *b_trig_EF_el_EF_e20_medium1;   //!
   TBranch        *b_trig_EF_el_EF_e20_medium2;   //!
   TBranch        *b_trig_EF_el_EF_e20_medium_IDTrkNoCut;   //!
   TBranch        *b_trig_EF_el_EF_e20_medium_SiTrk;   //!
   TBranch        *b_trig_EF_el_EF_e20_medium_TRT;   //!
   TBranch        *b_trig_EF_el_EF_e20_tight_e15_NoCut_Zee;   //!
   TBranch        *b_trig_EF_el_EF_e22_etcut_xs60_noMu;   //!
   TBranch        *b_trig_EF_el_EF_e22_etcut_xs60_noMu_dphi2j10xe07;   //!
   TBranch        *b_trig_EF_el_EF_e22_loose;   //!
   TBranch        *b_trig_EF_el_EF_e22_loose1;   //!
   TBranch        *b_trig_EF_el_EF_e22_looseTrk;   //!
   TBranch        *b_trig_EF_el_EF_e22_medium;   //!
   TBranch        *b_trig_EF_el_EF_e22_medium1;   //!
   TBranch        *b_trig_EF_el_EF_e22_medium2;   //!
   TBranch        *b_trig_EF_el_EF_e22_medium_IDTrkNoCut;   //!
   TBranch        *b_trig_EF_el_EF_e22_medium_SiTrk;   //!
   TBranch        *b_trig_EF_el_EF_e22_medium_TRT;   //!
   TBranch        *b_trig_EF_el_EF_e33_medium;   //!
   TBranch        *b_trig_EF_el_EF_e35_medium;   //!
   TBranch        *b_trig_EF_el_EF_e40_medium;   //!
   TBranch        *b_trig_EF_el_EF_e45_medium;   //!
   TBranch        *b_trig_EF_el_EF_e45_medium1;   //!
   TBranch        *b_trig_EF_el_EF_e5_medium_mu6;   //!
   TBranch        *b_trig_EF_el_EF_e5_medium_mu6_topo_medium;   //!
   TBranch        *b_trig_EF_el_EF_e5_tight;   //!
   TBranch        *b_trig_EF_el_EF_e5_tight_e14_etcut_Jpsi;   //!
   TBranch        *b_trig_EF_el_EF_e5_tight_e4_etcut_Jpsi;   //!
   TBranch        *b_trig_EF_el_EF_e5_tight_e4_etcut_Jpsi_SiTrk;   //!
   TBranch        *b_trig_EF_el_EF_e5_tight_e4_etcut_Jpsi_TRT;   //!
   TBranch        *b_trig_EF_el_EF_e5_tight_e5_NoCut;   //!
   TBranch        *b_trig_EF_el_EF_e5_tight_e9_etcut_Jpsi;   //!
   TBranch        *b_trig_EF_el_EF_e60_loose;   //!
   TBranch        *b_trig_EF_el_EF_e6T_medium;   //!
   TBranch        *b_trig_EF_el_EF_e7_tight_e14_etcut_Jpsi;   //!
   TBranch        *b_trig_EF_el_EF_e9_tight_e5_tight_Jpsi;   //!
   TBranch        *b_trig_EF_el_EF_eb_physics;   //!
   TBranch        *b_trig_EF_el_EF_eb_physics_empty;   //!
   TBranch        *b_trig_EF_el_EF_eb_physics_firstempty;   //!
   TBranch        *b_trig_EF_el_EF_eb_physics_noL1PS;   //!
   TBranch        *b_trig_EF_el_EF_eb_physics_unpaired_iso;   //!
   TBranch        *b_trig_EF_el_EF_eb_physics_unpaired_noniso;   //!
   TBranch        *b_trig_EF_el_EF_eb_random;   //!
   TBranch        *b_trig_EF_el_EF_eb_random_empty;   //!
   TBranch        *b_trig_EF_el_EF_eb_random_firstempty;   //!
   TBranch        *b_trig_EF_el_EF_eb_random_unpaired_iso;   //!
   TBranch        *b_trig_EF_el_vertweight;   //!
   TBranch        *b_trig_EF_el_hastrack;   //!
   TBranch        *b_trig_EF_ph_n;   //!
   TBranch        *b_trig_EF_ph_E;   //!
   TBranch        *b_trig_EF_ph_Et;   //!
   TBranch        *b_trig_EF_ph_pt;   //!
   TBranch        *b_trig_EF_ph_m;   //!
   TBranch        *b_trig_EF_ph_eta;   //!
   TBranch        *b_trig_EF_ph_phi;   //!
   TBranch        *b_trig_EF_ph_px;   //!
   TBranch        *b_trig_EF_ph_py;   //!
   TBranch        *b_trig_EF_ph_pz;   //!
   TBranch        *b_trig_EF_ph_EF_2g15_loose;   //!
   TBranch        *b_trig_EF_ph_EF_2g20_loose;   //!
   TBranch        *b_trig_EF_ph_EF_g100_etcut_g50_etcut;   //!
   TBranch        *b_trig_EF_ph_EF_g10_NoCut_cosmic;   //!
   TBranch        *b_trig_EF_ph_EF_g11_etcut;   //!
   TBranch        *b_trig_EF_ph_EF_g11_etcut_larcalib;   //!
   TBranch        *b_trig_EF_ph_EF_g150_etcut;   //!
   TBranch        *b_trig_EF_ph_EF_g15_loose;   //!
   TBranch        *b_trig_EF_ph_EF_g15_loose_larcalib;   //!
   TBranch        *b_trig_EF_ph_EF_g20_etcut;   //!
   TBranch        *b_trig_EF_ph_EF_g20_etcut_xe30_noMu;   //!
   TBranch        *b_trig_EF_ph_EF_g20_loose;   //!
   TBranch        *b_trig_EF_ph_EF_g20_loose_larcalib;   //!
   TBranch        *b_trig_EF_ph_EF_g40_loose;   //!
   TBranch        *b_trig_EF_ph_EF_g40_loose_EFxe40_noMu;   //!
   TBranch        *b_trig_EF_ph_EF_g40_loose_larcalib;   //!
   TBranch        *b_trig_EF_ph_EF_g40_loose_xe45_medium_noMu;   //!
   TBranch        *b_trig_EF_ph_EF_g40_loose_xe55_medium_noMu;   //!
   TBranch        *b_trig_EF_ph_EF_g40_tight;   //!
   TBranch        *b_trig_EF_ph_EF_g40_tight_b10_medium;   //!
   TBranch        *b_trig_EF_ph_EF_g5_NoCut_cosmic;   //!
   TBranch        *b_trig_EF_ph_EF_g60_loose;   //!
   TBranch        *b_trig_EF_ph_EF_g60_loose_larcalib;   //!
   TBranch        *b_trig_EF_ph_EF_g80_loose;   //!
   TBranch        *b_trig_EF_ph_EF_g80_loose_larcalib;   //!
   TBranch        *b_trig_EF_ph_author;   //!
   TBranch        *b_trig_EF_ph_isRecovered;   //!
   TBranch        *b_trig_EF_ph_isEM;   //!
   TBranch        *b_trig_EF_ph_convFlag;   //!
   TBranch        *b_trig_EF_ph_isConv;   //!
   TBranch        *b_trig_EF_ph_nConv;   //!
   TBranch        *b_trig_EF_ph_nSingleTrackConv;   //!
   TBranch        *b_trig_EF_ph_nDoubleTrackConv;   //!
   TBranch        *b_trig_EF_ph_loose;   //!
   TBranch        *b_trig_EF_ph_looseIso;   //!
   TBranch        *b_trig_EF_ph_tight;   //!
   TBranch        *b_trig_EF_ph_tightIso;   //!
   TBranch        *b_trig_EF_ph_looseAR;   //!
   TBranch        *b_trig_EF_ph_looseARIso;   //!
   TBranch        *b_trig_EF_ph_tightAR;   //!
   TBranch        *b_trig_EF_ph_tightARIso;   //!
   TBranch        *b_trig_EF_jet_n;   //!
   TBranch        *b_trig_EF_jet_emscale_E;   //!
   TBranch        *b_trig_EF_jet_emscale_pt;   //!
   TBranch        *b_trig_EF_jet_emscale_m;   //!
   TBranch        *b_trig_EF_jet_emscale_eta;   //!
   TBranch        *b_trig_EF_jet_emscale_phi;   //!
   TBranch        *b_trig_EF_jet_EF_2b10_medium_4j30_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_2b10_medium_j75_j30_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_3j100_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_3j30_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_3j40_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_3j45_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_3j75_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_4j30_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_4j40_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_4j45_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_4j55_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_4j60_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_5j30_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_5j40_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_5j45_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_6j30_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_b10_medium_4j30_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_fj100_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_fj10_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_fj135_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_fj15_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_fj20_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_fj30_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_fj55_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_fj75_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j100_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j10_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j135_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j15_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j180_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j20_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j240_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j30_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j30_fj30_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j320_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j40_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j40_fj40_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j425_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j55_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j55_fj55_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j75_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_j75_fj75_a4tc_EFFS;   //!
   TBranch        *b_trig_EF_jet_EF_mu4_j10_a4tc_EFFS;   //!

   BaseTree_ttbar(TTree * /*tree*/ =0) { }
   virtual ~BaseTree_ttbar() { }
   virtual Int_t   Version() const { return 2; }
   virtual void    Begin(TTree *tree);
   virtual void    SlaveBegin(TTree *tree);
   virtual void    Init(TTree *tree);
   virtual Bool_t  Notify();
   virtual Bool_t  Process(Long64_t entry);
   virtual Int_t   GetEntry(Long64_t entry, Int_t getall = 0) { return fChain ? fChain->GetTree()->GetEntry(entry, getall) : 0; }
   virtual void    SetOption(const char *option) { fOption = option; }
   virtual void    SetObject(TObject *obj) { fObject = obj; }
   virtual void    SetInputList(TList *input) { fInput = input; }
   virtual TList  *GetOutputList() const { return fOutput; }
   virtual void    SlaveTerminate();
   virtual void    Terminate();

   ClassDef(BaseTree_ttbar,0);
};

#endif

#ifdef BaseTree_ttbar_cxx
void BaseTree_ttbar::Init(TTree *tree)
{
   // The Init() function is called when the selector needs to initialize
   // a new tree or chain. Typically here the branch addresses and branch
   // pointers of the tree will be set.
   // It is normally not necessary to make changes to the generated
   // code, but the routine can be extended by the user if needed.
   // Init() will be called many times when running on PROOF
   // (once per file to be processed).

   // Set object pointer
   el_E = 0;
   el_Et = 0;
   el_pt = 0;
   el_m = 0;
   el_eta = 0;
   el_phi = 0;
   el_px = 0;
   el_py = 0;
   el_pz = 0;
   el_charge = 0;
   el_author = 0;
   el_isEM = 0;
   el_OQ = 0;
   el_convFlag = 0;
   el_isConv = 0;
   el_nConv = 0;
   el_nSingleTrackConv = 0;
   el_nDoubleTrackConv = 0;
   el_OQRecalc = 0;
   el_loose = 0;
   el_looseIso = 0;
   el_medium = 0;
   el_mediumIso = 0;
   el_mediumWithoutTrack = 0;
   el_mediumIsoWithoutTrack = 0;
   el_tight = 0;
   el_tightIso = 0;
   el_tightWithoutTrack = 0;
   el_tightIsoWithoutTrack = 0;
   el_loosePP = 0;
   el_loosePPIso = 0;
   el_mediumPP = 0;
   el_mediumPPIso = 0;
   el_tightPP = 0;
   el_tightPPIso = 0;
   el_goodOQ = 0;
   el_Ethad = 0;
   el_Ethad1 = 0;
   el_f1 = 0;
   el_f1core = 0;
   el_Emins1 = 0;
   el_fside = 0;
   el_Emax2 = 0;
   el_ws3 = 0;
   el_wstot = 0;
   el_emaxs1 = 0;
   el_deltaEs = 0;
   el_E233 = 0;
   el_E237 = 0;
   el_E277 = 0;
   el_weta2 = 0;
   el_f3 = 0;
   el_f3core = 0;
   el_rphiallcalo = 0;
   el_Etcone45 = 0;
   el_Etcone15 = 0;
   el_Etcone20 = 0;
   el_Etcone25 = 0;
   el_Etcone30 = 0;
   el_Etcone35 = 0;
   el_Etcone40 = 0;
   el_ptcone20 = 0;
   el_ptcone30 = 0;
   el_ptcone40 = 0;
   el_nucone20 = 0;
   el_nucone30 = 0;
   el_nucone40 = 0;
   el_Etcone15_pt_corrected = 0;
   el_Etcone20_pt_corrected = 0;
   el_Etcone25_pt_corrected = 0;
   el_Etcone30_pt_corrected = 0;
   el_Etcone35_pt_corrected = 0;
   el_Etcone40_pt_corrected = 0;
   el_convanglematch = 0;
   el_convtrackmatch = 0;
   el_hasconv = 0;
   el_convvtxx = 0;
   el_convvtxy = 0;
   el_convvtxz = 0;
   el_Rconv = 0;
   el_zconv = 0;
   el_convvtxchi2 = 0;
   el_pt1conv = 0;
   el_convtrk1nBLHits = 0;
   el_convtrk1nPixHits = 0;
   el_convtrk1nSCTHits = 0;
   el_convtrk1nTRTHits = 0;
   el_pt2conv = 0;
   el_convtrk2nBLHits = 0;
   el_convtrk2nPixHits = 0;
   el_convtrk2nSCTHits = 0;
   el_convtrk2nTRTHits = 0;
   el_ptconv = 0;
   el_pzconv = 0;
   el_pos7 = 0;
   el_etacorrmag = 0;
   el_deltaeta1 = 0;
   el_deltaeta2 = 0;
   el_deltaphi2 = 0;
   el_deltaphiRescaled = 0;
   el_deltaPhiRot = 0;
   el_expectHitInBLayer = 0;
   el_trackd0_physics = 0;
   el_etaSampling1 = 0;
   el_reta = 0;
   el_rphi = 0;
   el_EtringnoisedR03sig2 = 0;
   el_EtringnoisedR03sig3 = 0;
   el_EtringnoisedR03sig4 = 0;
   el_isolationlikelihoodjets = 0;
   el_isolationlikelihoodhqelectrons = 0;
   el_electronweight = 0;
   el_electronbgweight = 0;
   el_softeweight = 0;
   el_softebgweight = 0;
   el_neuralnet = 0;
   el_Hmatrix = 0;
   el_Hmatrix5 = 0;
   el_adaboost = 0;
   el_softeneuralnet = 0;
   el_zvertex = 0;
   el_errz = 0;
   el_etap = 0;
   el_depth = 0;
   el_refittedTrack_n = 0;
   el_refittedTrack_author = 0;
   el_refittedTrack_chi2 = 0;
   el_refittedTrack_hasBrem = 0;
   el_refittedTrack_bremRadius = 0;
   el_refittedTrack_bremZ = 0;
   el_refittedTrack_bremRadiusErr = 0;
   el_refittedTrack_bremZErr = 0;
   el_refittedTrack_bremFitStatus = 0;
   el_refittedTrack_qoverp = 0;
   el_refittedTrack_d0 = 0;
   el_refittedTrack_z0 = 0;
   el_refittedTrack_theta = 0;
   el_refittedTrack_phi = 0;
   el_refittedTrack_LMqoverp = 0;
   el_Es0 = 0;
   el_etas0 = 0;
   el_phis0 = 0;
   el_Es1 = 0;
   el_etas1 = 0;
   el_phis1 = 0;
   el_Es2 = 0;
   el_etas2 = 0;
   el_phis2 = 0;
   el_Es3 = 0;
   el_etas3 = 0;
   el_phis3 = 0;
   el_E_PreSamplerB = 0;
   el_E_EMB1 = 0;
   el_E_EMB2 = 0;
   el_E_EMB3 = 0;
   el_E_PreSamplerE = 0;
   el_E_EME1 = 0;
   el_E_EME2 = 0;
   el_E_EME3 = 0;
   el_E_HEC0 = 0;
   el_E_HEC1 = 0;
   el_E_HEC2 = 0;
   el_E_HEC3 = 0;
   el_E_TileBar0 = 0;
   el_E_TileBar1 = 0;
   el_E_TileBar2 = 0;
   el_E_TileGap1 = 0;
   el_E_TileGap2 = 0;
   el_E_TileGap3 = 0;
   el_E_TileExt0 = 0;
   el_E_TileExt1 = 0;
   el_E_TileExt2 = 0;
   el_E_FCAL0 = 0;
   el_E_FCAL1 = 0;
   el_E_FCAL2 = 0;
   el_cl_E = 0;
   el_cl_pt = 0;
   el_cl_eta = 0;
   el_cl_phi = 0;
   el_firstEdens = 0;
   el_cellmaxfrac = 0;
   el_longitudinal = 0;
   el_secondlambda = 0;
   el_lateral = 0;
   el_secondR = 0;
   el_centerlambda = 0;
   el_rawcl_Es0 = 0;
   el_rawcl_etas0 = 0;
   el_rawcl_phis0 = 0;
   el_rawcl_Es1 = 0;
   el_rawcl_etas1 = 0;
   el_rawcl_phis1 = 0;
   el_rawcl_Es2 = 0;
   el_rawcl_etas2 = 0;
   el_rawcl_phis2 = 0;
   el_rawcl_Es3 = 0;
   el_rawcl_etas3 = 0;
   el_rawcl_phis3 = 0;
   el_rawcl_E = 0;
   el_rawcl_pt = 0;
   el_rawcl_eta = 0;
   el_rawcl_phi = 0;
   el_trackd0 = 0;
   el_trackz0 = 0;
   el_trackphi = 0;
   el_tracktheta = 0;
   el_trackqoverp = 0;
   el_trackpt = 0;
   el_tracketa = 0;
   el_trackfitchi2 = 0;
   el_trackfitndof = 0;
   el_nBLHits = 0;
   el_nPixHits = 0;
   el_nSCTHits = 0;
   el_nTRTHits = 0;
   el_nTRTHighTHits = 0;
   el_nPixHoles = 0;
   el_nSCTHoles = 0;
   el_nTRTHoles = 0;
   el_nBLSharedHits = 0;
   el_nPixSharedHits = 0;
   el_nSCTSharedHits = 0;
   el_nBLayerOutliers = 0;
   el_nPixelOutliers = 0;
   el_nSCTOutliers = 0;
   el_nTRTOutliers = 0;
   el_nTRTHighTOutliers = 0;
   el_expectBLayerHit = 0;
   el_nSiHits = 0;
   el_TRTHighTHitsRatio = 0;
   el_TRTHighTOutliersRatio = 0;
   el_pixeldEdx = 0;
   el_nGoodHitsPixeldEdx = 0;
   el_massPixeldEdx = 0;
   el_likelihoodsPixeldEdx = 0;
   el_eProbabilityComb = 0;
   el_eProbabilityHT = 0;
   el_eProbabilityToT = 0;
   el_eProbabilityBrem = 0;
   el_vertweight = 0;
   el_vertx = 0;
   el_verty = 0;
   el_vertz = 0;
   el_trackd0beam = 0;
   el_trackz0beam = 0;
   el_tracksigd0beam = 0;
   el_tracksigz0beam = 0;
   el_trackd0pv = 0;
   el_trackz0pv = 0;
   el_tracksigd0pv = 0;
   el_tracksigz0pv = 0;
   el_trackIPEstimate_d0_biasedpvunbiased = 0;
   el_trackIPEstimate_z0_biasedpvunbiased = 0;
   el_trackIPEstimate_d0_unbiasedpvunbiased = 0;
   el_trackIPEstimate_z0_unbiasedpvunbiased = 0;
   el_trackIPEstimate_sigd0_biasedpvunbiased = 0;
   el_trackIPEstimate_sigz0_biasedpvunbiased = 0;
   el_trackIPEstimate_sigd0_unbiasedpvunbiased = 0;
   el_trackIPEstimate_sigz0_unbiasedpvunbiased = 0;
   el_hastrack = 0;
   el_deltaEmax2 = 0;
   el_calibHitsShowerDepth = 0;
   el_isIso = 0;
   el_mvaptcone20 = 0;
   el_mvaptcone30 = 0;
   el_mvaptcone40 = 0;
   el_jet_dr = 0;
   el_jet_E = 0;
   el_jet_pt = 0;
   el_jet_m = 0;
   el_jet_eta = 0;
   el_jet_phi = 0;
   el_jet_matched = 0;
   el_Etcone40_ED_corrected = 0;
   el_Etcone40_corrected = 0;
   el_Etcone35_ED_corrected = 0;
   el_Etcone35_corrected = 0;
   el_Etcone30_ED_corrected = 0;
   el_Etcone30_corrected = 0;
   el_Etcone25_ED_corrected = 0;
   el_Etcone25_corrected = 0;
   el_Etcone20_ED_corrected = 0;
   el_Etcone20_corrected = 0;
   el_Etcone15_ED_corrected = 0;
   el_Etcone15_corrected = 0;
   el_EF_dr = 0;
   el_EF_index = 0;
   el_L2_dr = 0;
   el_L2_index = 0;
   el_L1_dr = 0;
   el_L1_index = 0;
   v0_ksMass = 0;
   v0_lambda1Mass = 0;
   v0_lambda2Mass = 0;
   v0_vertexProb = 0;
   v0_vertexChi2 = 0;
   v0_ksPt = 0;
   v0_ksPx = 0;
   v0_ksPy = 0;
   v0_ksEta = 0;
   v0_ksPhi = 0;
   v0_ksMomentum = 0;
   v0_flightX = 0;
   v0_flightY = 0;
   v0_cosThetaPointing = 0;
   v0_totalFlightDistance = 0;
   v0_properDecayTime = 0;
   v0_properFlightDist = 0;
   v0_flightX_BS = 0;
   v0_flightY_BS = 0;
   v0_cosThetaPointing_BS = 0;
   v0_totalFlightDistance_BS = 0;
   v0_properDecayTime_BS = 0;
   v0_properFlightDist_BS = 0;
   v0_radius = 0;
   v0_thetaPiPlus = 0;
   v0_thetaPiMinus = 0;
   v0_trk_L = 0;
   v0_trk_T = 0;
   v0_thetaStarPiPlus = 0;
   v0_thetaStarPiMinus = 0;
   v0_trkPt_SV = 0;
   v0_trkEta_SV = 0;
   v0_trkPhi_SV = 0;
   v0_x = 0;
   v0_y = 0;
   v0_z = 0;
   v0_err_x = 0;
   v0_err_y = 0;
   v0_err_z = 0;
   v0_cov_xy = 0;
   v0_cov_xz = 0;
   v0_cov_yz = 0;
   v0_type = 0;
   v0_chi2 = 0;
   v0_ndof = 0;
   v0_px = 0;
   v0_py = 0;
   v0_pz = 0;
   v0_E = 0;
   v0_m = 0;
   v0_nTracks = 0;
   v0_sumPt = 0;
   v0_trk_n = 0;
   v0_trk_weight = 0;
   v0_trk_index = 0;
   ph_E = 0;
   ph_Et = 0;
   ph_pt = 0;
   ph_m = 0;
   ph_eta = 0;
   ph_phi = 0;
   ph_px = 0;
   ph_py = 0;
   ph_pz = 0;
   ph_author = 0;
   ph_isRecovered = 0;
   ph_isEM = 0;
   ph_OQ = 0;
   ph_OQRecalc = 0;
   ph_convFlag = 0;
   ph_isConv = 0;
   ph_nConv = 0;
   ph_nSingleTrackConv = 0;
   ph_nDoubleTrackConv = 0;
   ph_loose = 0;
   ph_looseIso = 0;
   ph_tight = 0;
   ph_tightIso = 0;
   ph_looseAR = 0;
   ph_looseARIso = 0;
   ph_tightAR = 0;
   ph_tightARIso = 0;
   ph_goodOQ = 0;
   ph_Ethad = 0;
   ph_Ethad1 = 0;
   ph_E033 = 0;
   ph_f1 = 0;
   ph_f1core = 0;
   ph_Emins1 = 0;
   ph_fside = 0;
   ph_Emax2 = 0;
   ph_ws3 = 0;
   ph_wstot = 0;
   ph_E132 = 0;
   ph_E1152 = 0;
   ph_emaxs1 = 0;
   ph_deltaEs = 0;
   ph_E233 = 0;
   ph_E237 = 0;
   ph_E277 = 0;
   ph_weta2 = 0;
   ph_f3 = 0;
   ph_f3core = 0;
   ph_rphiallcalo = 0;
   ph_Etcone45 = 0;
   ph_Etcone15 = 0;
   ph_Etcone20 = 0;
   ph_Etcone25 = 0;
   ph_Etcone30 = 0;
   ph_Etcone35 = 0;
   ph_Etcone40 = 0;
   ph_ptcone20 = 0;
   ph_ptcone30 = 0;
   ph_ptcone40 = 0;
   ph_nucone20 = 0;
   ph_nucone30 = 0;
   ph_nucone40 = 0;
   ph_Etcone15_pt_corrected = 0;
   ph_Etcone20_pt_corrected = 0;
   ph_Etcone25_pt_corrected = 0;
   ph_Etcone30_pt_corrected = 0;
   ph_Etcone35_pt_corrected = 0;
   ph_Etcone40_pt_corrected = 0;
   ph_convanglematch = 0;
   ph_convtrackmatch = 0;
   ph_hasconv = 0;
   ph_convvtxx = 0;
   ph_convvtxy = 0;
   ph_convvtxz = 0;
   ph_Rconv = 0;
   ph_zconv = 0;
   ph_convvtxchi2 = 0;
   ph_pt1conv = 0;
   ph_convtrk1nBLHits = 0;
   ph_convtrk1nPixHits = 0;
   ph_convtrk1nSCTHits = 0;
   ph_convtrk1nTRTHits = 0;
   ph_pt2conv = 0;
   ph_convtrk2nBLHits = 0;
   ph_convtrk2nPixHits = 0;
   ph_convtrk2nSCTHits = 0;
   ph_convtrk2nTRTHits = 0;
   ph_ptconv = 0;
   ph_pzconv = 0;
   ph_reta = 0;
   ph_rphi = 0;
   ph_EtringnoisedR03sig2 = 0;
   ph_EtringnoisedR03sig3 = 0;
   ph_EtringnoisedR03sig4 = 0;
   ph_isolationlikelihoodjets = 0;
   ph_isolationlikelihoodhqelectrons = 0;
   ph_loglikelihood = 0;
   ph_photonweight = 0;
   ph_photonbgweight = 0;
   ph_neuralnet = 0;
   ph_Hmatrix = 0;
   ph_Hmatrix5 = 0;
   ph_adaboost = 0;
   ph_zvertex = 0;
   ph_errz = 0;
   ph_etap = 0;
   ph_depth = 0;
   ph_cl_E = 0;
   ph_cl_pt = 0;
   ph_cl_eta = 0;
   ph_cl_phi = 0;
   ph_Es0 = 0;
   ph_etas0 = 0;
   ph_phis0 = 0;
   ph_Es1 = 0;
   ph_etas1 = 0;
   ph_phis1 = 0;
   ph_Es2 = 0;
   ph_etas2 = 0;
   ph_phis2 = 0;
   ph_Es3 = 0;
   ph_etas3 = 0;
   ph_phis3 = 0;
   ph_rawcl_Es0 = 0;
   ph_rawcl_etas0 = 0;
   ph_rawcl_phis0 = 0;
   ph_rawcl_Es1 = 0;
   ph_rawcl_etas1 = 0;
   ph_rawcl_phis1 = 0;
   ph_rawcl_Es2 = 0;
   ph_rawcl_etas2 = 0;
   ph_rawcl_phis2 = 0;
   ph_rawcl_Es3 = 0;
   ph_rawcl_etas3 = 0;
   ph_rawcl_phis3 = 0;
   ph_rawcl_E = 0;
   ph_rawcl_pt = 0;
   ph_rawcl_eta = 0;
   ph_rawcl_phi = 0;
   ph_deltaEmax2 = 0;
   ph_calibHitsShowerDepth = 0;
   ph_isIso = 0;
   ph_mvaptcone20 = 0;
   ph_mvaptcone30 = 0;
   ph_mvaptcone40 = 0;
   ph_topoEtcone20 = 0;
   ph_topoEtcone40 = 0;
   ph_topoEtcone60 = 0;
   ph_jet_dr = 0;
   ph_jet_E = 0;
   ph_jet_pt = 0;
   ph_jet_m = 0;
   ph_jet_eta = 0;
   ph_jet_phi = 0;
   ph_jet_matched = 0;
   ph_convIP = 0;
   ph_convIPRev = 0;
   ph_ptIsolationCone = 0;
   ph_ptIsolationConePhAngle = 0;
   ph_Etcone40_ED_corrected = 0;
   ph_Etcone40_corrected = 0;
   ph_Etcone35_ED_corrected = 0;
   ph_Etcone35_corrected = 0;
   ph_Etcone30_ED_corrected = 0;
   ph_Etcone30_corrected = 0;
   ph_Etcone25_ED_corrected = 0;
   ph_Etcone25_corrected = 0;
   ph_Etcone20_ED_corrected = 0;
   ph_Etcone20_corrected = 0;
   ph_Etcone15_ED_corrected = 0;
   ph_Etcone15_corrected = 0;
   ph_topodr = 0;
   ph_topopt = 0;
   ph_topoeta = 0;
   ph_topophi = 0;
   ph_topomatched = 0;
   ph_topoEMdr = 0;
   ph_topoEMpt = 0;
   ph_topoEMeta = 0;
   ph_topoEMphi = 0;
   ph_topoEMmatched = 0;
   ph_EF_dr = 0;
   ph_EF_index = 0;
   ph_L2_dr = 0;
   ph_L2_index = 0;
   ph_L1_dr = 0;
   ph_L1_index = 0;
   mu_E = 0;
   mu_pt = 0;
   mu_m = 0;
   mu_eta = 0;
   mu_phi = 0;
   mu_px = 0;
   mu_py = 0;
   mu_pz = 0;
   mu_charge = 0;
   mu_allauthor = 0;
   mu_author = 0;
   mu_beta = 0;
   mu_isMuonLikelihood = 0;
   mu_matchchi2 = 0;
   mu_matchndof = 0;
   mu_etcone20 = 0;
   mu_etcone30 = 0;
   mu_etcone40 = 0;
   mu_nucone20 = 0;
   mu_nucone30 = 0;
   mu_nucone40 = 0;
   mu_ptcone20 = 0;
   mu_ptcone30 = 0;
   mu_ptcone40 = 0;
   mu_energyLossPar = 0;
   mu_energyLossErr = 0;
   mu_etCore = 0;
   mu_energyLossType = 0;
   mu_caloMuonIdTag = 0;
   mu_caloLRLikelihood = 0;
   mu_bestMatch = 0;
   mu_isStandAloneMuon = 0;
   mu_isCombinedMuon = 0;
   mu_isLowPtReconstructedMuon = 0;
   mu_isSegmentTaggedMuon = 0;
   mu_isCaloMuonId = 0;
   mu_alsoFoundByLowPt = 0;
   mu_alsoFoundByCaloMuonId = 0;
   mu_loose = 0;
   mu_medium = 0;
   mu_tight = 0;
   mu_d0_exPV = 0;
   mu_z0_exPV = 0;
   mu_phi_exPV = 0;
   mu_theta_exPV = 0;
   mu_qoverp_exPV = 0;
   mu_cb_d0_exPV = 0;
   mu_cb_z0_exPV = 0;
   mu_cb_phi_exPV = 0;
   mu_cb_theta_exPV = 0;
   mu_cb_qoverp_exPV = 0;
   mu_id_d0_exPV = 0;
   mu_id_z0_exPV = 0;
   mu_id_phi_exPV = 0;
   mu_id_theta_exPV = 0;
   mu_id_qoverp_exPV = 0;
   mu_me_d0_exPV = 0;
   mu_me_z0_exPV = 0;
   mu_me_phi_exPV = 0;
   mu_me_theta_exPV = 0;
   mu_me_qoverp_exPV = 0;
   mu_ie_d0_exPV = 0;
   mu_ie_z0_exPV = 0;
   mu_ie_phi_exPV = 0;
   mu_ie_theta_exPV = 0;
   mu_ie_qoverp_exPV = 0;
   mu_SpaceTime_detID = 0;
   mu_SpaceTime_t = 0;
   mu_SpaceTime_tError = 0;
   mu_SpaceTime_weight = 0;
   mu_SpaceTime_x = 0;
   mu_SpaceTime_y = 0;
   mu_SpaceTime_z = 0;
   mu_cov_d0_exPV = 0;
   mu_cov_z0_exPV = 0;
   mu_cov_phi_exPV = 0;
   mu_cov_theta_exPV = 0;
   mu_cov_qoverp_exPV = 0;
   mu_cov_d0_z0_exPV = 0;
   mu_cov_d0_phi_exPV = 0;
   mu_cov_d0_theta_exPV = 0;
   mu_cov_d0_qoverp_exPV = 0;
   mu_cov_z0_phi_exPV = 0;
   mu_cov_z0_theta_exPV = 0;
   mu_cov_z0_qoverp_exPV = 0;
   mu_cov_phi_theta_exPV = 0;
   mu_cov_phi_qoverp_exPV = 0;
   mu_cov_theta_qoverp_exPV = 0;
   mu_id_cov_d0_exPV = 0;
   mu_id_cov_z0_exPV = 0;
   mu_id_cov_phi_exPV = 0;
   mu_id_cov_theta_exPV = 0;
   mu_id_cov_qoverp_exPV = 0;
   mu_id_cov_d0_z0_exPV = 0;
   mu_id_cov_d0_phi_exPV = 0;
   mu_id_cov_d0_theta_exPV = 0;
   mu_id_cov_d0_qoverp_exPV = 0;
   mu_id_cov_z0_phi_exPV = 0;
   mu_id_cov_z0_theta_exPV = 0;
   mu_id_cov_z0_qoverp_exPV = 0;
   mu_id_cov_phi_theta_exPV = 0;
   mu_id_cov_phi_qoverp_exPV = 0;
   mu_id_cov_theta_qoverp_exPV = 0;
   mu_me_cov_d0_exPV = 0;
   mu_me_cov_z0_exPV = 0;
   mu_me_cov_phi_exPV = 0;
   mu_me_cov_theta_exPV = 0;
   mu_me_cov_qoverp_exPV = 0;
   mu_me_cov_d0_z0_exPV = 0;
   mu_me_cov_d0_phi_exPV = 0;
   mu_me_cov_d0_theta_exPV = 0;
   mu_me_cov_d0_qoverp_exPV = 0;
   mu_me_cov_z0_phi_exPV = 0;
   mu_me_cov_z0_theta_exPV = 0;
   mu_me_cov_z0_qoverp_exPV = 0;
   mu_me_cov_phi_theta_exPV = 0;
   mu_me_cov_phi_qoverp_exPV = 0;
   mu_me_cov_theta_qoverp_exPV = 0;
   mu_ms_d0 = 0;
   mu_ms_z0 = 0;
   mu_ms_phi = 0;
   mu_ms_theta = 0;
   mu_ms_qoverp = 0;
   mu_id_d0 = 0;
   mu_id_z0 = 0;
   mu_id_phi = 0;
   mu_id_theta = 0;
   mu_id_qoverp = 0;
   mu_me_d0 = 0;
   mu_me_z0 = 0;
   mu_me_phi = 0;
   mu_me_theta = 0;
   mu_me_qoverp = 0;
   mu_ie_d0 = 0;
   mu_ie_z0 = 0;
   mu_ie_phi = 0;
   mu_ie_theta = 0;
   mu_ie_qoverp = 0;
   mu_nOutliersOnTrack = 0;
   mu_nBLHits = 0;
   mu_nPixHits = 0;
   mu_nSCTHits = 0;
   mu_nTRTHits = 0;
   mu_nTRTHighTHits = 0;
   mu_nBLSharedHits = 0;
   mu_nPixSharedHits = 0;
   mu_nPixHoles = 0;
   mu_nSCTSharedHits = 0;
   mu_nSCTHoles = 0;
   mu_nTRTOutliers = 0;
   mu_nTRTHighTOutliers = 0;
   mu_nGangedPixels = 0;
   mu_nPixelDeadSensors = 0;
   mu_nSCTDeadSensors = 0;
   mu_nTRTDeadStraws = 0;
   mu_expectBLayerHit = 0;
   mu_nMDTHits = 0;
   mu_nMDTHoles = 0;
   mu_nCSCEtaHits = 0;
   mu_nCSCEtaHoles = 0;
   mu_nCSCPhiHits = 0;
   mu_nCSCPhiHoles = 0;
   mu_nRPCEtaHits = 0;
   mu_nRPCEtaHoles = 0;
   mu_nRPCPhiHits = 0;
   mu_nRPCPhiHoles = 0;
   mu_nTGCEtaHits = 0;
   mu_nTGCEtaHoles = 0;
   mu_nTGCPhiHits = 0;
   mu_nTGCPhiHoles = 0;
   mu_nMDTBIHits = 0;
   mu_nMDTBMHits = 0;
   mu_nMDTBOHits = 0;
   mu_nMDTBEEHits = 0;
   mu_nMDTBIS78Hits = 0;
   mu_nMDTEIHits = 0;
   mu_nMDTEMHits = 0;
   mu_nMDTEOHits = 0;
   mu_nMDTEEHits = 0;
   mu_nRPCLayer1EtaHits = 0;
   mu_nRPCLayer2EtaHits = 0;
   mu_nRPCLayer3EtaHits = 0;
   mu_nRPCLayer1PhiHits = 0;
   mu_nRPCLayer2PhiHits = 0;
   mu_nRPCLayer3PhiHits = 0;
   mu_nTGCLayer1EtaHits = 0;
   mu_nTGCLayer2EtaHits = 0;
   mu_nTGCLayer3EtaHits = 0;
   mu_nTGCLayer4EtaHits = 0;
   mu_nTGCLayer1PhiHits = 0;
   mu_nTGCLayer2PhiHits = 0;
   mu_nTGCLayer3PhiHits = 0;
   mu_nTGCLayer4PhiHits = 0;
   mu_barrelSectors = 0;
   mu_endcapSectors = 0;
   mu_trackd0 = 0;
   mu_trackz0 = 0;
   mu_trackphi = 0;
   mu_tracktheta = 0;
   mu_trackqoverp = 0;
   mu_trackcov_d0 = 0;
   mu_trackcov_z0 = 0;
   mu_trackcov_phi = 0;
   mu_trackcov_theta = 0;
   mu_trackcov_qoverp = 0;
   mu_trackcov_d0_z0 = 0;
   mu_trackcov_d0_phi = 0;
   mu_trackcov_d0_theta = 0;
   mu_trackcov_d0_qoverp = 0;
   mu_trackcov_z0_phi = 0;
   mu_trackcov_z0_theta = 0;
   mu_trackcov_z0_qoverp = 0;
   mu_trackcov_phi_theta = 0;
   mu_trackcov_phi_qoverp = 0;
   mu_trackcov_theta_qoverp = 0;
   mu_trackfitchi2 = 0;
   mu_trackfitndof = 0;
   mu_hastrack = 0;
   mu_trackd0beam = 0;
   mu_trackz0beam = 0;
   mu_tracksigd0beam = 0;
   mu_tracksigz0beam = 0;
   mu_trackd0pv = 0;
   mu_trackz0pv = 0;
   mu_tracksigd0pv = 0;
   mu_tracksigz0pv = 0;
   mu_trackIPEstimate_d0_biasedpvunbiased = 0;
   mu_trackIPEstimate_z0_biasedpvunbiased = 0;
   mu_trackIPEstimate_d0_unbiasedpvunbiased = 0;
   mu_trackIPEstimate_z0_unbiasedpvunbiased = 0;
   mu_trackIPEstimate_sigd0_biasedpvunbiased = 0;
   mu_trackIPEstimate_sigz0_biasedpvunbiased = 0;
   mu_trackIPEstimate_sigd0_unbiasedpvunbiased = 0;
   mu_trackIPEstimate_sigz0_unbiasedpvunbiased = 0;
   mu_EFCB_dr = 0;
   mu_EFCB_index = 0;
   mu_EFMG_dr = 0;
   mu_EFME_dr = 0;
   mu_EFME_index = 0;
   mu_L2CB_dr = 0;
   mu_L2CB_index = 0;
   mu_L1_dr = 0;
   mu_L1_index = 0;
   tau_Et = 0;
   tau_pt = 0;
   tau_m = 0;
   tau_eta = 0;
   tau_phi = 0;
   tau_charge = 0;
   tau_BDTEleScore = 0;
   tau_BDTJetScore = 0;
   tau_likelihood = 0;
   tau_SafeLikelihood = 0;
   tau_electronVetoLoose = 0;
   tau_electronVetoMedium = 0;
   tau_electronVetoTight = 0;
   tau_muonVeto = 0;
   tau_tauCutLoose = 0;
   tau_tauCutMedium = 0;
   tau_tauCutTight = 0;
   tau_tauLlhLoose = 0;
   tau_tauLlhMedium = 0;
   tau_tauLlhTight = 0;
   tau_JetBDTSigLoose = 0;
   tau_JetBDTSigMedium = 0;
   tau_JetBDTSigTight = 0;
   tau_EleBDTLoose = 0;
   tau_EleBDTMedium = 0;
   tau_EleBDTTight = 0;
   tau_author = 0;
   tau_ROIword = 0;
   tau_nProng = 0;
   tau_numTrack = 0;
   tau_seedCalo_numTrack = 0;
   tau_etOverPtLeadTrk = 0;
   tau_ipZ0SinThetaSigLeadTrk = 0;
   tau_leadTrkPt = 0;
   tau_nLooseTrk = 0;
   tau_nLooseConvTrk = 0;
   tau_nProngLoose = 0;
   tau_ipSigLeadTrk = 0;
   tau_ipSigLeadLooseTrk = 0;
   tau_etOverPtLeadLooseTrk = 0;
   tau_leadLooseTrkPt = 0;
   tau_chrgLooseTrk = 0;
   tau_massTrkSys = 0;
   tau_trkWidth2 = 0;
   tau_trFlightPathSig = 0;
   tau_etEflow = 0;
   tau_mEflow = 0;
   tau_nPi0 = 0;
   tau_ele_E237E277 = 0;
   tau_ele_PresamplerFraction = 0;
   tau_ele_ECALFirstFraction = 0;
   tau_seedCalo_EMRadius = 0;
   tau_seedCalo_hadRadius = 0;
   tau_seedCalo_etEMAtEMScale = 0;
   tau_seedCalo_etHadAtEMScale = 0;
   tau_seedCalo_isolFrac = 0;
   tau_seedCalo_centFrac = 0;
   tau_seedCalo_stripWidth2 = 0;
   tau_seedCalo_nStrip = 0;
   tau_seedCalo_etEMCalib = 0;
   tau_seedCalo_etHadCalib = 0;
   tau_seedCalo_eta = 0;
   tau_seedCalo_phi = 0;
   tau_seedCalo_nIsolLooseTrk = 0;
   tau_seedCalo_trkAvgDist = 0;
   tau_seedCalo_trkRmsDist = 0;
   tau_numTopoClusters = 0;
   tau_numEffTopoClusters = 0;
   tau_topoInvMass = 0;
   tau_effTopoInvMass = 0;
   tau_topoMeanDeltaR = 0;
   tau_effTopoMeanDeltaR = 0;
   tau_numCells = 0;
   tau_seedTrk_EMRadius = 0;
   tau_seedTrk_isolFrac = 0;
   tau_seedTrk_etChrgHadOverSumTrkPt = 0;
   tau_seedTrk_isolFracWide = 0;
   tau_seedTrk_etHadAtEMScale = 0;
   tau_seedTrk_etEMAtEMScale = 0;
   tau_seedTrk_etEMCL = 0;
   tau_seedTrk_etChrgEM = 0;
   tau_seedTrk_etNeuEM = 0;
   tau_seedTrk_etResNeuEM = 0;
   tau_seedTrk_hadLeakEt = 0;
   tau_seedTrk_sumEMCellEtOverLeadTrkPt = 0;
   tau_seedTrk_secMaxStripEt = 0;
   tau_seedTrk_stripWidth2 = 0;
   tau_seedTrk_nStrip = 0;
   tau_seedTrk_etChrgHad = 0;
   tau_seedTrk_nOtherCoreTrk = 0;
   tau_seedTrk_nIsolTrk = 0;
   tau_seedTrk_etIsolEM = 0;
   tau_seedTrk_etIsolHad = 0;
   tau_calcVars_etHad_EMScale_Pt3Trks = 0;
   tau_calcVars_etEM_EMScale_Pt3Trks = 0;
   tau_calcVars_ipSigLeadLooseTrk = 0;
   tau_calcVars_drMax = 0;
   tau_calcVars_drMin = 0;
   tau_calcVars_TRTHTOverLT_LeadTrk = 0;
   tau_calcVars_calRadius = 0;
   tau_calcVars_EMFractionAtEMScale = 0;
   tau_calcVars_lead2ClusterEOverAllClusterE = 0;
   tau_calcVars_lead3ClusterEOverAllClusterE = 0;
   tau_calcVars_caloIso = 0;
   tau_calcVars_trackIso = 0;
   tau_calcVars_caloIsoCorrected = 0;
   tau_calcVars_BDTSigTrans = 0;
   tau_calcVars_BDTLooseBkg = 0;
   tau_calcVars_BDTMediumBkg = 0;
   tau_calcVars_BDTTightBkg = 0;
   tau_cluster_E = 0;
   tau_cluster_eta = 0;
   tau_cluster_phi = 0;
   tau_cluster_n = 0;
   tau_cluster_emfraction = 0;
   tau_Pi0Cluster_pt = 0;
   tau_Pi0Cluster_eta = 0;
   tau_Pi0Cluster_phi = 0;
   tau_secvtx_x = 0;
   tau_secvtx_y = 0;
   tau_secvtx_z = 0;
   tau_secvtx_chiSquared = 0;
   tau_secvtx_numberDoF = 0;
   tau_jet_Et = 0;
   tau_jet_pt = 0;
   tau_jet_m = 0;
   tau_jet_eta = 0;
   tau_jet_phi = 0;
   tau_jet_SamplingMax = 0;
   tau_jet_fracSamplingMax = 0;
   tau_jet_emfrac = 0;
   tau_jet_GCWJES = 0;
   tau_jet_EMJES = 0;
   tau_jet_emscale_E = 0;
   tau_jet_emscale_pt = 0;
   tau_jet_emscale_m = 0;
   tau_jet_emscale_eta = 0;
   tau_jet_emscale_phi = 0;
   tau_jet_flavor_weight_TrackCounting2D = 0;
   tau_jet_flavor_weight_JetProb = 0;
   tau_jet_flavor_weight_IP1D = 0;
   tau_jet_flavor_weight_IP2D = 0;
   tau_jet_flavor_weight_IP3D = 0;
   tau_jet_flavor_weight_SV0 = 0;
   tau_jet_flavor_weight_SV1 = 0;
   tau_jet_flavor_weight_SV2 = 0;
   tau_jet_flavor_weight_JetFitterTag = 0;
   tau_jet_flavor_weight_JetFitterCOMB = 0;
   tau_jet_flavor_weight_JetFitterTagNN = 0;
   tau_jet_flavor_weight_JetFitterCOMBNN = 0;
   tau_jet_flavor_weight_SoftMuonTag = 0;
   tau_jet_flavor_weight_SoftElectronTag = 0;
   tau_jet_flavor_weight_IP3DSV1 = 0;
   tau_seedCalo_track_n = 0;
   tau_seedCalo_wideTrk_n = 0;
   tau_otherTrk_n = 0;
   tau_EF_dr = 0;
   tau_EF_E = 0;
   tau_EF_Et = 0;
   tau_EF_pt = 0;
   tau_EF_eta = 0;
   tau_EF_phi = 0;
   tau_EF_matched = 0;
   tau_L2_dr = 0;
   tau_L2_E = 0;
   tau_L2_Et = 0;
   tau_L2_pt = 0;
   tau_L2_eta = 0;
   tau_L2_phi = 0;
   tau_L2_matched = 0;
   tau_L1_dr = 0;
   tau_L1_Et = 0;
   tau_L1_pt = 0;
   tau_L1_eta = 0;
   tau_L1_phi = 0;
   tau_L1_matched = 0;
   trk_pt = 0;
   trk_eta = 0;
   trk_d0_wrtPV = 0;
   trk_z0_wrtPV = 0;
   trk_phi_wrtPV = 0;
   trk_theta_wrtPV = 0;
   trk_qoverp_wrtPV = 0;
   trk_err_d0_wrtPV = 0;
   trk_err_z0_wrtPV = 0;
   trk_err_phi_wrtPV = 0;
   trk_err_theta_wrtPV = 0;
   trk_err_qoverp_wrtPV = 0;
   trk_chi2 = 0;
   trk_ndof = 0;
   trk_nBLHits = 0;
   trk_nPixHits = 0;
   trk_nSCTHits = 0;
   trk_nTRTHits = 0;
   trk_nTRTHighTHits = 0;
   trk_nPixHoles = 0;
   trk_nSCTHoles = 0;
   trk_nTRTHoles = 0;
   trk_nBLayerOutliers = 0;
   trk_nPixelOutliers = 0;
   trk_nSCTOutliers = 0;
   trk_nTRTOutliers = 0;
   trk_nTRTHighTOutliers = 0;
   trk_nContribPixelLayers = 0;
   trk_nGangedPixels = 0;
   trk_nGangedFlaggedFakes = 0;
   trk_nPixelDeadSensors = 0;
   trk_nPixelSpoiltHits = 0;
   trk_nSCTDoubleHoles = 0;
   trk_nSCTDeadSensors = 0;
   trk_nSCTSpoiltHits = 0;
   trk_nTRTDeadStraws = 0;
   trk_nTRTTubeHits = 0;
   trk_expectBLayerHit = 0;
   trk_20_trackIso = 0;
   trk_20_caloIso = 0;
   trk_20_nTrackIso = 0;
   trk_30_trackIso = 0;
   trk_30_caloIso = 0;
   trk_30_nTrackIso = 0;
   trk_40_trackIso = 0;
   trk_40_caloIso = 0;
   trk_40_nTrackIso = 0;
   jet_antiKtZ4Track_E = 0;
   jet_antiKtZ4Track_pt = 0;
   jet_antiKtZ4Track_m = 0;
   jet_antiKtZ4Track_eta = 0;
   jet_antiKtZ4Track_phi = 0;
   jet_antiKtZ4Track_EtaOrigin = 0;
   jet_antiKtZ4Track_PhiOrigin = 0;
   jet_antiKtZ4Track_MOrigin = 0;
   jet_antiKtZ4Track_EtaOriginEM = 0;
   jet_antiKtZ4Track_PhiOriginEM = 0;
   jet_antiKtZ4Track_MOriginEM = 0;
   jet_antiKtZ4Track_WIDTH = 0;
   jet_antiKtZ4Track_n90 = 0;
   jet_antiKtZ4Track_Timing = 0;
   jet_antiKtZ4Track_LArQuality = 0;
   jet_antiKtZ4Track_nTrk = 0;
   jet_antiKtZ4Track_sumPtTrk = 0;
   jet_antiKtZ4Track_OriginIndex = 0;
   jet_antiKtZ4Track_HECQuality = 0;
   jet_antiKtZ4Track_NegativeE = 0;
   jet_antiKtZ4Track_AverageLArQF = 0;
   jet_antiKtZ4Track_YFlip12 = 0;
   jet_antiKtZ4Track_YFlip23 = 0;
   jet_antiKtZ4Track_BCH_CORR_CELL = 0;
   jet_antiKtZ4Track_BCH_CORR_DOTX = 0;
   jet_antiKtZ4Track_BCH_CORR_JET = 0;
   jet_antiKtZ4Track_BCH_CORR_JET_FORCELL = 0;
   jet_antiKtZ4Track_ENG_BAD_CELLS = 0;
   jet_antiKtZ4Track_N_BAD_CELLS = 0;
   jet_antiKtZ4Track_N_BAD_CELLS_CORR = 0;
   jet_antiKtZ4Track_BAD_CELLS_CORR_E = 0;
   jet_antiKtZ4Track_NumTowers = 0;
   jet_antiKtZ4Track_SamplingMax = 0;
   jet_antiKtZ4Track_fracSamplingMax = 0;
   jet_antiKtZ4Track_hecf = 0;
   jet_antiKtZ4Track_tgap3f = 0;
   jet_antiKtZ4Track_isUgly = 0;
   jet_antiKtZ4Track_isBadLoose = 0;
   jet_antiKtZ4Track_isBadMedium = 0;
   jet_antiKtZ4Track_isBadTight = 0;
   jet_antiKtZ4Track_emfrac = 0;
   jet_antiKtZ4Track_Offset = 0;
   jet_antiKtZ4Track_EMJES = 0;
   jet_antiKtZ4Track_EMJES_EtaCorr = 0;
   jet_antiKtZ4Track_EMJESnooffset = 0;
   jet_antiKtZ4Track_GCWJES = 0;
   jet_antiKtZ4Track_GCWJES_EtaCorr = 0;
   jet_antiKtZ4Track_CB = 0;
   jet_antiKtZ4Track_LCJES = 0;
   jet_antiKtZ4Track_emscale_E = 0;
   jet_antiKtZ4Track_emscale_pt = 0;
   jet_antiKtZ4Track_emscale_m = 0;
   jet_antiKtZ4Track_emscale_eta = 0;
   jet_antiKtZ4Track_emscale_phi = 0;
   jet_antiKtZ4Track_jvtx_x = 0;
   jet_antiKtZ4Track_jvtx_y = 0;
   jet_antiKtZ4Track_jvtx_z = 0;
   jet_antiKtZ4Track_jvtxf = 0;
   jet_antiKtZ4Track_flavor_weight_Comb = 0;
   jet_antiKtZ4Track_flavor_weight_IP2D = 0;
   jet_antiKtZ4Track_flavor_weight_IP3D = 0;
   jet_antiKtZ4Track_flavor_weight_SV0 = 0;
   jet_antiKtZ4Track_flavor_weight_SV1 = 0;
   jet_antiKtZ4Track_flavor_weight_SV2 = 0;
   jet_antiKtZ4Track_flavor_weight_JetProb = 0;
   jet_antiKtZ4Track_flavor_weight_SoftMuonTag = 0;
   jet_antiKtZ4Track_flavor_weight_JetFitterTagNN = 0;
   jet_antiKtZ4Track_flavor_weight_JetFitterCOMBNN = 0;
   jet_antiKtZ4Track_flavor_weight_GbbNN = 0;
   jet_antiKtZ4Track_flavor_component_svp_isValid = 0;
   jet_antiKtZ4Track_flavor_component_svp_ntrkv = 0;
   jet_antiKtZ4Track_flavor_component_svp_ntrkj = 0;
   jet_antiKtZ4Track_flavor_component_svp_n2t = 0;
   jet_antiKtZ4Track_flavor_component_svp_mass = 0;
   jet_antiKtZ4Track_flavor_component_svp_efrc = 0;
   jet_antiKtZ4Track_flavor_component_svp_x = 0;
   jet_antiKtZ4Track_flavor_component_svp_y = 0;
   jet_antiKtZ4Track_flavor_component_svp_z = 0;
   jet_antiKtZ4Track_flavor_component_svp_err_x = 0;
   jet_antiKtZ4Track_flavor_component_svp_err_y = 0;
   jet_antiKtZ4Track_flavor_component_svp_err_z = 0;
   jet_antiKtZ4Track_flavor_component_svp_cov_xy = 0;
   jet_antiKtZ4Track_flavor_component_svp_cov_xz = 0;
   jet_antiKtZ4Track_flavor_component_svp_cov_yz = 0;
   jet_antiKtZ4Track_flavor_component_svp_chi2 = 0;
   jet_antiKtZ4Track_flavor_component_svp_ndof = 0;
   jet_antiKtZ4Track_flavor_component_svp_ntrk = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_isValid = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_ntrkv = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_ntrkj = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_n2t = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_mass = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_efrc = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_x = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_y = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_z = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_err_x = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_err_y = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_err_z = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_cov_xy = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_cov_xz = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_cov_yz = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_chi2 = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_ndof = 0;
   jet_antiKtZ4Track_flavor_component_sv0p_ntrk = 0;
   jet_antiKtZ4Track_flavor_assoctrk_index = 0;
   jet_antiKtZ4Track_el_dr = 0;
   jet_antiKtZ4Track_el_matched = 0;
   jet_antiKtZ4Track_mu_dr = 0;
   jet_antiKtZ4Track_mu_matched = 0;
   jet_antiKtZ4Track_L1_dr = 0;
   jet_antiKtZ4Track_L1_matched = 0;
   jet_antiKtZ4Track_L2_dr = 0;
   jet_antiKtZ4Track_L2_matched = 0;
   jet_antiKtZ4Track_EF_dr = 0;
   jet_antiKtZ4Track_EF_matched = 0;
   jet_E = 0;
   jet_pt = 0;
   jet_m = 0;
   jet_eta = 0;
   jet_phi = 0;
   jet_EtaOrigin = 0;
   jet_PhiOrigin = 0;
   jet_MOrigin = 0;
   jet_EtaOriginEM = 0;
   jet_PhiOriginEM = 0;
   jet_MOriginEM = 0;
   jet_WIDTH = 0;
   jet_n90 = 0;
   jet_Timing = 0;
   jet_LArQuality = 0;
   jet_nTrk = 0;
   jet_sumPtTrk = 0;
   jet_OriginIndex = 0;
   jet_HECQuality = 0;
   jet_NegativeE = 0;
   jet_AverageLArQF = 0;
   jet_YFlip12 = 0;
   jet_YFlip23 = 0;
   jet_BCH_CORR_CELL = 0;
   jet_BCH_CORR_DOTX = 0;
   jet_BCH_CORR_JET = 0;
   jet_BCH_CORR_JET_FORCELL = 0;
   jet_ENG_BAD_CELLS = 0;
   jet_N_BAD_CELLS = 0;
   jet_N_BAD_CELLS_CORR = 0;
   jet_BAD_CELLS_CORR_E = 0;
   jet_NumTowers = 0;
   jet_SamplingMax = 0;
   jet_fracSamplingMax = 0;
   jet_hecf = 0;
   jet_tgap3f = 0;
   jet_isUgly = 0;
   jet_isBadLoose = 0;
   jet_isBadMedium = 0;
   jet_isBadTight = 0;
   jet_emfrac = 0;
   jet_Offset = 0;
   jet_EMJES = 0;
   jet_EMJES_EtaCorr = 0;
   jet_EMJESnooffset = 0;
   jet_GCWJES = 0;
   jet_GCWJES_EtaCorr = 0;
   jet_CB = 0;
   jet_LCJES = 0;
   jet_emscale_E = 0;
   jet_emscale_pt = 0;
   jet_emscale_m = 0;
   jet_emscale_eta = 0;
   jet_emscale_phi = 0;
   jet_jvtx_x = 0;
   jet_jvtx_y = 0;
   jet_jvtx_z = 0;
   jet_jvtxf = 0;
   jet_GSCFactorF = 0;
   jet_WidthFraction = 0;
   jet_e_PreSamplerB = 0;
   jet_e_EMB1 = 0;
   jet_e_EMB2 = 0;
   jet_e_EMB3 = 0;
   jet_e_PreSamplerE = 0;
   jet_e_EME1 = 0;
   jet_e_EME2 = 0;
   jet_e_EME3 = 0;
   jet_e_HEC0 = 0;
   jet_e_HEC1 = 0;
   jet_e_HEC2 = 0;
   jet_e_HEC3 = 0;
   jet_e_TileBar0 = 0;
   jet_e_TileBar1 = 0;
   jet_e_TileBar2 = 0;
   jet_e_TileGap1 = 0;
   jet_e_TileGap2 = 0;
   jet_e_TileGap3 = 0;
   jet_e_TileExt0 = 0;
   jet_e_TileExt1 = 0;
   jet_e_TileExt2 = 0;
   jet_e_FCAL0 = 0;
   jet_e_FCAL1 = 0;
   jet_e_FCAL2 = 0;
   jet_flavor_weight_Comb = 0;
   jet_flavor_weight_IP2D = 0;
   jet_flavor_weight_IP3D = 0;
   jet_flavor_weight_SV0 = 0;
   jet_flavor_weight_SV1 = 0;
   jet_flavor_weight_SV2 = 0;
   jet_flavor_weight_JetProb = 0;
   jet_flavor_weight_SoftMuonTag = 0;
   jet_flavor_weight_JetFitterTagNN = 0;
   jet_flavor_weight_JetFitterCOMBNN = 0;
   jet_flavor_weight_GbbNN = 0;
   jet_flavor_component_svp_isValid = 0;
   jet_flavor_component_svp_ntrkv = 0;
   jet_flavor_component_svp_ntrkj = 0;
   jet_flavor_component_svp_n2t = 0;
   jet_flavor_component_svp_mass = 0;
   jet_flavor_component_svp_efrc = 0;
   jet_flavor_component_svp_x = 0;
   jet_flavor_component_svp_y = 0;
   jet_flavor_component_svp_z = 0;
   jet_flavor_component_svp_err_x = 0;
   jet_flavor_component_svp_err_y = 0;
   jet_flavor_component_svp_err_z = 0;
   jet_flavor_component_svp_cov_xy = 0;
   jet_flavor_component_svp_cov_xz = 0;
   jet_flavor_component_svp_cov_yz = 0;
   jet_flavor_component_svp_chi2 = 0;
   jet_flavor_component_svp_ndof = 0;
   jet_flavor_component_svp_ntrk = 0;
   jet_flavor_component_sv0p_isValid = 0;
   jet_flavor_component_sv0p_ntrkv = 0;
   jet_flavor_component_sv0p_ntrkj = 0;
   jet_flavor_component_sv0p_n2t = 0;
   jet_flavor_component_sv0p_mass = 0;
   jet_flavor_component_sv0p_efrc = 0;
   jet_flavor_component_sv0p_x = 0;
   jet_flavor_component_sv0p_y = 0;
   jet_flavor_component_sv0p_z = 0;
   jet_flavor_component_sv0p_err_x = 0;
   jet_flavor_component_sv0p_err_y = 0;
   jet_flavor_component_sv0p_err_z = 0;
   jet_flavor_component_sv0p_cov_xy = 0;
   jet_flavor_component_sv0p_cov_xz = 0;
   jet_flavor_component_sv0p_cov_yz = 0;
   jet_flavor_component_sv0p_chi2 = 0;
   jet_flavor_component_sv0p_ndof = 0;
   jet_flavor_component_sv0p_ntrk = 0;
   jet_flavor_assoctrk_index = 0;
   jet_el_dr = 0;
   jet_el_matched = 0;
   jet_mu_dr = 0;
   jet_mu_matched = 0;
   jet_L1_dr = 0;
   jet_L1_matched = 0;
   jet_L2_dr = 0;
   jet_L2_matched = 0;
   jet_EF_dr = 0;
   jet_EF_matched = 0;
   jet_AntiKt4LCTopoJets_E = 0;
   jet_AntiKt4LCTopoJets_pt = 0;
   jet_AntiKt4LCTopoJets_m = 0;
   jet_AntiKt4LCTopoJets_eta = 0;
   jet_AntiKt4LCTopoJets_phi = 0;
   jet_AntiKt4LCTopoJets_EtaOrigin = 0;
   jet_AntiKt4LCTopoJets_PhiOrigin = 0;
   jet_AntiKt4LCTopoJets_MOrigin = 0;
   jet_AntiKt4LCTopoJets_EtaOriginEM = 0;
   jet_AntiKt4LCTopoJets_PhiOriginEM = 0;
   jet_AntiKt4LCTopoJets_MOriginEM = 0;
   jet_AntiKt4LCTopoJets_WIDTH = 0;
   jet_AntiKt4LCTopoJets_n90 = 0;
   jet_AntiKt4LCTopoJets_Timing = 0;
   jet_AntiKt4LCTopoJets_LArQuality = 0;
   jet_AntiKt4LCTopoJets_nTrk = 0;
   jet_AntiKt4LCTopoJets_sumPtTrk = 0;
   jet_AntiKt4LCTopoJets_OriginIndex = 0;
   jet_AntiKt4LCTopoJets_HECQuality = 0;
   jet_AntiKt4LCTopoJets_NegativeE = 0;
   jet_AntiKt4LCTopoJets_AverageLArQF = 0;
   jet_AntiKt4LCTopoJets_YFlip12 = 0;
   jet_AntiKt4LCTopoJets_YFlip23 = 0;
   jet_AntiKt4LCTopoJets_BCH_CORR_CELL = 0;
   jet_AntiKt4LCTopoJets_BCH_CORR_DOTX = 0;
   jet_AntiKt4LCTopoJets_BCH_CORR_JET = 0;
   jet_AntiKt4LCTopoJets_BCH_CORR_JET_FORCELL = 0;
   jet_AntiKt4LCTopoJets_ENG_BAD_CELLS = 0;
   jet_AntiKt4LCTopoJets_N_BAD_CELLS = 0;
   jet_AntiKt4LCTopoJets_N_BAD_CELLS_CORR = 0;
   jet_AntiKt4LCTopoJets_BAD_CELLS_CORR_E = 0;
   jet_AntiKt4LCTopoJets_NumTowers = 0;
   jet_AntiKt4LCTopoJets_SamplingMax = 0;
   jet_AntiKt4LCTopoJets_fracSamplingMax = 0;
   jet_AntiKt4LCTopoJets_hecf = 0;
   jet_AntiKt4LCTopoJets_tgap3f = 0;
   jet_AntiKt4LCTopoJets_isUgly = 0;
   jet_AntiKt4LCTopoJets_isBadLoose = 0;
   jet_AntiKt4LCTopoJets_isBadMedium = 0;
   jet_AntiKt4LCTopoJets_isBadTight = 0;
   jet_AntiKt4LCTopoJets_emfrac = 0;
   jet_AntiKt4LCTopoJets_Offset = 0;
   jet_AntiKt4LCTopoJets_EMJES = 0;
   jet_AntiKt4LCTopoJets_EMJES_EtaCorr = 0;
   jet_AntiKt4LCTopoJets_EMJESnooffset = 0;
   jet_AntiKt4LCTopoJets_GCWJES = 0;
   jet_AntiKt4LCTopoJets_GCWJES_EtaCorr = 0;
   jet_AntiKt4LCTopoJets_CB = 0;
   jet_AntiKt4LCTopoJets_LCJES = 0;
   jet_AntiKt4LCTopoJets_emscale_E = 0;
   jet_AntiKt4LCTopoJets_emscale_pt = 0;
   jet_AntiKt4LCTopoJets_emscale_m = 0;
   jet_AntiKt4LCTopoJets_emscale_eta = 0;
   jet_AntiKt4LCTopoJets_emscale_phi = 0;
   jet_AntiKt4LCTopoJets_jvtx_x = 0;
   jet_AntiKt4LCTopoJets_jvtx_y = 0;
   jet_AntiKt4LCTopoJets_jvtx_z = 0;
   jet_AntiKt4LCTopoJets_jvtxf = 0;
   jet_AntiKt4LCTopoJets_GSCFactorF = 0;
   jet_AntiKt4LCTopoJets_WidthFraction = 0;
   jet_AntiKt4LCTopoJets_e_PreSamplerB = 0;
   jet_AntiKt4LCTopoJets_e_EMB1 = 0;
   jet_AntiKt4LCTopoJets_e_EMB2 = 0;
   jet_AntiKt4LCTopoJets_e_EMB3 = 0;
   jet_AntiKt4LCTopoJets_e_PreSamplerE = 0;
   jet_AntiKt4LCTopoJets_e_EME1 = 0;
   jet_AntiKt4LCTopoJets_e_EME2 = 0;
   jet_AntiKt4LCTopoJets_e_EME3 = 0;
   jet_AntiKt4LCTopoJets_e_HEC0 = 0;
   jet_AntiKt4LCTopoJets_e_HEC1 = 0;
   jet_AntiKt4LCTopoJets_e_HEC2 = 0;
   jet_AntiKt4LCTopoJets_e_HEC3 = 0;
   jet_AntiKt4LCTopoJets_e_TileBar0 = 0;
   jet_AntiKt4LCTopoJets_e_TileBar1 = 0;
   jet_AntiKt4LCTopoJets_e_TileBar2 = 0;
   jet_AntiKt4LCTopoJets_e_TileGap1 = 0;
   jet_AntiKt4LCTopoJets_e_TileGap2 = 0;
   jet_AntiKt4LCTopoJets_e_TileGap3 = 0;
   jet_AntiKt4LCTopoJets_e_TileExt0 = 0;
   jet_AntiKt4LCTopoJets_e_TileExt1 = 0;
   jet_AntiKt4LCTopoJets_e_TileExt2 = 0;
   jet_AntiKt4LCTopoJets_e_FCAL0 = 0;
   jet_AntiKt4LCTopoJets_e_FCAL1 = 0;
   jet_AntiKt4LCTopoJets_e_FCAL2 = 0;
   jet_AntiKt4LCTopoJets_flavor_weight_Comb = 0;
   jet_AntiKt4LCTopoJets_flavor_weight_IP2D = 0;
   jet_AntiKt4LCTopoJets_flavor_weight_IP3D = 0;
   jet_AntiKt4LCTopoJets_flavor_weight_SV0 = 0;
   jet_AntiKt4LCTopoJets_flavor_weight_SV1 = 0;
   jet_AntiKt4LCTopoJets_flavor_weight_SV2 = 0;
   jet_AntiKt4LCTopoJets_flavor_weight_JetProb = 0;
   jet_AntiKt4LCTopoJets_flavor_weight_SoftMuonTag = 0;
   jet_AntiKt4LCTopoJets_flavor_weight_JetFitterTagNN = 0;
   jet_AntiKt4LCTopoJets_flavor_weight_JetFitterCOMBNN = 0;
   jet_AntiKt4LCTopoJets_flavor_weight_GbbNN = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_isValid = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_ntrkv = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_ntrkj = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_n2t = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_mass = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_efrc = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_x = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_y = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_z = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_err_x = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_err_y = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_err_z = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_cov_xy = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_cov_xz = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_cov_yz = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_chi2 = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_ndof = 0;
   jet_AntiKt4LCTopoJets_flavor_component_svp_ntrk = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_isValid = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrkv = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrkj = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_n2t = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_mass = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_efrc = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_x = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_y = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_z = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_x = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_y = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_z = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_xy = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_xz = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_yz = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_chi2 = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_ndof = 0;
   jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrk = 0;
   jet_AntiKt4LCTopoJets_el_dr = 0;
   jet_AntiKt4LCTopoJets_el_matched = 0;
   jet_AntiKt4LCTopoJets_mu_dr = 0;
   jet_AntiKt4LCTopoJets_mu_matched = 0;
   jet_AntiKt4LCTopoJets_L1_dr = 0;
   jet_AntiKt4LCTopoJets_L1_matched = 0;
   jet_AntiKt4LCTopoJets_L2_dr = 0;
   jet_AntiKt4LCTopoJets_L2_matched = 0;
   jet_AntiKt4LCTopoJets_EF_dr = 0;
   jet_AntiKt4LCTopoJets_EF_matched = 0;
   vxp_x = 0;
   vxp_y = 0;
   vxp_z = 0;
   vxp_err_x = 0;
   vxp_err_y = 0;
   vxp_err_z = 0;
   vxp_cov_xy = 0;
   vxp_cov_xz = 0;
   vxp_cov_yz = 0;
   vxp_type = 0;
   vxp_chi2 = 0;
   vxp_ndof = 0;
   vxp_px = 0;
   vxp_py = 0;
   vxp_pz = 0;
   vxp_E = 0;
   vxp_m = 0;
   vxp_nTracks = 0;
   vxp_sumPt = 0;
   vxp_trk_n = 0;
   vxp_trk_weight = 0;
   vxp_trk_index = 0;
   el_MET_em_tight_wpx = 0;
   el_MET_em_tight_wpy = 0;
   el_MET_em_tight_wet = 0;
   el_MET_em_tight_statusWord = 0;
   ph_MET_em_tight_wpx = 0;
   ph_MET_em_tight_wpy = 0;
   ph_MET_em_tight_wet = 0;
   ph_MET_em_tight_statusWord = 0;
   mu_staco_MET_em_tight_wpx = 0;
   mu_staco_MET_em_tight_wpy = 0;
   mu_staco_MET_em_tight_wet = 0;
   mu_staco_MET_em_tight_statusWord = 0;
   mu_muid_MET_em_tight_wpx = 0;
   mu_muid_MET_em_tight_wpy = 0;
   mu_muid_MET_em_tight_wet = 0;
   mu_muid_MET_em_tight_statusWord = 0;
   jet_em_tight_wpx = 0;
   jet_em_tight_wpy = 0;
   jet_em_tight_wet = 0;
   jet_em_tight_statusWord = 0;
   el_MET_em_medium_wpx = 0;
   el_MET_em_medium_wpy = 0;
   el_MET_em_medium_wet = 0;
   el_MET_em_medium_statusWord = 0;
   ph_MET_em_medium_wpx = 0;
   ph_MET_em_medium_wpy = 0;
   ph_MET_em_medium_wet = 0;
   ph_MET_em_medium_statusWord = 0;
   mu_staco_MET_em_medium_wpx = 0;
   mu_staco_MET_em_medium_wpy = 0;
   mu_staco_MET_em_medium_wet = 0;
   mu_staco_MET_em_medium_statusWord = 0;
   mu_muid_MET_em_medium_wpx = 0;
   mu_muid_MET_em_medium_wpy = 0;
   mu_muid_MET_em_medium_wet = 0;
   mu_muid_MET_em_medium_statusWord = 0;
   jet_em_medium_wpx = 0;
   jet_em_medium_wpy = 0;
   jet_em_medium_wet = 0;
   jet_em_medium_statusWord = 0;
   el_MET_em_loose_wpx = 0;
   el_MET_em_loose_wpy = 0;
   el_MET_em_loose_wet = 0;
   el_MET_em_loose_statusWord = 0;
   ph_MET_em_loose_wpx = 0;
   ph_MET_em_loose_wpy = 0;
   ph_MET_em_loose_wet = 0;
   ph_MET_em_loose_statusWord = 0;
   mu_staco_MET_em_loose_wpx = 0;
   mu_staco_MET_em_loose_wpy = 0;
   mu_staco_MET_em_loose_wet = 0;
   mu_staco_MET_em_loose_statusWord = 0;
   mu_muid_MET_em_loose_wpx = 0;
   mu_muid_MET_em_loose_wpy = 0;
   mu_muid_MET_em_loose_wet = 0;
   mu_muid_MET_em_loose_statusWord = 0;
   jet_em_loose_wpx = 0;
   jet_em_loose_wpy = 0;
   jet_em_loose_wet = 0;
   jet_em_loose_statusWord = 0;
   el_MET_4lc_loose_wpx = 0;
   el_MET_4lc_loose_wpy = 0;
   el_MET_4lc_loose_wet = 0;
   el_MET_4lc_loose_statusWord = 0;
   ph_MET_4lc_loose_wpx = 0;
   ph_MET_4lc_loose_wpy = 0;
   ph_MET_4lc_loose_wet = 0;
   ph_MET_4lc_loose_statusWord = 0;
   mu_staco_MET_4lc_loose_wpx = 0;
   mu_staco_MET_4lc_loose_wpy = 0;
   mu_staco_MET_4lc_loose_wet = 0;
   mu_staco_MET_4lc_loose_statusWord = 0;
   mu_muid_MET_4lc_loose_wpx = 0;
   mu_muid_MET_4lc_loose_wpy = 0;
   mu_muid_MET_4lc_loose_wet = 0;
   mu_muid_MET_4lc_loose_statusWord = 0;
   jet_AntiKt4LCTopoJets_4lc_loose_wpx = 0;
   jet_AntiKt4LCTopoJets_4lc_loose_wpy = 0;
   jet_AntiKt4LCTopoJets_4lc_loose_wet = 0;
   jet_AntiKt4LCTopoJets_4lc_loose_statusWord = 0;
   el_MET_4lc_medium_wpx = 0;
   el_MET_4lc_medium_wpy = 0;
   el_MET_4lc_medium_wet = 0;
   el_MET_4lc_medium_statusWord = 0;
   ph_MET_4lc_medium_wpx = 0;
   ph_MET_4lc_medium_wpy = 0;
   ph_MET_4lc_medium_wet = 0;
   ph_MET_4lc_medium_statusWord = 0;
   mu_staco_MET_4lc_medium_wpx = 0;
   mu_staco_MET_4lc_medium_wpy = 0;
   mu_staco_MET_4lc_medium_wet = 0;
   mu_staco_MET_4lc_medium_statusWord = 0;
   mu_muid_MET_4lc_medium_wpx = 0;
   mu_muid_MET_4lc_medium_wpy = 0;
   mu_muid_MET_4lc_medium_wet = 0;
   mu_muid_MET_4lc_medium_statusWord = 0;
   jet_AntiKt4LCTopoJets_4lc_medium_wpx = 0;
   jet_AntiKt4LCTopoJets_4lc_medium_wpy = 0;
   jet_AntiKt4LCTopoJets_4lc_medium_wet = 0;
   jet_AntiKt4LCTopoJets_4lc_medium_statusWord = 0;
   el_MET_4lc_tight_wpx = 0;
   el_MET_4lc_tight_wpy = 0;
   el_MET_4lc_tight_wet = 0;
   el_MET_4lc_tight_statusWord = 0;
   ph_MET_4lc_tight_wpx = 0;
   ph_MET_4lc_tight_wpy = 0;
   ph_MET_4lc_tight_wet = 0;
   ph_MET_4lc_tight_statusWord = 0;
   mu_staco_MET_4lc_tight_wpx = 0;
   mu_staco_MET_4lc_tight_wpy = 0;
   mu_staco_MET_4lc_tight_wet = 0;
   mu_staco_MET_4lc_tight_statusWord = 0;
   mu_muid_MET_4lc_tight_wpx = 0;
   mu_muid_MET_4lc_tight_wpy = 0;
   mu_muid_MET_4lc_tight_wet = 0;
   mu_muid_MET_4lc_tight_statusWord = 0;
   jet_AntiKt4LCTopoJets_4lc_tight_wpx = 0;
   jet_AntiKt4LCTopoJets_4lc_tight_wpy = 0;
   jet_AntiKt4LCTopoJets_4lc_tight_wet = 0;
   jet_AntiKt4LCTopoJets_4lc_tight_statusWord = 0;
   el_MET_6lc_tight_wpx = 0;
   el_MET_6lc_tight_wpy = 0;
   el_MET_6lc_tight_wet = 0;
   el_MET_6lc_tight_statusWord = 0;
   ph_MET_6lc_tight_wpx = 0;
   ph_MET_6lc_tight_wpy = 0;
   ph_MET_6lc_tight_wet = 0;
   ph_MET_6lc_tight_statusWord = 0;
   mu_staco_MET_6lc_tight_wpx = 0;
   mu_staco_MET_6lc_tight_wpy = 0;
   mu_staco_MET_6lc_tight_wet = 0;
   mu_staco_MET_6lc_tight_statusWord = 0;
   mu_muid_MET_6lc_tight_wpx = 0;
   mu_muid_MET_6lc_tight_wpy = 0;
   mu_muid_MET_6lc_tight_wet = 0;
   mu_muid_MET_6lc_tight_statusWord = 0;
   jet_AntiKt6LCTopoJets_6lc_tight_wpx = 0;
   jet_AntiKt6LCTopoJets_6lc_tight_wpy = 0;
   jet_AntiKt6LCTopoJets_6lc_tight_wet = 0;
   jet_AntiKt6LCTopoJets_6lc_tight_statusWord = 0;
   el_MET_em_medium_photon_wpx = 0;
   el_MET_em_medium_photon_wpy = 0;
   el_MET_em_medium_photon_wet = 0;
   el_MET_em_medium_photon_statusWord = 0;
   ph_MET_em_medium_photon_wpx = 0;
   ph_MET_em_medium_photon_wpy = 0;
   ph_MET_em_medium_photon_wet = 0;
   ph_MET_em_medium_photon_statusWord = 0;
   mu_staco_MET_em_medium_photon_wpx = 0;
   mu_staco_MET_em_medium_photon_wpy = 0;
   mu_staco_MET_em_medium_photon_wet = 0;
   mu_staco_MET_em_medium_photon_statusWord = 0;
   mu_muid_MET_em_medium_photon_wpx = 0;
   mu_muid_MET_em_medium_photon_wpy = 0;
   mu_muid_MET_em_medium_photon_wet = 0;
   mu_muid_MET_em_medium_photon_statusWord = 0;
   jet_em_medium_photon_wpx = 0;
   jet_em_medium_photon_wpy = 0;
   jet_em_medium_photon_wet = 0;
   jet_em_medium_photon_statusWord = 0;
   el_MET_em_tight_photon_wpx = 0;
   el_MET_em_tight_photon_wpy = 0;
   el_MET_em_tight_photon_wet = 0;
   el_MET_em_tight_photon_statusWord = 0;
   ph_MET_em_tight_photon_wpx = 0;
   ph_MET_em_tight_photon_wpy = 0;
   ph_MET_em_tight_photon_wet = 0;
   ph_MET_em_tight_photon_statusWord = 0;
   mu_staco_MET_em_tight_photon_wpx = 0;
   mu_staco_MET_em_tight_photon_wpy = 0;
   mu_staco_MET_em_tight_photon_wet = 0;
   mu_staco_MET_em_tight_photon_statusWord = 0;
   mu_muid_MET_em_tight_photon_wpx = 0;
   mu_muid_MET_em_tight_photon_wpy = 0;
   mu_muid_MET_em_tight_photon_wet = 0;
   mu_muid_MET_em_tight_photon_statusWord = 0;
   jet_em_tight_photon_wpx = 0;
   jet_em_tight_photon_wpy = 0;
   jet_em_tight_photon_wet = 0;
   jet_em_tight_photon_statusWord = 0;
   el_MET_4lc_medium_photon_wpx = 0;
   el_MET_4lc_medium_photon_wpy = 0;
   el_MET_4lc_medium_photon_wet = 0;
   el_MET_4lc_medium_photon_statusWord = 0;
   ph_MET_4lc_medium_photon_wpx = 0;
   ph_MET_4lc_medium_photon_wpy = 0;
   ph_MET_4lc_medium_photon_wet = 0;
   ph_MET_4lc_medium_photon_statusWord = 0;
   mu_staco_MET_4lc_medium_photon_wpx = 0;
   mu_staco_MET_4lc_medium_photon_wpy = 0;
   mu_staco_MET_4lc_medium_photon_wet = 0;
   mu_staco_MET_4lc_medium_photon_statusWord = 0;
   mu_muid_MET_4lc_medium_photon_wpx = 0;
   mu_muid_MET_4lc_medium_photon_wpy = 0;
   mu_muid_MET_4lc_medium_photon_wet = 0;
   mu_muid_MET_4lc_medium_photon_statusWord = 0;
   jet_AntiKt4LCTopoJets_4lc_medium_photon_wpx = 0;
   jet_AntiKt4LCTopoJets_4lc_medium_photon_wpy = 0;
   jet_AntiKt4LCTopoJets_4lc_medium_photon_wet = 0;
   jet_AntiKt4LCTopoJets_4lc_medium_photon_statusWord = 0;
   el_MET_4lc_tight_photon_wpx = 0;
   el_MET_4lc_tight_photon_wpy = 0;
   el_MET_4lc_tight_photon_wet = 0;
   el_MET_4lc_tight_photon_statusWord = 0;
   ph_MET_4lc_tight_photon_wpx = 0;
   ph_MET_4lc_tight_photon_wpy = 0;
   ph_MET_4lc_tight_photon_wet = 0;
   ph_MET_4lc_tight_photon_statusWord = 0;
   mu_staco_MET_4lc_tight_photon_wpx = 0;
   mu_staco_MET_4lc_tight_photon_wpy = 0;
   mu_staco_MET_4lc_tight_photon_wet = 0;
   mu_staco_MET_4lc_tight_photon_statusWord = 0;
   mu_muid_MET_4lc_tight_photon_wpx = 0;
   mu_muid_MET_4lc_tight_photon_wpy = 0;
   mu_muid_MET_4lc_tight_photon_wet = 0;
   mu_muid_MET_4lc_tight_photon_statusWord = 0;
   jet_AntiKt4LCTopoJets_4lc_tight_photon_wpx = 0;
   jet_AntiKt4LCTopoJets_4lc_tight_photon_wpy = 0;
   jet_AntiKt4LCTopoJets_4lc_tight_photon_wet = 0;
   jet_AntiKt4LCTopoJets_4lc_tight_photon_statusWord = 0;
   mb_E = 0;
   mb_eta = 0;
   mb_phi = 0;
   mb_time = 0;
   mb_quality = 0;
   mb_type = 0;
   mb_module = 0;
   mb_channel = 0;
   topJet_use = 0;
   topJet_inTrigger = 0;
   topJet_index = 0;
   topJet_overlap_jet_n = 0;
   topJet_overlap_jet_index = 0;
   topJet_overlap_mu_n = 0;
   topJet_overlap_mu_index = 0;
   topJet_overlap_tau_n = 0;
   topJet_overlap_tau_index = 0;
   topMu_use = 0;
   topMu_inTrigger = 0;
   topMu_index = 0;
   topMu_overlap_jet_n = 0;
   topMu_overlap_jet_index = 0;
   topMu_overlap_mu_n = 0;
   topMu_overlap_mu_index = 0;
   topMu_overlap_tau_n = 0;
   topMu_overlap_tau_index = 0;
   topEl_use = 0;
   topEl_inTrigger = 0;
   topEl_index = 0;
   topEl_overlap_jet_n = 0;
   topEl_overlap_jet_index = 0;
   topEl_overlap_mu_n = 0;
   topEl_overlap_mu_index = 0;
   topEl_overlap_tau_n = 0;
   topEl_overlap_tau_index = 0;
   top_phJet_use = 0;
   top_phJet_inTrigger = 0;
   top_phJet_index = 0;
   top_phJet_overlap_jet_n = 0;
   top_phJet_overlap_jet_index = 0;
   top_phJet_overlap_mu_n = 0;
   top_phJet_overlap_mu_index = 0;
   top_phJet_overlap_trk_n = 0;
   top_phJet_overlap_trk_index = 0;
   top_phJet_overlap_tau_n = 0;
   top_phJet_overlap_tau_index = 0;
   top_phMu_use = 0;
   top_phMu_inTrigger = 0;
   top_phMu_index = 0;
   top_phMu_overlap_jet_n = 0;
   top_phMu_overlap_jet_index = 0;
   top_phMu_overlap_mu_n = 0;
   top_phMu_overlap_mu_index = 0;
   top_phMu_overlap_trk_n = 0;
   top_phMu_overlap_trk_index = 0;
   top_phMu_overlap_tau_n = 0;
   top_phMu_overlap_tau_index = 0;
   top_phEl_use = 0;
   top_phEl_inTrigger = 0;
   top_phEl_index = 0;
   top_phEl_overlap_jet_n = 0;
   top_phEl_overlap_jet_index = 0;
   top_phEl_overlap_mu_n = 0;
   top_phEl_overlap_mu_index = 0;
   top_phEl_overlap_trk_n = 0;
   top_phEl_overlap_trk_index = 0;
   top_phEl_overlap_tau_n = 0;
   top_phEl_overlap_tau_index = 0;
   top_phPh_use = 0;
   top_phPh_inTrigger = 0;
   top_phPh_index = 0;
   top_phPh_overlap_jet_n = 0;
   top_phPh_overlap_jet_index = 0;
   top_phPh_overlap_mu_n = 0;
   top_phPh_overlap_mu_index = 0;
   top_phPh_overlap_trk_n = 0;
   top_phPh_overlap_trk_index = 0;
   top_phPh_overlap_tau_n = 0;
   top_phPh_overlap_tau_index = 0;
   trig_Nav_chain_ChainId = 0;
   trig_Nav_chain_RoIType = 0;
   trig_Nav_chain_RoIIndex = 0;
   trig_RoI_L2_b_type = 0;
   trig_RoI_L2_b_active = 0;
   trig_RoI_L2_b_lastStep = 0;
   trig_RoI_L2_b_TENumber = 0;
   trig_RoI_L2_b_roiNumber = 0;
   trig_RoI_L2_b_Jet_ROI = 0;
   trig_RoI_L2_b_Jet_ROIStatus = 0;
   trig_RoI_L2_b_Muon_ROI = 0;
   trig_RoI_L2_b_Muon_ROIStatus = 0;
   trig_RoI_L2_b_TrigL2BjetContainer = 0;
   trig_RoI_L2_b_TrigL2BjetContainerStatus = 0;
   trig_RoI_L2_b_TrigInDetTrackCollection_TrigSiTrack_Jet = 0;
   trig_RoI_L2_b_TrigInDetTrackCollection_TrigSiTrack_JetStatus = 0;
   trig_RoI_L2_b_TrigInDetTrackCollection_TrigIDSCAN_Jet = 0;
   trig_RoI_L2_b_TrigInDetTrackCollection_TrigIDSCAN_JetStatus = 0;
   trig_RoI_EF_b_type = 0;
   trig_RoI_EF_b_active = 0;
   trig_RoI_EF_b_lastStep = 0;
   trig_RoI_EF_b_TENumber = 0;
   trig_RoI_EF_b_roiNumber = 0;
   trig_RoI_EF_b_Jet_ROI = 0;
   trig_RoI_EF_b_Jet_ROIStatus = 0;
   trig_RoI_EF_b_Muon_ROI = 0;
   trig_RoI_EF_b_Muon_ROIStatus = 0;
   trig_RoI_EF_b_TrigEFBjetContainer = 0;
   trig_RoI_EF_b_TrigEFBjetContainerStatus = 0;
   trig_RoI_EF_b_Rec__TrackParticleContainer = 0;
   trig_RoI_EF_b_Rec__TrackParticleContainerStatus = 0;
   trig_L1_jet_eta = 0;
   trig_L1_jet_phi = 0;
   trig_L1_jet_thrNames = 0;
   trig_L1_jet_thrValues = 0;
   trig_L1_jet_thrPattern = 0;
   trig_L1_jet_et4x4 = 0;
   trig_L1_jet_et6x6 = 0;
   trig_L1_jet_et8x8 = 0;
   trig_L1_jet_RoIWord = 0;
   trig_L1_TAV = 0;
   trig_L2_passedPhysics = 0;
   trig_EF_passedPhysics = 0;
   trig_L1_TBP = 0;
   trig_L1_TAP = 0;
   trig_L2_passedRaw = 0;
   trig_EF_passedRaw = 0;
   trig_L2_resurrected = 0;
   trig_EF_resurrected = 0;
   trig_L2_passedThrough = 0;
   trig_EF_passedThrough = 0;
   trig_L2_bjet_roiId = 0;
   trig_L2_bjet_valid = 0;
   trig_L2_bjet_prmVtx = 0;
   trig_L2_bjet_pt = 0;
   trig_L2_bjet_eta = 0;
   trig_L2_bjet_phi = 0;
   trig_L2_bjet_xComb = 0;
   trig_L2_bjet_xIP1D = 0;
   trig_L2_bjet_xIP2D = 0;
   trig_L2_bjet_xIP3D = 0;
   trig_L2_bjet_xCHI2 = 0;
   trig_L2_bjet_xSV = 0;
   trig_L2_bjet_xMVtx = 0;
   trig_L2_bjet_xEVtx = 0;
   trig_L2_bjet_xNVtx = 0;
   trig_L2_bjet_BSx = 0;
   trig_L2_bjet_BSy = 0;
   trig_L2_bjet_BSz = 0;
   trig_L2_bjet_sBSx = 0;
   trig_L2_bjet_sBSy = 0;
   trig_L2_bjet_sBSz = 0;
   trig_L2_bjet_sBSxy = 0;
   trig_L2_bjet_BTiltXZ = 0;
   trig_L2_bjet_BTiltYZ = 0;
   trig_L2_bjet_BSstatus = 0;
   trig_EF_bjet_roiId = 0;
   trig_EF_bjet_valid = 0;
   trig_EF_bjet_prmVtx = 0;
   trig_EF_bjet_pt = 0;
   trig_EF_bjet_eta = 0;
   trig_EF_bjet_phi = 0;
   trig_EF_bjet_xComb = 0;
   trig_EF_bjet_xIP1D = 0;
   trig_EF_bjet_xIP2D = 0;
   trig_EF_bjet_xIP3D = 0;
   trig_EF_bjet_xCHI2 = 0;
   trig_EF_bjet_xSV = 0;
   trig_EF_bjet_xMVtx = 0;
   trig_EF_bjet_xEVtx = 0;
   trig_EF_bjet_xNVtx = 0;
   trig_EF_pv_x = 0;
   trig_EF_pv_y = 0;
   trig_EF_pv_z = 0;
   trig_EF_pv_type = 0;
   trig_EF_pv_err_x = 0;
   trig_EF_pv_err_y = 0;
   trig_EF_pv_err_z = 0;
   trig_L1_mu_pt = 0;
   trig_L1_mu_eta = 0;
   trig_L1_mu_phi = 0;
   trig_L1_mu_thrName = 0;
   trig_L1_mu_thrNumber = 0;
   trig_L1_mu_RoINumber = 0;
   trig_L1_mu_sectorAddress = 0;
   trig_L1_mu_firstCandidate = 0;
   trig_L1_mu_moreCandInRoI = 0;
   trig_L1_mu_moreCandInSector = 0;
   trig_L1_mu_source = 0;
   trig_L1_mu_hemisphere = 0;
   trig_L1_mu_charge = 0;
   trig_L1_mu_vetoed = 0;
   trig_L2_combmuonfeature_pt = 0;
   trig_L2_combmuonfeature_eta = 0;
   trig_L2_combmuonfeature_phi = 0;
   trig_L2_combmuonfeature_sigma_pt = 0;
   trig_L2_combmuonfeature_L2_2mu10 = 0;
   trig_L2_combmuonfeature_L2_2mu10_empty = 0;
   trig_L2_combmuonfeature_L2_2mu10_loose = 0;
   trig_L2_combmuonfeature_L2_2mu10_loose_empty = 0;
   trig_L2_combmuonfeature_L2_2mu10_loose_noOvlpRm = 0;
   trig_L2_combmuonfeature_L2_2mu13_Zmumu_IDTrkNoCut = 0;
   trig_L2_combmuonfeature_L2_2mu4 = 0;
   trig_L2_combmuonfeature_L2_2mu4_Bmumu = 0;
   trig_L2_combmuonfeature_L2_2mu4_Bmumux = 0;
   trig_L2_combmuonfeature_L2_2mu4_DiMu = 0;
   trig_L2_combmuonfeature_L2_2mu4_DiMu_DY = 0;
   trig_L2_combmuonfeature_L2_2mu4_DiMu_DY20 = 0;
   trig_L2_combmuonfeature_L2_2mu4_DiMu_DY_noVtx_noOS = 0;
   trig_L2_combmuonfeature_L2_2mu4_DiMu_SiTrk = 0;
   trig_L2_combmuonfeature_L2_2mu4_DiMu_noVtx_noOS = 0;
   trig_L2_combmuonfeature_L2_2mu4_Jpsimumu = 0;
   trig_L2_combmuonfeature_L2_2mu4_Jpsimumu_IDTrkNoCut = 0;
   trig_L2_combmuonfeature_L2_2mu4_Upsimumu = 0;
   trig_L2_combmuonfeature_L2_2mu4i_DiMu_DY = 0;
   trig_L2_combmuonfeature_L2_2mu6 = 0;
   trig_L2_combmuonfeature_L2_2mu6_DiMu = 0;
   trig_L2_combmuonfeature_L2_2mu6_MSonly_g10_loose = 0;
   trig_L2_combmuonfeature_L2_2mu6_MSonly_g10_loose_nonfilled = 0;
   trig_L2_combmuonfeature_L2_2mu6_NL = 0;
   trig_L2_combmuonfeature_L2_mu0_cal_empty = 0;
   trig_L2_combmuonfeature_L2_mu0_empty_NoAlg = 0;
   trig_L2_combmuonfeature_L2_mu0_firstempty_NoAlg = 0;
   trig_L2_combmuonfeature_L2_mu0_unpaired_iso_NoAlg = 0;
   trig_L2_combmuonfeature_L2_mu10 = 0;
   trig_L2_combmuonfeature_L2_mu10_Jpsimumu = 0;
   trig_L2_combmuonfeature_L2_mu10_NL = 0;
   trig_L2_combmuonfeature_L2_mu10_Upsimumu_FS = 0;
   trig_L2_combmuonfeature_L2_mu10_Upsimumu_tight_FS = 0;
   trig_L2_combmuonfeature_L2_mu10_cal = 0;
   trig_L2_combmuonfeature_L2_mu10_cal_medium = 0;
   trig_L2_combmuonfeature_L2_mu10_loose = 0;
   trig_L2_combmuonfeature_L2_mu10_muCombTag_NoEF = 0;
   trig_L2_combmuonfeature_L2_mu11_empty_NoAlg = 0;
   trig_L2_combmuonfeature_L2_mu13 = 0;
   trig_L2_combmuonfeature_L2_mu13_MG = 0;
   trig_L2_combmuonfeature_L2_mu13_muCombTag_NoEF = 0;
   trig_L2_combmuonfeature_L2_mu15 = 0;
   trig_L2_combmuonfeature_L2_mu15_medium = 0;
   trig_L2_combmuonfeature_L2_mu15_tight = 0;
   trig_L2_combmuonfeature_L2_mu15_xe20_noMu = 0;
   trig_L2_combmuonfeature_L2_mu15i = 0;
   trig_L2_combmuonfeature_L2_mu15i_medium = 0;
   trig_L2_combmuonfeature_L2_mu18 = 0;
   trig_L2_combmuonfeature_L2_mu18_L1J10 = 0;
   trig_L2_combmuonfeature_L2_mu18_MG = 0;
   trig_L2_combmuonfeature_L2_mu18_MG_L1J10 = 0;
   trig_L2_combmuonfeature_L2_mu18_MG_medium = 0;
   trig_L2_combmuonfeature_L2_mu18_medium = 0;
   trig_L2_combmuonfeature_L2_mu20 = 0;
   trig_L2_combmuonfeature_L2_mu20_IDTrkNoCut = 0;
   trig_L2_combmuonfeature_L2_mu20_MG = 0;
   trig_L2_combmuonfeature_L2_mu20_MG_medium = 0;
   trig_L2_combmuonfeature_L2_mu20_empty = 0;
   trig_L2_combmuonfeature_L2_mu20_medium = 0;
   trig_L2_combmuonfeature_L2_mu20_muCombTag_NoEF = 0;
   trig_L2_combmuonfeature_L2_mu20_tight = 0;
   trig_L2_combmuonfeature_L2_mu20i = 0;
   trig_L2_combmuonfeature_L2_mu20i_medium = 0;
   trig_L2_combmuonfeature_L2_mu22 = 0;
   trig_L2_combmuonfeature_L2_mu22_MG = 0;
   trig_L2_combmuonfeature_L2_mu22_MG_medium = 0;
   trig_L2_combmuonfeature_L2_mu22_medium = 0;
   trig_L2_combmuonfeature_L2_mu24_MG_medium = 0;
   trig_L2_combmuonfeature_L2_mu24_MG_tight = 0;
   trig_L2_combmuonfeature_L2_mu24_medium = 0;
   trig_L2_combmuonfeature_L2_mu24_tight = 0;
   trig_L2_combmuonfeature_L2_mu30_MG_medium = 0;
   trig_L2_combmuonfeature_L2_mu30_MG_tight = 0;
   trig_L2_combmuonfeature_L2_mu30_medium = 0;
   trig_L2_combmuonfeature_L2_mu30_tight = 0;
   trig_L2_combmuonfeature_L2_mu4 = 0;
   trig_L2_combmuonfeature_L2_mu40_MSonly_barrel = 0;
   trig_L2_combmuonfeature_L2_mu40_MSonly_barrel_medium = 0;
   trig_L2_combmuonfeature_L2_mu40_MSonly_empty = 0;
   trig_L2_combmuonfeature_L2_mu40_MSonly_tight = 0;
   trig_L2_combmuonfeature_L2_mu40_MSonly_tight_L1MU11 = 0;
   trig_L2_combmuonfeature_L2_mu40_MSonly_tighter = 0;
   trig_L2_combmuonfeature_L2_mu40_slow = 0;
   trig_L2_combmuonfeature_L2_mu40_slow_empty = 0;
   trig_L2_combmuonfeature_L2_mu40_slow_medium = 0;
   trig_L2_combmuonfeature_L2_mu40_slow_outOfTime = 0;
   trig_L2_combmuonfeature_L2_mu40_slow_outOfTime_medium = 0;
   trig_L2_combmuonfeature_L2_mu4_DiMu = 0;
   trig_L2_combmuonfeature_L2_mu4_DiMu_FS_noOS = 0;
   trig_L2_combmuonfeature_L2_mu4_Jpsimumu = 0;
   trig_L2_combmuonfeature_L2_mu4_L1J10_matched = 0;
   trig_L2_combmuonfeature_L2_mu4_L1J15_matched = 0;
   trig_L2_combmuonfeature_L2_mu4_L1J20_matched = 0;
   trig_L2_combmuonfeature_L2_mu4_L1J30_matched = 0;
   trig_L2_combmuonfeature_L2_mu4_L1J50_matched = 0;
   trig_L2_combmuonfeature_L2_mu4_L1J75_matched = 0;
   trig_L2_combmuonfeature_L2_mu4_L1MU11_MSonly_cosmic = 0;
   trig_L2_combmuonfeature_L2_mu4_L1MU11_cosmic = 0;
   trig_L2_combmuonfeature_L2_mu4_MSonly_cosmic = 0;
   trig_L2_combmuonfeature_L2_mu4_Trk_Jpsi = 0;
   trig_L2_combmuonfeature_L2_mu4_Trk_Upsi_FS = 0;
   trig_L2_combmuonfeature_L2_mu4_Upsimumu_FS = 0;
   trig_L2_combmuonfeature_L2_mu4_Upsimumu_SiTrk_FS = 0;
   trig_L2_combmuonfeature_L2_mu4_Upsimumu_tight_FS = 0;
   trig_L2_combmuonfeature_L2_mu4_cosmic = 0;
   trig_L2_combmuonfeature_L2_mu4_j10_a4tc_EFFS = 0;
   trig_L2_combmuonfeature_L2_mu4_j40_xe20_loose_noMu = 0;
   trig_L2_combmuonfeature_L2_mu4_j95_L1matched = 0;
   trig_L2_combmuonfeature_L2_mu4imu6i_DiMu_DY = 0;
   trig_L2_combmuonfeature_L2_mu4imu6i_DiMu_DY14_noVtx_noOS = 0;
   trig_L2_combmuonfeature_L2_mu4mu6_Bmumu = 0;
   trig_L2_combmuonfeature_L2_mu4mu6_Bmumux = 0;
   trig_L2_combmuonfeature_L2_mu4mu6_DiMu = 0;
   trig_L2_combmuonfeature_L2_mu4mu6_DiMu_DY20 = 0;
   trig_L2_combmuonfeature_L2_mu4mu6_DiMu_noVtx_noOS = 0;
   trig_L2_combmuonfeature_L2_mu4mu6_Jpsimumu = 0;
   trig_L2_combmuonfeature_L2_mu4mu6_Upsimumu = 0;
   trig_L2_combmuonfeature_L2_mu6 = 0;
   trig_L2_combmuonfeature_L2_mu6_DiMu_noOS = 0;
   trig_L2_combmuonfeature_L2_mu6_Jpsimumu = 0;
   trig_L2_combmuonfeature_L2_mu6_Jpsimumu_SiTrk = 0;
   trig_L2_combmuonfeature_L2_mu6_Jpsimumu_tight = 0;
   trig_L2_combmuonfeature_L2_mu6_Trk_Jpsi_loose = 0;
   trig_L2_combmuonfeature_mf_pt = 0;
   trig_L2_combmuonfeature_mf_eta = 0;
   trig_L2_combmuonfeature_mf_phi = 0;
   trig_L2_combmuonfeature_mf_mf = 0;
   trig_L2_combmuonfeature_idtrk_algorithmId = 0;
   trig_L2_combmuonfeature_idtrk_trackStatus = 0;
   trig_L2_combmuonfeature_idtrk_chi2Ndof = 0;
   trig_L2_combmuonfeature_idtrk_nStrawHits = 0;
   trig_L2_combmuonfeature_idtrk_nHighThrHits = 0;
   trig_L2_combmuonfeature_idtrk_nPixelSpacePoints = 0;
   trig_L2_combmuonfeature_idtrk_nSCT_SpacePoints = 0;
   trig_L2_combmuonfeature_idtrk_idtrkfitpar_a0 = 0;
   trig_L2_combmuonfeature_idtrk_idtrkfitpar_z0 = 0;
   trig_L2_combmuonfeature_idtrk_idtrkfitpar_phi0 = 0;
   trig_L2_combmuonfeature_idtrk_idtrkfitpar_eta = 0;
   trig_L2_combmuonfeature_idtrk_idtrkfitpar_pt = 0;
   trig_L2_combmuonfeature_idtrk_idtrkfitpar_hasidtrkfitpar = 0;
   trig_L2_combmuonfeature_idtrk_hasidtrk = 0;
   trig_EF_trigmuonef_EF_2mu10 = 0;
   trig_EF_trigmuonef_EF_2mu10_empty = 0;
   trig_EF_trigmuonef_EF_2mu10_loose = 0;
   trig_EF_trigmuonef_EF_2mu10_loose_empty = 0;
   trig_EF_trigmuonef_EF_2mu10_loose_noOvlpRm = 0;
   trig_EF_trigmuonef_EF_2mu13_Zmumu_IDTrkNoCut = 0;
   trig_EF_trigmuonef_EF_2mu4 = 0;
   trig_EF_trigmuonef_EF_2mu4_Bmumu = 0;
   trig_EF_trigmuonef_EF_2mu4_Bmumux = 0;
   trig_EF_trigmuonef_EF_2mu4_DiMu = 0;
   trig_EF_trigmuonef_EF_2mu4_DiMu_DY = 0;
   trig_EF_trigmuonef_EF_2mu4_DiMu_DY20 = 0;
   trig_EF_trigmuonef_EF_2mu4_DiMu_DY_noVtx_noOS = 0;
   trig_EF_trigmuonef_EF_2mu4_DiMu_SiTrk = 0;
   trig_EF_trigmuonef_EF_2mu4_DiMu_noVtx_noOS = 0;
   trig_EF_trigmuonef_EF_2mu4_Jpsimumu = 0;
   trig_EF_trigmuonef_EF_2mu4_Jpsimumu_IDTrkNoCut = 0;
   trig_EF_trigmuonef_EF_2mu4_Upsimumu = 0;
   trig_EF_trigmuonef_EF_2mu4i_DiMu_DY = 0;
   trig_EF_trigmuonef_EF_2mu6 = 0;
   trig_EF_trigmuonef_EF_2mu6_DiMu = 0;
   trig_EF_trigmuonef_EF_2mu6_MSonly_g10_loose = 0;
   trig_EF_trigmuonef_EF_2mu6_MSonly_g10_loose_nonfilled = 0;
   trig_EF_trigmuonef_EF_2mu6_NL = 0;
   trig_EF_trigmuonef_EF_mu0_empty_NoAlg = 0;
   trig_EF_trigmuonef_EF_mu0_firstempty_NoAlg = 0;
   trig_EF_trigmuonef_EF_mu0_unpaired_iso_NoAlg = 0;
   trig_EF_trigmuonef_EF_mu10 = 0;
   trig_EF_trigmuonef_EF_mu10_Jpsimumu = 0;
   trig_EF_trigmuonef_EF_mu10_NL = 0;
   trig_EF_trigmuonef_EF_mu10_Upsimumu_FS = 0;
   trig_EF_trigmuonef_EF_mu10_Upsimumu_tight_FS = 0;
   trig_EF_trigmuonef_EF_mu10_loose = 0;
   trig_EF_trigmuonef_EF_mu10_muCombTag_NoEF = 0;
   trig_EF_trigmuonef_EF_mu11_empty_NoAlg = 0;
   trig_EF_trigmuonef_EF_mu13 = 0;
   trig_EF_trigmuonef_EF_mu13_MG = 0;
   trig_EF_trigmuonef_EF_mu13_muCombTag_NoEF = 0;
   trig_EF_trigmuonef_EF_mu15 = 0;
   trig_EF_trigmuonef_EF_mu15_mu10_EFFS = 0;
   trig_EF_trigmuonef_EF_mu15_mu10_EFFS_medium = 0;
   trig_EF_trigmuonef_EF_mu15_mu10_EFFS_tight = 0;
   trig_EF_trigmuonef_EF_mu15_xe30_noMu = 0;
   trig_EF_trigmuonef_EF_mu15i = 0;
   trig_EF_trigmuonef_EF_mu15i_medium = 0;
   trig_EF_trigmuonef_EF_mu18 = 0;
   trig_EF_trigmuonef_EF_mu18_L1J10 = 0;
   trig_EF_trigmuonef_EF_mu18_MG = 0;
   trig_EF_trigmuonef_EF_mu18_MG_L1J10 = 0;
   trig_EF_trigmuonef_EF_mu18_MG_medium = 0;
   trig_EF_trigmuonef_EF_mu18_medium = 0;
   trig_EF_trigmuonef_EF_mu20 = 0;
   trig_EF_trigmuonef_EF_mu20_IDTrkNoCut = 0;
   trig_EF_trigmuonef_EF_mu20_IDTrkNoCut_ManyVx = 0;
   trig_EF_trigmuonef_EF_mu20_MG = 0;
   trig_EF_trigmuonef_EF_mu20_MG_medium = 0;
   trig_EF_trigmuonef_EF_mu20_empty = 0;
   trig_EF_trigmuonef_EF_mu20_medium = 0;
   trig_EF_trigmuonef_EF_mu20_mu10_EFFS_tight = 0;
   trig_EF_trigmuonef_EF_mu20_muCombTag_NoEF = 0;
   trig_EF_trigmuonef_EF_mu20i = 0;
   trig_EF_trigmuonef_EF_mu20i_medium = 0;
   trig_EF_trigmuonef_EF_mu22 = 0;
   trig_EF_trigmuonef_EF_mu22_MG = 0;
   trig_EF_trigmuonef_EF_mu22_MG_medium = 0;
   trig_EF_trigmuonef_EF_mu22_medium = 0;
   trig_EF_trigmuonef_EF_mu24_MG_medium = 0;
   trig_EF_trigmuonef_EF_mu24_MG_tight = 0;
   trig_EF_trigmuonef_EF_mu24_medium = 0;
   trig_EF_trigmuonef_EF_mu24_tight = 0;
   trig_EF_trigmuonef_EF_mu30_MG_medium = 0;
   trig_EF_trigmuonef_EF_mu30_MG_tight = 0;
   trig_EF_trigmuonef_EF_mu30_medium = 0;
   trig_EF_trigmuonef_EF_mu30_tight = 0;
   trig_EF_trigmuonef_EF_mu4 = 0;
   trig_EF_trigmuonef_EF_mu40_MSonly_barrel = 0;
   trig_EF_trigmuonef_EF_mu40_MSonly_barrel_medium = 0;
   trig_EF_trigmuonef_EF_mu40_MSonly_empty = 0;
   trig_EF_trigmuonef_EF_mu40_MSonly_tight = 0;
   trig_EF_trigmuonef_EF_mu40_MSonly_tight_L1MU11 = 0;
   trig_EF_trigmuonef_EF_mu40_MSonly_tighter = 0;
   trig_EF_trigmuonef_EF_mu40_slow = 0;
   trig_EF_trigmuonef_EF_mu40_slow_empty = 0;
   trig_EF_trigmuonef_EF_mu40_slow_medium = 0;
   trig_EF_trigmuonef_EF_mu40_slow_outOfTime = 0;
   trig_EF_trigmuonef_EF_mu40_slow_outOfTime_medium = 0;
   trig_EF_trigmuonef_EF_mu4_DiMu = 0;
   trig_EF_trigmuonef_EF_mu4_DiMu_FS_noOS = 0;
   trig_EF_trigmuonef_EF_mu4_Jpsimumu = 0;
   trig_EF_trigmuonef_EF_mu4_L1J10_matched = 0;
   trig_EF_trigmuonef_EF_mu4_L1J15_matched = 0;
   trig_EF_trigmuonef_EF_mu4_L1J20_matched = 0;
   trig_EF_trigmuonef_EF_mu4_L1J30_matched = 0;
   trig_EF_trigmuonef_EF_mu4_L1J50_matched = 0;
   trig_EF_trigmuonef_EF_mu4_L1J75_matched = 0;
   trig_EF_trigmuonef_EF_mu4_L1MU11_MSonly_cosmic = 0;
   trig_EF_trigmuonef_EF_mu4_L1MU11_cosmic = 0;
   trig_EF_trigmuonef_EF_mu4_MSonly_cosmic = 0;
   trig_EF_trigmuonef_EF_mu4_Trk_Jpsi = 0;
   trig_EF_trigmuonef_EF_mu4_Trk_Upsi_FS = 0;
   trig_EF_trigmuonef_EF_mu4_Upsimumu_FS = 0;
   trig_EF_trigmuonef_EF_mu4_Upsimumu_SiTrk_FS = 0;
   trig_EF_trigmuonef_EF_mu4_Upsimumu_tight_FS = 0;
   trig_EF_trigmuonef_EF_mu4_cosmic = 0;
   trig_EF_trigmuonef_EF_mu4_j10_a4tc_EFFS = 0;
   trig_EF_trigmuonef_EF_mu4_j10_a4tc_EFFS_matched = 0;
   trig_EF_trigmuonef_EF_mu4_j135_a4tc_EFFS_L1matched = 0;
   trig_EF_trigmuonef_EF_mu4_j180_a4tc_EFFS_L1matched = 0;
   trig_EF_trigmuonef_EF_mu4_j45_a4tc_EFFS_xe45_loose_noMu = 0;
   trig_EF_trigmuonef_EF_mu4imu6i_DiMu_DY = 0;
   trig_EF_trigmuonef_EF_mu4imu6i_DiMu_DY14_noVtx_noOS = 0;
   trig_EF_trigmuonef_EF_mu4mu6_Bmumu = 0;
   trig_EF_trigmuonef_EF_mu4mu6_Bmumux = 0;
   trig_EF_trigmuonef_EF_mu4mu6_DiMu = 0;
   trig_EF_trigmuonef_EF_mu4mu6_DiMu_DY20 = 0;
   trig_EF_trigmuonef_EF_mu4mu6_DiMu_noVtx_noOS = 0;
   trig_EF_trigmuonef_EF_mu4mu6_Jpsimumu = 0;
   trig_EF_trigmuonef_EF_mu4mu6_Upsimumu = 0;
   trig_EF_trigmuonef_EF_mu6 = 0;
   trig_EF_trigmuonef_EF_mu6_DiMu_noOS = 0;
   trig_EF_trigmuonef_EF_mu6_Jpsimumu = 0;
   trig_EF_trigmuonef_EF_mu6_Jpsimumu_SiTrk = 0;
   trig_EF_trigmuonef_EF_mu6_Jpsimumu_tight = 0;
   trig_EF_trigmuonef_EF_mu6_Trk_Jpsi_loose = 0;
   trig_EF_trigmuonef_track_n = 0;
   trig_EF_trigmuonef_track_MuonType = 0;
   trig_EF_trigmuonef_track_MS_pt = 0;
   trig_EF_trigmuonef_track_MS_eta = 0;
   trig_EF_trigmuonef_track_MS_phi = 0;
   trig_EF_trigmuonef_track_MS_charge = 0;
   trig_EF_trigmuonef_track_MS_d0 = 0;
   trig_EF_trigmuonef_track_MS_z0 = 0;
   trig_EF_trigmuonef_track_MS_chi2 = 0;
   trig_EF_trigmuonef_track_MS_chi2prob = 0;
   trig_EF_trigmuonef_track_MS_posX = 0;
   trig_EF_trigmuonef_track_MS_posY = 0;
   trig_EF_trigmuonef_track_MS_posZ = 0;
   trig_EF_trigmuonef_track_MS_hasMS = 0;
   trig_EF_trigmuonef_track_SA_pt = 0;
   trig_EF_trigmuonef_track_SA_eta = 0;
   trig_EF_trigmuonef_track_SA_phi = 0;
   trig_EF_trigmuonef_track_SA_charge = 0;
   trig_EF_trigmuonef_track_SA_d0 = 0;
   trig_EF_trigmuonef_track_SA_z0 = 0;
   trig_EF_trigmuonef_track_SA_chi2 = 0;
   trig_EF_trigmuonef_track_SA_chi2prob = 0;
   trig_EF_trigmuonef_track_SA_posX = 0;
   trig_EF_trigmuonef_track_SA_posY = 0;
   trig_EF_trigmuonef_track_SA_posZ = 0;
   trig_EF_trigmuonef_track_SA_hasSA = 0;
   trig_EF_trigmuonef_track_CB_pt = 0;
   trig_EF_trigmuonef_track_CB_eta = 0;
   trig_EF_trigmuonef_track_CB_phi = 0;
   trig_EF_trigmuonef_track_CB_charge = 0;
   trig_EF_trigmuonef_track_CB_d0 = 0;
   trig_EF_trigmuonef_track_CB_z0 = 0;
   trig_EF_trigmuonef_track_CB_chi2 = 0;
   trig_EF_trigmuonef_track_CB_chi2prob = 0;
   trig_EF_trigmuonef_track_CB_posX = 0;
   trig_EF_trigmuonef_track_CB_posY = 0;
   trig_EF_trigmuonef_track_CB_posZ = 0;
   trig_EF_trigmuonef_track_CB_matchChi2 = 0;
   trig_EF_trigmuonef_track_CB_hasCB = 0;
   trig_L1_esum_thrNames = 0;
   trig_L2_met_nameOfComponent = 0;
   trig_L2_met_MExComponent = 0;
   trig_L2_met_MEyComponent = 0;
   trig_L2_met_MEzComponent = 0;
   trig_L2_met_sumEtComponent = 0;
   trig_L2_met_sumEComponent = 0;
   trig_L2_met_componentCalib0 = 0;
   trig_L2_met_componentCalib1 = 0;
   trig_L2_met_sumOfSigns = 0;
   trig_L2_met_usedChannels = 0;
   trig_L2_met_status = 0;
   trig_EF_met_nameOfComponent = 0;
   trig_EF_met_MExComponent = 0;
   trig_EF_met_MEyComponent = 0;
   trig_EF_met_MEzComponent = 0;
   trig_EF_met_sumEtComponent = 0;
   trig_EF_met_sumEComponent = 0;
   trig_EF_met_componentCalib0 = 0;
   trig_EF_met_componentCalib1 = 0;
   trig_EF_met_sumOfSigns = 0;
   trig_EF_met_usedChannels = 0;
   trig_EF_met_status = 0;
   trig_L1_emtau_eta = 0;
   trig_L1_emtau_phi = 0;
   trig_L1_emtau_thrNames = 0;
   trig_L1_emtau_thrValues = 0;
   trig_L1_emtau_core = 0;
   trig_L1_emtau_EMClus = 0;
   trig_L1_emtau_tauClus = 0;
   trig_L1_emtau_EMIsol = 0;
   trig_L1_emtau_hadIsol = 0;
   trig_L1_emtau_hadCore = 0;
   trig_L1_emtau_thrPattern = 0;
   trig_L1_emtau_L1_2EM10 = 0;
   trig_L1_emtau_L1_2EM14 = 0;
   trig_L1_emtau_L1_2EM3 = 0;
   trig_L1_emtau_L1_2EM3_EM12 = 0;
   trig_L1_emtau_L1_2EM3_EM7 = 0;
   trig_L1_emtau_L1_2EM5 = 0;
   trig_L1_emtau_L1_2EM5_EM10 = 0;
   trig_L1_emtau_L1_2EM5_MU6 = 0;
   trig_L1_emtau_L1_2EM5_NL = 0;
   trig_L1_emtau_L1_2EM7 = 0;
   trig_L1_emtau_L1_2EM7_EM10 = 0;
   trig_L1_emtau_L1_EM10 = 0;
   trig_L1_emtau_L1_EM10_MU6 = 0;
   trig_L1_emtau_L1_EM10_XE20 = 0;
   trig_L1_emtau_L1_EM10_XE30 = 0;
   trig_L1_emtau_L1_EM10_XS45 = 0;
   trig_L1_emtau_L1_EM10_XS50 = 0;
   trig_L1_emtau_L1_EM12 = 0;
   trig_L1_emtau_L1_EM14 = 0;
   trig_L1_emtau_L1_EM14_XE10 = 0;
   trig_L1_emtau_L1_EM14_XE20 = 0;
   trig_L1_emtau_L1_EM16 = 0;
   trig_L1_emtau_L1_EM3 = 0;
   trig_L1_emtau_L1_EM30 = 0;
   trig_L1_emtau_L1_EM3_EMPTY = 0;
   trig_L1_emtau_L1_EM3_FIRSTEMPTY = 0;
   trig_L1_emtau_L1_EM3_MU0 = 0;
   trig_L1_emtau_L1_EM3_MU6 = 0;
   trig_L1_emtau_L1_EM3_UNPAIRED_ISO = 0;
   trig_L1_emtau_L1_EM3_UNPAIRED_NONISO = 0;
   trig_L1_emtau_L1_EM5 = 0;
   trig_L1_emtau_L1_EM5_2MU6 = 0;
   trig_L1_emtau_L1_EM5_EMPTY = 0;
   trig_L1_emtau_L1_EM5_MU10 = 0;
   trig_L1_emtau_L1_EM5_MU6 = 0;
   trig_L1_emtau_L1_EM7 = 0;
   trig_L2_el_E = 0;
   trig_L2_el_Et = 0;
   trig_L2_el_pt = 0;
   trig_L2_el_eta = 0;
   trig_L2_el_phi = 0;
   trig_L2_el_RoIWord = 0;
   trig_L2_el_zvertex = 0;
   trig_L2_el_charge = 0;
   trig_L2_el_L2_2e10_medium = 0;
   trig_L2_el_L2_2e10_medium_mu6 = 0;
   trig_L2_el_L2_2e12T_medium = 0;
   trig_L2_el_L2_2e12_medium = 0;
   trig_L2_el_L2_2e15_medium = 0;
   trig_L2_el_L2_2e5_tight = 0;
   trig_L2_el_L2_2e5_tight_Jpsi = 0;
   trig_L2_el_L2_e10_medium = 0;
   trig_L2_el_L2_e10_medium_2mu6 = 0;
   trig_L2_el_L2_e10_medium_mu10 = 0;
   trig_L2_el_L2_e10_medium_mu6 = 0;
   trig_L2_el_L2_e10_medium_mu6_topo_medium = 0;
   trig_L2_el_L2_e11T_medium = 0;
   trig_L2_el_L2_e11T_medium_2e6T_medium = 0;
   trig_L2_el_L2_e11_etcut = 0;
   trig_L2_el_L2_e12T_medium_mu6_topo_medium = 0;
   trig_L2_el_L2_e12_medium = 0;
   trig_L2_el_L2_e13_etcut_xs45_noMu = 0;
   trig_L2_el_L2_e15_HLTtighter = 0;
   trig_L2_el_L2_e15_medium = 0;
   trig_L2_el_L2_e15_medium_e12_medium = 0;
   trig_L2_el_L2_e15_medium_xe20_noMu = 0;
   trig_L2_el_L2_e15_medium_xe30_noMu = 0;
   trig_L2_el_L2_e15_medium_xe35_noMu = 0;
   trig_L2_el_L2_e15_tight = 0;
   trig_L2_el_L2_e20_etcut_xs45_noMu = 0;
   trig_L2_el_L2_e20_loose = 0;
   trig_L2_el_L2_e20_loose1 = 0;
   trig_L2_el_L2_e20_looseTrk = 0;
   trig_L2_el_L2_e20_medium = 0;
   trig_L2_el_L2_e20_medium1 = 0;
   trig_L2_el_L2_e20_medium2 = 0;
   trig_L2_el_L2_e20_medium_IDTrkNoCut = 0;
   trig_L2_el_L2_e20_medium_SiTrk = 0;
   trig_L2_el_L2_e20_medium_TRT = 0;
   trig_L2_el_L2_e20_tight_e15_NoCut_Zee = 0;
   trig_L2_el_L2_e22_etcut_xs45_noMu = 0;
   trig_L2_el_L2_e22_loose = 0;
   trig_L2_el_L2_e22_loose1 = 0;
   trig_L2_el_L2_e22_looseTrk = 0;
   trig_L2_el_L2_e22_medium = 0;
   trig_L2_el_L2_e22_medium1 = 0;
   trig_L2_el_L2_e22_medium2 = 0;
   trig_L2_el_L2_e22_medium_IDTrkNoCut = 0;
   trig_L2_el_L2_e22_medium_SiTrk = 0;
   trig_L2_el_L2_e22_medium_TRT = 0;
   trig_L2_el_L2_e33_medium = 0;
   trig_L2_el_L2_e35_medium = 0;
   trig_L2_el_L2_e40_medium = 0;
   trig_L2_el_L2_e45_medium = 0;
   trig_L2_el_L2_e45_medium1 = 0;
   trig_L2_el_L2_e5_medium_mu6 = 0;
   trig_L2_el_L2_e5_medium_mu6_topo_medium = 0;
   trig_L2_el_L2_e5_tight = 0;
   trig_L2_el_L2_e5_tight_e14_etcut_Jpsi = 0;
   trig_L2_el_L2_e5_tight_e4_etcut_Jpsi = 0;
   trig_L2_el_L2_e5_tight_e4_etcut_Jpsi_SiTrk = 0;
   trig_L2_el_L2_e5_tight_e4_etcut_Jpsi_TRT = 0;
   trig_L2_el_L2_e5_tight_e5_NoCut = 0;
   trig_L2_el_L2_e5_tight_e9_etcut_Jpsi = 0;
   trig_L2_el_L2_e60_loose = 0;
   trig_L2_el_L2_e6T_medium = 0;
   trig_L2_el_L2_e7_tight_e14_etcut_Jpsi = 0;
   trig_L2_el_L2_e9_tight_e5_tight_Jpsi = 0;
   trig_L2_el_L2_eb_physics = 0;
   trig_L2_el_L2_eb_physics_empty = 0;
   trig_L2_el_L2_eb_physics_firstempty = 0;
   trig_L2_el_L2_eb_physics_noL1PS = 0;
   trig_L2_el_L2_eb_physics_unpaired_iso = 0;
   trig_L2_el_L2_eb_physics_unpaired_noniso = 0;
   trig_L2_el_L2_eb_random = 0;
   trig_L2_el_L2_eb_random_empty = 0;
   trig_L2_el_L2_eb_random_firstempty = 0;
   trig_L2_el_L2_eb_random_unpaired_iso = 0;
   trig_L2_el_L2_em3_empty_larcalib = 0;
   trig_L2_el_L2_em5_empty_larcalib = 0;
   trig_L2_ph_E = 0;
   trig_L2_ph_Et = 0;
   trig_L2_ph_pt = 0;
   trig_L2_ph_eta = 0;
   trig_L2_ph_phi = 0;
   trig_L2_ph_RoIWord = 0;
   trig_L2_ph_L2_2g15_loose = 0;
   trig_L2_ph_L2_2g20_loose = 0;
   trig_L2_ph_L2_g100_etcut_g50_etcut = 0;
   trig_L2_ph_L2_g10_NoCut_cosmic = 0;
   trig_L2_ph_L2_g11_etcut = 0;
   trig_L2_ph_L2_g150_etcut = 0;
   trig_L2_ph_L2_g15_loose = 0;
   trig_L2_ph_L2_g20_etcut = 0;
   trig_L2_ph_L2_g20_etcut_xe30_noMu = 0;
   trig_L2_ph_L2_g20_loose = 0;
   trig_L2_ph_L2_g40_loose = 0;
   trig_L2_ph_L2_g40_loose_EFxe40_noMu = 0;
   trig_L2_ph_L2_g40_loose_xe30_medium_noMu = 0;
   trig_L2_ph_L2_g40_loose_xe35_medium_noMu = 0;
   trig_L2_ph_L2_g40_tight = 0;
   trig_L2_ph_L2_g40_tight_b10_medium = 0;
   trig_L2_ph_L2_g5_NoCut_cosmic = 0;
   trig_L2_ph_L2_g60_loose = 0;
   trig_L2_ph_L2_g80_loose = 0;
   trig_L2_jet_E = 0;
   trig_L2_jet_eta = 0;
   trig_L2_jet_phi = 0;
   trig_L2_jet_RoIWord = 0;
   trig_EF_el_E = 0;
   trig_EF_el_Et = 0;
   trig_EF_el_pt = 0;
   trig_EF_el_m = 0;
   trig_EF_el_eta = 0;
   trig_EF_el_phi = 0;
   trig_EF_el_px = 0;
   trig_EF_el_py = 0;
   trig_EF_el_pz = 0;
   trig_EF_el_charge = 0;
   trig_EF_el_author = 0;
   trig_EF_el_isEM = 0;
   trig_EF_el_loose = 0;
   trig_EF_el_looseIso = 0;
   trig_EF_el_medium = 0;
   trig_EF_el_mediumIso = 0;
   trig_EF_el_mediumWithoutTrack = 0;
   trig_EF_el_mediumIsoWithoutTrack = 0;
   trig_EF_el_tight = 0;
   trig_EF_el_tightIso = 0;
   trig_EF_el_tightWithoutTrack = 0;
   trig_EF_el_tightIsoWithoutTrack = 0;
   trig_EF_el_loosePP = 0;
   trig_EF_el_loosePPIso = 0;
   trig_EF_el_mediumPP = 0;
   trig_EF_el_mediumPPIso = 0;
   trig_EF_el_tightPP = 0;
   trig_EF_el_tightPPIso = 0;
   trig_EF_el_EF_2e10_medium = 0;
   trig_EF_el_EF_2e10_medium_mu6 = 0;
   trig_EF_el_EF_2e12T_medium = 0;
   trig_EF_el_EF_2e12_medium = 0;
   trig_EF_el_EF_2e15_medium = 0;
   trig_EF_el_EF_2e5_tight = 0;
   trig_EF_el_EF_2e5_tight_Jpsi = 0;
   trig_EF_el_EF_e10_medium = 0;
   trig_EF_el_EF_e10_medium_2mu6 = 0;
   trig_EF_el_EF_e10_medium_mu10 = 0;
   trig_EF_el_EF_e10_medium_mu6 = 0;
   trig_EF_el_EF_e10_medium_mu6_topo_medium = 0;
   trig_EF_el_EF_e11T_medium = 0;
   trig_EF_el_EF_e11T_medium_2e6T_medium = 0;
   trig_EF_el_EF_e11_etcut = 0;
   trig_EF_el_EF_e12T_medium_mu6_topo_medium = 0;
   trig_EF_el_EF_e12_medium = 0;
   trig_EF_el_EF_e13_etcut_xs60_noMu = 0;
   trig_EF_el_EF_e13_etcut_xs60_noMu_dphi2j10xe07 = 0;
   trig_EF_el_EF_e13_etcut_xs70_noMu = 0;
   trig_EF_el_EF_e15_HLTtighter = 0;
   trig_EF_el_EF_e15_medium = 0;
   trig_EF_el_EF_e15_medium_e12_medium = 0;
   trig_EF_el_EF_e15_medium_xe30_noMu = 0;
   trig_EF_el_EF_e15_medium_xe40_noMu = 0;
   trig_EF_el_EF_e15_medium_xe50_noMu = 0;
   trig_EF_el_EF_e15_tight = 0;
   trig_EF_el_EF_e20_etcut_xs60_noMu = 0;
   trig_EF_el_EF_e20_etcut_xs60_noMu_dphi2j10xe07 = 0;
   trig_EF_el_EF_e20_loose = 0;
   trig_EF_el_EF_e20_loose1 = 0;
   trig_EF_el_EF_e20_looseTrk = 0;
   trig_EF_el_EF_e20_medium = 0;
   trig_EF_el_EF_e20_medium1 = 0;
   trig_EF_el_EF_e20_medium2 = 0;
   trig_EF_el_EF_e20_medium_IDTrkNoCut = 0;
   trig_EF_el_EF_e20_medium_SiTrk = 0;
   trig_EF_el_EF_e20_medium_TRT = 0;
   trig_EF_el_EF_e20_tight_e15_NoCut_Zee = 0;
   trig_EF_el_EF_e22_etcut_xs60_noMu = 0;
   trig_EF_el_EF_e22_etcut_xs60_noMu_dphi2j10xe07 = 0;
   trig_EF_el_EF_e22_loose = 0;
   trig_EF_el_EF_e22_loose1 = 0;
   trig_EF_el_EF_e22_looseTrk = 0;
   trig_EF_el_EF_e22_medium = 0;
   trig_EF_el_EF_e22_medium1 = 0;
   trig_EF_el_EF_e22_medium2 = 0;
   trig_EF_el_EF_e22_medium_IDTrkNoCut = 0;
   trig_EF_el_EF_e22_medium_SiTrk = 0;
   trig_EF_el_EF_e22_medium_TRT = 0;
   trig_EF_el_EF_e33_medium = 0;
   trig_EF_el_EF_e35_medium = 0;
   trig_EF_el_EF_e40_medium = 0;
   trig_EF_el_EF_e45_medium = 0;
   trig_EF_el_EF_e45_medium1 = 0;
   trig_EF_el_EF_e5_medium_mu6 = 0;
   trig_EF_el_EF_e5_medium_mu6_topo_medium = 0;
   trig_EF_el_EF_e5_tight = 0;
   trig_EF_el_EF_e5_tight_e14_etcut_Jpsi = 0;
   trig_EF_el_EF_e5_tight_e4_etcut_Jpsi = 0;
   trig_EF_el_EF_e5_tight_e4_etcut_Jpsi_SiTrk = 0;
   trig_EF_el_EF_e5_tight_e4_etcut_Jpsi_TRT = 0;
   trig_EF_el_EF_e5_tight_e5_NoCut = 0;
   trig_EF_el_EF_e5_tight_e9_etcut_Jpsi = 0;
   trig_EF_el_EF_e60_loose = 0;
   trig_EF_el_EF_e6T_medium = 0;
   trig_EF_el_EF_e7_tight_e14_etcut_Jpsi = 0;
   trig_EF_el_EF_e9_tight_e5_tight_Jpsi = 0;
   trig_EF_el_EF_eb_physics = 0;
   trig_EF_el_EF_eb_physics_empty = 0;
   trig_EF_el_EF_eb_physics_firstempty = 0;
   trig_EF_el_EF_eb_physics_noL1PS = 0;
   trig_EF_el_EF_eb_physics_unpaired_iso = 0;
   trig_EF_el_EF_eb_physics_unpaired_noniso = 0;
   trig_EF_el_EF_eb_random = 0;
   trig_EF_el_EF_eb_random_empty = 0;
   trig_EF_el_EF_eb_random_firstempty = 0;
   trig_EF_el_EF_eb_random_unpaired_iso = 0;
   trig_EF_el_vertweight = 0;
   trig_EF_el_hastrack = 0;
   trig_EF_ph_E = 0;
   trig_EF_ph_Et = 0;
   trig_EF_ph_pt = 0;
   trig_EF_ph_m = 0;
   trig_EF_ph_eta = 0;
   trig_EF_ph_phi = 0;
   trig_EF_ph_px = 0;
   trig_EF_ph_py = 0;
   trig_EF_ph_pz = 0;
   trig_EF_ph_EF_2g15_loose = 0;
   trig_EF_ph_EF_2g20_loose = 0;
   trig_EF_ph_EF_g100_etcut_g50_etcut = 0;
   trig_EF_ph_EF_g10_NoCut_cosmic = 0;
   trig_EF_ph_EF_g11_etcut = 0;
   trig_EF_ph_EF_g11_etcut_larcalib = 0;
   trig_EF_ph_EF_g150_etcut = 0;
   trig_EF_ph_EF_g15_loose = 0;
   trig_EF_ph_EF_g15_loose_larcalib = 0;
   trig_EF_ph_EF_g20_etcut = 0;
   trig_EF_ph_EF_g20_etcut_xe30_noMu = 0;
   trig_EF_ph_EF_g20_loose = 0;
   trig_EF_ph_EF_g20_loose_larcalib = 0;
   trig_EF_ph_EF_g40_loose = 0;
   trig_EF_ph_EF_g40_loose_EFxe40_noMu = 0;
   trig_EF_ph_EF_g40_loose_larcalib = 0;
   trig_EF_ph_EF_g40_loose_xe45_medium_noMu = 0;
   trig_EF_ph_EF_g40_loose_xe55_medium_noMu = 0;
   trig_EF_ph_EF_g40_tight = 0;
   trig_EF_ph_EF_g40_tight_b10_medium = 0;
   trig_EF_ph_EF_g5_NoCut_cosmic = 0;
   trig_EF_ph_EF_g60_loose = 0;
   trig_EF_ph_EF_g60_loose_larcalib = 0;
   trig_EF_ph_EF_g80_loose = 0;
   trig_EF_ph_EF_g80_loose_larcalib = 0;
   trig_EF_ph_author = 0;
   trig_EF_ph_isRecovered = 0;
   trig_EF_ph_isEM = 0;
   trig_EF_ph_convFlag = 0;
   trig_EF_ph_isConv = 0;
   trig_EF_ph_nConv = 0;
   trig_EF_ph_nSingleTrackConv = 0;
   trig_EF_ph_nDoubleTrackConv = 0;
   trig_EF_ph_loose = 0;
   trig_EF_ph_looseIso = 0;
   trig_EF_ph_tight = 0;
   trig_EF_ph_tightIso = 0;
   trig_EF_ph_looseAR = 0;
   trig_EF_ph_looseARIso = 0;
   trig_EF_ph_tightAR = 0;
   trig_EF_ph_tightARIso = 0;
   trig_EF_jet_emscale_E = 0;
   trig_EF_jet_emscale_pt = 0;
   trig_EF_jet_emscale_m = 0;
   trig_EF_jet_emscale_eta = 0;
   trig_EF_jet_emscale_phi = 0;
   trig_EF_jet_EF_2b10_medium_4j30_a4tc_EFFS = 0;
   trig_EF_jet_EF_2b10_medium_j75_j30_a4tc_EFFS = 0;
   trig_EF_jet_EF_3j100_a4tc_EFFS = 0;
   trig_EF_jet_EF_3j30_a4tc_EFFS = 0;
   trig_EF_jet_EF_3j40_a4tc_EFFS = 0;
   trig_EF_jet_EF_3j45_a4tc_EFFS = 0;
   trig_EF_jet_EF_3j75_a4tc_EFFS = 0;
   trig_EF_jet_EF_4j30_a4tc_EFFS = 0;
   trig_EF_jet_EF_4j40_a4tc_EFFS = 0;
   trig_EF_jet_EF_4j45_a4tc_EFFS = 0;
   trig_EF_jet_EF_4j55_a4tc_EFFS = 0;
   trig_EF_jet_EF_4j60_a4tc_EFFS = 0;
   trig_EF_jet_EF_5j30_a4tc_EFFS = 0;
   trig_EF_jet_EF_5j40_a4tc_EFFS = 0;
   trig_EF_jet_EF_5j45_a4tc_EFFS = 0;
   trig_EF_jet_EF_6j30_a4tc_EFFS = 0;
   trig_EF_jet_EF_b10_medium_4j30_a4tc_EFFS = 0;
   trig_EF_jet_EF_fj100_a4tc_EFFS = 0;
   trig_EF_jet_EF_fj10_a4tc_EFFS = 0;
   trig_EF_jet_EF_fj135_a4tc_EFFS = 0;
   trig_EF_jet_EF_fj15_a4tc_EFFS = 0;
   trig_EF_jet_EF_fj20_a4tc_EFFS = 0;
   trig_EF_jet_EF_fj30_a4tc_EFFS = 0;
   trig_EF_jet_EF_fj55_a4tc_EFFS = 0;
   trig_EF_jet_EF_fj75_a4tc_EFFS = 0;
   trig_EF_jet_EF_j100_a4tc_EFFS = 0;
   trig_EF_jet_EF_j10_a4tc_EFFS = 0;
   trig_EF_jet_EF_j135_a4tc_EFFS = 0;
   trig_EF_jet_EF_j15_a4tc_EFFS = 0;
   trig_EF_jet_EF_j180_a4tc_EFFS = 0;
   trig_EF_jet_EF_j20_a4tc_EFFS = 0;
   trig_EF_jet_EF_j240_a4tc_EFFS = 0;
   trig_EF_jet_EF_j30_a4tc_EFFS = 0;
   trig_EF_jet_EF_j30_fj30_a4tc_EFFS = 0;
   trig_EF_jet_EF_j320_a4tc_EFFS = 0;
   trig_EF_jet_EF_j40_a4tc_EFFS = 0;
   trig_EF_jet_EF_j40_fj40_a4tc_EFFS = 0;
   trig_EF_jet_EF_j425_a4tc_EFFS = 0;
   trig_EF_jet_EF_j55_a4tc_EFFS = 0;
   trig_EF_jet_EF_j55_fj55_a4tc_EFFS = 0;
   trig_EF_jet_EF_j75_a4tc_EFFS = 0;
   trig_EF_jet_EF_j75_fj75_a4tc_EFFS = 0;
   trig_EF_jet_EF_mu4_j10_a4tc_EFFS = 0;
   // Set branch addresses and branch pointers
   if (!tree) return;
   fChain = tree;
   fChain->SetMakeClass(1);

   fChain->SetBranchAddress("trig_DB_SMK", &trig_DB_SMK, &b_trig_DB_SMK);
   fChain->SetBranchAddress("trig_DB_L1PSK", &trig_DB_L1PSK, &b_trig_DB_L1PSK);
   fChain->SetBranchAddress("trig_DB_HLTPSK", &trig_DB_HLTPSK, &b_trig_DB_HLTPSK);
   fChain->SetBranchAddress("bunch_configID", &bunch_configID, &b_bunch_configID);
   fChain->SetBranchAddress("RunNumber", &RunNumber, &b_RunNumber);
   fChain->SetBranchAddress("EventNumber", &EventNumber, &b_EventNumber);
   fChain->SetBranchAddress("timestamp", &timestamp, &b_timestamp);
   fChain->SetBranchAddress("timestamp_ns", &timestamp_ns, &b_timestamp_ns);
   fChain->SetBranchAddress("lbn", &lbn, &b_lbn);
   fChain->SetBranchAddress("bcid", &bcid, &b_bcid);
   fChain->SetBranchAddress("detmask0", &detmask0, &b_detmask0);
   fChain->SetBranchAddress("detmask1", &detmask1, &b_detmask1);
   fChain->SetBranchAddress("actualIntPerXing", &actualIntPerXing, &b_actualIntPerXing);
   fChain->SetBranchAddress("averageIntPerXing", &averageIntPerXing, &b_averageIntPerXing);
   fChain->SetBranchAddress("pixelFlags", &pixelFlags, &b_pixelFlags);
   fChain->SetBranchAddress("sctFlags", &sctFlags, &b_sctFlags);
   fChain->SetBranchAddress("trtFlags", &trtFlags, &b_trtFlags);
   fChain->SetBranchAddress("larFlags", &larFlags, &b_larFlags);
   fChain->SetBranchAddress("tileFlags", &tileFlags, &b_tileFlags);
   fChain->SetBranchAddress("muonFlags", &muonFlags, &b_muonFlags);
   fChain->SetBranchAddress("fwdFlags", &fwdFlags, &b_fwdFlags);
   fChain->SetBranchAddress("coreFlags", &coreFlags, &b_coreFlags);
   fChain->SetBranchAddress("pixelError", &pixelError, &b_pixelError);
   fChain->SetBranchAddress("sctError", &sctError, &b_sctError);
   fChain->SetBranchAddress("trtError", &trtError, &b_trtError);
   fChain->SetBranchAddress("larError", &larError, &b_larError);
   fChain->SetBranchAddress("tileError", &tileError, &b_tileError);
   fChain->SetBranchAddress("muonError", &muonError, &b_muonError);
   fChain->SetBranchAddress("fwdError", &fwdError, &b_fwdError);
   fChain->SetBranchAddress("coreError", &coreError, &b_coreError);
   fChain->SetBranchAddress("el_n", &el_n, &b_el_n);
   fChain->SetBranchAddress("el_E", &el_E, &b_el_E);
   fChain->SetBranchAddress("el_Et", &el_Et, &b_el_Et);
   fChain->SetBranchAddress("el_pt", &el_pt, &b_el_pt);
   fChain->SetBranchAddress("el_m", &el_m, &b_el_m);
   fChain->SetBranchAddress("el_eta", &el_eta, &b_el_eta);
   fChain->SetBranchAddress("el_phi", &el_phi, &b_el_phi);
   fChain->SetBranchAddress("el_px", &el_px, &b_el_px);
   fChain->SetBranchAddress("el_py", &el_py, &b_el_py);
   fChain->SetBranchAddress("el_pz", &el_pz, &b_el_pz);
   fChain->SetBranchAddress("el_charge", &el_charge, &b_el_charge);
   fChain->SetBranchAddress("el_author", &el_author, &b_el_author);
   fChain->SetBranchAddress("el_isEM", &el_isEM, &b_el_isEM);
   fChain->SetBranchAddress("el_OQ", &el_OQ, &b_el_OQ);
   fChain->SetBranchAddress("el_convFlag", &el_convFlag, &b_el_convFlag);
   fChain->SetBranchAddress("el_isConv", &el_isConv, &b_el_isConv);
   fChain->SetBranchAddress("el_nConv", &el_nConv, &b_el_nConv);
   fChain->SetBranchAddress("el_nSingleTrackConv", &el_nSingleTrackConv, &b_el_nSingleTrackConv);
   fChain->SetBranchAddress("el_nDoubleTrackConv", &el_nDoubleTrackConv, &b_el_nDoubleTrackConv);
   fChain->SetBranchAddress("el_OQRecalc", &el_OQRecalc, &b_el_OQRecalc);
   fChain->SetBranchAddress("el_loose", &el_loose, &b_el_loose);
   fChain->SetBranchAddress("el_looseIso", &el_looseIso, &b_el_looseIso);
   fChain->SetBranchAddress("el_medium", &el_medium, &b_el_medium);
   fChain->SetBranchAddress("el_mediumIso", &el_mediumIso, &b_el_mediumIso);
   fChain->SetBranchAddress("el_mediumWithoutTrack", &el_mediumWithoutTrack, &b_el_mediumWithoutTrack);
   fChain->SetBranchAddress("el_mediumIsoWithoutTrack", &el_mediumIsoWithoutTrack, &b_el_mediumIsoWithoutTrack);
   fChain->SetBranchAddress("el_tight", &el_tight, &b_el_tight);
   fChain->SetBranchAddress("el_tightIso", &el_tightIso, &b_el_tightIso);
   fChain->SetBranchAddress("el_tightWithoutTrack", &el_tightWithoutTrack, &b_el_tightWithoutTrack);
   fChain->SetBranchAddress("el_tightIsoWithoutTrack", &el_tightIsoWithoutTrack, &b_el_tightIsoWithoutTrack);
   fChain->SetBranchAddress("el_loosePP", &el_loosePP, &b_el_loosePP);
   fChain->SetBranchAddress("el_loosePPIso", &el_loosePPIso, &b_el_loosePPIso);
   fChain->SetBranchAddress("el_mediumPP", &el_mediumPP, &b_el_mediumPP);
   fChain->SetBranchAddress("el_mediumPPIso", &el_mediumPPIso, &b_el_mediumPPIso);
   fChain->SetBranchAddress("el_tightPP", &el_tightPP, &b_el_tightPP);
   fChain->SetBranchAddress("el_tightPPIso", &el_tightPPIso, &b_el_tightPPIso);
   fChain->SetBranchAddress("el_goodOQ", &el_goodOQ, &b_el_goodOQ);
   fChain->SetBranchAddress("el_Ethad", &el_Ethad, &b_el_Ethad);
   fChain->SetBranchAddress("el_Ethad1", &el_Ethad1, &b_el_Ethad1);
   fChain->SetBranchAddress("el_f1", &el_f1, &b_el_f1);
   fChain->SetBranchAddress("el_f1core", &el_f1core, &b_el_f1core);
   fChain->SetBranchAddress("el_Emins1", &el_Emins1, &b_el_Emins1);
   fChain->SetBranchAddress("el_fside", &el_fside, &b_el_fside);
   fChain->SetBranchAddress("el_Emax2", &el_Emax2, &b_el_Emax2);
   fChain->SetBranchAddress("el_ws3", &el_ws3, &b_el_ws3);
   fChain->SetBranchAddress("el_wstot", &el_wstot, &b_el_wstot);
   fChain->SetBranchAddress("el_emaxs1", &el_emaxs1, &b_el_emaxs1);
   fChain->SetBranchAddress("el_deltaEs", &el_deltaEs, &b_el_deltaEs);
   fChain->SetBranchAddress("el_E233", &el_E233, &b_el_E233);
   fChain->SetBranchAddress("el_E237", &el_E237, &b_el_E237);
   fChain->SetBranchAddress("el_E277", &el_E277, &b_el_E277);
   fChain->SetBranchAddress("el_weta2", &el_weta2, &b_el_weta2);
   fChain->SetBranchAddress("el_f3", &el_f3, &b_el_f3);
   fChain->SetBranchAddress("el_f3core", &el_f3core, &b_el_f3core);
   fChain->SetBranchAddress("el_rphiallcalo", &el_rphiallcalo, &b_el_rphiallcalo);
   fChain->SetBranchAddress("el_Etcone45", &el_Etcone45, &b_el_Etcone45);
   fChain->SetBranchAddress("el_Etcone15", &el_Etcone15, &b_el_Etcone15);
   fChain->SetBranchAddress("el_Etcone20", &el_Etcone20, &b_el_Etcone20);
   fChain->SetBranchAddress("el_Etcone25", &el_Etcone25, &b_el_Etcone25);
   fChain->SetBranchAddress("el_Etcone30", &el_Etcone30, &b_el_Etcone30);
   fChain->SetBranchAddress("el_Etcone35", &el_Etcone35, &b_el_Etcone35);
   fChain->SetBranchAddress("el_Etcone40", &el_Etcone40, &b_el_Etcone40);
   fChain->SetBranchAddress("el_ptcone20", &el_ptcone20, &b_el_ptcone20);
   fChain->SetBranchAddress("el_ptcone30", &el_ptcone30, &b_el_ptcone30);
   fChain->SetBranchAddress("el_ptcone40", &el_ptcone40, &b_el_ptcone40);
   fChain->SetBranchAddress("el_nucone20", &el_nucone20, &b_el_nucone20);
   fChain->SetBranchAddress("el_nucone30", &el_nucone30, &b_el_nucone30);
   fChain->SetBranchAddress("el_nucone40", &el_nucone40, &b_el_nucone40);
   fChain->SetBranchAddress("el_Etcone15_pt_corrected", &el_Etcone15_pt_corrected, &b_el_Etcone15_pt_corrected);
   fChain->SetBranchAddress("el_Etcone20_pt_corrected", &el_Etcone20_pt_corrected, &b_el_Etcone20_pt_corrected);
   fChain->SetBranchAddress("el_Etcone25_pt_corrected", &el_Etcone25_pt_corrected, &b_el_Etcone25_pt_corrected);
   fChain->SetBranchAddress("el_Etcone30_pt_corrected", &el_Etcone30_pt_corrected, &b_el_Etcone30_pt_corrected);
   fChain->SetBranchAddress("el_Etcone35_pt_corrected", &el_Etcone35_pt_corrected, &b_el_Etcone35_pt_corrected);
   fChain->SetBranchAddress("el_Etcone40_pt_corrected", &el_Etcone40_pt_corrected, &b_el_Etcone40_pt_corrected);
   fChain->SetBranchAddress("el_convanglematch", &el_convanglematch, &b_el_convanglematch);
   fChain->SetBranchAddress("el_convtrackmatch", &el_convtrackmatch, &b_el_convtrackmatch);
   fChain->SetBranchAddress("el_hasconv", &el_hasconv, &b_el_hasconv);
   fChain->SetBranchAddress("el_convvtxx", &el_convvtxx, &b_el_convvtxx);
   fChain->SetBranchAddress("el_convvtxy", &el_convvtxy, &b_el_convvtxy);
   fChain->SetBranchAddress("el_convvtxz", &el_convvtxz, &b_el_convvtxz);
   fChain->SetBranchAddress("el_Rconv", &el_Rconv, &b_el_Rconv);
   fChain->SetBranchAddress("el_zconv", &el_zconv, &b_el_zconv);
   fChain->SetBranchAddress("el_convvtxchi2", &el_convvtxchi2, &b_el_convvtxchi2);
   fChain->SetBranchAddress("el_pt1conv", &el_pt1conv, &b_el_pt1conv);
   fChain->SetBranchAddress("el_convtrk1nBLHits", &el_convtrk1nBLHits, &b_el_convtrk1nBLHits);
   fChain->SetBranchAddress("el_convtrk1nPixHits", &el_convtrk1nPixHits, &b_el_convtrk1nPixHits);
   fChain->SetBranchAddress("el_convtrk1nSCTHits", &el_convtrk1nSCTHits, &b_el_convtrk1nSCTHits);
   fChain->SetBranchAddress("el_convtrk1nTRTHits", &el_convtrk1nTRTHits, &b_el_convtrk1nTRTHits);
   fChain->SetBranchAddress("el_pt2conv", &el_pt2conv, &b_el_pt2conv);
   fChain->SetBranchAddress("el_convtrk2nBLHits", &el_convtrk2nBLHits, &b_el_convtrk2nBLHits);
   fChain->SetBranchAddress("el_convtrk2nPixHits", &el_convtrk2nPixHits, &b_el_convtrk2nPixHits);
   fChain->SetBranchAddress("el_convtrk2nSCTHits", &el_convtrk2nSCTHits, &b_el_convtrk2nSCTHits);
   fChain->SetBranchAddress("el_convtrk2nTRTHits", &el_convtrk2nTRTHits, &b_el_convtrk2nTRTHits);
   fChain->SetBranchAddress("el_ptconv", &el_ptconv, &b_el_ptconv);
   fChain->SetBranchAddress("el_pzconv", &el_pzconv, &b_el_pzconv);
   fChain->SetBranchAddress("el_pos7", &el_pos7, &b_el_pos7);
   fChain->SetBranchAddress("el_etacorrmag", &el_etacorrmag, &b_el_etacorrmag);
   fChain->SetBranchAddress("el_deltaeta1", &el_deltaeta1, &b_el_deltaeta1);
   fChain->SetBranchAddress("el_deltaeta2", &el_deltaeta2, &b_el_deltaeta2);
   fChain->SetBranchAddress("el_deltaphi2", &el_deltaphi2, &b_el_deltaphi2);
   fChain->SetBranchAddress("el_deltaphiRescaled", &el_deltaphiRescaled, &b_el_deltaphiRescaled);
   fChain->SetBranchAddress("el_deltaPhiRot", &el_deltaPhiRot, &b_el_deltaPhiRot);
   fChain->SetBranchAddress("el_expectHitInBLayer", &el_expectHitInBLayer, &b_el_expectHitInBLayer);
   fChain->SetBranchAddress("el_trackd0_physics", &el_trackd0_physics, &b_el_trackd0_physics);
   fChain->SetBranchAddress("el_etaSampling1", &el_etaSampling1, &b_el_etaSampling1);
   fChain->SetBranchAddress("el_reta", &el_reta, &b_el_reta);
   fChain->SetBranchAddress("el_rphi", &el_rphi, &b_el_rphi);
   fChain->SetBranchAddress("el_EtringnoisedR03sig2", &el_EtringnoisedR03sig2, &b_el_EtringnoisedR03sig2);
   fChain->SetBranchAddress("el_EtringnoisedR03sig3", &el_EtringnoisedR03sig3, &b_el_EtringnoisedR03sig3);
   fChain->SetBranchAddress("el_EtringnoisedR03sig4", &el_EtringnoisedR03sig4, &b_el_EtringnoisedR03sig4);
   fChain->SetBranchAddress("el_isolationlikelihoodjets", &el_isolationlikelihoodjets, &b_el_isolationlikelihoodjets);
   fChain->SetBranchAddress("el_isolationlikelihoodhqelectrons", &el_isolationlikelihoodhqelectrons, &b_el_isolationlikelihoodhqelectrons);
   fChain->SetBranchAddress("el_electronweight", &el_electronweight, &b_el_electronweight);
   fChain->SetBranchAddress("el_electronbgweight", &el_electronbgweight, &b_el_electronbgweight);
   fChain->SetBranchAddress("el_softeweight", &el_softeweight, &b_el_softeweight);
   fChain->SetBranchAddress("el_softebgweight", &el_softebgweight, &b_el_softebgweight);
   fChain->SetBranchAddress("el_neuralnet", &el_neuralnet, &b_el_neuralnet);
   fChain->SetBranchAddress("el_Hmatrix", &el_Hmatrix, &b_el_Hmatrix);
   fChain->SetBranchAddress("el_Hmatrix5", &el_Hmatrix5, &b_el_Hmatrix5);
   fChain->SetBranchAddress("el_adaboost", &el_adaboost, &b_el_adaboost);
   fChain->SetBranchAddress("el_softeneuralnet", &el_softeneuralnet, &b_el_softeneuralnet);
   fChain->SetBranchAddress("el_zvertex", &el_zvertex, &b_el_zvertex);
   fChain->SetBranchAddress("el_errz", &el_errz, &b_el_errz);
   fChain->SetBranchAddress("el_etap", &el_etap, &b_el_etap);
   fChain->SetBranchAddress("el_depth", &el_depth, &b_el_depth);
   fChain->SetBranchAddress("el_refittedTrack_n", &el_refittedTrack_n, &b_el_refittedTrack_n);
   fChain->SetBranchAddress("el_refittedTrack_author", &el_refittedTrack_author, &b_el_refittedTrack_author);
   fChain->SetBranchAddress("el_refittedTrack_chi2", &el_refittedTrack_chi2, &b_el_refittedTrack_chi2);
   fChain->SetBranchAddress("el_refittedTrack_hasBrem", &el_refittedTrack_hasBrem, &b_el_refittedTrack_hasBrem);
   fChain->SetBranchAddress("el_refittedTrack_bremRadius", &el_refittedTrack_bremRadius, &b_el_refittedTrack_bremRadius);
   fChain->SetBranchAddress("el_refittedTrack_bremZ", &el_refittedTrack_bremZ, &b_el_refittedTrack_bremZ);
   fChain->SetBranchAddress("el_refittedTrack_bremRadiusErr", &el_refittedTrack_bremRadiusErr, &b_el_refittedTrack_bremRadiusErr);
   fChain->SetBranchAddress("el_refittedTrack_bremZErr", &el_refittedTrack_bremZErr, &b_el_refittedTrack_bremZErr);
   fChain->SetBranchAddress("el_refittedTrack_bremFitStatus", &el_refittedTrack_bremFitStatus, &b_el_refittedTrack_bremFitStatus);
   fChain->SetBranchAddress("el_refittedTrack_qoverp", &el_refittedTrack_qoverp, &b_el_refittedTrack_qoverp);
   fChain->SetBranchAddress("el_refittedTrack_d0", &el_refittedTrack_d0, &b_el_refittedTrack_d0);
   fChain->SetBranchAddress("el_refittedTrack_z0", &el_refittedTrack_z0, &b_el_refittedTrack_z0);
   fChain->SetBranchAddress("el_refittedTrack_theta", &el_refittedTrack_theta, &b_el_refittedTrack_theta);
   fChain->SetBranchAddress("el_refittedTrack_phi", &el_refittedTrack_phi, &b_el_refittedTrack_phi);
   fChain->SetBranchAddress("el_refittedTrack_LMqoverp", &el_refittedTrack_LMqoverp, &b_el_refittedTrack_LMqoverp);
   fChain->SetBranchAddress("el_Es0", &el_Es0, &b_el_Es0);
   fChain->SetBranchAddress("el_etas0", &el_etas0, &b_el_etas0);
   fChain->SetBranchAddress("el_phis0", &el_phis0, &b_el_phis0);
   fChain->SetBranchAddress("el_Es1", &el_Es1, &b_el_Es1);
   fChain->SetBranchAddress("el_etas1", &el_etas1, &b_el_etas1);
   fChain->SetBranchAddress("el_phis1", &el_phis1, &b_el_phis1);
   fChain->SetBranchAddress("el_Es2", &el_Es2, &b_el_Es2);
   fChain->SetBranchAddress("el_etas2", &el_etas2, &b_el_etas2);
   fChain->SetBranchAddress("el_phis2", &el_phis2, &b_el_phis2);
   fChain->SetBranchAddress("el_Es3", &el_Es3, &b_el_Es3);
   fChain->SetBranchAddress("el_etas3", &el_etas3, &b_el_etas3);
   fChain->SetBranchAddress("el_phis3", &el_phis3, &b_el_phis3);
   fChain->SetBranchAddress("el_E_PreSamplerB", &el_E_PreSamplerB, &b_el_E_PreSamplerB);
   fChain->SetBranchAddress("el_E_EMB1", &el_E_EMB1, &b_el_E_EMB1);
   fChain->SetBranchAddress("el_E_EMB2", &el_E_EMB2, &b_el_E_EMB2);
   fChain->SetBranchAddress("el_E_EMB3", &el_E_EMB3, &b_el_E_EMB3);
   fChain->SetBranchAddress("el_E_PreSamplerE", &el_E_PreSamplerE, &b_el_E_PreSamplerE);
   fChain->SetBranchAddress("el_E_EME1", &el_E_EME1, &b_el_E_EME1);
   fChain->SetBranchAddress("el_E_EME2", &el_E_EME2, &b_el_E_EME2);
   fChain->SetBranchAddress("el_E_EME3", &el_E_EME3, &b_el_E_EME3);
   fChain->SetBranchAddress("el_E_HEC0", &el_E_HEC0, &b_el_E_HEC0);
   fChain->SetBranchAddress("el_E_HEC1", &el_E_HEC1, &b_el_E_HEC1);
   fChain->SetBranchAddress("el_E_HEC2", &el_E_HEC2, &b_el_E_HEC2);
   fChain->SetBranchAddress("el_E_HEC3", &el_E_HEC3, &b_el_E_HEC3);
   fChain->SetBranchAddress("el_E_TileBar0", &el_E_TileBar0, &b_el_E_TileBar0);
   fChain->SetBranchAddress("el_E_TileBar1", &el_E_TileBar1, &b_el_E_TileBar1);
   fChain->SetBranchAddress("el_E_TileBar2", &el_E_TileBar2, &b_el_E_TileBar2);
   fChain->SetBranchAddress("el_E_TileGap1", &el_E_TileGap1, &b_el_E_TileGap1);
   fChain->SetBranchAddress("el_E_TileGap2", &el_E_TileGap2, &b_el_E_TileGap2);
   fChain->SetBranchAddress("el_E_TileGap3", &el_E_TileGap3, &b_el_E_TileGap3);
   fChain->SetBranchAddress("el_E_TileExt0", &el_E_TileExt0, &b_el_E_TileExt0);
   fChain->SetBranchAddress("el_E_TileExt1", &el_E_TileExt1, &b_el_E_TileExt1);
   fChain->SetBranchAddress("el_E_TileExt2", &el_E_TileExt2, &b_el_E_TileExt2);
   fChain->SetBranchAddress("el_E_FCAL0", &el_E_FCAL0, &b_el_E_FCAL0);
   fChain->SetBranchAddress("el_E_FCAL1", &el_E_FCAL1, &b_el_E_FCAL1);
   fChain->SetBranchAddress("el_E_FCAL2", &el_E_FCAL2, &b_el_E_FCAL2);
   fChain->SetBranchAddress("el_cl_E", &el_cl_E, &b_el_cl_E);
   fChain->SetBranchAddress("el_cl_pt", &el_cl_pt, &b_el_cl_pt);
   fChain->SetBranchAddress("el_cl_eta", &el_cl_eta, &b_el_cl_eta);
   fChain->SetBranchAddress("el_cl_phi", &el_cl_phi, &b_el_cl_phi);
   fChain->SetBranchAddress("el_firstEdens", &el_firstEdens, &b_el_firstEdens);
   fChain->SetBranchAddress("el_cellmaxfrac", &el_cellmaxfrac, &b_el_cellmaxfrac);
   fChain->SetBranchAddress("el_longitudinal", &el_longitudinal, &b_el_longitudinal);
   fChain->SetBranchAddress("el_secondlambda", &el_secondlambda, &b_el_secondlambda);
   fChain->SetBranchAddress("el_lateral", &el_lateral, &b_el_lateral);
   fChain->SetBranchAddress("el_secondR", &el_secondR, &b_el_secondR);
   fChain->SetBranchAddress("el_centerlambda", &el_centerlambda, &b_el_centerlambda);
   fChain->SetBranchAddress("el_rawcl_Es0", &el_rawcl_Es0, &b_el_rawcl_Es0);
   fChain->SetBranchAddress("el_rawcl_etas0", &el_rawcl_etas0, &b_el_rawcl_etas0);
   fChain->SetBranchAddress("el_rawcl_phis0", &el_rawcl_phis0, &b_el_rawcl_phis0);
   fChain->SetBranchAddress("el_rawcl_Es1", &el_rawcl_Es1, &b_el_rawcl_Es1);
   fChain->SetBranchAddress("el_rawcl_etas1", &el_rawcl_etas1, &b_el_rawcl_etas1);
   fChain->SetBranchAddress("el_rawcl_phis1", &el_rawcl_phis1, &b_el_rawcl_phis1);
   fChain->SetBranchAddress("el_rawcl_Es2", &el_rawcl_Es2, &b_el_rawcl_Es2);
   fChain->SetBranchAddress("el_rawcl_etas2", &el_rawcl_etas2, &b_el_rawcl_etas2);
   fChain->SetBranchAddress("el_rawcl_phis2", &el_rawcl_phis2, &b_el_rawcl_phis2);
   fChain->SetBranchAddress("el_rawcl_Es3", &el_rawcl_Es3, &b_el_rawcl_Es3);
   fChain->SetBranchAddress("el_rawcl_etas3", &el_rawcl_etas3, &b_el_rawcl_etas3);
   fChain->SetBranchAddress("el_rawcl_phis3", &el_rawcl_phis3, &b_el_rawcl_phis3);
   fChain->SetBranchAddress("el_rawcl_E", &el_rawcl_E, &b_el_rawcl_E);
   fChain->SetBranchAddress("el_rawcl_pt", &el_rawcl_pt, &b_el_rawcl_pt);
   fChain->SetBranchAddress("el_rawcl_eta", &el_rawcl_eta, &b_el_rawcl_eta);
   fChain->SetBranchAddress("el_rawcl_phi", &el_rawcl_phi, &b_el_rawcl_phi);
   fChain->SetBranchAddress("el_trackd0", &el_trackd0, &b_el_trackd0);
   fChain->SetBranchAddress("el_trackz0", &el_trackz0, &b_el_trackz0);
   fChain->SetBranchAddress("el_trackphi", &el_trackphi, &b_el_trackphi);
   fChain->SetBranchAddress("el_tracktheta", &el_tracktheta, &b_el_tracktheta);
   fChain->SetBranchAddress("el_trackqoverp", &el_trackqoverp, &b_el_trackqoverp);
   fChain->SetBranchAddress("el_trackpt", &el_trackpt, &b_el_trackpt);
   fChain->SetBranchAddress("el_tracketa", &el_tracketa, &b_el_tracketa);
   fChain->SetBranchAddress("el_trackfitchi2", &el_trackfitchi2, &b_el_trackfitchi2);
   fChain->SetBranchAddress("el_trackfitndof", &el_trackfitndof, &b_el_trackfitndof);
   fChain->SetBranchAddress("el_nBLHits", &el_nBLHits, &b_el_nBLHits);
   fChain->SetBranchAddress("el_nPixHits", &el_nPixHits, &b_el_nPixHits);
   fChain->SetBranchAddress("el_nSCTHits", &el_nSCTHits, &b_el_nSCTHits);
   fChain->SetBranchAddress("el_nTRTHits", &el_nTRTHits, &b_el_nTRTHits);
   fChain->SetBranchAddress("el_nTRTHighTHits", &el_nTRTHighTHits, &b_el_nTRTHighTHits);
   fChain->SetBranchAddress("el_nPixHoles", &el_nPixHoles, &b_el_nPixHoles);
   fChain->SetBranchAddress("el_nSCTHoles", &el_nSCTHoles, &b_el_nSCTHoles);
   fChain->SetBranchAddress("el_nTRTHoles", &el_nTRTHoles, &b_el_nTRTHoles);
   fChain->SetBranchAddress("el_nBLSharedHits", &el_nBLSharedHits, &b_el_nBLSharedHits);
   fChain->SetBranchAddress("el_nPixSharedHits", &el_nPixSharedHits, &b_el_nPixSharedHits);
   fChain->SetBranchAddress("el_nSCTSharedHits", &el_nSCTSharedHits, &b_el_nSCTSharedHits);
   fChain->SetBranchAddress("el_nBLayerOutliers", &el_nBLayerOutliers, &b_el_nBLayerOutliers);
   fChain->SetBranchAddress("el_nPixelOutliers", &el_nPixelOutliers, &b_el_nPixelOutliers);
   fChain->SetBranchAddress("el_nSCTOutliers", &el_nSCTOutliers, &b_el_nSCTOutliers);
   fChain->SetBranchAddress("el_nTRTOutliers", &el_nTRTOutliers, &b_el_nTRTOutliers);
   fChain->SetBranchAddress("el_nTRTHighTOutliers", &el_nTRTHighTOutliers, &b_el_nTRTHighTOutliers);
   fChain->SetBranchAddress("el_expectBLayerHit", &el_expectBLayerHit, &b_el_expectBLayerHit);
   fChain->SetBranchAddress("el_nSiHits", &el_nSiHits, &b_el_nSiHits);
   fChain->SetBranchAddress("el_TRTHighTHitsRatio", &el_TRTHighTHitsRatio, &b_el_TRTHighTHitsRatio);
   fChain->SetBranchAddress("el_TRTHighTOutliersRatio", &el_TRTHighTOutliersRatio, &b_el_TRTHighTOutliersRatio);
   fChain->SetBranchAddress("el_pixeldEdx", &el_pixeldEdx, &b_el_pixeldEdx);
   fChain->SetBranchAddress("el_nGoodHitsPixeldEdx", &el_nGoodHitsPixeldEdx, &b_el_nGoodHitsPixeldEdx);
   fChain->SetBranchAddress("el_massPixeldEdx", &el_massPixeldEdx, &b_el_massPixeldEdx);
   fChain->SetBranchAddress("el_likelihoodsPixeldEdx", &el_likelihoodsPixeldEdx, &b_el_likelihoodsPixeldEdx);
   fChain->SetBranchAddress("el_eProbabilityComb", &el_eProbabilityComb, &b_el_eProbabilityComb);
   fChain->SetBranchAddress("el_eProbabilityHT", &el_eProbabilityHT, &b_el_eProbabilityHT);
   fChain->SetBranchAddress("el_eProbabilityToT", &el_eProbabilityToT, &b_el_eProbabilityToT);
   fChain->SetBranchAddress("el_eProbabilityBrem", &el_eProbabilityBrem, &b_el_eProbabilityBrem);
   fChain->SetBranchAddress("el_vertweight", &el_vertweight, &b_el_vertweight);
   fChain->SetBranchAddress("el_vertx", &el_vertx, &b_el_vertx);
   fChain->SetBranchAddress("el_verty", &el_verty, &b_el_verty);
   fChain->SetBranchAddress("el_vertz", &el_vertz, &b_el_vertz);
   fChain->SetBranchAddress("el_trackd0beam", &el_trackd0beam, &b_el_trackd0beam);
   fChain->SetBranchAddress("el_trackz0beam", &el_trackz0beam, &b_el_trackz0beam);
   fChain->SetBranchAddress("el_tracksigd0beam", &el_tracksigd0beam, &b_el_tracksigd0beam);
   fChain->SetBranchAddress("el_tracksigz0beam", &el_tracksigz0beam, &b_el_tracksigz0beam);
   fChain->SetBranchAddress("el_trackd0pv", &el_trackd0pv, &b_el_trackd0pv);
   fChain->SetBranchAddress("el_trackz0pv", &el_trackz0pv, &b_el_trackz0pv);
   fChain->SetBranchAddress("el_tracksigd0pv", &el_tracksigd0pv, &b_el_tracksigd0pv);
   fChain->SetBranchAddress("el_tracksigz0pv", &el_tracksigz0pv, &b_el_tracksigz0pv);
   fChain->SetBranchAddress("el_trackIPEstimate_d0_biasedpvunbiased", &el_trackIPEstimate_d0_biasedpvunbiased, &b_el_trackIPEstimate_d0_biasedpvunbiased);
   fChain->SetBranchAddress("el_trackIPEstimate_z0_biasedpvunbiased", &el_trackIPEstimate_z0_biasedpvunbiased, &b_el_trackIPEstimate_z0_biasedpvunbiased);
   fChain->SetBranchAddress("el_trackIPEstimate_d0_unbiasedpvunbiased", &el_trackIPEstimate_d0_unbiasedpvunbiased, &b_el_trackIPEstimate_d0_unbiasedpvunbiased);
   fChain->SetBranchAddress("el_trackIPEstimate_z0_unbiasedpvunbiased", &el_trackIPEstimate_z0_unbiasedpvunbiased, &b_el_trackIPEstimate_z0_unbiasedpvunbiased);
   fChain->SetBranchAddress("el_trackIPEstimate_sigd0_biasedpvunbiased", &el_trackIPEstimate_sigd0_biasedpvunbiased, &b_el_trackIPEstimate_sigd0_biasedpvunbiased);
   fChain->SetBranchAddress("el_trackIPEstimate_sigz0_biasedpvunbiased", &el_trackIPEstimate_sigz0_biasedpvunbiased, &b_el_trackIPEstimate_sigz0_biasedpvunbiased);
   fChain->SetBranchAddress("el_trackIPEstimate_sigd0_unbiasedpvunbiased", &el_trackIPEstimate_sigd0_unbiasedpvunbiased, &b_el_trackIPEstimate_sigd0_unbiasedpvunbiased);
   fChain->SetBranchAddress("el_trackIPEstimate_sigz0_unbiasedpvunbiased", &el_trackIPEstimate_sigz0_unbiasedpvunbiased, &b_el_trackIPEstimate_sigz0_unbiasedpvunbiased);
   fChain->SetBranchAddress("el_hastrack", &el_hastrack, &b_el_hastrack);
   fChain->SetBranchAddress("el_deltaEmax2", &el_deltaEmax2, &b_el_deltaEmax2);
   fChain->SetBranchAddress("el_calibHitsShowerDepth", &el_calibHitsShowerDepth, &b_el_calibHitsShowerDepth);
   fChain->SetBranchAddress("el_isIso", &el_isIso, &b_el_isIso);
   fChain->SetBranchAddress("el_mvaptcone20", &el_mvaptcone20, &b_el_mvaptcone20);
   fChain->SetBranchAddress("el_mvaptcone30", &el_mvaptcone30, &b_el_mvaptcone30);
   fChain->SetBranchAddress("el_mvaptcone40", &el_mvaptcone40, &b_el_mvaptcone40);
   fChain->SetBranchAddress("el_jet_dr", &el_jet_dr, &b_el_jet_dr);
   fChain->SetBranchAddress("el_jet_E", &el_jet_E, &b_el_jet_E);
   fChain->SetBranchAddress("el_jet_pt", &el_jet_pt, &b_el_jet_pt);
   fChain->SetBranchAddress("el_jet_m", &el_jet_m, &b_el_jet_m);
   fChain->SetBranchAddress("el_jet_eta", &el_jet_eta, &b_el_jet_eta);
   fChain->SetBranchAddress("el_jet_phi", &el_jet_phi, &b_el_jet_phi);
   fChain->SetBranchAddress("el_jet_matched", &el_jet_matched, &b_el_jet_matched);
   fChain->SetBranchAddress("el_Etcone40_ED_corrected", &el_Etcone40_ED_corrected, &b_el_Etcone40_ED_corrected);
   fChain->SetBranchAddress("el_Etcone40_corrected", &el_Etcone40_corrected, &b_el_Etcone40_corrected);
   fChain->SetBranchAddress("el_Etcone35_ED_corrected", &el_Etcone35_ED_corrected, &b_el_Etcone35_ED_corrected);
   fChain->SetBranchAddress("el_Etcone35_corrected", &el_Etcone35_corrected, &b_el_Etcone35_corrected);
   fChain->SetBranchAddress("el_Etcone30_ED_corrected", &el_Etcone30_ED_corrected, &b_el_Etcone30_ED_corrected);
   fChain->SetBranchAddress("el_Etcone30_corrected", &el_Etcone30_corrected, &b_el_Etcone30_corrected);
   fChain->SetBranchAddress("el_Etcone25_ED_corrected", &el_Etcone25_ED_corrected, &b_el_Etcone25_ED_corrected);
   fChain->SetBranchAddress("el_Etcone25_corrected", &el_Etcone25_corrected, &b_el_Etcone25_corrected);
   fChain->SetBranchAddress("el_Etcone20_ED_corrected", &el_Etcone20_ED_corrected, &b_el_Etcone20_ED_corrected);
   fChain->SetBranchAddress("el_Etcone20_corrected", &el_Etcone20_corrected, &b_el_Etcone20_corrected);
   fChain->SetBranchAddress("el_Etcone15_ED_corrected", &el_Etcone15_ED_corrected, &b_el_Etcone15_ED_corrected);
   fChain->SetBranchAddress("el_Etcone15_corrected", &el_Etcone15_corrected, &b_el_Etcone15_corrected);
   fChain->SetBranchAddress("el_EF_dr", &el_EF_dr, &b_el_EF_dr);
   fChain->SetBranchAddress("el_EF_index", &el_EF_index, &b_el_EF_index);
   fChain->SetBranchAddress("el_L2_dr", &el_L2_dr, &b_el_L2_dr);
   fChain->SetBranchAddress("el_L2_index", &el_L2_index, &b_el_L2_index);
   fChain->SetBranchAddress("el_L1_dr", &el_L1_dr, &b_el_L1_dr);
   fChain->SetBranchAddress("el_L1_index", &el_L1_index, &b_el_L1_index);
   fChain->SetBranchAddress("EF_2b10_medium_4L1J10", &EF_2b10_medium_4L1J10, &b_EF_2b10_medium_4L1J10);
   fChain->SetBranchAddress("EF_2b10_medium_4j30_a4tc_EFFS", &EF_2b10_medium_4j30_a4tc_EFFS, &b_EF_2b10_medium_4j30_a4tc_EFFS);
   fChain->SetBranchAddress("EF_2b10_medium_L1JE100", &EF_2b10_medium_L1JE100, &b_EF_2b10_medium_L1JE100);
   fChain->SetBranchAddress("EF_2b10_medium_L1JE140", &EF_2b10_medium_L1JE140, &b_EF_2b10_medium_L1JE140);
   fChain->SetBranchAddress("EF_2b10_medium_L1_2J10J50", &EF_2b10_medium_L1_2J10J50, &b_EF_2b10_medium_L1_2J10J50);
   fChain->SetBranchAddress("EF_2b10_medium_j75_j30_a4tc_EFFS", &EF_2b10_medium_j75_j30_a4tc_EFFS, &b_EF_2b10_medium_j75_j30_a4tc_EFFS);
   fChain->SetBranchAddress("EF_2b15_medium_3L1J15", &EF_2b15_medium_3L1J15, &b_EF_2b15_medium_3L1J15);
   fChain->SetBranchAddress("EF_2b20_medium_3L1J20", &EF_2b20_medium_3L1J20, &b_EF_2b20_medium_3L1J20);
   fChain->SetBranchAddress("EF_2e10_medium", &EF_2e10_medium, &b_EF_2e10_medium);
   fChain->SetBranchAddress("EF_2e10_medium_mu6", &EF_2e10_medium_mu6, &b_EF_2e10_medium_mu6);
   fChain->SetBranchAddress("EF_2e12T_medium", &EF_2e12T_medium, &b_EF_2e12T_medium);
   fChain->SetBranchAddress("EF_2e12_medium", &EF_2e12_medium, &b_EF_2e12_medium);
   fChain->SetBranchAddress("EF_2e15_medium", &EF_2e15_medium, &b_EF_2e15_medium);
   fChain->SetBranchAddress("EF_2e5_tight", &EF_2e5_tight, &b_EF_2e5_tight);
   fChain->SetBranchAddress("EF_2e5_tight_Jpsi", &EF_2e5_tight_Jpsi, &b_EF_2e5_tight_Jpsi);
   fChain->SetBranchAddress("EF_2g15_loose", &EF_2g15_loose, &b_EF_2g15_loose);
   fChain->SetBranchAddress("EF_2g20_loose", &EF_2g20_loose, &b_EF_2g20_loose);
   fChain->SetBranchAddress("EF_2j45_a4tc_EFFS_leadingmct100_xe40_medium_noMu", &EF_2j45_a4tc_EFFS_leadingmct100_xe40_medium_noMu, &b_EF_2j45_a4tc_EFFS_leadingmct100_xe40_medium_noMu);
   fChain->SetBranchAddress("EF_2j55_a4tc_EFFS_leadingmct100_xe40_medium_noMu", &EF_2j55_a4tc_EFFS_leadingmct100_xe40_medium_noMu, &b_EF_2j55_a4tc_EFFS_leadingmct100_xe40_medium_noMu);
   fChain->SetBranchAddress("EF_2mu10", &EF_2mu10, &b_EF_2mu10);
   fChain->SetBranchAddress("EF_2mu10_empty", &EF_2mu10_empty, &b_EF_2mu10_empty);
   fChain->SetBranchAddress("EF_2mu10_loose", &EF_2mu10_loose, &b_EF_2mu10_loose);
   fChain->SetBranchAddress("EF_2mu10_loose_empty", &EF_2mu10_loose_empty, &b_EF_2mu10_loose_empty);
   fChain->SetBranchAddress("EF_2mu10_loose_noOvlpRm", &EF_2mu10_loose_noOvlpRm, &b_EF_2mu10_loose_noOvlpRm);
   fChain->SetBranchAddress("EF_2mu13_Zmumu_IDTrkNoCut", &EF_2mu13_Zmumu_IDTrkNoCut, &b_EF_2mu13_Zmumu_IDTrkNoCut);
   fChain->SetBranchAddress("EF_2mu4", &EF_2mu4, &b_EF_2mu4);
   fChain->SetBranchAddress("EF_2mu4_Bmumu", &EF_2mu4_Bmumu, &b_EF_2mu4_Bmumu);
   fChain->SetBranchAddress("EF_2mu4_Bmumux", &EF_2mu4_Bmumux, &b_EF_2mu4_Bmumux);
   fChain->SetBranchAddress("EF_2mu4_DiMu", &EF_2mu4_DiMu, &b_EF_2mu4_DiMu);
   fChain->SetBranchAddress("EF_2mu4_DiMu_DY", &EF_2mu4_DiMu_DY, &b_EF_2mu4_DiMu_DY);
   fChain->SetBranchAddress("EF_2mu4_DiMu_DY20", &EF_2mu4_DiMu_DY20, &b_EF_2mu4_DiMu_DY20);
   fChain->SetBranchAddress("EF_2mu4_DiMu_DY_noVtx_noOS", &EF_2mu4_DiMu_DY_noVtx_noOS, &b_EF_2mu4_DiMu_DY_noVtx_noOS);
   fChain->SetBranchAddress("EF_2mu4_DiMu_SiTrk", &EF_2mu4_DiMu_SiTrk, &b_EF_2mu4_DiMu_SiTrk);
   fChain->SetBranchAddress("EF_2mu4_DiMu_noVtx_noOS", &EF_2mu4_DiMu_noVtx_noOS, &b_EF_2mu4_DiMu_noVtx_noOS);
   fChain->SetBranchAddress("EF_2mu4_Jpsimumu", &EF_2mu4_Jpsimumu, &b_EF_2mu4_Jpsimumu);
   fChain->SetBranchAddress("EF_2mu4_Jpsimumu_IDTrkNoCut", &EF_2mu4_Jpsimumu_IDTrkNoCut, &b_EF_2mu4_Jpsimumu_IDTrkNoCut);
   fChain->SetBranchAddress("EF_2mu4_Upsimumu", &EF_2mu4_Upsimumu, &b_EF_2mu4_Upsimumu);
   fChain->SetBranchAddress("EF_2mu4i_DiMu_DY", &EF_2mu4i_DiMu_DY, &b_EF_2mu4i_DiMu_DY);
   fChain->SetBranchAddress("EF_2mu6", &EF_2mu6, &b_EF_2mu6);
   fChain->SetBranchAddress("EF_2mu6_DiMu", &EF_2mu6_DiMu, &b_EF_2mu6_DiMu);
   fChain->SetBranchAddress("EF_2mu6_MSonly_g10_loose", &EF_2mu6_MSonly_g10_loose, &b_EF_2mu6_MSonly_g10_loose);
   fChain->SetBranchAddress("EF_2mu6_MSonly_g10_loose_nonfilled", &EF_2mu6_MSonly_g10_loose_nonfilled, &b_EF_2mu6_MSonly_g10_loose_nonfilled);
   fChain->SetBranchAddress("EF_2mu6_NL", &EF_2mu6_NL, &b_EF_2mu6_NL);
   fChain->SetBranchAddress("EF_2tau29T_medium1", &EF_2tau29T_medium1, &b_EF_2tau29T_medium1);
   fChain->SetBranchAddress("EF_2tau29_medium1", &EF_2tau29_medium1, &b_EF_2tau29_medium1);
   fChain->SetBranchAddress("EF_3b10_loose_4L1J10", &EF_3b10_loose_4L1J10, &b_EF_3b10_loose_4L1J10);
   fChain->SetBranchAddress("EF_3b15_loose_4L1J15", &EF_3b15_loose_4L1J15, &b_EF_3b15_loose_4L1J15);
   fChain->SetBranchAddress("EF_4j30_a4tc_EFFS", &EF_4j30_a4tc_EFFS, &b_EF_4j30_a4tc_EFFS);
   fChain->SetBranchAddress("EF_b10_EFj10_a4tc_EFFS_IDTrkNoCut", &EF_b10_EFj10_a4tc_EFFS_IDTrkNoCut, &b_EF_b10_EFj10_a4tc_EFFS_IDTrkNoCut);
   fChain->SetBranchAddress("EF_b10_IDTrkNoCut", &EF_b10_IDTrkNoCut, &b_EF_b10_IDTrkNoCut);
   fChain->SetBranchAddress("EF_b10_medium_4j30_a4tc_EFFS", &EF_b10_medium_4j30_a4tc_EFFS, &b_EF_b10_medium_4j30_a4tc_EFFS);
   fChain->SetBranchAddress("EF_b10_medium_EFxe25_noMu_L1JE140", &EF_b10_medium_EFxe25_noMu_L1JE140, &b_EF_b10_medium_EFxe25_noMu_L1JE140);
   fChain->SetBranchAddress("EF_b10_tight_4L1J10", &EF_b10_tight_4L1J10, &b_EF_b10_tight_4L1J10);
   fChain->SetBranchAddress("EF_b10_tight_L1JE140", &EF_b10_tight_L1JE140, &b_EF_b10_tight_L1JE140);
   fChain->SetBranchAddress("EF_e10_medium", &EF_e10_medium, &b_EF_e10_medium);
   fChain->SetBranchAddress("EF_e10_medium_2mu6", &EF_e10_medium_2mu6, &b_EF_e10_medium_2mu6);
   fChain->SetBranchAddress("EF_e10_medium_mu10", &EF_e10_medium_mu10, &b_EF_e10_medium_mu10);
   fChain->SetBranchAddress("EF_e10_medium_mu6", &EF_e10_medium_mu6, &b_EF_e10_medium_mu6);
   fChain->SetBranchAddress("EF_e10_medium_mu6_topo_medium", &EF_e10_medium_mu6_topo_medium, &b_EF_e10_medium_mu6_topo_medium);
   fChain->SetBranchAddress("EF_e11T_medium", &EF_e11T_medium, &b_EF_e11T_medium);
   fChain->SetBranchAddress("EF_e11T_medium_2e6T_medium", &EF_e11T_medium_2e6T_medium, &b_EF_e11T_medium_2e6T_medium);
   fChain->SetBranchAddress("EF_e11_etcut", &EF_e11_etcut, &b_EF_e11_etcut);
   fChain->SetBranchAddress("EF_e12T_medium_mu6_topo_medium", &EF_e12T_medium_mu6_topo_medium, &b_EF_e12T_medium_mu6_topo_medium);
   fChain->SetBranchAddress("EF_e12_medium", &EF_e12_medium, &b_EF_e12_medium);
   fChain->SetBranchAddress("EF_e13_etcut_xs60_noMu", &EF_e13_etcut_xs60_noMu, &b_EF_e13_etcut_xs60_noMu);
   fChain->SetBranchAddress("EF_e13_etcut_xs60_noMu_dphi2j10xe07", &EF_e13_etcut_xs60_noMu_dphi2j10xe07, &b_EF_e13_etcut_xs60_noMu_dphi2j10xe07);
   fChain->SetBranchAddress("EF_e13_etcut_xs70_noMu", &EF_e13_etcut_xs70_noMu, &b_EF_e13_etcut_xs70_noMu);
   fChain->SetBranchAddress("EF_e15_HLTtighter", &EF_e15_HLTtighter, &b_EF_e15_HLTtighter);
   fChain->SetBranchAddress("EF_e15_medium", &EF_e15_medium, &b_EF_e15_medium);
   fChain->SetBranchAddress("EF_e15_medium_e12_medium", &EF_e15_medium_e12_medium, &b_EF_e15_medium_e12_medium);
   fChain->SetBranchAddress("EF_e15_medium_xe30_noMu", &EF_e15_medium_xe30_noMu, &b_EF_e15_medium_xe30_noMu);
   fChain->SetBranchAddress("EF_e15_medium_xe40_noMu", &EF_e15_medium_xe40_noMu, &b_EF_e15_medium_xe40_noMu);
   fChain->SetBranchAddress("EF_e15_medium_xe50_noMu", &EF_e15_medium_xe50_noMu, &b_EF_e15_medium_xe50_noMu);
   fChain->SetBranchAddress("EF_e15_tight", &EF_e15_tight, &b_EF_e15_tight);
   fChain->SetBranchAddress("EF_e20_etcut_xs60_noMu", &EF_e20_etcut_xs60_noMu, &b_EF_e20_etcut_xs60_noMu);
   fChain->SetBranchAddress("EF_e20_etcut_xs60_noMu_dphi2j10xe07", &EF_e20_etcut_xs60_noMu_dphi2j10xe07, &b_EF_e20_etcut_xs60_noMu_dphi2j10xe07);
   fChain->SetBranchAddress("EF_e20_loose", &EF_e20_loose, &b_EF_e20_loose);
   fChain->SetBranchAddress("EF_e20_loose1", &EF_e20_loose1, &b_EF_e20_loose1);
   fChain->SetBranchAddress("EF_e20_looseTrk", &EF_e20_looseTrk, &b_EF_e20_looseTrk);
   fChain->SetBranchAddress("EF_e20_medium", &EF_e20_medium, &b_EF_e20_medium);
   fChain->SetBranchAddress("EF_e20_medium1", &EF_e20_medium1, &b_EF_e20_medium1);
   fChain->SetBranchAddress("EF_e20_medium2", &EF_e20_medium2, &b_EF_e20_medium2);
   fChain->SetBranchAddress("EF_e20_medium_IDTrkNoCut", &EF_e20_medium_IDTrkNoCut, &b_EF_e20_medium_IDTrkNoCut);
   fChain->SetBranchAddress("EF_e20_medium_SiTrk", &EF_e20_medium_SiTrk, &b_EF_e20_medium_SiTrk);
   fChain->SetBranchAddress("EF_e20_medium_TRT", &EF_e20_medium_TRT, &b_EF_e20_medium_TRT);
   fChain->SetBranchAddress("EF_e20_tight_e15_NoCut_Zee", &EF_e20_tight_e15_NoCut_Zee, &b_EF_e20_tight_e15_NoCut_Zee);
   fChain->SetBranchAddress("EF_e22_etcut_xs60_noMu", &EF_e22_etcut_xs60_noMu, &b_EF_e22_etcut_xs60_noMu);
   fChain->SetBranchAddress("EF_e22_etcut_xs60_noMu_dphi2j10xe07", &EF_e22_etcut_xs60_noMu_dphi2j10xe07, &b_EF_e22_etcut_xs60_noMu_dphi2j10xe07);
   fChain->SetBranchAddress("EF_e22_loose", &EF_e22_loose, &b_EF_e22_loose);
   fChain->SetBranchAddress("EF_e22_loose1", &EF_e22_loose1, &b_EF_e22_loose1);
   fChain->SetBranchAddress("EF_e22_looseTrk", &EF_e22_looseTrk, &b_EF_e22_looseTrk);
   fChain->SetBranchAddress("EF_e22_medium", &EF_e22_medium, &b_EF_e22_medium);
   fChain->SetBranchAddress("EF_e22_medium1", &EF_e22_medium1, &b_EF_e22_medium1);
   fChain->SetBranchAddress("EF_e22_medium2", &EF_e22_medium2, &b_EF_e22_medium2);
   fChain->SetBranchAddress("EF_e22_medium_IDTrkNoCut", &EF_e22_medium_IDTrkNoCut, &b_EF_e22_medium_IDTrkNoCut);
   fChain->SetBranchAddress("EF_e22_medium_SiTrk", &EF_e22_medium_SiTrk, &b_EF_e22_medium_SiTrk);
   fChain->SetBranchAddress("EF_e22_medium_TRT", &EF_e22_medium_TRT, &b_EF_e22_medium_TRT);
   fChain->SetBranchAddress("EF_e33_medium", &EF_e33_medium, &b_EF_e33_medium);
   fChain->SetBranchAddress("EF_e35_medium", &EF_e35_medium, &b_EF_e35_medium);
   fChain->SetBranchAddress("EF_e40_medium", &EF_e40_medium, &b_EF_e40_medium);
   fChain->SetBranchAddress("EF_e45_medium", &EF_e45_medium, &b_EF_e45_medium);
   fChain->SetBranchAddress("EF_e45_medium1", &EF_e45_medium1, &b_EF_e45_medium1);
   fChain->SetBranchAddress("EF_e5_medium_mu6", &EF_e5_medium_mu6, &b_EF_e5_medium_mu6);
   fChain->SetBranchAddress("EF_e5_medium_mu6_topo_medium", &EF_e5_medium_mu6_topo_medium, &b_EF_e5_medium_mu6_topo_medium);
   fChain->SetBranchAddress("EF_e5_tight", &EF_e5_tight, &b_EF_e5_tight);
   fChain->SetBranchAddress("EF_e5_tight_e14_etcut_Jpsi", &EF_e5_tight_e14_etcut_Jpsi, &b_EF_e5_tight_e14_etcut_Jpsi);
   fChain->SetBranchAddress("EF_e5_tight_e4_etcut_Jpsi", &EF_e5_tight_e4_etcut_Jpsi, &b_EF_e5_tight_e4_etcut_Jpsi);
   fChain->SetBranchAddress("EF_e5_tight_e4_etcut_Jpsi_SiTrk", &EF_e5_tight_e4_etcut_Jpsi_SiTrk, &b_EF_e5_tight_e4_etcut_Jpsi_SiTrk);
   fChain->SetBranchAddress("EF_e5_tight_e4_etcut_Jpsi_TRT", &EF_e5_tight_e4_etcut_Jpsi_TRT, &b_EF_e5_tight_e4_etcut_Jpsi_TRT);
   fChain->SetBranchAddress("EF_e5_tight_e5_NoCut", &EF_e5_tight_e5_NoCut, &b_EF_e5_tight_e5_NoCut);
   fChain->SetBranchAddress("EF_e5_tight_e9_etcut_Jpsi", &EF_e5_tight_e9_etcut_Jpsi, &b_EF_e5_tight_e9_etcut_Jpsi);
   fChain->SetBranchAddress("EF_e60_loose", &EF_e60_loose, &b_EF_e60_loose);
   fChain->SetBranchAddress("EF_e6T_medium", &EF_e6T_medium, &b_EF_e6T_medium);
   fChain->SetBranchAddress("EF_e7_tight_e14_etcut_Jpsi", &EF_e7_tight_e14_etcut_Jpsi, &b_EF_e7_tight_e14_etcut_Jpsi);
   fChain->SetBranchAddress("EF_e9_tight_e5_tight_Jpsi", &EF_e9_tight_e5_tight_Jpsi, &b_EF_e9_tight_e5_tight_Jpsi);
   fChain->SetBranchAddress("EF_eb_physics", &EF_eb_physics, &b_EF_eb_physics);
   fChain->SetBranchAddress("EF_eb_physics_empty", &EF_eb_physics_empty, &b_EF_eb_physics_empty);
   fChain->SetBranchAddress("EF_eb_physics_firstempty", &EF_eb_physics_firstempty, &b_EF_eb_physics_firstempty);
   fChain->SetBranchAddress("EF_eb_physics_noL1PS", &EF_eb_physics_noL1PS, &b_EF_eb_physics_noL1PS);
   fChain->SetBranchAddress("EF_eb_physics_unpaired_iso", &EF_eb_physics_unpaired_iso, &b_EF_eb_physics_unpaired_iso);
   fChain->SetBranchAddress("EF_eb_physics_unpaired_noniso", &EF_eb_physics_unpaired_noniso, &b_EF_eb_physics_unpaired_noniso);
   fChain->SetBranchAddress("EF_eb_random", &EF_eb_random, &b_EF_eb_random);
   fChain->SetBranchAddress("EF_eb_random_empty", &EF_eb_random_empty, &b_EF_eb_random_empty);
   fChain->SetBranchAddress("EF_eb_random_firstempty", &EF_eb_random_firstempty, &b_EF_eb_random_firstempty);
   fChain->SetBranchAddress("EF_eb_random_unpaired_iso", &EF_eb_random_unpaired_iso, &b_EF_eb_random_unpaired_iso);
   fChain->SetBranchAddress("EF_g100_etcut_g50_etcut", &EF_g100_etcut_g50_etcut, &b_EF_g100_etcut_g50_etcut);
   fChain->SetBranchAddress("EF_g10_NoCut_cosmic", &EF_g10_NoCut_cosmic, &b_EF_g10_NoCut_cosmic);
   fChain->SetBranchAddress("EF_g11_etcut", &EF_g11_etcut, &b_EF_g11_etcut);
   fChain->SetBranchAddress("EF_g11_etcut_larcalib", &EF_g11_etcut_larcalib, &b_EF_g11_etcut_larcalib);
   fChain->SetBranchAddress("EF_g150_etcut", &EF_g150_etcut, &b_EF_g150_etcut);
   fChain->SetBranchAddress("EF_g15_loose", &EF_g15_loose, &b_EF_g15_loose);
   fChain->SetBranchAddress("EF_g15_loose_larcalib", &EF_g15_loose_larcalib, &b_EF_g15_loose_larcalib);
   fChain->SetBranchAddress("EF_g20_etcut", &EF_g20_etcut, &b_EF_g20_etcut);
   fChain->SetBranchAddress("EF_g20_etcut_xe30_noMu", &EF_g20_etcut_xe30_noMu, &b_EF_g20_etcut_xe30_noMu);
   fChain->SetBranchAddress("EF_g20_loose", &EF_g20_loose, &b_EF_g20_loose);
   fChain->SetBranchAddress("EF_g20_loose_larcalib", &EF_g20_loose_larcalib, &b_EF_g20_loose_larcalib);
   fChain->SetBranchAddress("EF_g40_loose", &EF_g40_loose, &b_EF_g40_loose);
   fChain->SetBranchAddress("EF_g40_loose_EFxe40_noMu", &EF_g40_loose_EFxe40_noMu, &b_EF_g40_loose_EFxe40_noMu);
   fChain->SetBranchAddress("EF_g40_loose_larcalib", &EF_g40_loose_larcalib, &b_EF_g40_loose_larcalib);
   fChain->SetBranchAddress("EF_g40_loose_xe45_medium_noMu", &EF_g40_loose_xe45_medium_noMu, &b_EF_g40_loose_xe45_medium_noMu);
   fChain->SetBranchAddress("EF_g40_loose_xe55_medium_noMu", &EF_g40_loose_xe55_medium_noMu, &b_EF_g40_loose_xe55_medium_noMu);
   fChain->SetBranchAddress("EF_g40_tight", &EF_g40_tight, &b_EF_g40_tight);
   fChain->SetBranchAddress("EF_g40_tight_b10_medium", &EF_g40_tight_b10_medium, &b_EF_g40_tight_b10_medium);
   fChain->SetBranchAddress("EF_g5_NoCut_cosmic", &EF_g5_NoCut_cosmic, &b_EF_g5_NoCut_cosmic);
   fChain->SetBranchAddress("EF_g60_loose", &EF_g60_loose, &b_EF_g60_loose);
   fChain->SetBranchAddress("EF_g60_loose_larcalib", &EF_g60_loose_larcalib, &b_EF_g60_loose_larcalib);
   fChain->SetBranchAddress("EF_g80_loose", &EF_g80_loose, &b_EF_g80_loose);
   fChain->SetBranchAddress("EF_g80_loose_larcalib", &EF_g80_loose_larcalib, &b_EF_g80_loose_larcalib);
   fChain->SetBranchAddress("EF_j100_a4tc_EFFS", &EF_j100_a4tc_EFFS, &b_EF_j100_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j100_a4tc_EFFS_ht350", &EF_j100_a4tc_EFFS_ht350, &b_EF_j100_a4tc_EFFS_ht350);
   fChain->SetBranchAddress("EF_j100_a4tc_EFFS_ht400", &EF_j100_a4tc_EFFS_ht400, &b_EF_j100_a4tc_EFFS_ht400);
   fChain->SetBranchAddress("EF_j100_a4tc_EFFS_ht500", &EF_j100_a4tc_EFFS_ht500, &b_EF_j100_a4tc_EFFS_ht500);
   fChain->SetBranchAddress("EF_j10_a4tc_EFFS", &EF_j10_a4tc_EFFS, &b_EF_j10_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j10_a4tc_EFFS_1vx", &EF_j10_a4tc_EFFS_1vx, &b_EF_j10_a4tc_EFFS_1vx);
   fChain->SetBranchAddress("EF_j135_a4tc_EFFS", &EF_j135_a4tc_EFFS, &b_EF_j135_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j135_a4tc_EFFS_ht500", &EF_j135_a4tc_EFFS_ht500, &b_EF_j135_a4tc_EFFS_ht500);
   fChain->SetBranchAddress("EF_j135_j30_a4tc_EFFS_dphi04", &EF_j135_j30_a4tc_EFFS_dphi04, &b_EF_j135_j30_a4tc_EFFS_dphi04);
   fChain->SetBranchAddress("EF_j15_a4tc_EFFS", &EF_j15_a4tc_EFFS, &b_EF_j15_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j180_a4tc_EFFS", &EF_j180_a4tc_EFFS, &b_EF_j180_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j180_j30_a4tc_EFFS_dphi04", &EF_j180_j30_a4tc_EFFS_dphi04, &b_EF_j180_j30_a4tc_EFFS_dphi04);
   fChain->SetBranchAddress("EF_j20_a4tc_EFFS", &EF_j20_a4tc_EFFS, &b_EF_j20_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j240_a10tc_EFFS", &EF_j240_a10tc_EFFS, &b_EF_j240_a10tc_EFFS);
   fChain->SetBranchAddress("EF_j240_a4tc_EFFS", &EF_j240_a4tc_EFFS, &b_EF_j240_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j240_a4tc_EFFS_l2cleanph", &EF_j240_a4tc_EFFS_l2cleanph, &b_EF_j240_a4tc_EFFS_l2cleanph);
   fChain->SetBranchAddress("EF_j30_a4tc_EFFS", &EF_j30_a4tc_EFFS, &b_EF_j30_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j30_a4tc_EFFS_l2cleanph", &EF_j30_a4tc_EFFS_l2cleanph, &b_EF_j30_a4tc_EFFS_l2cleanph);
   fChain->SetBranchAddress("EF_j30_eta13_a4tc_EFFS_EFxe30_noMu_empty", &EF_j30_eta13_a4tc_EFFS_EFxe30_noMu_empty, &b_EF_j30_eta13_a4tc_EFFS_EFxe30_noMu_empty);
   fChain->SetBranchAddress("EF_j30_eta13_a4tc_EFFS_EFxe30_noMu_firstempty", &EF_j30_eta13_a4tc_EFFS_EFxe30_noMu_firstempty, &b_EF_j30_eta13_a4tc_EFFS_EFxe30_noMu_firstempty);
   fChain->SetBranchAddress("EF_j30_fj30_a4tc_EFFS", &EF_j30_fj30_a4tc_EFFS, &b_EF_j30_fj30_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j320_a10tc_EFFS", &EF_j320_a10tc_EFFS, &b_EF_j320_a10tc_EFFS);
   fChain->SetBranchAddress("EF_j320_a4tc_EFFS", &EF_j320_a4tc_EFFS, &b_EF_j320_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j35_a4tc_EFFS_L1TAU_HVtrk", &EF_j35_a4tc_EFFS_L1TAU_HVtrk, &b_EF_j35_a4tc_EFFS_L1TAU_HVtrk);
   fChain->SetBranchAddress("EF_j35_a4tc_EFFS_L1TAU_HVtrk_cosmic", &EF_j35_a4tc_EFFS_L1TAU_HVtrk_cosmic, &b_EF_j35_a4tc_EFFS_L1TAU_HVtrk_cosmic);
   fChain->SetBranchAddress("EF_j35_a4tc_EFFS_L1TAU_HVtrk_firstempty", &EF_j35_a4tc_EFFS_L1TAU_HVtrk_firstempty, &b_EF_j35_a4tc_EFFS_L1TAU_HVtrk_firstempty);
   fChain->SetBranchAddress("EF_j35_a4tc_EFFS_L1TAU_HVtrk_unpaired_iso", &EF_j35_a4tc_EFFS_L1TAU_HVtrk_unpaired_iso, &b_EF_j35_a4tc_EFFS_L1TAU_HVtrk_unpaired_iso);
   fChain->SetBranchAddress("EF_j35_a4tc_EFFS_L1TAU_HVtrk_unpaired_noniso", &EF_j35_a4tc_EFFS_L1TAU_HVtrk_unpaired_noniso, &b_EF_j35_a4tc_EFFS_L1TAU_HVtrk_unpaired_noniso);
   fChain->SetBranchAddress("EF_j40_a4tc_EFFS", &EF_j40_a4tc_EFFS, &b_EF_j40_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j40_fj40_a4tc_EFFS", &EF_j40_fj40_a4tc_EFFS, &b_EF_j40_fj40_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j425_a10tc_EFFS", &EF_j425_a10tc_EFFS, &b_EF_j425_a10tc_EFFS);
   fChain->SetBranchAddress("EF_j425_a4tc_EFFS", &EF_j425_a4tc_EFFS, &b_EF_j425_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j50_eta13_a4tc_EFFS_EFxe50_noMu_empty", &EF_j50_eta13_a4tc_EFFS_EFxe50_noMu_empty, &b_EF_j50_eta13_a4tc_EFFS_EFxe50_noMu_empty);
   fChain->SetBranchAddress("EF_j50_eta13_a4tc_EFFS_EFxe50_noMu_firstempty", &EF_j50_eta13_a4tc_EFFS_EFxe50_noMu_firstempty, &b_EF_j50_eta13_a4tc_EFFS_EFxe50_noMu_firstempty);
   fChain->SetBranchAddress("EF_j50_eta25_a4tc_EFFS_EFxe50_noMu_empty", &EF_j50_eta25_a4tc_EFFS_EFxe50_noMu_empty, &b_EF_j50_eta25_a4tc_EFFS_EFxe50_noMu_empty);
   fChain->SetBranchAddress("EF_j50_eta25_a4tc_EFFS_EFxe50_noMu_firstempty", &EF_j50_eta25_a4tc_EFFS_EFxe50_noMu_firstempty, &b_EF_j50_eta25_a4tc_EFFS_EFxe50_noMu_firstempty);
   fChain->SetBranchAddress("EF_j55_a4tc_EFFS", &EF_j55_a4tc_EFFS, &b_EF_j55_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j55_a4tc_EFFS_xe55_medium_noMu_dphi2j30xe10", &EF_j55_a4tc_EFFS_xe55_medium_noMu_dphi2j30xe10, &b_EF_j55_a4tc_EFFS_xe55_medium_noMu_dphi2j30xe10);
   fChain->SetBranchAddress("EF_j55_a4tc_EFFS_xe55_medium_noMu_dphi2j30xe10_l2cleancons", &EF_j55_a4tc_EFFS_xe55_medium_noMu_dphi2j30xe10_l2cleancons, &b_EF_j55_a4tc_EFFS_xe55_medium_noMu_dphi2j30xe10_l2cleancons);
   fChain->SetBranchAddress("EF_j55_fj55_a4tc_EFFS", &EF_j55_fj55_a4tc_EFFS, &b_EF_j55_fj55_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j65_a4tc_EFFS_xe65_noMu_dphi2j30xe10", &EF_j65_a4tc_EFFS_xe65_noMu_dphi2j30xe10, &b_EF_j65_a4tc_EFFS_xe65_noMu_dphi2j30xe10);
   fChain->SetBranchAddress("EF_j75_2j30_a4tc_EFFS_ht350", &EF_j75_2j30_a4tc_EFFS_ht350, &b_EF_j75_2j30_a4tc_EFFS_ht350);
   fChain->SetBranchAddress("EF_j75_a4tc_EFFS", &EF_j75_a4tc_EFFS, &b_EF_j75_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j75_a4tc_EFFS_xe40_loose_noMu", &EF_j75_a4tc_EFFS_xe40_loose_noMu, &b_EF_j75_a4tc_EFFS_xe40_loose_noMu);
   fChain->SetBranchAddress("EF_j75_a4tc_EFFS_xe45_loose_noMu", &EF_j75_a4tc_EFFS_xe45_loose_noMu, &b_EF_j75_a4tc_EFFS_xe45_loose_noMu);
   fChain->SetBranchAddress("EF_j75_a4tc_EFFS_xe55_loose_noMu", &EF_j75_a4tc_EFFS_xe55_loose_noMu, &b_EF_j75_a4tc_EFFS_xe55_loose_noMu);
   fChain->SetBranchAddress("EF_j75_a4tc_EFFS_xe55_noMu", &EF_j75_a4tc_EFFS_xe55_noMu, &b_EF_j75_a4tc_EFFS_xe55_noMu);
   fChain->SetBranchAddress("EF_j75_a4tc_EFFS_xe55_noMu_l2cleancons", &EF_j75_a4tc_EFFS_xe55_noMu_l2cleancons, &b_EF_j75_a4tc_EFFS_xe55_noMu_l2cleancons);
   fChain->SetBranchAddress("EF_j75_fj75_a4tc_EFFS", &EF_j75_fj75_a4tc_EFFS, &b_EF_j75_fj75_a4tc_EFFS);
   fChain->SetBranchAddress("EF_j75_j30_a4tc_EFFS_anymct150", &EF_j75_j30_a4tc_EFFS_anymct150, &b_EF_j75_j30_a4tc_EFFS_anymct150);
   fChain->SetBranchAddress("EF_j75_j30_a4tc_EFFS_anymct175", &EF_j75_j30_a4tc_EFFS_anymct175, &b_EF_j75_j30_a4tc_EFFS_anymct175);
   fChain->SetBranchAddress("EF_j80_a4tc_EFFS_xe60_noMu", &EF_j80_a4tc_EFFS_xe60_noMu, &b_EF_j80_a4tc_EFFS_xe60_noMu);
   fChain->SetBranchAddress("EF_mu0_empty_NoAlg", &EF_mu0_empty_NoAlg, &b_EF_mu0_empty_NoAlg);
   fChain->SetBranchAddress("EF_mu0_firstempty_NoAlg", &EF_mu0_firstempty_NoAlg, &b_EF_mu0_firstempty_NoAlg);
   fChain->SetBranchAddress("EF_mu0_unpaired_iso_NoAlg", &EF_mu0_unpaired_iso_NoAlg, &b_EF_mu0_unpaired_iso_NoAlg);
   fChain->SetBranchAddress("EF_mu10", &EF_mu10, &b_EF_mu10);
   fChain->SetBranchAddress("EF_mu10_Jpsimumu", &EF_mu10_Jpsimumu, &b_EF_mu10_Jpsimumu);
   fChain->SetBranchAddress("EF_mu10_NL", &EF_mu10_NL, &b_EF_mu10_NL);
   fChain->SetBranchAddress("EF_mu10_Upsimumu_FS", &EF_mu10_Upsimumu_FS, &b_EF_mu10_Upsimumu_FS);
   fChain->SetBranchAddress("EF_mu10_Upsimumu_tight_FS", &EF_mu10_Upsimumu_tight_FS, &b_EF_mu10_Upsimumu_tight_FS);
   fChain->SetBranchAddress("EF_mu10_loose", &EF_mu10_loose, &b_EF_mu10_loose);
   fChain->SetBranchAddress("EF_mu10_muCombTag_NoEF", &EF_mu10_muCombTag_NoEF, &b_EF_mu10_muCombTag_NoEF);
   fChain->SetBranchAddress("EF_mu11_empty_NoAlg", &EF_mu11_empty_NoAlg, &b_EF_mu11_empty_NoAlg);
   fChain->SetBranchAddress("EF_mu13", &EF_mu13, &b_EF_mu13);
   fChain->SetBranchAddress("EF_mu13_MG", &EF_mu13_MG, &b_EF_mu13_MG);
   fChain->SetBranchAddress("EF_mu13_muCombTag_NoEF", &EF_mu13_muCombTag_NoEF, &b_EF_mu13_muCombTag_NoEF);
   fChain->SetBranchAddress("EF_mu15", &EF_mu15, &b_EF_mu15);
   fChain->SetBranchAddress("EF_mu15_mu10_EFFS", &EF_mu15_mu10_EFFS, &b_EF_mu15_mu10_EFFS);
   fChain->SetBranchAddress("EF_mu15_mu10_EFFS_medium", &EF_mu15_mu10_EFFS_medium, &b_EF_mu15_mu10_EFFS_medium);
   fChain->SetBranchAddress("EF_mu15_mu10_EFFS_tight", &EF_mu15_mu10_EFFS_tight, &b_EF_mu15_mu10_EFFS_tight);
   fChain->SetBranchAddress("EF_mu15_xe30_noMu", &EF_mu15_xe30_noMu, &b_EF_mu15_xe30_noMu);
   fChain->SetBranchAddress("EF_mu15i", &EF_mu15i, &b_EF_mu15i);
   fChain->SetBranchAddress("EF_mu15i_medium", &EF_mu15i_medium, &b_EF_mu15i_medium);
   fChain->SetBranchAddress("EF_mu18", &EF_mu18, &b_EF_mu18);
   fChain->SetBranchAddress("EF_mu18_L1J10", &EF_mu18_L1J10, &b_EF_mu18_L1J10);
   fChain->SetBranchAddress("EF_mu18_MG", &EF_mu18_MG, &b_EF_mu18_MG);
   fChain->SetBranchAddress("EF_mu18_MG_L1J10", &EF_mu18_MG_L1J10, &b_EF_mu18_MG_L1J10);
   fChain->SetBranchAddress("EF_mu18_MG_medium", &EF_mu18_MG_medium, &b_EF_mu18_MG_medium);
   fChain->SetBranchAddress("EF_mu18_medium", &EF_mu18_medium, &b_EF_mu18_medium);
   fChain->SetBranchAddress("EF_mu20", &EF_mu20, &b_EF_mu20);
   fChain->SetBranchAddress("EF_mu20_IDTrkNoCut", &EF_mu20_IDTrkNoCut, &b_EF_mu20_IDTrkNoCut);
   fChain->SetBranchAddress("EF_mu20_IDTrkNoCut_ManyVx", &EF_mu20_IDTrkNoCut_ManyVx, &b_EF_mu20_IDTrkNoCut_ManyVx);
   fChain->SetBranchAddress("EF_mu20_MG", &EF_mu20_MG, &b_EF_mu20_MG);
   fChain->SetBranchAddress("EF_mu20_MG_medium", &EF_mu20_MG_medium, &b_EF_mu20_MG_medium);
   fChain->SetBranchAddress("EF_mu20_empty", &EF_mu20_empty, &b_EF_mu20_empty);
   fChain->SetBranchAddress("EF_mu20_medium", &EF_mu20_medium, &b_EF_mu20_medium);
   fChain->SetBranchAddress("EF_mu20_mu10_EFFS_tight", &EF_mu20_mu10_EFFS_tight, &b_EF_mu20_mu10_EFFS_tight);
   fChain->SetBranchAddress("EF_mu20_muCombTag_NoEF", &EF_mu20_muCombTag_NoEF, &b_EF_mu20_muCombTag_NoEF);
   fChain->SetBranchAddress("EF_mu20i", &EF_mu20i, &b_EF_mu20i);
   fChain->SetBranchAddress("EF_mu20i_medium", &EF_mu20i_medium, &b_EF_mu20i_medium);
   fChain->SetBranchAddress("EF_mu22", &EF_mu22, &b_EF_mu22);
   fChain->SetBranchAddress("EF_mu22_MG", &EF_mu22_MG, &b_EF_mu22_MG);
   fChain->SetBranchAddress("EF_mu22_MG_medium", &EF_mu22_MG_medium, &b_EF_mu22_MG_medium);
   fChain->SetBranchAddress("EF_mu22_medium", &EF_mu22_medium, &b_EF_mu22_medium);
   fChain->SetBranchAddress("EF_mu24_MG_medium", &EF_mu24_MG_medium, &b_EF_mu24_MG_medium);
   fChain->SetBranchAddress("EF_mu24_MG_tight", &EF_mu24_MG_tight, &b_EF_mu24_MG_tight);
   fChain->SetBranchAddress("EF_mu24_medium", &EF_mu24_medium, &b_EF_mu24_medium);
   fChain->SetBranchAddress("EF_mu24_tight", &EF_mu24_tight, &b_EF_mu24_tight);
   fChain->SetBranchAddress("EF_mu30_MG_medium", &EF_mu30_MG_medium, &b_EF_mu30_MG_medium);
   fChain->SetBranchAddress("EF_mu30_MG_tight", &EF_mu30_MG_tight, &b_EF_mu30_MG_tight);
   fChain->SetBranchAddress("EF_mu30_medium", &EF_mu30_medium, &b_EF_mu30_medium);
   fChain->SetBranchAddress("EF_mu30_tight", &EF_mu30_tight, &b_EF_mu30_tight);
   fChain->SetBranchAddress("EF_mu4", &EF_mu4, &b_EF_mu4);
   fChain->SetBranchAddress("EF_mu40_MSonly_barrel", &EF_mu40_MSonly_barrel, &b_EF_mu40_MSonly_barrel);
   fChain->SetBranchAddress("EF_mu40_MSonly_barrel_medium", &EF_mu40_MSonly_barrel_medium, &b_EF_mu40_MSonly_barrel_medium);
   fChain->SetBranchAddress("EF_mu40_MSonly_empty", &EF_mu40_MSonly_empty, &b_EF_mu40_MSonly_empty);
   fChain->SetBranchAddress("EF_mu40_MSonly_tight", &EF_mu40_MSonly_tight, &b_EF_mu40_MSonly_tight);
   fChain->SetBranchAddress("EF_mu40_MSonly_tight_L1MU11", &EF_mu40_MSonly_tight_L1MU11, &b_EF_mu40_MSonly_tight_L1MU11);
   fChain->SetBranchAddress("EF_mu40_MSonly_tighter", &EF_mu40_MSonly_tighter, &b_EF_mu40_MSonly_tighter);
   fChain->SetBranchAddress("EF_mu40_slow", &EF_mu40_slow, &b_EF_mu40_slow);
   fChain->SetBranchAddress("EF_mu40_slow_empty", &EF_mu40_slow_empty, &b_EF_mu40_slow_empty);
   fChain->SetBranchAddress("EF_mu40_slow_medium", &EF_mu40_slow_medium, &b_EF_mu40_slow_medium);
   fChain->SetBranchAddress("EF_mu40_slow_outOfTime", &EF_mu40_slow_outOfTime, &b_EF_mu40_slow_outOfTime);
   fChain->SetBranchAddress("EF_mu40_slow_outOfTime_medium", &EF_mu40_slow_outOfTime_medium, &b_EF_mu40_slow_outOfTime_medium);
   fChain->SetBranchAddress("EF_mu4_DiMu", &EF_mu4_DiMu, &b_EF_mu4_DiMu);
   fChain->SetBranchAddress("EF_mu4_DiMu_FS_noOS", &EF_mu4_DiMu_FS_noOS, &b_EF_mu4_DiMu_FS_noOS);
   fChain->SetBranchAddress("EF_mu4_Jpsimumu", &EF_mu4_Jpsimumu, &b_EF_mu4_Jpsimumu);
   fChain->SetBranchAddress("EF_mu4_L1J10_matched", &EF_mu4_L1J10_matched, &b_EF_mu4_L1J10_matched);
   fChain->SetBranchAddress("EF_mu4_L1J15_matched", &EF_mu4_L1J15_matched, &b_EF_mu4_L1J15_matched);
   fChain->SetBranchAddress("EF_mu4_L1J20_matched", &EF_mu4_L1J20_matched, &b_EF_mu4_L1J20_matched);
   fChain->SetBranchAddress("EF_mu4_L1J30_matched", &EF_mu4_L1J30_matched, &b_EF_mu4_L1J30_matched);
   fChain->SetBranchAddress("EF_mu4_L1J50_matched", &EF_mu4_L1J50_matched, &b_EF_mu4_L1J50_matched);
   fChain->SetBranchAddress("EF_mu4_L1J75_matched", &EF_mu4_L1J75_matched, &b_EF_mu4_L1J75_matched);
   fChain->SetBranchAddress("EF_mu4_L1MU11_MSonly_cosmic", &EF_mu4_L1MU11_MSonly_cosmic, &b_EF_mu4_L1MU11_MSonly_cosmic);
   fChain->SetBranchAddress("EF_mu4_L1MU11_cosmic", &EF_mu4_L1MU11_cosmic, &b_EF_mu4_L1MU11_cosmic);
   fChain->SetBranchAddress("EF_mu4_MSonly_cosmic", &EF_mu4_MSonly_cosmic, &b_EF_mu4_MSonly_cosmic);
   fChain->SetBranchAddress("EF_mu4_Trk_Jpsi", &EF_mu4_Trk_Jpsi, &b_EF_mu4_Trk_Jpsi);
   fChain->SetBranchAddress("EF_mu4_Trk_Upsi_FS", &EF_mu4_Trk_Upsi_FS, &b_EF_mu4_Trk_Upsi_FS);
   fChain->SetBranchAddress("EF_mu4_Upsimumu_FS", &EF_mu4_Upsimumu_FS, &b_EF_mu4_Upsimumu_FS);
   fChain->SetBranchAddress("EF_mu4_Upsimumu_SiTrk_FS", &EF_mu4_Upsimumu_SiTrk_FS, &b_EF_mu4_Upsimumu_SiTrk_FS);
   fChain->SetBranchAddress("EF_mu4_Upsimumu_tight_FS", &EF_mu4_Upsimumu_tight_FS, &b_EF_mu4_Upsimumu_tight_FS);
   fChain->SetBranchAddress("EF_mu4_cosmic", &EF_mu4_cosmic, &b_EF_mu4_cosmic);
   fChain->SetBranchAddress("EF_mu4_j10_a4tc_EFFS", &EF_mu4_j10_a4tc_EFFS, &b_EF_mu4_j10_a4tc_EFFS);
   fChain->SetBranchAddress("EF_mu4_j10_a4tc_EFFS_matched", &EF_mu4_j10_a4tc_EFFS_matched, &b_EF_mu4_j10_a4tc_EFFS_matched);
   fChain->SetBranchAddress("EF_mu4_j135_a4tc_EFFS_L1matched", &EF_mu4_j135_a4tc_EFFS_L1matched, &b_EF_mu4_j135_a4tc_EFFS_L1matched);
   fChain->SetBranchAddress("EF_mu4_j180_a4tc_EFFS_L1matched", &EF_mu4_j180_a4tc_EFFS_L1matched, &b_EF_mu4_j180_a4tc_EFFS_L1matched);
   fChain->SetBranchAddress("EF_mu4_j45_a4tc_EFFS_xe45_loose_noMu", &EF_mu4_j45_a4tc_EFFS_xe45_loose_noMu, &b_EF_mu4_j45_a4tc_EFFS_xe45_loose_noMu);
   fChain->SetBranchAddress("EF_mu4imu6i_DiMu_DY", &EF_mu4imu6i_DiMu_DY, &b_EF_mu4imu6i_DiMu_DY);
   fChain->SetBranchAddress("EF_mu4imu6i_DiMu_DY14_noVtx_noOS", &EF_mu4imu6i_DiMu_DY14_noVtx_noOS, &b_EF_mu4imu6i_DiMu_DY14_noVtx_noOS);
   fChain->SetBranchAddress("EF_mu4mu6_Bmumu", &EF_mu4mu6_Bmumu, &b_EF_mu4mu6_Bmumu);
   fChain->SetBranchAddress("EF_mu4mu6_Bmumux", &EF_mu4mu6_Bmumux, &b_EF_mu4mu6_Bmumux);
   fChain->SetBranchAddress("EF_mu4mu6_DiMu", &EF_mu4mu6_DiMu, &b_EF_mu4mu6_DiMu);
   fChain->SetBranchAddress("EF_mu4mu6_DiMu_DY20", &EF_mu4mu6_DiMu_DY20, &b_EF_mu4mu6_DiMu_DY20);
   fChain->SetBranchAddress("EF_mu4mu6_DiMu_noVtx_noOS", &EF_mu4mu6_DiMu_noVtx_noOS, &b_EF_mu4mu6_DiMu_noVtx_noOS);
   fChain->SetBranchAddress("EF_mu4mu6_Jpsimumu", &EF_mu4mu6_Jpsimumu, &b_EF_mu4mu6_Jpsimumu);
   fChain->SetBranchAddress("EF_mu4mu6_Upsimumu", &EF_mu4mu6_Upsimumu, &b_EF_mu4mu6_Upsimumu);
   fChain->SetBranchAddress("EF_mu6", &EF_mu6, &b_EF_mu6);
   fChain->SetBranchAddress("EF_mu6_DiMu_noOS", &EF_mu6_DiMu_noOS, &b_EF_mu6_DiMu_noOS);
   fChain->SetBranchAddress("EF_mu6_Jpsimumu", &EF_mu6_Jpsimumu, &b_EF_mu6_Jpsimumu);
   fChain->SetBranchAddress("EF_mu6_Jpsimumu_SiTrk", &EF_mu6_Jpsimumu_SiTrk, &b_EF_mu6_Jpsimumu_SiTrk);
   fChain->SetBranchAddress("EF_mu6_Jpsimumu_tight", &EF_mu6_Jpsimumu_tight, &b_EF_mu6_Jpsimumu_tight);
   fChain->SetBranchAddress("EF_mu6_Trk_Jpsi_loose", &EF_mu6_Trk_Jpsi_loose, &b_EF_mu6_Trk_Jpsi_loose);
   fChain->SetBranchAddress("EF_tau100_medium", &EF_tau100_medium, &b_EF_tau100_medium);
   fChain->SetBranchAddress("EF_tau125_medium", &EF_tau125_medium, &b_EF_tau125_medium);
   fChain->SetBranchAddress("EF_tau125_medium1", &EF_tau125_medium1, &b_EF_tau125_medium1);
   fChain->SetBranchAddress("EF_tau16_IDTrkNoCut", &EF_tau16_IDTrkNoCut, &b_EF_tau16_IDTrkNoCut);
   fChain->SetBranchAddress("EF_tau16_loose", &EF_tau16_loose, &b_EF_tau16_loose);
   fChain->SetBranchAddress("EF_tau16_loose_e15_medium", &EF_tau16_loose_e15_medium, &b_EF_tau16_loose_e15_medium);
   fChain->SetBranchAddress("EF_tau16_loose_mu10", &EF_tau16_loose_mu10, &b_EF_tau16_loose_mu10);
   fChain->SetBranchAddress("EF_tau16_loose_mu15", &EF_tau16_loose_mu15, &b_EF_tau16_loose_mu15);
   fChain->SetBranchAddress("EF_tau16_medium", &EF_tau16_medium, &b_EF_tau16_medium);
   fChain->SetBranchAddress("EF_tau16_medium_mu10", &EF_tau16_medium_mu10, &b_EF_tau16_medium_mu10);
   fChain->SetBranchAddress("EF_tau20T_medium", &EF_tau20T_medium, &b_EF_tau20T_medium);
   fChain->SetBranchAddress("EF_tau20T_medium_e15_medium", &EF_tau20T_medium_e15_medium, &b_EF_tau20T_medium_e15_medium);
   fChain->SetBranchAddress("EF_tau20T_medium_mu15", &EF_tau20T_medium_mu15, &b_EF_tau20T_medium_mu15);
   fChain->SetBranchAddress("EF_tau20_medium", &EF_tau20_medium, &b_EF_tau20_medium);
   fChain->SetBranchAddress("EF_tau20_medium1", &EF_tau20_medium1, &b_EF_tau20_medium1);
   fChain->SetBranchAddress("EF_tau20_medium_e15_medium", &EF_tau20_medium_e15_medium, &b_EF_tau20_medium_e15_medium);
   fChain->SetBranchAddress("EF_tau20_medium_mu15", &EF_tau20_medium_mu15, &b_EF_tau20_medium_mu15);
   fChain->SetBranchAddress("EF_tau29T_medium", &EF_tau29T_medium, &b_EF_tau29T_medium);
   fChain->SetBranchAddress("EF_tau29T_medium1_tau20T_medium1", &EF_tau29T_medium1_tau20T_medium1, &b_EF_tau29T_medium1_tau20T_medium1);
   fChain->SetBranchAddress("EF_tau29T_medium1_xs45_loose_noMu_3L1J10", &EF_tau29T_medium1_xs45_loose_noMu_3L1J10, &b_EF_tau29T_medium1_xs45_loose_noMu_3L1J10);
   fChain->SetBranchAddress("EF_tau29T_medium_xs75_loose_noMu", &EF_tau29T_medium_xs75_loose_noMu, &b_EF_tau29T_medium_xs75_loose_noMu);
   fChain->SetBranchAddress("EF_tau29T_medium_xs75_noMu", &EF_tau29T_medium_xs75_noMu, &b_EF_tau29T_medium_xs75_noMu);
   fChain->SetBranchAddress("EF_tau29_loose", &EF_tau29_loose, &b_EF_tau29_loose);
   fChain->SetBranchAddress("EF_tau29_loose1", &EF_tau29_loose1, &b_EF_tau29_loose1);
   fChain->SetBranchAddress("EF_tau29_loose1_xs45_loose_noMu_3L1J10", &EF_tau29_loose1_xs45_loose_noMu_3L1J10, &b_EF_tau29_loose1_xs45_loose_noMu_3L1J10);
   fChain->SetBranchAddress("EF_tau29_loose_xs45_loose_noMu_3L1J10", &EF_tau29_loose_xs45_loose_noMu_3L1J10, &b_EF_tau29_loose_xs45_loose_noMu_3L1J10);
   fChain->SetBranchAddress("EF_tau29_loose_xs70_loose_noMu", &EF_tau29_loose_xs70_loose_noMu, &b_EF_tau29_loose_xs70_loose_noMu);
   fChain->SetBranchAddress("EF_tau29_loose_xs80_loose_noMu", &EF_tau29_loose_xs80_loose_noMu, &b_EF_tau29_loose_xs80_loose_noMu);
   fChain->SetBranchAddress("EF_tau29_medium", &EF_tau29_medium, &b_EF_tau29_medium);
   fChain->SetBranchAddress("EF_tau29_medium1", &EF_tau29_medium1, &b_EF_tau29_medium1);
   fChain->SetBranchAddress("EF_tau29_medium1_tau20_medium1", &EF_tau29_medium1_tau20_medium1, &b_EF_tau29_medium1_tau20_medium1);
   fChain->SetBranchAddress("EF_tau29_medium1_xs45_loose_noMu_3L1J10", &EF_tau29_medium1_xs45_loose_noMu_3L1J10, &b_EF_tau29_medium1_xs45_loose_noMu_3L1J10);
   fChain->SetBranchAddress("EF_tau29_medium_xe35_noMu", &EF_tau29_medium_xe35_noMu, &b_EF_tau29_medium_xe35_noMu);
   fChain->SetBranchAddress("EF_tau29_medium_xe40_loose_noMu", &EF_tau29_medium_xe40_loose_noMu, &b_EF_tau29_medium_xe40_loose_noMu);
   fChain->SetBranchAddress("EF_tau29_medium_xs70_noMu", &EF_tau29_medium_xs70_noMu, &b_EF_tau29_medium_xs70_noMu);
   fChain->SetBranchAddress("EF_tau29_medium_xs75_noMu", &EF_tau29_medium_xs75_noMu, &b_EF_tau29_medium_xs75_noMu);
   fChain->SetBranchAddress("EF_tau50_IDTrkNoCut", &EF_tau50_IDTrkNoCut, &b_EF_tau50_IDTrkNoCut);
   fChain->SetBranchAddress("EF_tau50_medium", &EF_tau50_medium, &b_EF_tau50_medium);
   fChain->SetBranchAddress("EF_tau84_loose", &EF_tau84_loose, &b_EF_tau84_loose);
   fChain->SetBranchAddress("EF_tauNoCut", &EF_tauNoCut, &b_EF_tauNoCut);
   fChain->SetBranchAddress("EF_tauNoCut_L1TAU50", &EF_tauNoCut_L1TAU50, &b_EF_tauNoCut_L1TAU50);
   fChain->SetBranchAddress("EF_tauNoCut_cosmic", &EF_tauNoCut_cosmic, &b_EF_tauNoCut_cosmic);
   fChain->SetBranchAddress("EF_xe20_noMu", &EF_xe20_noMu, &b_EF_xe20_noMu);
   fChain->SetBranchAddress("EF_xe30_noMu", &EF_xe30_noMu, &b_EF_xe30_noMu);
   fChain->SetBranchAddress("EF_xe40_noMu", &EF_xe40_noMu, &b_EF_xe40_noMu);
   fChain->SetBranchAddress("EF_xe50_noMu", &EF_xe50_noMu, &b_EF_xe50_noMu);
   fChain->SetBranchAddress("EF_xe60_noMu", &EF_xe60_noMu, &b_EF_xe60_noMu);
   fChain->SetBranchAddress("EF_xe60_tight_noMu", &EF_xe60_tight_noMu, &b_EF_xe60_tight_noMu);
   fChain->SetBranchAddress("EF_xe60_verytight_noMu", &EF_xe60_verytight_noMu, &b_EF_xe60_verytight_noMu);
   fChain->SetBranchAddress("EF_xe70_noMu", &EF_xe70_noMu, &b_EF_xe70_noMu);
   fChain->SetBranchAddress("EF_xe70_tight_noMu", &EF_xe70_tight_noMu, &b_EF_xe70_tight_noMu);
   fChain->SetBranchAddress("EF_xe80_noMu", &EF_xe80_noMu, &b_EF_xe80_noMu);
   fChain->SetBranchAddress("EF_xe90_noMu", &EF_xe90_noMu, &b_EF_xe90_noMu);
   fChain->SetBranchAddress("L1_2EM10", &L1_2EM10, &b_L1_2EM10);
   fChain->SetBranchAddress("L1_2EM14", &L1_2EM14, &b_L1_2EM14);
   fChain->SetBranchAddress("L1_2EM3", &L1_2EM3, &b_L1_2EM3);
   fChain->SetBranchAddress("L1_2EM3_EM12", &L1_2EM3_EM12, &b_L1_2EM3_EM12);
   fChain->SetBranchAddress("L1_2EM3_EM7", &L1_2EM3_EM7, &b_L1_2EM3_EM7);
   fChain->SetBranchAddress("L1_2EM5", &L1_2EM5, &b_L1_2EM5);
   fChain->SetBranchAddress("L1_2EM5_EM10", &L1_2EM5_EM10, &b_L1_2EM5_EM10);
   fChain->SetBranchAddress("L1_2EM5_MU6", &L1_2EM5_MU6, &b_L1_2EM5_MU6);
   fChain->SetBranchAddress("L1_2EM5_NL", &L1_2EM5_NL, &b_L1_2EM5_NL);
   fChain->SetBranchAddress("L1_2EM7", &L1_2EM7, &b_L1_2EM7);
   fChain->SetBranchAddress("L1_2EM7_EM10", &L1_2EM7_EM10, &b_L1_2EM7_EM10);
   fChain->SetBranchAddress("L1_2J20_XE20", &L1_2J20_XE20, &b_L1_2J20_XE20);
   fChain->SetBranchAddress("L1_2J30_XE20", &L1_2J30_XE20, &b_L1_2J30_XE20);
   fChain->SetBranchAddress("L1_2MU0", &L1_2MU0, &b_L1_2MU0);
   fChain->SetBranchAddress("L1_2MU0_EMPTY", &L1_2MU0_EMPTY, &b_L1_2MU0_EMPTY);
   fChain->SetBranchAddress("L1_2MU0_FIRSTEMPTY", &L1_2MU0_FIRSTEMPTY, &b_L1_2MU0_FIRSTEMPTY);
   fChain->SetBranchAddress("L1_2MU0_MU6", &L1_2MU0_MU6, &b_L1_2MU0_MU6);
   fChain->SetBranchAddress("L1_2MU10", &L1_2MU10, &b_L1_2MU10);
   fChain->SetBranchAddress("L1_2MU6", &L1_2MU6, &b_L1_2MU6);
   fChain->SetBranchAddress("L1_2MU6_EMPTY", &L1_2MU6_EMPTY, &b_L1_2MU6_EMPTY);
   fChain->SetBranchAddress("L1_2MU6_FIRSTEMPTY", &L1_2MU6_FIRSTEMPTY, &b_L1_2MU6_FIRSTEMPTY);
   fChain->SetBranchAddress("L1_2MU6_NL", &L1_2MU6_NL, &b_L1_2MU6_NL);
   fChain->SetBranchAddress("L1_2MU6_UNPAIRED_ISO", &L1_2MU6_UNPAIRED_ISO, &b_L1_2MU6_UNPAIRED_ISO);
   fChain->SetBranchAddress("L1_2MU6_UNPAIRED_NONISO", &L1_2MU6_UNPAIRED_NONISO, &b_L1_2MU6_UNPAIRED_NONISO);
   fChain->SetBranchAddress("L1_2TAU11", &L1_2TAU11, &b_L1_2TAU11);
   fChain->SetBranchAddress("L1_2TAU11_EM10", &L1_2TAU11_EM10, &b_L1_2TAU11_EM10);
   fChain->SetBranchAddress("L1_2TAU11_TAU15", &L1_2TAU11_TAU15, &b_L1_2TAU11_TAU15);
   fChain->SetBranchAddress("L1_2TAU15", &L1_2TAU15, &b_L1_2TAU15);
   fChain->SetBranchAddress("L1_2TAU15_TAU20", &L1_2TAU15_TAU20, &b_L1_2TAU15_TAU20);
   fChain->SetBranchAddress("L1_2TAU6", &L1_2TAU6, &b_L1_2TAU6);
   fChain->SetBranchAddress("L1_2TAU6_EM10", &L1_2TAU6_EM10, &b_L1_2TAU6_EM10);
   fChain->SetBranchAddress("L1_2TAU8_EM10", &L1_2TAU8_EM10, &b_L1_2TAU8_EM10);
   fChain->SetBranchAddress("L1_2TAU8_TAU11", &L1_2TAU8_TAU11, &b_L1_2TAU8_TAU11);
   fChain->SetBranchAddress("L1_EM10", &L1_EM10, &b_L1_EM10);
   fChain->SetBranchAddress("L1_EM10_MU6", &L1_EM10_MU6, &b_L1_EM10_MU6);
   fChain->SetBranchAddress("L1_EM10_XE20", &L1_EM10_XE20, &b_L1_EM10_XE20);
   fChain->SetBranchAddress("L1_EM10_XE30", &L1_EM10_XE30, &b_L1_EM10_XE30);
   fChain->SetBranchAddress("L1_EM10_XS45", &L1_EM10_XS45, &b_L1_EM10_XS45);
   fChain->SetBranchAddress("L1_EM10_XS50", &L1_EM10_XS50, &b_L1_EM10_XS50);
   fChain->SetBranchAddress("L1_EM12", &L1_EM12, &b_L1_EM12);
   fChain->SetBranchAddress("L1_EM14", &L1_EM14, &b_L1_EM14);
   fChain->SetBranchAddress("L1_EM14_XE10", &L1_EM14_XE10, &b_L1_EM14_XE10);
   fChain->SetBranchAddress("L1_EM14_XE20", &L1_EM14_XE20, &b_L1_EM14_XE20);
   fChain->SetBranchAddress("L1_EM16", &L1_EM16, &b_L1_EM16);
   fChain->SetBranchAddress("L1_EM3", &L1_EM3, &b_L1_EM3);
   fChain->SetBranchAddress("L1_EM30", &L1_EM30, &b_L1_EM30);
   fChain->SetBranchAddress("L1_EM3_EMPTY", &L1_EM3_EMPTY, &b_L1_EM3_EMPTY);
   fChain->SetBranchAddress("L1_EM3_FIRSTEMPTY", &L1_EM3_FIRSTEMPTY, &b_L1_EM3_FIRSTEMPTY);
   fChain->SetBranchAddress("L1_EM3_MU0", &L1_EM3_MU0, &b_L1_EM3_MU0);
   fChain->SetBranchAddress("L1_EM3_MU6", &L1_EM3_MU6, &b_L1_EM3_MU6);
   fChain->SetBranchAddress("L1_EM3_UNPAIRED_ISO", &L1_EM3_UNPAIRED_ISO, &b_L1_EM3_UNPAIRED_ISO);
   fChain->SetBranchAddress("L1_EM3_UNPAIRED_NONISO", &L1_EM3_UNPAIRED_NONISO, &b_L1_EM3_UNPAIRED_NONISO);
   fChain->SetBranchAddress("L1_EM5", &L1_EM5, &b_L1_EM5);
   fChain->SetBranchAddress("L1_EM5_2MU6", &L1_EM5_2MU6, &b_L1_EM5_2MU6);
   fChain->SetBranchAddress("L1_EM5_EMPTY", &L1_EM5_EMPTY, &b_L1_EM5_EMPTY);
   fChain->SetBranchAddress("L1_EM5_MU10", &L1_EM5_MU10, &b_L1_EM5_MU10);
   fChain->SetBranchAddress("L1_EM5_MU6", &L1_EM5_MU6, &b_L1_EM5_MU6);
   fChain->SetBranchAddress("L1_EM7", &L1_EM7, &b_L1_EM7);
   fChain->SetBranchAddress("L1_J30_XE35", &L1_J30_XE35, &b_L1_J30_XE35);
   fChain->SetBranchAddress("L1_J30_XE40", &L1_J30_XE40, &b_L1_J30_XE40);
   fChain->SetBranchAddress("L1_J50_XE20", &L1_J50_XE20, &b_L1_J50_XE20);
   fChain->SetBranchAddress("L1_J50_XE30", &L1_J50_XE30, &b_L1_J50_XE30);
   fChain->SetBranchAddress("L1_J50_XE35", &L1_J50_XE35, &b_L1_J50_XE35);
   fChain->SetBranchAddress("L1_MU0", &L1_MU0, &b_L1_MU0);
   fChain->SetBranchAddress("L1_MU0_EMPTY", &L1_MU0_EMPTY, &b_L1_MU0_EMPTY);
   fChain->SetBranchAddress("L1_MU0_FIRSTEMPTY", &L1_MU0_FIRSTEMPTY, &b_L1_MU0_FIRSTEMPTY);
   fChain->SetBranchAddress("L1_MU0_J10", &L1_MU0_J10, &b_L1_MU0_J10);
   fChain->SetBranchAddress("L1_MU0_J15", &L1_MU0_J15, &b_L1_MU0_J15);
   fChain->SetBranchAddress("L1_MU0_J15_EMPTY", &L1_MU0_J15_EMPTY, &b_L1_MU0_J15_EMPTY);
   fChain->SetBranchAddress("L1_MU0_J15_FIRSTEMPTY", &L1_MU0_J15_FIRSTEMPTY, &b_L1_MU0_J15_FIRSTEMPTY);
   fChain->SetBranchAddress("L1_MU0_J15_UNPAIRED_ISO", &L1_MU0_J15_UNPAIRED_ISO, &b_L1_MU0_J15_UNPAIRED_ISO);
   fChain->SetBranchAddress("L1_MU0_J15_UNPAIRED_NONISO", &L1_MU0_J15_UNPAIRED_NONISO, &b_L1_MU0_J15_UNPAIRED_NONISO);
   fChain->SetBranchAddress("L1_MU0_J20_XE20", &L1_MU0_J20_XE20, &b_L1_MU0_J20_XE20);
   fChain->SetBranchAddress("L1_MU0_J30", &L1_MU0_J30, &b_L1_MU0_J30);
   fChain->SetBranchAddress("L1_MU0_J50", &L1_MU0_J50, &b_L1_MU0_J50);
   fChain->SetBranchAddress("L1_MU0_J75", &L1_MU0_J75, &b_L1_MU0_J75);
   fChain->SetBranchAddress("L1_MU0_UNPAIRED_ISO", &L1_MU0_UNPAIRED_ISO, &b_L1_MU0_UNPAIRED_ISO);
   fChain->SetBranchAddress("L1_MU0_UNPAIRED_NONISO", &L1_MU0_UNPAIRED_NONISO, &b_L1_MU0_UNPAIRED_NONISO);
   fChain->SetBranchAddress("L1_MU10", &L1_MU10, &b_L1_MU10);
   fChain->SetBranchAddress("L1_MU10_EMPTY", &L1_MU10_EMPTY, &b_L1_MU10_EMPTY);
   fChain->SetBranchAddress("L1_MU10_FIRSTEMPTY", &L1_MU10_FIRSTEMPTY, &b_L1_MU10_FIRSTEMPTY);
   fChain->SetBranchAddress("L1_MU10_J10", &L1_MU10_J10, &b_L1_MU10_J10);
   fChain->SetBranchAddress("L1_MU10_UNPAIRED_ISO", &L1_MU10_UNPAIRED_ISO, &b_L1_MU10_UNPAIRED_ISO);
   fChain->SetBranchAddress("L1_MU10_XE20", &L1_MU10_XE20, &b_L1_MU10_XE20);
   fChain->SetBranchAddress("L1_MU11", &L1_MU11, &b_L1_MU11);
   fChain->SetBranchAddress("L1_MU11_EMPTY", &L1_MU11_EMPTY, &b_L1_MU11_EMPTY);
   fChain->SetBranchAddress("L1_MU15", &L1_MU15, &b_L1_MU15);
   fChain->SetBranchAddress("L1_MU20", &L1_MU20, &b_L1_MU20);
   fChain->SetBranchAddress("L1_MU20_FIRSTEMPTY", &L1_MU20_FIRSTEMPTY, &b_L1_MU20_FIRSTEMPTY);
   fChain->SetBranchAddress("L1_MU6", &L1_MU6, &b_L1_MU6);
   fChain->SetBranchAddress("L1_MU6_FIRSTEMPTY", &L1_MU6_FIRSTEMPTY, &b_L1_MU6_FIRSTEMPTY);
   fChain->SetBranchAddress("L1_MU6_NL", &L1_MU6_NL, &b_L1_MU6_NL);
   fChain->SetBranchAddress("L1_TAU11", &L1_TAU11, &b_L1_TAU11);
   fChain->SetBranchAddress("L1_TAU11_2J10_J20_XE20", &L1_TAU11_2J10_J20_XE20, &b_L1_TAU11_2J10_J20_XE20);
   fChain->SetBranchAddress("L1_TAU11_MU10", &L1_TAU11_MU10, &b_L1_TAU11_MU10);
   fChain->SetBranchAddress("L1_TAU11_XE10_3J10", &L1_TAU11_XE10_3J10, &b_L1_TAU11_XE10_3J10);
   fChain->SetBranchAddress("L1_TAU11_XE20", &L1_TAU11_XE20, &b_L1_TAU11_XE20);
   fChain->SetBranchAddress("L1_TAU11_XS30", &L1_TAU11_XS30, &b_L1_TAU11_XS30);
   fChain->SetBranchAddress("L1_TAU11_XS35", &L1_TAU11_XS35, &b_L1_TAU11_XS35);
   fChain->SetBranchAddress("L1_TAU15", &L1_TAU15, &b_L1_TAU15);
   fChain->SetBranchAddress("L1_TAU15_XE10_3J10", &L1_TAU15_XE10_3J10, &b_L1_TAU15_XE10_3J10);
   fChain->SetBranchAddress("L1_TAU15_XE20", &L1_TAU15_XE20, &b_L1_TAU15_XE20);
   fChain->SetBranchAddress("L1_TAU15_XS35", &L1_TAU15_XS35, &b_L1_TAU15_XS35);
   fChain->SetBranchAddress("L1_TAU20", &L1_TAU20, &b_L1_TAU20);
   fChain->SetBranchAddress("L1_TAU30", &L1_TAU30, &b_L1_TAU30);
   fChain->SetBranchAddress("L1_TAU50", &L1_TAU50, &b_L1_TAU50);
   fChain->SetBranchAddress("L1_TAU6", &L1_TAU6, &b_L1_TAU6);
   fChain->SetBranchAddress("L1_TAU6_J50_XE20", &L1_TAU6_J50_XE20, &b_L1_TAU6_J50_XE20);
   fChain->SetBranchAddress("L1_TAU6_MU10", &L1_TAU6_MU10, &b_L1_TAU6_MU10);
   fChain->SetBranchAddress("L1_TAU6_XE10", &L1_TAU6_XE10, &b_L1_TAU6_XE10);
   fChain->SetBranchAddress("L1_TAU8", &L1_TAU8, &b_L1_TAU8);
   fChain->SetBranchAddress("L1_TAU8_EMPTY", &L1_TAU8_EMPTY, &b_L1_TAU8_EMPTY);
   fChain->SetBranchAddress("L1_TAU8_FIRSTEMPTY", &L1_TAU8_FIRSTEMPTY, &b_L1_TAU8_FIRSTEMPTY);
   fChain->SetBranchAddress("L1_TAU8_MU10", &L1_TAU8_MU10, &b_L1_TAU8_MU10);
   fChain->SetBranchAddress("L1_TAU8_UNPAIRED_ISO", &L1_TAU8_UNPAIRED_ISO, &b_L1_TAU8_UNPAIRED_ISO);
   fChain->SetBranchAddress("L1_TAU8_UNPAIRED_NONISO", &L1_TAU8_UNPAIRED_NONISO, &b_L1_TAU8_UNPAIRED_NONISO);
   fChain->SetBranchAddress("L1_XE10", &L1_XE10, &b_L1_XE10);
   fChain->SetBranchAddress("L1_XE20", &L1_XE20, &b_L1_XE20);
   fChain->SetBranchAddress("L1_XE25", &L1_XE25, &b_L1_XE25);
   fChain->SetBranchAddress("L1_XE30", &L1_XE30, &b_L1_XE30);
   fChain->SetBranchAddress("L1_XE35", &L1_XE35, &b_L1_XE35);
   fChain->SetBranchAddress("L1_XE40", &L1_XE40, &b_L1_XE40);
   fChain->SetBranchAddress("L1_XE50", &L1_XE50, &b_L1_XE50);
   fChain->SetBranchAddress("L1_XE60", &L1_XE60, &b_L1_XE60);
   fChain->SetBranchAddress("L2_2b10_medium_4L1J10", &L2_2b10_medium_4L1J10, &b_L2_2b10_medium_4L1J10);
   fChain->SetBranchAddress("L2_2b10_medium_4j25", &L2_2b10_medium_4j25, &b_L2_2b10_medium_4j25);
   fChain->SetBranchAddress("L2_2b10_medium_L1JE100", &L2_2b10_medium_L1JE100, &b_L2_2b10_medium_L1JE100);
   fChain->SetBranchAddress("L2_2b10_medium_L1JE140", &L2_2b10_medium_L1JE140, &b_L2_2b10_medium_L1JE140);
   fChain->SetBranchAddress("L2_2b10_medium_L1_2J10J50", &L2_2b10_medium_L1_2J10J50, &b_L2_2b10_medium_L1_2J10J50);
   fChain->SetBranchAddress("L2_2b10_medium_j70_j25", &L2_2b10_medium_j70_j25, &b_L2_2b10_medium_j70_j25);
   fChain->SetBranchAddress("L2_2b15_medium_3L1J15", &L2_2b15_medium_3L1J15, &b_L2_2b15_medium_3L1J15);
   fChain->SetBranchAddress("L2_2b20_medium_3L1J20", &L2_2b20_medium_3L1J20, &b_L2_2b20_medium_3L1J20);
   fChain->SetBranchAddress("L2_2e10_medium", &L2_2e10_medium, &b_L2_2e10_medium);
   fChain->SetBranchAddress("L2_2e10_medium_mu6", &L2_2e10_medium_mu6, &b_L2_2e10_medium_mu6);
   fChain->SetBranchAddress("L2_2e12T_medium", &L2_2e12T_medium, &b_L2_2e12T_medium);
   fChain->SetBranchAddress("L2_2e12_medium", &L2_2e12_medium, &b_L2_2e12_medium);
   fChain->SetBranchAddress("L2_2e15_medium", &L2_2e15_medium, &b_L2_2e15_medium);
   fChain->SetBranchAddress("L2_2e5_tight", &L2_2e5_tight, &b_L2_2e5_tight);
   fChain->SetBranchAddress("L2_2e5_tight_Jpsi", &L2_2e5_tight_Jpsi, &b_L2_2e5_tight_Jpsi);
   fChain->SetBranchAddress("L2_2g15_loose", &L2_2g15_loose, &b_L2_2g15_loose);
   fChain->SetBranchAddress("L2_2g20_loose", &L2_2g20_loose, &b_L2_2g20_loose);
   fChain->SetBranchAddress("L2_2j40_anymct100_xe20_medium_noMu", &L2_2j40_anymct100_xe20_medium_noMu, &b_L2_2j40_anymct100_xe20_medium_noMu);
   fChain->SetBranchAddress("L2_2j50_anymct100_xe20_medium_noMu", &L2_2j50_anymct100_xe20_medium_noMu, &b_L2_2j50_anymct100_xe20_medium_noMu);
   fChain->SetBranchAddress("L2_2mu10", &L2_2mu10, &b_L2_2mu10);
   fChain->SetBranchAddress("L2_2mu10_empty", &L2_2mu10_empty, &b_L2_2mu10_empty);
   fChain->SetBranchAddress("L2_2mu10_loose", &L2_2mu10_loose, &b_L2_2mu10_loose);
   fChain->SetBranchAddress("L2_2mu10_loose_empty", &L2_2mu10_loose_empty, &b_L2_2mu10_loose_empty);
   fChain->SetBranchAddress("L2_2mu10_loose_noOvlpRm", &L2_2mu10_loose_noOvlpRm, &b_L2_2mu10_loose_noOvlpRm);
   fChain->SetBranchAddress("L2_2mu13_Zmumu_IDTrkNoCut", &L2_2mu13_Zmumu_IDTrkNoCut, &b_L2_2mu13_Zmumu_IDTrkNoCut);
   fChain->SetBranchAddress("L2_2mu4", &L2_2mu4, &b_L2_2mu4);
   fChain->SetBranchAddress("L2_2mu4_Bmumu", &L2_2mu4_Bmumu, &b_L2_2mu4_Bmumu);
   fChain->SetBranchAddress("L2_2mu4_Bmumux", &L2_2mu4_Bmumux, &b_L2_2mu4_Bmumux);
   fChain->SetBranchAddress("L2_2mu4_DiMu", &L2_2mu4_DiMu, &b_L2_2mu4_DiMu);
   fChain->SetBranchAddress("L2_2mu4_DiMu_DY", &L2_2mu4_DiMu_DY, &b_L2_2mu4_DiMu_DY);
   fChain->SetBranchAddress("L2_2mu4_DiMu_DY20", &L2_2mu4_DiMu_DY20, &b_L2_2mu4_DiMu_DY20);
   fChain->SetBranchAddress("L2_2mu4_DiMu_DY_noVtx_noOS", &L2_2mu4_DiMu_DY_noVtx_noOS, &b_L2_2mu4_DiMu_DY_noVtx_noOS);
   fChain->SetBranchAddress("L2_2mu4_DiMu_SiTrk", &L2_2mu4_DiMu_SiTrk, &b_L2_2mu4_DiMu_SiTrk);
   fChain->SetBranchAddress("L2_2mu4_DiMu_noVtx_noOS", &L2_2mu4_DiMu_noVtx_noOS, &b_L2_2mu4_DiMu_noVtx_noOS);
   fChain->SetBranchAddress("L2_2mu4_Jpsimumu", &L2_2mu4_Jpsimumu, &b_L2_2mu4_Jpsimumu);
   fChain->SetBranchAddress("L2_2mu4_Jpsimumu_IDTrkNoCut", &L2_2mu4_Jpsimumu_IDTrkNoCut, &b_L2_2mu4_Jpsimumu_IDTrkNoCut);
   fChain->SetBranchAddress("L2_2mu4_Upsimumu", &L2_2mu4_Upsimumu, &b_L2_2mu4_Upsimumu);
   fChain->SetBranchAddress("L2_2mu4i_DiMu_DY", &L2_2mu4i_DiMu_DY, &b_L2_2mu4i_DiMu_DY);
   fChain->SetBranchAddress("L2_2mu6", &L2_2mu6, &b_L2_2mu6);
   fChain->SetBranchAddress("L2_2mu6_DiMu", &L2_2mu6_DiMu, &b_L2_2mu6_DiMu);
   fChain->SetBranchAddress("L2_2mu6_MSonly_g10_loose", &L2_2mu6_MSonly_g10_loose, &b_L2_2mu6_MSonly_g10_loose);
   fChain->SetBranchAddress("L2_2mu6_MSonly_g10_loose_nonfilled", &L2_2mu6_MSonly_g10_loose_nonfilled, &b_L2_2mu6_MSonly_g10_loose_nonfilled);
   fChain->SetBranchAddress("L2_2mu6_NL", &L2_2mu6_NL, &b_L2_2mu6_NL);
   fChain->SetBranchAddress("L2_2tau29T_medium1", &L2_2tau29T_medium1, &b_L2_2tau29T_medium1);
   fChain->SetBranchAddress("L2_2tau29_medium1", &L2_2tau29_medium1, &b_L2_2tau29_medium1);
   fChain->SetBranchAddress("L2_3b10_loose_4L1J10", &L2_3b10_loose_4L1J10, &b_L2_3b10_loose_4L1J10);
   fChain->SetBranchAddress("L2_3b15_loose_4L1J15", &L2_3b15_loose_4L1J15, &b_L2_3b15_loose_4L1J15);
   fChain->SetBranchAddress("L2_b10_IDTrkNoCut", &L2_b10_IDTrkNoCut, &b_L2_b10_IDTrkNoCut);
   fChain->SetBranchAddress("L2_b10_medium_4j25", &L2_b10_medium_4j25, &b_L2_b10_medium_4j25);
   fChain->SetBranchAddress("L2_b10_medium_EFxe25_noMu_L1JE140", &L2_b10_medium_EFxe25_noMu_L1JE140, &b_L2_b10_medium_EFxe25_noMu_L1JE140);
   fChain->SetBranchAddress("L2_b10_tight_4L1J10", &L2_b10_tight_4L1J10, &b_L2_b10_tight_4L1J10);
   fChain->SetBranchAddress("L2_b10_tight_L1JE140", &L2_b10_tight_L1JE140, &b_L2_b10_tight_L1JE140);
   fChain->SetBranchAddress("L2_e10_medium", &L2_e10_medium, &b_L2_e10_medium);
   fChain->SetBranchAddress("L2_e10_medium_2mu6", &L2_e10_medium_2mu6, &b_L2_e10_medium_2mu6);
   fChain->SetBranchAddress("L2_e10_medium_mu10", &L2_e10_medium_mu10, &b_L2_e10_medium_mu10);
   fChain->SetBranchAddress("L2_e10_medium_mu6", &L2_e10_medium_mu6, &b_L2_e10_medium_mu6);
   fChain->SetBranchAddress("L2_e10_medium_mu6_topo_medium", &L2_e10_medium_mu6_topo_medium, &b_L2_e10_medium_mu6_topo_medium);
   fChain->SetBranchAddress("L2_e11T_medium", &L2_e11T_medium, &b_L2_e11T_medium);
   fChain->SetBranchAddress("L2_e11T_medium_2e6T_medium", &L2_e11T_medium_2e6T_medium, &b_L2_e11T_medium_2e6T_medium);
   fChain->SetBranchAddress("L2_e11_etcut", &L2_e11_etcut, &b_L2_e11_etcut);
   fChain->SetBranchAddress("L2_e12T_medium_mu6_topo_medium", &L2_e12T_medium_mu6_topo_medium, &b_L2_e12T_medium_mu6_topo_medium);
   fChain->SetBranchAddress("L2_e12_medium", &L2_e12_medium, &b_L2_e12_medium);
   fChain->SetBranchAddress("L2_e13_etcut_xs45_noMu", &L2_e13_etcut_xs45_noMu, &b_L2_e13_etcut_xs45_noMu);
   fChain->SetBranchAddress("L2_e15_HLTtighter", &L2_e15_HLTtighter, &b_L2_e15_HLTtighter);
   fChain->SetBranchAddress("L2_e15_medium", &L2_e15_medium, &b_L2_e15_medium);
   fChain->SetBranchAddress("L2_e15_medium_e12_medium", &L2_e15_medium_e12_medium, &b_L2_e15_medium_e12_medium);
   fChain->SetBranchAddress("L2_e15_medium_xe20_noMu", &L2_e15_medium_xe20_noMu, &b_L2_e15_medium_xe20_noMu);
   fChain->SetBranchAddress("L2_e15_medium_xe30_noMu", &L2_e15_medium_xe30_noMu, &b_L2_e15_medium_xe30_noMu);
   fChain->SetBranchAddress("L2_e15_medium_xe35_noMu", &L2_e15_medium_xe35_noMu, &b_L2_e15_medium_xe35_noMu);
   fChain->SetBranchAddress("L2_e15_tight", &L2_e15_tight, &b_L2_e15_tight);
   fChain->SetBranchAddress("L2_e20_etcut_xs45_noMu", &L2_e20_etcut_xs45_noMu, &b_L2_e20_etcut_xs45_noMu);
   fChain->SetBranchAddress("L2_e20_loose", &L2_e20_loose, &b_L2_e20_loose);
   fChain->SetBranchAddress("L2_e20_loose1", &L2_e20_loose1, &b_L2_e20_loose1);
   fChain->SetBranchAddress("L2_e20_looseTrk", &L2_e20_looseTrk, &b_L2_e20_looseTrk);
   fChain->SetBranchAddress("L2_e20_medium", &L2_e20_medium, &b_L2_e20_medium);
   fChain->SetBranchAddress("L2_e20_medium1", &L2_e20_medium1, &b_L2_e20_medium1);
   fChain->SetBranchAddress("L2_e20_medium2", &L2_e20_medium2, &b_L2_e20_medium2);
   fChain->SetBranchAddress("L2_e20_medium_IDTrkNoCut", &L2_e20_medium_IDTrkNoCut, &b_L2_e20_medium_IDTrkNoCut);
   fChain->SetBranchAddress("L2_e20_medium_SiTrk", &L2_e20_medium_SiTrk, &b_L2_e20_medium_SiTrk);
   fChain->SetBranchAddress("L2_e20_medium_TRT", &L2_e20_medium_TRT, &b_L2_e20_medium_TRT);
   fChain->SetBranchAddress("L2_e20_tight_e15_NoCut_Zee", &L2_e20_tight_e15_NoCut_Zee, &b_L2_e20_tight_e15_NoCut_Zee);
   fChain->SetBranchAddress("L2_e22_etcut_xs45_noMu", &L2_e22_etcut_xs45_noMu, &b_L2_e22_etcut_xs45_noMu);
   fChain->SetBranchAddress("L2_e22_loose", &L2_e22_loose, &b_L2_e22_loose);
   fChain->SetBranchAddress("L2_e22_loose1", &L2_e22_loose1, &b_L2_e22_loose1);
   fChain->SetBranchAddress("L2_e22_looseTrk", &L2_e22_looseTrk, &b_L2_e22_looseTrk);
   fChain->SetBranchAddress("L2_e22_medium", &L2_e22_medium, &b_L2_e22_medium);
   fChain->SetBranchAddress("L2_e22_medium1", &L2_e22_medium1, &b_L2_e22_medium1);
   fChain->SetBranchAddress("L2_e22_medium2", &L2_e22_medium2, &b_L2_e22_medium2);
   fChain->SetBranchAddress("L2_e22_medium_IDTrkNoCut", &L2_e22_medium_IDTrkNoCut, &b_L2_e22_medium_IDTrkNoCut);
   fChain->SetBranchAddress("L2_e22_medium_SiTrk", &L2_e22_medium_SiTrk, &b_L2_e22_medium_SiTrk);
   fChain->SetBranchAddress("L2_e22_medium_TRT", &L2_e22_medium_TRT, &b_L2_e22_medium_TRT);
   fChain->SetBranchAddress("L2_e33_medium", &L2_e33_medium, &b_L2_e33_medium);
   fChain->SetBranchAddress("L2_e35_medium", &L2_e35_medium, &b_L2_e35_medium);
   fChain->SetBranchAddress("L2_e40_medium", &L2_e40_medium, &b_L2_e40_medium);
   fChain->SetBranchAddress("L2_e45_medium", &L2_e45_medium, &b_L2_e45_medium);
   fChain->SetBranchAddress("L2_e45_medium1", &L2_e45_medium1, &b_L2_e45_medium1);
   fChain->SetBranchAddress("L2_e5_medium_mu6", &L2_e5_medium_mu6, &b_L2_e5_medium_mu6);
   fChain->SetBranchAddress("L2_e5_medium_mu6_topo_medium", &L2_e5_medium_mu6_topo_medium, &b_L2_e5_medium_mu6_topo_medium);
   fChain->SetBranchAddress("L2_e5_tight", &L2_e5_tight, &b_L2_e5_tight);
   fChain->SetBranchAddress("L2_e5_tight_e14_etcut_Jpsi", &L2_e5_tight_e14_etcut_Jpsi, &b_L2_e5_tight_e14_etcut_Jpsi);
   fChain->SetBranchAddress("L2_e5_tight_e4_etcut_Jpsi", &L2_e5_tight_e4_etcut_Jpsi, &b_L2_e5_tight_e4_etcut_Jpsi);
   fChain->SetBranchAddress("L2_e5_tight_e4_etcut_Jpsi_SiTrk", &L2_e5_tight_e4_etcut_Jpsi_SiTrk, &b_L2_e5_tight_e4_etcut_Jpsi_SiTrk);
   fChain->SetBranchAddress("L2_e5_tight_e4_etcut_Jpsi_TRT", &L2_e5_tight_e4_etcut_Jpsi_TRT, &b_L2_e5_tight_e4_etcut_Jpsi_TRT);
   fChain->SetBranchAddress("L2_e5_tight_e5_NoCut", &L2_e5_tight_e5_NoCut, &b_L2_e5_tight_e5_NoCut);
   fChain->SetBranchAddress("L2_e5_tight_e9_etcut_Jpsi", &L2_e5_tight_e9_etcut_Jpsi, &b_L2_e5_tight_e9_etcut_Jpsi);
   fChain->SetBranchAddress("L2_e60_loose", &L2_e60_loose, &b_L2_e60_loose);
   fChain->SetBranchAddress("L2_e6T_medium", &L2_e6T_medium, &b_L2_e6T_medium);
   fChain->SetBranchAddress("L2_e7_tight_e14_etcut_Jpsi", &L2_e7_tight_e14_etcut_Jpsi, &b_L2_e7_tight_e14_etcut_Jpsi);
   fChain->SetBranchAddress("L2_e9_tight_e5_tight_Jpsi", &L2_e9_tight_e5_tight_Jpsi, &b_L2_e9_tight_e5_tight_Jpsi);
   fChain->SetBranchAddress("L2_eb_physics", &L2_eb_physics, &b_L2_eb_physics);
   fChain->SetBranchAddress("L2_eb_physics_empty", &L2_eb_physics_empty, &b_L2_eb_physics_empty);
   fChain->SetBranchAddress("L2_eb_physics_firstempty", &L2_eb_physics_firstempty, &b_L2_eb_physics_firstempty);
   fChain->SetBranchAddress("L2_eb_physics_noL1PS", &L2_eb_physics_noL1PS, &b_L2_eb_physics_noL1PS);
   fChain->SetBranchAddress("L2_eb_physics_unpaired_iso", &L2_eb_physics_unpaired_iso, &b_L2_eb_physics_unpaired_iso);
   fChain->SetBranchAddress("L2_eb_physics_unpaired_noniso", &L2_eb_physics_unpaired_noniso, &b_L2_eb_physics_unpaired_noniso);
   fChain->SetBranchAddress("L2_eb_random", &L2_eb_random, &b_L2_eb_random);
   fChain->SetBranchAddress("L2_eb_random_empty", &L2_eb_random_empty, &b_L2_eb_random_empty);
   fChain->SetBranchAddress("L2_eb_random_firstempty", &L2_eb_random_firstempty, &b_L2_eb_random_firstempty);
   fChain->SetBranchAddress("L2_eb_random_unpaired_iso", &L2_eb_random_unpaired_iso, &b_L2_eb_random_unpaired_iso);
   fChain->SetBranchAddress("L2_em3_empty_larcalib", &L2_em3_empty_larcalib, &b_L2_em3_empty_larcalib);
   fChain->SetBranchAddress("L2_em5_empty_larcalib", &L2_em5_empty_larcalib, &b_L2_em5_empty_larcalib);
   fChain->SetBranchAddress("L2_g100_etcut_g50_etcut", &L2_g100_etcut_g50_etcut, &b_L2_g100_etcut_g50_etcut);
   fChain->SetBranchAddress("L2_g10_NoCut_cosmic", &L2_g10_NoCut_cosmic, &b_L2_g10_NoCut_cosmic);
   fChain->SetBranchAddress("L2_g11_etcut", &L2_g11_etcut, &b_L2_g11_etcut);
   fChain->SetBranchAddress("L2_g150_etcut", &L2_g150_etcut, &b_L2_g150_etcut);
   fChain->SetBranchAddress("L2_g15_loose", &L2_g15_loose, &b_L2_g15_loose);
   fChain->SetBranchAddress("L2_g20_etcut", &L2_g20_etcut, &b_L2_g20_etcut);
   fChain->SetBranchAddress("L2_g20_etcut_xe30_noMu", &L2_g20_etcut_xe30_noMu, &b_L2_g20_etcut_xe30_noMu);
   fChain->SetBranchAddress("L2_g20_loose", &L2_g20_loose, &b_L2_g20_loose);
   fChain->SetBranchAddress("L2_g40_loose", &L2_g40_loose, &b_L2_g40_loose);
   fChain->SetBranchAddress("L2_g40_loose_EFxe40_noMu", &L2_g40_loose_EFxe40_noMu, &b_L2_g40_loose_EFxe40_noMu);
   fChain->SetBranchAddress("L2_g40_loose_xe30_medium_noMu", &L2_g40_loose_xe30_medium_noMu, &b_L2_g40_loose_xe30_medium_noMu);
   fChain->SetBranchAddress("L2_g40_loose_xe35_medium_noMu", &L2_g40_loose_xe35_medium_noMu, &b_L2_g40_loose_xe35_medium_noMu);
   fChain->SetBranchAddress("L2_g40_tight", &L2_g40_tight, &b_L2_g40_tight);
   fChain->SetBranchAddress("L2_g40_tight_b10_medium", &L2_g40_tight_b10_medium, &b_L2_g40_tight_b10_medium);
   fChain->SetBranchAddress("L2_g5_NoCut_cosmic", &L2_g5_NoCut_cosmic, &b_L2_g5_NoCut_cosmic);
   fChain->SetBranchAddress("L2_g60_loose", &L2_g60_loose, &b_L2_g60_loose);
   fChain->SetBranchAddress("L2_g80_loose", &L2_g80_loose, &b_L2_g80_loose);
   fChain->SetBranchAddress("L2_j50_xe35_medium_noMu", &L2_j50_xe35_medium_noMu, &b_L2_j50_xe35_medium_noMu);
   fChain->SetBranchAddress("L2_j50_xe35_medium_noMu_l2cleancons", &L2_j50_xe35_medium_noMu_l2cleancons, &b_L2_j50_xe35_medium_noMu_l2cleancons);
   fChain->SetBranchAddress("L2_j60_xe45_noMu", &L2_j60_xe45_noMu, &b_L2_j60_xe45_noMu);
   fChain->SetBranchAddress("L2_j70_xe20_loose_noMu", &L2_j70_xe20_loose_noMu, &b_L2_j70_xe20_loose_noMu);
   fChain->SetBranchAddress("L2_j70_xe25_loose_noMu", &L2_j70_xe25_loose_noMu, &b_L2_j70_xe25_loose_noMu);
   fChain->SetBranchAddress("L2_j70_xe35_noMu", &L2_j70_xe35_noMu, &b_L2_j70_xe35_noMu);
   fChain->SetBranchAddress("L2_j70_xe35_noMu_l2cleancons", &L2_j70_xe35_noMu_l2cleancons, &b_L2_j70_xe35_noMu_l2cleancons);
   fChain->SetBranchAddress("L2_j75_xe40_noMu", &L2_j75_xe40_noMu, &b_L2_j75_xe40_noMu);
   fChain->SetBranchAddress("L2_mu0_cal_empty", &L2_mu0_cal_empty, &b_L2_mu0_cal_empty);
   fChain->SetBranchAddress("L2_mu0_empty_NoAlg", &L2_mu0_empty_NoAlg, &b_L2_mu0_empty_NoAlg);
   fChain->SetBranchAddress("L2_mu0_firstempty_NoAlg", &L2_mu0_firstempty_NoAlg, &b_L2_mu0_firstempty_NoAlg);
   fChain->SetBranchAddress("L2_mu0_unpaired_iso_NoAlg", &L2_mu0_unpaired_iso_NoAlg, &b_L2_mu0_unpaired_iso_NoAlg);
   fChain->SetBranchAddress("L2_mu10", &L2_mu10, &b_L2_mu10);
   fChain->SetBranchAddress("L2_mu10_Jpsimumu", &L2_mu10_Jpsimumu, &b_L2_mu10_Jpsimumu);
   fChain->SetBranchAddress("L2_mu10_NL", &L2_mu10_NL, &b_L2_mu10_NL);
   fChain->SetBranchAddress("L2_mu10_Upsimumu_FS", &L2_mu10_Upsimumu_FS, &b_L2_mu10_Upsimumu_FS);
   fChain->SetBranchAddress("L2_mu10_Upsimumu_tight_FS", &L2_mu10_Upsimumu_tight_FS, &b_L2_mu10_Upsimumu_tight_FS);
   fChain->SetBranchAddress("L2_mu10_cal", &L2_mu10_cal, &b_L2_mu10_cal);
   fChain->SetBranchAddress("L2_mu10_cal_medium", &L2_mu10_cal_medium, &b_L2_mu10_cal_medium);
   fChain->SetBranchAddress("L2_mu10_loose", &L2_mu10_loose, &b_L2_mu10_loose);
   fChain->SetBranchAddress("L2_mu10_muCombTag_NoEF", &L2_mu10_muCombTag_NoEF, &b_L2_mu10_muCombTag_NoEF);
   fChain->SetBranchAddress("L2_mu11_empty_NoAlg", &L2_mu11_empty_NoAlg, &b_L2_mu11_empty_NoAlg);
   fChain->SetBranchAddress("L2_mu13", &L2_mu13, &b_L2_mu13);
   fChain->SetBranchAddress("L2_mu13_MG", &L2_mu13_MG, &b_L2_mu13_MG);
   fChain->SetBranchAddress("L2_mu13_muCombTag_NoEF", &L2_mu13_muCombTag_NoEF, &b_L2_mu13_muCombTag_NoEF);
   fChain->SetBranchAddress("L2_mu15", &L2_mu15, &b_L2_mu15);
   fChain->SetBranchAddress("L2_mu15_medium", &L2_mu15_medium, &b_L2_mu15_medium);
   fChain->SetBranchAddress("L2_mu15_tight", &L2_mu15_tight, &b_L2_mu15_tight);
   fChain->SetBranchAddress("L2_mu15_xe20_noMu", &L2_mu15_xe20_noMu, &b_L2_mu15_xe20_noMu);
   fChain->SetBranchAddress("L2_mu15i", &L2_mu15i, &b_L2_mu15i);
   fChain->SetBranchAddress("L2_mu15i_medium", &L2_mu15i_medium, &b_L2_mu15i_medium);
   fChain->SetBranchAddress("L2_mu18", &L2_mu18, &b_L2_mu18);
   fChain->SetBranchAddress("L2_mu18_L1J10", &L2_mu18_L1J10, &b_L2_mu18_L1J10);
   fChain->SetBranchAddress("L2_mu18_MG", &L2_mu18_MG, &b_L2_mu18_MG);
   fChain->SetBranchAddress("L2_mu18_MG_L1J10", &L2_mu18_MG_L1J10, &b_L2_mu18_MG_L1J10);
   fChain->SetBranchAddress("L2_mu18_MG_medium", &L2_mu18_MG_medium, &b_L2_mu18_MG_medium);
   fChain->SetBranchAddress("L2_mu18_medium", &L2_mu18_medium, &b_L2_mu18_medium);
   fChain->SetBranchAddress("L2_mu20", &L2_mu20, &b_L2_mu20);
   fChain->SetBranchAddress("L2_mu20_IDTrkNoCut", &L2_mu20_IDTrkNoCut, &b_L2_mu20_IDTrkNoCut);
   fChain->SetBranchAddress("L2_mu20_MG", &L2_mu20_MG, &b_L2_mu20_MG);
   fChain->SetBranchAddress("L2_mu20_MG_medium", &L2_mu20_MG_medium, &b_L2_mu20_MG_medium);
   fChain->SetBranchAddress("L2_mu20_empty", &L2_mu20_empty, &b_L2_mu20_empty);
   fChain->SetBranchAddress("L2_mu20_medium", &L2_mu20_medium, &b_L2_mu20_medium);
   fChain->SetBranchAddress("L2_mu20_muCombTag_NoEF", &L2_mu20_muCombTag_NoEF, &b_L2_mu20_muCombTag_NoEF);
   fChain->SetBranchAddress("L2_mu20_tight", &L2_mu20_tight, &b_L2_mu20_tight);
   fChain->SetBranchAddress("L2_mu20i", &L2_mu20i, &b_L2_mu20i);
   fChain->SetBranchAddress("L2_mu20i_medium", &L2_mu20i_medium, &b_L2_mu20i_medium);
   fChain->SetBranchAddress("L2_mu22", &L2_mu22, &b_L2_mu22);
   fChain->SetBranchAddress("L2_mu22_MG", &L2_mu22_MG, &b_L2_mu22_MG);
   fChain->SetBranchAddress("L2_mu22_MG_medium", &L2_mu22_MG_medium, &b_L2_mu22_MG_medium);
   fChain->SetBranchAddress("L2_mu22_medium", &L2_mu22_medium, &b_L2_mu22_medium);
   fChain->SetBranchAddress("L2_mu24_MG_medium", &L2_mu24_MG_medium, &b_L2_mu24_MG_medium);
   fChain->SetBranchAddress("L2_mu24_MG_tight", &L2_mu24_MG_tight, &b_L2_mu24_MG_tight);
   fChain->SetBranchAddress("L2_mu24_medium", &L2_mu24_medium, &b_L2_mu24_medium);
   fChain->SetBranchAddress("L2_mu24_tight", &L2_mu24_tight, &b_L2_mu24_tight);
   fChain->SetBranchAddress("L2_mu30_MG_medium", &L2_mu30_MG_medium, &b_L2_mu30_MG_medium);
   fChain->SetBranchAddress("L2_mu30_MG_tight", &L2_mu30_MG_tight, &b_L2_mu30_MG_tight);
   fChain->SetBranchAddress("L2_mu30_medium", &L2_mu30_medium, &b_L2_mu30_medium);
   fChain->SetBranchAddress("L2_mu30_tight", &L2_mu30_tight, &b_L2_mu30_tight);
   fChain->SetBranchAddress("L2_mu4", &L2_mu4, &b_L2_mu4);
   fChain->SetBranchAddress("L2_mu40_MSonly_barrel", &L2_mu40_MSonly_barrel, &b_L2_mu40_MSonly_barrel);
   fChain->SetBranchAddress("L2_mu40_MSonly_barrel_medium", &L2_mu40_MSonly_barrel_medium, &b_L2_mu40_MSonly_barrel_medium);
   fChain->SetBranchAddress("L2_mu40_MSonly_empty", &L2_mu40_MSonly_empty, &b_L2_mu40_MSonly_empty);
   fChain->SetBranchAddress("L2_mu40_MSonly_tight", &L2_mu40_MSonly_tight, &b_L2_mu40_MSonly_tight);
   fChain->SetBranchAddress("L2_mu40_MSonly_tight_L1MU11", &L2_mu40_MSonly_tight_L1MU11, &b_L2_mu40_MSonly_tight_L1MU11);
   fChain->SetBranchAddress("L2_mu40_MSonly_tighter", &L2_mu40_MSonly_tighter, &b_L2_mu40_MSonly_tighter);
   fChain->SetBranchAddress("L2_mu40_slow", &L2_mu40_slow, &b_L2_mu40_slow);
   fChain->SetBranchAddress("L2_mu40_slow_empty", &L2_mu40_slow_empty, &b_L2_mu40_slow_empty);
   fChain->SetBranchAddress("L2_mu40_slow_medium", &L2_mu40_slow_medium, &b_L2_mu40_slow_medium);
   fChain->SetBranchAddress("L2_mu40_slow_outOfTime", &L2_mu40_slow_outOfTime, &b_L2_mu40_slow_outOfTime);
   fChain->SetBranchAddress("L2_mu40_slow_outOfTime_medium", &L2_mu40_slow_outOfTime_medium, &b_L2_mu40_slow_outOfTime_medium);
   fChain->SetBranchAddress("L2_mu4_DiMu", &L2_mu4_DiMu, &b_L2_mu4_DiMu);
   fChain->SetBranchAddress("L2_mu4_DiMu_FS_noOS", &L2_mu4_DiMu_FS_noOS, &b_L2_mu4_DiMu_FS_noOS);
   fChain->SetBranchAddress("L2_mu4_Jpsimumu", &L2_mu4_Jpsimumu, &b_L2_mu4_Jpsimumu);
   fChain->SetBranchAddress("L2_mu4_L1J10_matched", &L2_mu4_L1J10_matched, &b_L2_mu4_L1J10_matched);
   fChain->SetBranchAddress("L2_mu4_L1J15_matched", &L2_mu4_L1J15_matched, &b_L2_mu4_L1J15_matched);
   fChain->SetBranchAddress("L2_mu4_L1J20_matched", &L2_mu4_L1J20_matched, &b_L2_mu4_L1J20_matched);
   fChain->SetBranchAddress("L2_mu4_L1J30_matched", &L2_mu4_L1J30_matched, &b_L2_mu4_L1J30_matched);
   fChain->SetBranchAddress("L2_mu4_L1J50_matched", &L2_mu4_L1J50_matched, &b_L2_mu4_L1J50_matched);
   fChain->SetBranchAddress("L2_mu4_L1J75_matched", &L2_mu4_L1J75_matched, &b_L2_mu4_L1J75_matched);
   fChain->SetBranchAddress("L2_mu4_L1MU11_MSonly_cosmic", &L2_mu4_L1MU11_MSonly_cosmic, &b_L2_mu4_L1MU11_MSonly_cosmic);
   fChain->SetBranchAddress("L2_mu4_L1MU11_cosmic", &L2_mu4_L1MU11_cosmic, &b_L2_mu4_L1MU11_cosmic);
   fChain->SetBranchAddress("L2_mu4_MSonly_cosmic", &L2_mu4_MSonly_cosmic, &b_L2_mu4_MSonly_cosmic);
   fChain->SetBranchAddress("L2_mu4_Trk_Jpsi", &L2_mu4_Trk_Jpsi, &b_L2_mu4_Trk_Jpsi);
   fChain->SetBranchAddress("L2_mu4_Trk_Upsi_FS", &L2_mu4_Trk_Upsi_FS, &b_L2_mu4_Trk_Upsi_FS);
   fChain->SetBranchAddress("L2_mu4_Upsimumu_FS", &L2_mu4_Upsimumu_FS, &b_L2_mu4_Upsimumu_FS);
   fChain->SetBranchAddress("L2_mu4_Upsimumu_SiTrk_FS", &L2_mu4_Upsimumu_SiTrk_FS, &b_L2_mu4_Upsimumu_SiTrk_FS);
   fChain->SetBranchAddress("L2_mu4_Upsimumu_tight_FS", &L2_mu4_Upsimumu_tight_FS, &b_L2_mu4_Upsimumu_tight_FS);
   fChain->SetBranchAddress("L2_mu4_cosmic", &L2_mu4_cosmic, &b_L2_mu4_cosmic);
   fChain->SetBranchAddress("L2_mu4_j10_a4tc_EFFS", &L2_mu4_j10_a4tc_EFFS, &b_L2_mu4_j10_a4tc_EFFS);
   fChain->SetBranchAddress("L2_mu4_j40_xe20_loose_noMu", &L2_mu4_j40_xe20_loose_noMu, &b_L2_mu4_j40_xe20_loose_noMu);
   fChain->SetBranchAddress("L2_mu4_j95_L1matched", &L2_mu4_j95_L1matched, &b_L2_mu4_j95_L1matched);
   fChain->SetBranchAddress("L2_mu4imu6i_DiMu_DY", &L2_mu4imu6i_DiMu_DY, &b_L2_mu4imu6i_DiMu_DY);
   fChain->SetBranchAddress("L2_mu4imu6i_DiMu_DY14_noVtx_noOS", &L2_mu4imu6i_DiMu_DY14_noVtx_noOS, &b_L2_mu4imu6i_DiMu_DY14_noVtx_noOS);
   fChain->SetBranchAddress("L2_mu4mu6_Bmumu", &L2_mu4mu6_Bmumu, &b_L2_mu4mu6_Bmumu);
   fChain->SetBranchAddress("L2_mu4mu6_Bmumux", &L2_mu4mu6_Bmumux, &b_L2_mu4mu6_Bmumux);
   fChain->SetBranchAddress("L2_mu4mu6_DiMu", &L2_mu4mu6_DiMu, &b_L2_mu4mu6_DiMu);
   fChain->SetBranchAddress("L2_mu4mu6_DiMu_DY20", &L2_mu4mu6_DiMu_DY20, &b_L2_mu4mu6_DiMu_DY20);
   fChain->SetBranchAddress("L2_mu4mu6_DiMu_noVtx_noOS", &L2_mu4mu6_DiMu_noVtx_noOS, &b_L2_mu4mu6_DiMu_noVtx_noOS);
   fChain->SetBranchAddress("L2_mu4mu6_Jpsimumu", &L2_mu4mu6_Jpsimumu, &b_L2_mu4mu6_Jpsimumu);
   fChain->SetBranchAddress("L2_mu4mu6_Upsimumu", &L2_mu4mu6_Upsimumu, &b_L2_mu4mu6_Upsimumu);
   fChain->SetBranchAddress("L2_mu6", &L2_mu6, &b_L2_mu6);
   fChain->SetBranchAddress("L2_mu6_DiMu_noOS", &L2_mu6_DiMu_noOS, &b_L2_mu6_DiMu_noOS);
   fChain->SetBranchAddress("L2_mu6_Jpsimumu", &L2_mu6_Jpsimumu, &b_L2_mu6_Jpsimumu);
   fChain->SetBranchAddress("L2_mu6_Jpsimumu_SiTrk", &L2_mu6_Jpsimumu_SiTrk, &b_L2_mu6_Jpsimumu_SiTrk);
   fChain->SetBranchAddress("L2_mu6_Jpsimumu_tight", &L2_mu6_Jpsimumu_tight, &b_L2_mu6_Jpsimumu_tight);
   fChain->SetBranchAddress("L2_mu6_Trk_Jpsi_loose", &L2_mu6_Trk_Jpsi_loose, &b_L2_mu6_Trk_Jpsi_loose);
   fChain->SetBranchAddress("L2_tau100_medium", &L2_tau100_medium, &b_L2_tau100_medium);
   fChain->SetBranchAddress("L2_tau125_medium", &L2_tau125_medium, &b_L2_tau125_medium);
   fChain->SetBranchAddress("L2_tau125_medium1", &L2_tau125_medium1, &b_L2_tau125_medium1);
   fChain->SetBranchAddress("L2_tau16_IDTrkNoCut", &L2_tau16_IDTrkNoCut, &b_L2_tau16_IDTrkNoCut);
   fChain->SetBranchAddress("L2_tau16_loose", &L2_tau16_loose, &b_L2_tau16_loose);
   fChain->SetBranchAddress("L2_tau16_loose_e15_medium", &L2_tau16_loose_e15_medium, &b_L2_tau16_loose_e15_medium);
   fChain->SetBranchAddress("L2_tau16_loose_mu10", &L2_tau16_loose_mu10, &b_L2_tau16_loose_mu10);
   fChain->SetBranchAddress("L2_tau16_loose_mu15", &L2_tau16_loose_mu15, &b_L2_tau16_loose_mu15);
   fChain->SetBranchAddress("L2_tau16_medium", &L2_tau16_medium, &b_L2_tau16_medium);
   fChain->SetBranchAddress("L2_tau16_medium_mu10", &L2_tau16_medium_mu10, &b_L2_tau16_medium_mu10);
   fChain->SetBranchAddress("L2_tau20T_medium", &L2_tau20T_medium, &b_L2_tau20T_medium);
   fChain->SetBranchAddress("L2_tau20T_medium_e15_medium", &L2_tau20T_medium_e15_medium, &b_L2_tau20T_medium_e15_medium);
   fChain->SetBranchAddress("L2_tau20T_medium_mu15", &L2_tau20T_medium_mu15, &b_L2_tau20T_medium_mu15);
   fChain->SetBranchAddress("L2_tau20_medium", &L2_tau20_medium, &b_L2_tau20_medium);
   fChain->SetBranchAddress("L2_tau20_medium1", &L2_tau20_medium1, &b_L2_tau20_medium1);
   fChain->SetBranchAddress("L2_tau20_medium_e15_medium", &L2_tau20_medium_e15_medium, &b_L2_tau20_medium_e15_medium);
   fChain->SetBranchAddress("L2_tau20_medium_mu15", &L2_tau20_medium_mu15, &b_L2_tau20_medium_mu15);
   fChain->SetBranchAddress("L2_tau29T_medium", &L2_tau29T_medium, &b_L2_tau29T_medium);
   fChain->SetBranchAddress("L2_tau29T_medium1_tau20T_medium1", &L2_tau29T_medium1_tau20T_medium1, &b_L2_tau29T_medium1_tau20T_medium1);
   fChain->SetBranchAddress("L2_tau29T_medium1_xs20_noMu_3L1J10", &L2_tau29T_medium1_xs20_noMu_3L1J10, &b_L2_tau29T_medium1_xs20_noMu_3L1J10);
   fChain->SetBranchAddress("L2_tau29T_medium_xs35_noMu", &L2_tau29T_medium_xs35_noMu, &b_L2_tau29T_medium_xs35_noMu);
   fChain->SetBranchAddress("L2_tau29T_medium_xs50_noMu", &L2_tau29T_medium_xs50_noMu, &b_L2_tau29T_medium_xs50_noMu);
   fChain->SetBranchAddress("L2_tau29_loose", &L2_tau29_loose, &b_L2_tau29_loose);
   fChain->SetBranchAddress("L2_tau29_loose1", &L2_tau29_loose1, &b_L2_tau29_loose1);
   fChain->SetBranchAddress("L2_tau29_loose1_xs20_noMu_3L1J10", &L2_tau29_loose1_xs20_noMu_3L1J10, &b_L2_tau29_loose1_xs20_noMu_3L1J10);
   fChain->SetBranchAddress("L2_tau29_loose_xs20_noMu_3L1J10", &L2_tau29_loose_xs20_noMu_3L1J10, &b_L2_tau29_loose_xs20_noMu_3L1J10);
   fChain->SetBranchAddress("L2_tau29_loose_xs35_noMu", &L2_tau29_loose_xs35_noMu, &b_L2_tau29_loose_xs35_noMu);
   fChain->SetBranchAddress("L2_tau29_medium", &L2_tau29_medium, &b_L2_tau29_medium);
   fChain->SetBranchAddress("L2_tau29_medium1", &L2_tau29_medium1, &b_L2_tau29_medium1);
   fChain->SetBranchAddress("L2_tau29_medium1_tau20_medium1", &L2_tau29_medium1_tau20_medium1, &b_L2_tau29_medium1_tau20_medium1);
   fChain->SetBranchAddress("L2_tau29_medium1_xs20_noMu_3L1J10", &L2_tau29_medium1_xs20_noMu_3L1J10, &b_L2_tau29_medium1_xs20_noMu_3L1J10);
   fChain->SetBranchAddress("L2_tau29_medium_xe25_noMu", &L2_tau29_medium_xe25_noMu, &b_L2_tau29_medium_xe25_noMu);
   fChain->SetBranchAddress("L2_tau29_medium_xe30_loose_noMu", &L2_tau29_medium_xe30_loose_noMu, &b_L2_tau29_medium_xe30_loose_noMu);
   fChain->SetBranchAddress("L2_tau29_medium_xs50_noMu", &L2_tau29_medium_xs50_noMu, &b_L2_tau29_medium_xs50_noMu);
   fChain->SetBranchAddress("L2_tau50_IDTrkNoCut", &L2_tau50_IDTrkNoCut, &b_L2_tau50_IDTrkNoCut);
   fChain->SetBranchAddress("L2_tau50_medium", &L2_tau50_medium, &b_L2_tau50_medium);
   fChain->SetBranchAddress("L2_tau84_loose", &L2_tau84_loose, &b_L2_tau84_loose);
   fChain->SetBranchAddress("L2_tau8_empty_larcalib", &L2_tau8_empty_larcalib, &b_L2_tau8_empty_larcalib);
   fChain->SetBranchAddress("L2_tauNoCut", &L2_tauNoCut, &b_L2_tauNoCut);
   fChain->SetBranchAddress("L2_tauNoCut_L1TAU50", &L2_tauNoCut_L1TAU50, &b_L2_tauNoCut_L1TAU50);
   fChain->SetBranchAddress("L2_tauNoCut_cosmic", &L2_tauNoCut_cosmic, &b_L2_tauNoCut_cosmic);
   fChain->SetBranchAddress("L2_xe10_noMu", &L2_xe10_noMu, &b_L2_xe10_noMu);
   fChain->SetBranchAddress("L2_xe20_noMu", &L2_xe20_noMu, &b_L2_xe20_noMu);
   fChain->SetBranchAddress("L2_xe30_noMu", &L2_xe30_noMu, &b_L2_xe30_noMu);
   fChain->SetBranchAddress("L2_xe35_noMu", &L2_xe35_noMu, &b_L2_xe35_noMu);
   fChain->SetBranchAddress("L2_xe40_noMu", &L2_xe40_noMu, &b_L2_xe40_noMu);
   fChain->SetBranchAddress("L2_xe45_noMu", &L2_xe45_noMu, &b_L2_xe45_noMu);
   fChain->SetBranchAddress("L2_xe50_noMu", &L2_xe50_noMu, &b_L2_xe50_noMu);
   fChain->SetBranchAddress("L2_xe55_noMu", &L2_xe55_noMu, &b_L2_xe55_noMu);
   fChain->SetBranchAddress("L2_xe60_noMu", &L2_xe60_noMu, &b_L2_xe60_noMu);
   fChain->SetBranchAddress("L2_xe70_noMu", &L2_xe70_noMu, &b_L2_xe70_noMu);
   fChain->SetBranchAddress("v0_n", &v0_n, &b_v0_n);
   fChain->SetBranchAddress("v0_ksMass", &v0_ksMass, &b_v0_ksMass);
   fChain->SetBranchAddress("v0_lambda1Mass", &v0_lambda1Mass, &b_v0_lambda1Mass);
   fChain->SetBranchAddress("v0_lambda2Mass", &v0_lambda2Mass, &b_v0_lambda2Mass);
   fChain->SetBranchAddress("v0_vertexProb", &v0_vertexProb, &b_v0_vertexProb);
   fChain->SetBranchAddress("v0_vertexChi2", &v0_vertexChi2, &b_v0_vertexChi2);
   fChain->SetBranchAddress("v0_ksPt", &v0_ksPt, &b_v0_ksPt);
   fChain->SetBranchAddress("v0_ksPx", &v0_ksPx, &b_v0_ksPx);
   fChain->SetBranchAddress("v0_ksPy", &v0_ksPy, &b_v0_ksPy);
   fChain->SetBranchAddress("v0_ksEta", &v0_ksEta, &b_v0_ksEta);
   fChain->SetBranchAddress("v0_ksPhi", &v0_ksPhi, &b_v0_ksPhi);
   fChain->SetBranchAddress("v0_ksMomentum", &v0_ksMomentum, &b_v0_ksMomentum);
   fChain->SetBranchAddress("v0_flightX", &v0_flightX, &b_v0_flightX);
   fChain->SetBranchAddress("v0_flightY", &v0_flightY, &b_v0_flightY);
   fChain->SetBranchAddress("v0_cosThetaPointing", &v0_cosThetaPointing, &b_v0_cosThetaPointing);
   fChain->SetBranchAddress("v0_totalFlightDistance", &v0_totalFlightDistance, &b_v0_totalFlightDistance);
   fChain->SetBranchAddress("v0_properDecayTime", &v0_properDecayTime, &b_v0_properDecayTime);
   fChain->SetBranchAddress("v0_properFlightDist", &v0_properFlightDist, &b_v0_properFlightDist);
   fChain->SetBranchAddress("v0_flightX_BS", &v0_flightX_BS, &b_v0_flightX_BS);
   fChain->SetBranchAddress("v0_flightY_BS", &v0_flightY_BS, &b_v0_flightY_BS);
   fChain->SetBranchAddress("v0_cosThetaPointing_BS", &v0_cosThetaPointing_BS, &b_v0_cosThetaPointing_BS);
   fChain->SetBranchAddress("v0_totalFlightDistance_BS", &v0_totalFlightDistance_BS, &b_v0_totalFlightDistance_BS);
   fChain->SetBranchAddress("v0_properDecayTime_BS", &v0_properDecayTime_BS, &b_v0_properDecayTime_BS);
   fChain->SetBranchAddress("v0_properFlightDist_BS", &v0_properFlightDist_BS, &b_v0_properFlightDist_BS);
   fChain->SetBranchAddress("v0_radius", &v0_radius, &b_v0_radius);
   fChain->SetBranchAddress("v0_thetaPiPlus", &v0_thetaPiPlus, &b_v0_thetaPiPlus);
   fChain->SetBranchAddress("v0_thetaPiMinus", &v0_thetaPiMinus, &b_v0_thetaPiMinus);
   fChain->SetBranchAddress("v0_trk_L", &v0_trk_L, &b_v0_trk_L);
   fChain->SetBranchAddress("v0_trk_T", &v0_trk_T, &b_v0_trk_T);
   fChain->SetBranchAddress("v0_thetaStarPiPlus", &v0_thetaStarPiPlus, &b_v0_thetaStarPiPlus);
   fChain->SetBranchAddress("v0_thetaStarPiMinus", &v0_thetaStarPiMinus, &b_v0_thetaStarPiMinus);
   fChain->SetBranchAddress("v0_trkPt_SV", &v0_trkPt_SV, &b_v0_trkPt_SV);
   fChain->SetBranchAddress("v0_trkEta_SV", &v0_trkEta_SV, &b_v0_trkEta_SV);
   fChain->SetBranchAddress("v0_trkPhi_SV", &v0_trkPhi_SV, &b_v0_trkPhi_SV);
   fChain->SetBranchAddress("v0_x", &v0_x, &b_v0_x);
   fChain->SetBranchAddress("v0_y", &v0_y, &b_v0_y);
   fChain->SetBranchAddress("v0_z", &v0_z, &b_v0_z);
   fChain->SetBranchAddress("v0_err_x", &v0_err_x, &b_v0_err_x);
   fChain->SetBranchAddress("v0_err_y", &v0_err_y, &b_v0_err_y);
   fChain->SetBranchAddress("v0_err_z", &v0_err_z, &b_v0_err_z);
   fChain->SetBranchAddress("v0_cov_xy", &v0_cov_xy, &b_v0_cov_xy);
   fChain->SetBranchAddress("v0_cov_xz", &v0_cov_xz, &b_v0_cov_xz);
   fChain->SetBranchAddress("v0_cov_yz", &v0_cov_yz, &b_v0_cov_yz);
   fChain->SetBranchAddress("v0_type", &v0_type, &b_v0_type);
   fChain->SetBranchAddress("v0_chi2", &v0_chi2, &b_v0_chi2);
   fChain->SetBranchAddress("v0_ndof", &v0_ndof, &b_v0_ndof);
   fChain->SetBranchAddress("v0_px", &v0_px, &b_v0_px);
   fChain->SetBranchAddress("v0_py", &v0_py, &b_v0_py);
   fChain->SetBranchAddress("v0_pz", &v0_pz, &b_v0_pz);
   fChain->SetBranchAddress("v0_E", &v0_E, &b_v0_E);
   fChain->SetBranchAddress("v0_m", &v0_m, &b_v0_m);
   fChain->SetBranchAddress("v0_nTracks", &v0_nTracks, &b_v0_nTracks);
   fChain->SetBranchAddress("v0_sumPt", &v0_sumPt, &b_v0_sumPt);
   fChain->SetBranchAddress("v0_trk_n", &v0_trk_n, &b_v0_trk_n);
   fChain->SetBranchAddress("v0_trk_weight", &v0_trk_weight, &b_v0_trk_weight);
   fChain->SetBranchAddress("v0_trk_index", &v0_trk_index, &b_v0_trk_index);
   fChain->SetBranchAddress("ph_n", &ph_n, &b_ph_n);
   fChain->SetBranchAddress("ph_E", &ph_E, &b_ph_E);
   fChain->SetBranchAddress("ph_Et", &ph_Et, &b_ph_Et);
   fChain->SetBranchAddress("ph_pt", &ph_pt, &b_ph_pt);
   fChain->SetBranchAddress("ph_m", &ph_m, &b_ph_m);
   fChain->SetBranchAddress("ph_eta", &ph_eta, &b_ph_eta);
   fChain->SetBranchAddress("ph_phi", &ph_phi, &b_ph_phi);
   fChain->SetBranchAddress("ph_px", &ph_px, &b_ph_px);
   fChain->SetBranchAddress("ph_py", &ph_py, &b_ph_py);
   fChain->SetBranchAddress("ph_pz", &ph_pz, &b_ph_pz);
   fChain->SetBranchAddress("ph_author", &ph_author, &b_ph_author);
   fChain->SetBranchAddress("ph_isRecovered", &ph_isRecovered, &b_ph_isRecovered);
   fChain->SetBranchAddress("ph_isEM", &ph_isEM, &b_ph_isEM);
   fChain->SetBranchAddress("ph_OQ", &ph_OQ, &b_ph_OQ);
   fChain->SetBranchAddress("ph_OQRecalc", &ph_OQRecalc, &b_ph_OQRecalc);
   fChain->SetBranchAddress("ph_convFlag", &ph_convFlag, &b_ph_convFlag);
   fChain->SetBranchAddress("ph_isConv", &ph_isConv, &b_ph_isConv);
   fChain->SetBranchAddress("ph_nConv", &ph_nConv, &b_ph_nConv);
   fChain->SetBranchAddress("ph_nSingleTrackConv", &ph_nSingleTrackConv, &b_ph_nSingleTrackConv);
   fChain->SetBranchAddress("ph_nDoubleTrackConv", &ph_nDoubleTrackConv, &b_ph_nDoubleTrackConv);
   fChain->SetBranchAddress("ph_loose", &ph_loose, &b_ph_loose);
   fChain->SetBranchAddress("ph_looseIso", &ph_looseIso, &b_ph_looseIso);
   fChain->SetBranchAddress("ph_tight", &ph_tight, &b_ph_tight);
   fChain->SetBranchAddress("ph_tightIso", &ph_tightIso, &b_ph_tightIso);
   fChain->SetBranchAddress("ph_looseAR", &ph_looseAR, &b_ph_looseAR);
   fChain->SetBranchAddress("ph_looseARIso", &ph_looseARIso, &b_ph_looseARIso);
   fChain->SetBranchAddress("ph_tightAR", &ph_tightAR, &b_ph_tightAR);
   fChain->SetBranchAddress("ph_tightARIso", &ph_tightARIso, &b_ph_tightARIso);
   fChain->SetBranchAddress("ph_goodOQ", &ph_goodOQ, &b_ph_goodOQ);
   fChain->SetBranchAddress("ph_Ethad", &ph_Ethad, &b_ph_Ethad);
   fChain->SetBranchAddress("ph_Ethad1", &ph_Ethad1, &b_ph_Ethad1);
   fChain->SetBranchAddress("ph_E033", &ph_E033, &b_ph_E033);
   fChain->SetBranchAddress("ph_f1", &ph_f1, &b_ph_f1);
   fChain->SetBranchAddress("ph_f1core", &ph_f1core, &b_ph_f1core);
   fChain->SetBranchAddress("ph_Emins1", &ph_Emins1, &b_ph_Emins1);
   fChain->SetBranchAddress("ph_fside", &ph_fside, &b_ph_fside);
   fChain->SetBranchAddress("ph_Emax2", &ph_Emax2, &b_ph_Emax2);
   fChain->SetBranchAddress("ph_ws3", &ph_ws3, &b_ph_ws3);
   fChain->SetBranchAddress("ph_wstot", &ph_wstot, &b_ph_wstot);
   fChain->SetBranchAddress("ph_E132", &ph_E132, &b_ph_E132);
   fChain->SetBranchAddress("ph_E1152", &ph_E1152, &b_ph_E1152);
   fChain->SetBranchAddress("ph_emaxs1", &ph_emaxs1, &b_ph_emaxs1);
   fChain->SetBranchAddress("ph_deltaEs", &ph_deltaEs, &b_ph_deltaEs);
   fChain->SetBranchAddress("ph_E233", &ph_E233, &b_ph_E233);
   fChain->SetBranchAddress("ph_E237", &ph_E237, &b_ph_E237);
   fChain->SetBranchAddress("ph_E277", &ph_E277, &b_ph_E277);
   fChain->SetBranchAddress("ph_weta2", &ph_weta2, &b_ph_weta2);
   fChain->SetBranchAddress("ph_f3", &ph_f3, &b_ph_f3);
   fChain->SetBranchAddress("ph_f3core", &ph_f3core, &b_ph_f3core);
   fChain->SetBranchAddress("ph_rphiallcalo", &ph_rphiallcalo, &b_ph_rphiallcalo);
   fChain->SetBranchAddress("ph_Etcone45", &ph_Etcone45, &b_ph_Etcone45);
   fChain->SetBranchAddress("ph_Etcone15", &ph_Etcone15, &b_ph_Etcone15);
   fChain->SetBranchAddress("ph_Etcone20", &ph_Etcone20, &b_ph_Etcone20);
   fChain->SetBranchAddress("ph_Etcone25", &ph_Etcone25, &b_ph_Etcone25);
   fChain->SetBranchAddress("ph_Etcone30", &ph_Etcone30, &b_ph_Etcone30);
   fChain->SetBranchAddress("ph_Etcone35", &ph_Etcone35, &b_ph_Etcone35);
   fChain->SetBranchAddress("ph_Etcone40", &ph_Etcone40, &b_ph_Etcone40);
   fChain->SetBranchAddress("ph_ptcone20", &ph_ptcone20, &b_ph_ptcone20);
   fChain->SetBranchAddress("ph_ptcone30", &ph_ptcone30, &b_ph_ptcone30);
   fChain->SetBranchAddress("ph_ptcone40", &ph_ptcone40, &b_ph_ptcone40);
   fChain->SetBranchAddress("ph_nucone20", &ph_nucone20, &b_ph_nucone20);
   fChain->SetBranchAddress("ph_nucone30", &ph_nucone30, &b_ph_nucone30);
   fChain->SetBranchAddress("ph_nucone40", &ph_nucone40, &b_ph_nucone40);
   fChain->SetBranchAddress("ph_Etcone15_pt_corrected", &ph_Etcone15_pt_corrected, &b_ph_Etcone15_pt_corrected);
   fChain->SetBranchAddress("ph_Etcone20_pt_corrected", &ph_Etcone20_pt_corrected, &b_ph_Etcone20_pt_corrected);
   fChain->SetBranchAddress("ph_Etcone25_pt_corrected", &ph_Etcone25_pt_corrected, &b_ph_Etcone25_pt_corrected);
   fChain->SetBranchAddress("ph_Etcone30_pt_corrected", &ph_Etcone30_pt_corrected, &b_ph_Etcone30_pt_corrected);
   fChain->SetBranchAddress("ph_Etcone35_pt_corrected", &ph_Etcone35_pt_corrected, &b_ph_Etcone35_pt_corrected);
   fChain->SetBranchAddress("ph_Etcone40_pt_corrected", &ph_Etcone40_pt_corrected, &b_ph_Etcone40_pt_corrected);
   fChain->SetBranchAddress("ph_convanglematch", &ph_convanglematch, &b_ph_convanglematch);
   fChain->SetBranchAddress("ph_convtrackmatch", &ph_convtrackmatch, &b_ph_convtrackmatch);
   fChain->SetBranchAddress("ph_hasconv", &ph_hasconv, &b_ph_hasconv);
   fChain->SetBranchAddress("ph_convvtxx", &ph_convvtxx, &b_ph_convvtxx);
   fChain->SetBranchAddress("ph_convvtxy", &ph_convvtxy, &b_ph_convvtxy);
   fChain->SetBranchAddress("ph_convvtxz", &ph_convvtxz, &b_ph_convvtxz);
   fChain->SetBranchAddress("ph_Rconv", &ph_Rconv, &b_ph_Rconv);
   fChain->SetBranchAddress("ph_zconv", &ph_zconv, &b_ph_zconv);
   fChain->SetBranchAddress("ph_convvtxchi2", &ph_convvtxchi2, &b_ph_convvtxchi2);
   fChain->SetBranchAddress("ph_pt1conv", &ph_pt1conv, &b_ph_pt1conv);
   fChain->SetBranchAddress("ph_convtrk1nBLHits", &ph_convtrk1nBLHits, &b_ph_convtrk1nBLHits);
   fChain->SetBranchAddress("ph_convtrk1nPixHits", &ph_convtrk1nPixHits, &b_ph_convtrk1nPixHits);
   fChain->SetBranchAddress("ph_convtrk1nSCTHits", &ph_convtrk1nSCTHits, &b_ph_convtrk1nSCTHits);
   fChain->SetBranchAddress("ph_convtrk1nTRTHits", &ph_convtrk1nTRTHits, &b_ph_convtrk1nTRTHits);
   fChain->SetBranchAddress("ph_pt2conv", &ph_pt2conv, &b_ph_pt2conv);
   fChain->SetBranchAddress("ph_convtrk2nBLHits", &ph_convtrk2nBLHits, &b_ph_convtrk2nBLHits);
   fChain->SetBranchAddress("ph_convtrk2nPixHits", &ph_convtrk2nPixHits, &b_ph_convtrk2nPixHits);
   fChain->SetBranchAddress("ph_convtrk2nSCTHits", &ph_convtrk2nSCTHits, &b_ph_convtrk2nSCTHits);
   fChain->SetBranchAddress("ph_convtrk2nTRTHits", &ph_convtrk2nTRTHits, &b_ph_convtrk2nTRTHits);
   fChain->SetBranchAddress("ph_ptconv", &ph_ptconv, &b_ph_ptconv);
   fChain->SetBranchAddress("ph_pzconv", &ph_pzconv, &b_ph_pzconv);
   fChain->SetBranchAddress("ph_reta", &ph_reta, &b_ph_reta);
   fChain->SetBranchAddress("ph_rphi", &ph_rphi, &b_ph_rphi);
   fChain->SetBranchAddress("ph_EtringnoisedR03sig2", &ph_EtringnoisedR03sig2, &b_ph_EtringnoisedR03sig2);
   fChain->SetBranchAddress("ph_EtringnoisedR03sig3", &ph_EtringnoisedR03sig3, &b_ph_EtringnoisedR03sig3);
   fChain->SetBranchAddress("ph_EtringnoisedR03sig4", &ph_EtringnoisedR03sig4, &b_ph_EtringnoisedR03sig4);
   fChain->SetBranchAddress("ph_isolationlikelihoodjets", &ph_isolationlikelihoodjets, &b_ph_isolationlikelihoodjets);
   fChain->SetBranchAddress("ph_isolationlikelihoodhqelectrons", &ph_isolationlikelihoodhqelectrons, &b_ph_isolationlikelihoodhqelectrons);
   fChain->SetBranchAddress("ph_loglikelihood", &ph_loglikelihood, &b_ph_loglikelihood);
   fChain->SetBranchAddress("ph_photonweight", &ph_photonweight, &b_ph_photonweight);
   fChain->SetBranchAddress("ph_photonbgweight", &ph_photonbgweight, &b_ph_photonbgweight);
   fChain->SetBranchAddress("ph_neuralnet", &ph_neuralnet, &b_ph_neuralnet);
   fChain->SetBranchAddress("ph_Hmatrix", &ph_Hmatrix, &b_ph_Hmatrix);
   fChain->SetBranchAddress("ph_Hmatrix5", &ph_Hmatrix5, &b_ph_Hmatrix5);
   fChain->SetBranchAddress("ph_adaboost", &ph_adaboost, &b_ph_adaboost);
   fChain->SetBranchAddress("ph_zvertex", &ph_zvertex, &b_ph_zvertex);
   fChain->SetBranchAddress("ph_errz", &ph_errz, &b_ph_errz);
   fChain->SetBranchAddress("ph_etap", &ph_etap, &b_ph_etap);
   fChain->SetBranchAddress("ph_depth", &ph_depth, &b_ph_depth);
   fChain->SetBranchAddress("ph_cl_E", &ph_cl_E, &b_ph_cl_E);
   fChain->SetBranchAddress("ph_cl_pt", &ph_cl_pt, &b_ph_cl_pt);
   fChain->SetBranchAddress("ph_cl_eta", &ph_cl_eta, &b_ph_cl_eta);
   fChain->SetBranchAddress("ph_cl_phi", &ph_cl_phi, &b_ph_cl_phi);
   fChain->SetBranchAddress("ph_Es0", &ph_Es0, &b_ph_Es0);
   fChain->SetBranchAddress("ph_etas0", &ph_etas0, &b_ph_etas0);
   fChain->SetBranchAddress("ph_phis0", &ph_phis0, &b_ph_phis0);
   fChain->SetBranchAddress("ph_Es1", &ph_Es1, &b_ph_Es1);
   fChain->SetBranchAddress("ph_etas1", &ph_etas1, &b_ph_etas1);
   fChain->SetBranchAddress("ph_phis1", &ph_phis1, &b_ph_phis1);
   fChain->SetBranchAddress("ph_Es2", &ph_Es2, &b_ph_Es2);
   fChain->SetBranchAddress("ph_etas2", &ph_etas2, &b_ph_etas2);
   fChain->SetBranchAddress("ph_phis2", &ph_phis2, &b_ph_phis2);
   fChain->SetBranchAddress("ph_Es3", &ph_Es3, &b_ph_Es3);
   fChain->SetBranchAddress("ph_etas3", &ph_etas3, &b_ph_etas3);
   fChain->SetBranchAddress("ph_phis3", &ph_phis3, &b_ph_phis3);
   fChain->SetBranchAddress("ph_rawcl_Es0", &ph_rawcl_Es0, &b_ph_rawcl_Es0);
   fChain->SetBranchAddress("ph_rawcl_etas0", &ph_rawcl_etas0, &b_ph_rawcl_etas0);
   fChain->SetBranchAddress("ph_rawcl_phis0", &ph_rawcl_phis0, &b_ph_rawcl_phis0);
   fChain->SetBranchAddress("ph_rawcl_Es1", &ph_rawcl_Es1, &b_ph_rawcl_Es1);
   fChain->SetBranchAddress("ph_rawcl_etas1", &ph_rawcl_etas1, &b_ph_rawcl_etas1);
   fChain->SetBranchAddress("ph_rawcl_phis1", &ph_rawcl_phis1, &b_ph_rawcl_phis1);
   fChain->SetBranchAddress("ph_rawcl_Es2", &ph_rawcl_Es2, &b_ph_rawcl_Es2);
   fChain->SetBranchAddress("ph_rawcl_etas2", &ph_rawcl_etas2, &b_ph_rawcl_etas2);
   fChain->SetBranchAddress("ph_rawcl_phis2", &ph_rawcl_phis2, &b_ph_rawcl_phis2);
   fChain->SetBranchAddress("ph_rawcl_Es3", &ph_rawcl_Es3, &b_ph_rawcl_Es3);
   fChain->SetBranchAddress("ph_rawcl_etas3", &ph_rawcl_etas3, &b_ph_rawcl_etas3);
   fChain->SetBranchAddress("ph_rawcl_phis3", &ph_rawcl_phis3, &b_ph_rawcl_phis3);
   fChain->SetBranchAddress("ph_rawcl_E", &ph_rawcl_E, &b_ph_rawcl_E);
   fChain->SetBranchAddress("ph_rawcl_pt", &ph_rawcl_pt, &b_ph_rawcl_pt);
   fChain->SetBranchAddress("ph_rawcl_eta", &ph_rawcl_eta, &b_ph_rawcl_eta);
   fChain->SetBranchAddress("ph_rawcl_phi", &ph_rawcl_phi, &b_ph_rawcl_phi);
   fChain->SetBranchAddress("ph_deltaEmax2", &ph_deltaEmax2, &b_ph_deltaEmax2);
   fChain->SetBranchAddress("ph_calibHitsShowerDepth", &ph_calibHitsShowerDepth, &b_ph_calibHitsShowerDepth);
   fChain->SetBranchAddress("ph_isIso", &ph_isIso, &b_ph_isIso);
   fChain->SetBranchAddress("ph_mvaptcone20", &ph_mvaptcone20, &b_ph_mvaptcone20);
   fChain->SetBranchAddress("ph_mvaptcone30", &ph_mvaptcone30, &b_ph_mvaptcone30);
   fChain->SetBranchAddress("ph_mvaptcone40", &ph_mvaptcone40, &b_ph_mvaptcone40);
   fChain->SetBranchAddress("ph_topoEtcone20", &ph_topoEtcone20, &b_ph_topoEtcone20);
   fChain->SetBranchAddress("ph_topoEtcone40", &ph_topoEtcone40, &b_ph_topoEtcone40);
   fChain->SetBranchAddress("ph_topoEtcone60", &ph_topoEtcone60, &b_ph_topoEtcone60);
   fChain->SetBranchAddress("ph_jet_dr", &ph_jet_dr, &b_ph_jet_dr);
   fChain->SetBranchAddress("ph_jet_E", &ph_jet_E, &b_ph_jet_E);
   fChain->SetBranchAddress("ph_jet_pt", &ph_jet_pt, &b_ph_jet_pt);
   fChain->SetBranchAddress("ph_jet_m", &ph_jet_m, &b_ph_jet_m);
   fChain->SetBranchAddress("ph_jet_eta", &ph_jet_eta, &b_ph_jet_eta);
   fChain->SetBranchAddress("ph_jet_phi", &ph_jet_phi, &b_ph_jet_phi);
   fChain->SetBranchAddress("ph_jet_matched", &ph_jet_matched, &b_ph_jet_matched);
   fChain->SetBranchAddress("ph_convIP", &ph_convIP, &b_ph_convIP);
   fChain->SetBranchAddress("ph_convIPRev", &ph_convIPRev, &b_ph_convIPRev);
   fChain->SetBranchAddress("ph_ptIsolationCone", &ph_ptIsolationCone, &b_ph_ptIsolationCone);
   fChain->SetBranchAddress("ph_ptIsolationConePhAngle", &ph_ptIsolationConePhAngle, &b_ph_ptIsolationConePhAngle);
   fChain->SetBranchAddress("ph_Etcone40_ED_corrected", &ph_Etcone40_ED_corrected, &b_ph_Etcone40_ED_corrected);
   fChain->SetBranchAddress("ph_Etcone40_corrected", &ph_Etcone40_corrected, &b_ph_Etcone40_corrected);
   fChain->SetBranchAddress("ph_Etcone35_ED_corrected", &ph_Etcone35_ED_corrected, &b_ph_Etcone35_ED_corrected);
   fChain->SetBranchAddress("ph_Etcone35_corrected", &ph_Etcone35_corrected, &b_ph_Etcone35_corrected);
   fChain->SetBranchAddress("ph_Etcone30_ED_corrected", &ph_Etcone30_ED_corrected, &b_ph_Etcone30_ED_corrected);
   fChain->SetBranchAddress("ph_Etcone30_corrected", &ph_Etcone30_corrected, &b_ph_Etcone30_corrected);
   fChain->SetBranchAddress("ph_Etcone25_ED_corrected", &ph_Etcone25_ED_corrected, &b_ph_Etcone25_ED_corrected);
   fChain->SetBranchAddress("ph_Etcone25_corrected", &ph_Etcone25_corrected, &b_ph_Etcone25_corrected);
   fChain->SetBranchAddress("ph_Etcone20_ED_corrected", &ph_Etcone20_ED_corrected, &b_ph_Etcone20_ED_corrected);
   fChain->SetBranchAddress("ph_Etcone20_corrected", &ph_Etcone20_corrected, &b_ph_Etcone20_corrected);
   fChain->SetBranchAddress("ph_Etcone15_ED_corrected", &ph_Etcone15_ED_corrected, &b_ph_Etcone15_ED_corrected);
   fChain->SetBranchAddress("ph_Etcone15_corrected", &ph_Etcone15_corrected, &b_ph_Etcone15_corrected);
   fChain->SetBranchAddress("ph_topodr", &ph_topodr, &b_ph_topodr);
   fChain->SetBranchAddress("ph_topopt", &ph_topopt, &b_ph_topopt);
   fChain->SetBranchAddress("ph_topoeta", &ph_topoeta, &b_ph_topoeta);
   fChain->SetBranchAddress("ph_topophi", &ph_topophi, &b_ph_topophi);
   fChain->SetBranchAddress("ph_topomatched", &ph_topomatched, &b_ph_topomatched);
   fChain->SetBranchAddress("ph_topoEMdr", &ph_topoEMdr, &b_ph_topoEMdr);
   fChain->SetBranchAddress("ph_topoEMpt", &ph_topoEMpt, &b_ph_topoEMpt);
   fChain->SetBranchAddress("ph_topoEMeta", &ph_topoEMeta, &b_ph_topoEMeta);
   fChain->SetBranchAddress("ph_topoEMphi", &ph_topoEMphi, &b_ph_topoEMphi);
   fChain->SetBranchAddress("ph_topoEMmatched", &ph_topoEMmatched, &b_ph_topoEMmatched);
   fChain->SetBranchAddress("ph_EF_dr", &ph_EF_dr, &b_ph_EF_dr);
   fChain->SetBranchAddress("ph_EF_index", &ph_EF_index, &b_ph_EF_index);
   fChain->SetBranchAddress("ph_L2_dr", &ph_L2_dr, &b_ph_L2_dr);
   fChain->SetBranchAddress("ph_L2_index", &ph_L2_index, &b_ph_L2_index);
   fChain->SetBranchAddress("ph_L1_dr", &ph_L1_dr, &b_ph_L1_dr);
   fChain->SetBranchAddress("ph_L1_index", &ph_L1_index, &b_ph_L1_index);
   fChain->SetBranchAddress("mu_n", &mu_n, &b_mu_n);
   fChain->SetBranchAddress("mu_E", &mu_E, &b_mu_E);
   fChain->SetBranchAddress("mu_pt", &mu_pt, &b_mu_pt);
   fChain->SetBranchAddress("mu_m", &mu_m, &b_mu_m);
   fChain->SetBranchAddress("mu_eta", &mu_eta, &b_mu_eta);
   fChain->SetBranchAddress("mu_phi", &mu_phi, &b_mu_phi);
   fChain->SetBranchAddress("mu_px", &mu_px, &b_mu_px);
   fChain->SetBranchAddress("mu_py", &mu_py, &b_mu_py);
   fChain->SetBranchAddress("mu_pz", &mu_pz, &b_mu_pz);
   fChain->SetBranchAddress("mu_charge", &mu_charge, &b_mu_charge);
   fChain->SetBranchAddress("mu_allauthor", &mu_allauthor, &b_mu_allauthor);
   fChain->SetBranchAddress("mu_author", &mu_author, &b_mu_author);
   fChain->SetBranchAddress("mu_beta", &mu_beta, &b_mu_beta);
   fChain->SetBranchAddress("mu_isMuonLikelihood", &mu_isMuonLikelihood, &b_mu_isMuonLikelihood);
   fChain->SetBranchAddress("mu_matchchi2", &mu_matchchi2, &b_mu_matchchi2);
   fChain->SetBranchAddress("mu_matchndof", &mu_matchndof, &b_mu_matchndof);
   fChain->SetBranchAddress("mu_etcone20", &mu_etcone20, &b_mu_etcone20);
   fChain->SetBranchAddress("mu_etcone30", &mu_etcone30, &b_mu_etcone30);
   fChain->SetBranchAddress("mu_etcone40", &mu_etcone40, &b_mu_etcone40);
   fChain->SetBranchAddress("mu_nucone20", &mu_nucone20, &b_mu_nucone20);
   fChain->SetBranchAddress("mu_nucone30", &mu_nucone30, &b_mu_nucone30);
   fChain->SetBranchAddress("mu_nucone40", &mu_nucone40, &b_mu_nucone40);
   fChain->SetBranchAddress("mu_ptcone20", &mu_ptcone20, &b_mu_ptcone20);
   fChain->SetBranchAddress("mu_ptcone30", &mu_ptcone30, &b_mu_ptcone30);
   fChain->SetBranchAddress("mu_ptcone40", &mu_ptcone40, &b_mu_ptcone40);
   fChain->SetBranchAddress("mu_energyLossPar", &mu_energyLossPar, &b_mu_energyLossPar);
   fChain->SetBranchAddress("mu_energyLossErr", &mu_energyLossErr, &b_mu_energyLossErr);
   fChain->SetBranchAddress("mu_etCore", &mu_etCore, &b_mu_etCore);
   fChain->SetBranchAddress("mu_energyLossType", &mu_energyLossType, &b_mu_energyLossType);
   fChain->SetBranchAddress("mu_caloMuonIdTag", &mu_caloMuonIdTag, &b_mu_caloMuonIdTag);
   fChain->SetBranchAddress("mu_caloLRLikelihood", &mu_caloLRLikelihood, &b_mu_caloLRLikelihood);
   fChain->SetBranchAddress("mu_bestMatch", &mu_bestMatch, &b_mu_bestMatch);
   fChain->SetBranchAddress("mu_isStandAloneMuon", &mu_isStandAloneMuon, &b_mu_isStandAloneMuon);
   fChain->SetBranchAddress("mu_isCombinedMuon", &mu_isCombinedMuon, &b_mu_isCombinedMuon);
   fChain->SetBranchAddress("mu_isLowPtReconstructedMuon", &mu_isLowPtReconstructedMuon, &b_mu_isLowPtReconstructedMuon);
   fChain->SetBranchAddress("mu_isSegmentTaggedMuon", &mu_isSegmentTaggedMuon, &b_mu_isSegmentTaggedMuon);
   fChain->SetBranchAddress("mu_isCaloMuonId", &mu_isCaloMuonId, &b_mu_isCaloMuonId);
   fChain->SetBranchAddress("mu_alsoFoundByLowPt", &mu_alsoFoundByLowPt, &b_mu_alsoFoundByLowPt);
   fChain->SetBranchAddress("mu_alsoFoundByCaloMuonId", &mu_alsoFoundByCaloMuonId, &b_mu_alsoFoundByCaloMuonId);
   fChain->SetBranchAddress("mu_loose", &mu_loose, &b_mu_loose);
   fChain->SetBranchAddress("mu_medium", &mu_medium, &b_mu_medium);
   fChain->SetBranchAddress("mu_tight", &mu_tight, &b_mu_tight);
   fChain->SetBranchAddress("mu_d0_exPV", &mu_d0_exPV, &b_mu_d0_exPV);
   fChain->SetBranchAddress("mu_z0_exPV", &mu_z0_exPV, &b_mu_z0_exPV);
   fChain->SetBranchAddress("mu_phi_exPV", &mu_phi_exPV, &b_mu_phi_exPV);
   fChain->SetBranchAddress("mu_theta_exPV", &mu_theta_exPV, &b_mu_theta_exPV);
   fChain->SetBranchAddress("mu_qoverp_exPV", &mu_qoverp_exPV, &b_mu_qoverp_exPV);
   fChain->SetBranchAddress("mu_cb_d0_exPV", &mu_cb_d0_exPV, &b_mu_cb_d0_exPV);
   fChain->SetBranchAddress("mu_cb_z0_exPV", &mu_cb_z0_exPV, &b_mu_cb_z0_exPV);
   fChain->SetBranchAddress("mu_cb_phi_exPV", &mu_cb_phi_exPV, &b_mu_cb_phi_exPV);
   fChain->SetBranchAddress("mu_cb_theta_exPV", &mu_cb_theta_exPV, &b_mu_cb_theta_exPV);
   fChain->SetBranchAddress("mu_cb_qoverp_exPV", &mu_cb_qoverp_exPV, &b_mu_cb_qoverp_exPV);
   fChain->SetBranchAddress("mu_id_d0_exPV", &mu_id_d0_exPV, &b_mu_id_d0_exPV);
   fChain->SetBranchAddress("mu_id_z0_exPV", &mu_id_z0_exPV, &b_mu_id_z0_exPV);
   fChain->SetBranchAddress("mu_id_phi_exPV", &mu_id_phi_exPV, &b_mu_id_phi_exPV);
   fChain->SetBranchAddress("mu_id_theta_exPV", &mu_id_theta_exPV, &b_mu_id_theta_exPV);
   fChain->SetBranchAddress("mu_id_qoverp_exPV", &mu_id_qoverp_exPV, &b_mu_id_qoverp_exPV);
   fChain->SetBranchAddress("mu_me_d0_exPV", &mu_me_d0_exPV, &b_mu_me_d0_exPV);
   fChain->SetBranchAddress("mu_me_z0_exPV", &mu_me_z0_exPV, &b_mu_me_z0_exPV);
   fChain->SetBranchAddress("mu_me_phi_exPV", &mu_me_phi_exPV, &b_mu_me_phi_exPV);
   fChain->SetBranchAddress("mu_me_theta_exPV", &mu_me_theta_exPV, &b_mu_me_theta_exPV);
   fChain->SetBranchAddress("mu_me_qoverp_exPV", &mu_me_qoverp_exPV, &b_mu_me_qoverp_exPV);
   fChain->SetBranchAddress("mu_ie_d0_exPV", &mu_ie_d0_exPV, &b_mu_ie_d0_exPV);
   fChain->SetBranchAddress("mu_ie_z0_exPV", &mu_ie_z0_exPV, &b_mu_ie_z0_exPV);
   fChain->SetBranchAddress("mu_ie_phi_exPV", &mu_ie_phi_exPV, &b_mu_ie_phi_exPV);
   fChain->SetBranchAddress("mu_ie_theta_exPV", &mu_ie_theta_exPV, &b_mu_ie_theta_exPV);
   fChain->SetBranchAddress("mu_ie_qoverp_exPV", &mu_ie_qoverp_exPV, &b_mu_ie_qoverp_exPV);
   fChain->SetBranchAddress("mu_SpaceTime_detID", &mu_SpaceTime_detID, &b_mu_SpaceTime_detID);
   fChain->SetBranchAddress("mu_SpaceTime_t", &mu_SpaceTime_t, &b_mu_SpaceTime_t);
   fChain->SetBranchAddress("mu_SpaceTime_tError", &mu_SpaceTime_tError, &b_mu_SpaceTime_tError);
   fChain->SetBranchAddress("mu_SpaceTime_weight", &mu_SpaceTime_weight, &b_mu_SpaceTime_weight);
   fChain->SetBranchAddress("mu_SpaceTime_x", &mu_SpaceTime_x, &b_mu_SpaceTime_x);
   fChain->SetBranchAddress("mu_SpaceTime_y", &mu_SpaceTime_y, &b_mu_SpaceTime_y);
   fChain->SetBranchAddress("mu_SpaceTime_z", &mu_SpaceTime_z, &b_mu_SpaceTime_z);
   fChain->SetBranchAddress("mu_cov_d0_exPV", &mu_cov_d0_exPV, &b_mu_cov_d0_exPV);
   fChain->SetBranchAddress("mu_cov_z0_exPV", &mu_cov_z0_exPV, &b_mu_cov_z0_exPV);
   fChain->SetBranchAddress("mu_cov_phi_exPV", &mu_cov_phi_exPV, &b_mu_cov_phi_exPV);
   fChain->SetBranchAddress("mu_cov_theta_exPV", &mu_cov_theta_exPV, &b_mu_cov_theta_exPV);
   fChain->SetBranchAddress("mu_cov_qoverp_exPV", &mu_cov_qoverp_exPV, &b_mu_cov_qoverp_exPV);
   fChain->SetBranchAddress("mu_cov_d0_z0_exPV", &mu_cov_d0_z0_exPV, &b_mu_cov_d0_z0_exPV);
   fChain->SetBranchAddress("mu_cov_d0_phi_exPV", &mu_cov_d0_phi_exPV, &b_mu_cov_d0_phi_exPV);
   fChain->SetBranchAddress("mu_cov_d0_theta_exPV", &mu_cov_d0_theta_exPV, &b_mu_cov_d0_theta_exPV);
   fChain->SetBranchAddress("mu_cov_d0_qoverp_exPV", &mu_cov_d0_qoverp_exPV, &b_mu_cov_d0_qoverp_exPV);
   fChain->SetBranchAddress("mu_cov_z0_phi_exPV", &mu_cov_z0_phi_exPV, &b_mu_cov_z0_phi_exPV);
   fChain->SetBranchAddress("mu_cov_z0_theta_exPV", &mu_cov_z0_theta_exPV, &b_mu_cov_z0_theta_exPV);
   fChain->SetBranchAddress("mu_cov_z0_qoverp_exPV", &mu_cov_z0_qoverp_exPV, &b_mu_cov_z0_qoverp_exPV);
   fChain->SetBranchAddress("mu_cov_phi_theta_exPV", &mu_cov_phi_theta_exPV, &b_mu_cov_phi_theta_exPV);
   fChain->SetBranchAddress("mu_cov_phi_qoverp_exPV", &mu_cov_phi_qoverp_exPV, &b_mu_cov_phi_qoverp_exPV);
   fChain->SetBranchAddress("mu_cov_theta_qoverp_exPV", &mu_cov_theta_qoverp_exPV, &b_mu_cov_theta_qoverp_exPV);
   fChain->SetBranchAddress("mu_id_cov_d0_exPV", &mu_id_cov_d0_exPV, &b_mu_id_cov_d0_exPV);
   fChain->SetBranchAddress("mu_id_cov_z0_exPV", &mu_id_cov_z0_exPV, &b_mu_id_cov_z0_exPV);
   fChain->SetBranchAddress("mu_id_cov_phi_exPV", &mu_id_cov_phi_exPV, &b_mu_id_cov_phi_exPV);
   fChain->SetBranchAddress("mu_id_cov_theta_exPV", &mu_id_cov_theta_exPV, &b_mu_id_cov_theta_exPV);
   fChain->SetBranchAddress("mu_id_cov_qoverp_exPV", &mu_id_cov_qoverp_exPV, &b_mu_id_cov_qoverp_exPV);
   fChain->SetBranchAddress("mu_id_cov_d0_z0_exPV", &mu_id_cov_d0_z0_exPV, &b_mu_id_cov_d0_z0_exPV);
   fChain->SetBranchAddress("mu_id_cov_d0_phi_exPV", &mu_id_cov_d0_phi_exPV, &b_mu_id_cov_d0_phi_exPV);
   fChain->SetBranchAddress("mu_id_cov_d0_theta_exPV", &mu_id_cov_d0_theta_exPV, &b_mu_id_cov_d0_theta_exPV);
   fChain->SetBranchAddress("mu_id_cov_d0_qoverp_exPV", &mu_id_cov_d0_qoverp_exPV, &b_mu_id_cov_d0_qoverp_exPV);
   fChain->SetBranchAddress("mu_id_cov_z0_phi_exPV", &mu_id_cov_z0_phi_exPV, &b_mu_id_cov_z0_phi_exPV);
   fChain->SetBranchAddress("mu_id_cov_z0_theta_exPV", &mu_id_cov_z0_theta_exPV, &b_mu_id_cov_z0_theta_exPV);
   fChain->SetBranchAddress("mu_id_cov_z0_qoverp_exPV", &mu_id_cov_z0_qoverp_exPV, &b_mu_id_cov_z0_qoverp_exPV);
   fChain->SetBranchAddress("mu_id_cov_phi_theta_exPV", &mu_id_cov_phi_theta_exPV, &b_mu_id_cov_phi_theta_exPV);
   fChain->SetBranchAddress("mu_id_cov_phi_qoverp_exPV", &mu_id_cov_phi_qoverp_exPV, &b_mu_id_cov_phi_qoverp_exPV);
   fChain->SetBranchAddress("mu_id_cov_theta_qoverp_exPV", &mu_id_cov_theta_qoverp_exPV, &b_mu_id_cov_theta_qoverp_exPV);
   fChain->SetBranchAddress("mu_me_cov_d0_exPV", &mu_me_cov_d0_exPV, &b_mu_me_cov_d0_exPV);
   fChain->SetBranchAddress("mu_me_cov_z0_exPV", &mu_me_cov_z0_exPV, &b_mu_me_cov_z0_exPV);
   fChain->SetBranchAddress("mu_me_cov_phi_exPV", &mu_me_cov_phi_exPV, &b_mu_me_cov_phi_exPV);
   fChain->SetBranchAddress("mu_me_cov_theta_exPV", &mu_me_cov_theta_exPV, &b_mu_me_cov_theta_exPV);
   fChain->SetBranchAddress("mu_me_cov_qoverp_exPV", &mu_me_cov_qoverp_exPV, &b_mu_me_cov_qoverp_exPV);
   fChain->SetBranchAddress("mu_me_cov_d0_z0_exPV", &mu_me_cov_d0_z0_exPV, &b_mu_me_cov_d0_z0_exPV);
   fChain->SetBranchAddress("mu_me_cov_d0_phi_exPV", &mu_me_cov_d0_phi_exPV, &b_mu_me_cov_d0_phi_exPV);
   fChain->SetBranchAddress("mu_me_cov_d0_theta_exPV", &mu_me_cov_d0_theta_exPV, &b_mu_me_cov_d0_theta_exPV);
   fChain->SetBranchAddress("mu_me_cov_d0_qoverp_exPV", &mu_me_cov_d0_qoverp_exPV, &b_mu_me_cov_d0_qoverp_exPV);
   fChain->SetBranchAddress("mu_me_cov_z0_phi_exPV", &mu_me_cov_z0_phi_exPV, &b_mu_me_cov_z0_phi_exPV);
   fChain->SetBranchAddress("mu_me_cov_z0_theta_exPV", &mu_me_cov_z0_theta_exPV, &b_mu_me_cov_z0_theta_exPV);
   fChain->SetBranchAddress("mu_me_cov_z0_qoverp_exPV", &mu_me_cov_z0_qoverp_exPV, &b_mu_me_cov_z0_qoverp_exPV);
   fChain->SetBranchAddress("mu_me_cov_phi_theta_exPV", &mu_me_cov_phi_theta_exPV, &b_mu_me_cov_phi_theta_exPV);
   fChain->SetBranchAddress("mu_me_cov_phi_qoverp_exPV", &mu_me_cov_phi_qoverp_exPV, &b_mu_me_cov_phi_qoverp_exPV);
   fChain->SetBranchAddress("mu_me_cov_theta_qoverp_exPV", &mu_me_cov_theta_qoverp_exPV, &b_mu_me_cov_theta_qoverp_exPV);
   fChain->SetBranchAddress("mu_ms_d0", &mu_ms_d0, &b_mu_ms_d0);
   fChain->SetBranchAddress("mu_ms_z0", &mu_ms_z0, &b_mu_ms_z0);
   fChain->SetBranchAddress("mu_ms_phi", &mu_ms_phi, &b_mu_ms_phi);
   fChain->SetBranchAddress("mu_ms_theta", &mu_ms_theta, &b_mu_ms_theta);
   fChain->SetBranchAddress("mu_ms_qoverp", &mu_ms_qoverp, &b_mu_ms_qoverp);
   fChain->SetBranchAddress("mu_id_d0", &mu_id_d0, &b_mu_id_d0);
   fChain->SetBranchAddress("mu_id_z0", &mu_id_z0, &b_mu_id_z0);
   fChain->SetBranchAddress("mu_id_phi", &mu_id_phi, &b_mu_id_phi);
   fChain->SetBranchAddress("mu_id_theta", &mu_id_theta, &b_mu_id_theta);
   fChain->SetBranchAddress("mu_id_qoverp", &mu_id_qoverp, &b_mu_id_qoverp);
   fChain->SetBranchAddress("mu_me_d0", &mu_me_d0, &b_mu_me_d0);
   fChain->SetBranchAddress("mu_me_z0", &mu_me_z0, &b_mu_me_z0);
   fChain->SetBranchAddress("mu_me_phi", &mu_me_phi, &b_mu_me_phi);
   fChain->SetBranchAddress("mu_me_theta", &mu_me_theta, &b_mu_me_theta);
   fChain->SetBranchAddress("mu_me_qoverp", &mu_me_qoverp, &b_mu_me_qoverp);
   fChain->SetBranchAddress("mu_ie_d0", &mu_ie_d0, &b_mu_ie_d0);
   fChain->SetBranchAddress("mu_ie_z0", &mu_ie_z0, &b_mu_ie_z0);
   fChain->SetBranchAddress("mu_ie_phi", &mu_ie_phi, &b_mu_ie_phi);
   fChain->SetBranchAddress("mu_ie_theta", &mu_ie_theta, &b_mu_ie_theta);
   fChain->SetBranchAddress("mu_ie_qoverp", &mu_ie_qoverp, &b_mu_ie_qoverp);
   fChain->SetBranchAddress("mu_nOutliersOnTrack", &mu_nOutliersOnTrack, &b_mu_nOutliersOnTrack);
   fChain->SetBranchAddress("mu_nBLHits", &mu_nBLHits, &b_mu_nBLHits);
   fChain->SetBranchAddress("mu_nPixHits", &mu_nPixHits, &b_mu_nPixHits);
   fChain->SetBranchAddress("mu_nSCTHits", &mu_nSCTHits, &b_mu_nSCTHits);
   fChain->SetBranchAddress("mu_nTRTHits", &mu_nTRTHits, &b_mu_nTRTHits);
   fChain->SetBranchAddress("mu_nTRTHighTHits", &mu_nTRTHighTHits, &b_mu_nTRTHighTHits);
   fChain->SetBranchAddress("mu_nBLSharedHits", &mu_nBLSharedHits, &b_mu_nBLSharedHits);
   fChain->SetBranchAddress("mu_nPixSharedHits", &mu_nPixSharedHits, &b_mu_nPixSharedHits);
   fChain->SetBranchAddress("mu_nPixHoles", &mu_nPixHoles, &b_mu_nPixHoles);
   fChain->SetBranchAddress("mu_nSCTSharedHits", &mu_nSCTSharedHits, &b_mu_nSCTSharedHits);
   fChain->SetBranchAddress("mu_nSCTHoles", &mu_nSCTHoles, &b_mu_nSCTHoles);
   fChain->SetBranchAddress("mu_nTRTOutliers", &mu_nTRTOutliers, &b_mu_nTRTOutliers);
   fChain->SetBranchAddress("mu_nTRTHighTOutliers", &mu_nTRTHighTOutliers, &b_mu_nTRTHighTOutliers);
   fChain->SetBranchAddress("mu_nGangedPixels", &mu_nGangedPixels, &b_mu_nGangedPixels);
   fChain->SetBranchAddress("mu_nPixelDeadSensors", &mu_nPixelDeadSensors, &b_mu_nPixelDeadSensors);
   fChain->SetBranchAddress("mu_nSCTDeadSensors", &mu_nSCTDeadSensors, &b_mu_nSCTDeadSensors);
   fChain->SetBranchAddress("mu_nTRTDeadStraws", &mu_nTRTDeadStraws, &b_mu_nTRTDeadStraws);
   fChain->SetBranchAddress("mu_expectBLayerHit", &mu_expectBLayerHit, &b_mu_expectBLayerHit);
   fChain->SetBranchAddress("mu_nMDTHits", &mu_nMDTHits, &b_mu_nMDTHits);
   fChain->SetBranchAddress("mu_nMDTHoles", &mu_nMDTHoles, &b_mu_nMDTHoles);
   fChain->SetBranchAddress("mu_nCSCEtaHits", &mu_nCSCEtaHits, &b_mu_nCSCEtaHits);
   fChain->SetBranchAddress("mu_nCSCEtaHoles", &mu_nCSCEtaHoles, &b_mu_nCSCEtaHoles);
   fChain->SetBranchAddress("mu_nCSCPhiHits", &mu_nCSCPhiHits, &b_mu_nCSCPhiHits);
   fChain->SetBranchAddress("mu_nCSCPhiHoles", &mu_nCSCPhiHoles, &b_mu_nCSCPhiHoles);
   fChain->SetBranchAddress("mu_nRPCEtaHits", &mu_nRPCEtaHits, &b_mu_nRPCEtaHits);
   fChain->SetBranchAddress("mu_nRPCEtaHoles", &mu_nRPCEtaHoles, &b_mu_nRPCEtaHoles);
   fChain->SetBranchAddress("mu_nRPCPhiHits", &mu_nRPCPhiHits, &b_mu_nRPCPhiHits);
   fChain->SetBranchAddress("mu_nRPCPhiHoles", &mu_nRPCPhiHoles, &b_mu_nRPCPhiHoles);
   fChain->SetBranchAddress("mu_nTGCEtaHits", &mu_nTGCEtaHits, &b_mu_nTGCEtaHits);
   fChain->SetBranchAddress("mu_nTGCEtaHoles", &mu_nTGCEtaHoles, &b_mu_nTGCEtaHoles);
   fChain->SetBranchAddress("mu_nTGCPhiHits", &mu_nTGCPhiHits, &b_mu_nTGCPhiHits);
   fChain->SetBranchAddress("mu_nTGCPhiHoles", &mu_nTGCPhiHoles, &b_mu_nTGCPhiHoles);
   fChain->SetBranchAddress("mu_nMDTBIHits", &mu_nMDTBIHits, &b_mu_nMDTBIHits);
   fChain->SetBranchAddress("mu_nMDTBMHits", &mu_nMDTBMHits, &b_mu_nMDTBMHits);
   fChain->SetBranchAddress("mu_nMDTBOHits", &mu_nMDTBOHits, &b_mu_nMDTBOHits);
   fChain->SetBranchAddress("mu_nMDTBEEHits", &mu_nMDTBEEHits, &b_mu_nMDTBEEHits);
   fChain->SetBranchAddress("mu_nMDTBIS78Hits", &mu_nMDTBIS78Hits, &b_mu_nMDTBIS78Hits);
   fChain->SetBranchAddress("mu_nMDTEIHits", &mu_nMDTEIHits, &b_mu_nMDTEIHits);
   fChain->SetBranchAddress("mu_nMDTEMHits", &mu_nMDTEMHits, &b_mu_nMDTEMHits);
   fChain->SetBranchAddress("mu_nMDTEOHits", &mu_nMDTEOHits, &b_mu_nMDTEOHits);
   fChain->SetBranchAddress("mu_nMDTEEHits", &mu_nMDTEEHits, &b_mu_nMDTEEHits);
   fChain->SetBranchAddress("mu_nRPCLayer1EtaHits", &mu_nRPCLayer1EtaHits, &b_mu_nRPCLayer1EtaHits);
   fChain->SetBranchAddress("mu_nRPCLayer2EtaHits", &mu_nRPCLayer2EtaHits, &b_mu_nRPCLayer2EtaHits);
   fChain->SetBranchAddress("mu_nRPCLayer3EtaHits", &mu_nRPCLayer3EtaHits, &b_mu_nRPCLayer3EtaHits);
   fChain->SetBranchAddress("mu_nRPCLayer1PhiHits", &mu_nRPCLayer1PhiHits, &b_mu_nRPCLayer1PhiHits);
   fChain->SetBranchAddress("mu_nRPCLayer2PhiHits", &mu_nRPCLayer2PhiHits, &b_mu_nRPCLayer2PhiHits);
   fChain->SetBranchAddress("mu_nRPCLayer3PhiHits", &mu_nRPCLayer3PhiHits, &b_mu_nRPCLayer3PhiHits);
   fChain->SetBranchAddress("mu_nTGCLayer1EtaHits", &mu_nTGCLayer1EtaHits, &b_mu_nTGCLayer1EtaHits);
   fChain->SetBranchAddress("mu_nTGCLayer2EtaHits", &mu_nTGCLayer2EtaHits, &b_mu_nTGCLayer2EtaHits);
   fChain->SetBranchAddress("mu_nTGCLayer3EtaHits", &mu_nTGCLayer3EtaHits, &b_mu_nTGCLayer3EtaHits);
   fChain->SetBranchAddress("mu_nTGCLayer4EtaHits", &mu_nTGCLayer4EtaHits, &b_mu_nTGCLayer4EtaHits);
   fChain->SetBranchAddress("mu_nTGCLayer1PhiHits", &mu_nTGCLayer1PhiHits, &b_mu_nTGCLayer1PhiHits);
   fChain->SetBranchAddress("mu_nTGCLayer2PhiHits", &mu_nTGCLayer2PhiHits, &b_mu_nTGCLayer2PhiHits);
   fChain->SetBranchAddress("mu_nTGCLayer3PhiHits", &mu_nTGCLayer3PhiHits, &b_mu_nTGCLayer3PhiHits);
   fChain->SetBranchAddress("mu_nTGCLayer4PhiHits", &mu_nTGCLayer4PhiHits, &b_mu_nTGCLayer4PhiHits);
   fChain->SetBranchAddress("mu_barrelSectors", &mu_barrelSectors, &b_mu_barrelSectors);
   fChain->SetBranchAddress("mu_endcapSectors", &mu_endcapSectors, &b_mu_endcapSectors);
   fChain->SetBranchAddress("mu_trackd0", &mu_trackd0, &b_mu_trackd0);
   fChain->SetBranchAddress("mu_trackz0", &mu_trackz0, &b_mu_trackz0);
   fChain->SetBranchAddress("mu_trackphi", &mu_trackphi, &b_mu_trackphi);
   fChain->SetBranchAddress("mu_tracktheta", &mu_tracktheta, &b_mu_tracktheta);
   fChain->SetBranchAddress("mu_trackqoverp", &mu_trackqoverp, &b_mu_trackqoverp);
   fChain->SetBranchAddress("mu_trackcov_d0", &mu_trackcov_d0, &b_mu_trackcov_d0);
   fChain->SetBranchAddress("mu_trackcov_z0", &mu_trackcov_z0, &b_mu_trackcov_z0);
   fChain->SetBranchAddress("mu_trackcov_phi", &mu_trackcov_phi, &b_mu_trackcov_phi);
   fChain->SetBranchAddress("mu_trackcov_theta", &mu_trackcov_theta, &b_mu_trackcov_theta);
   fChain->SetBranchAddress("mu_trackcov_qoverp", &mu_trackcov_qoverp, &b_mu_trackcov_qoverp);
   fChain->SetBranchAddress("mu_trackcov_d0_z0", &mu_trackcov_d0_z0, &b_mu_trackcov_d0_z0);
   fChain->SetBranchAddress("mu_trackcov_d0_phi", &mu_trackcov_d0_phi, &b_mu_trackcov_d0_phi);
   fChain->SetBranchAddress("mu_trackcov_d0_theta", &mu_trackcov_d0_theta, &b_mu_trackcov_d0_theta);
   fChain->SetBranchAddress("mu_trackcov_d0_qoverp", &mu_trackcov_d0_qoverp, &b_mu_trackcov_d0_qoverp);
   fChain->SetBranchAddress("mu_trackcov_z0_phi", &mu_trackcov_z0_phi, &b_mu_trackcov_z0_phi);
   fChain->SetBranchAddress("mu_trackcov_z0_theta", &mu_trackcov_z0_theta, &b_mu_trackcov_z0_theta);
   fChain->SetBranchAddress("mu_trackcov_z0_qoverp", &mu_trackcov_z0_qoverp, &b_mu_trackcov_z0_qoverp);
   fChain->SetBranchAddress("mu_trackcov_phi_theta", &mu_trackcov_phi_theta, &b_mu_trackcov_phi_theta);
   fChain->SetBranchAddress("mu_trackcov_phi_qoverp", &mu_trackcov_phi_qoverp, &b_mu_trackcov_phi_qoverp);
   fChain->SetBranchAddress("mu_trackcov_theta_qoverp", &mu_trackcov_theta_qoverp, &b_mu_trackcov_theta_qoverp);
   fChain->SetBranchAddress("mu_trackfitchi2", &mu_trackfitchi2, &b_mu_trackfitchi2);
   fChain->SetBranchAddress("mu_trackfitndof", &mu_trackfitndof, &b_mu_trackfitndof);
   fChain->SetBranchAddress("mu_hastrack", &mu_hastrack, &b_mu_hastrack);
   fChain->SetBranchAddress("mu_trackd0beam", &mu_trackd0beam, &b_mu_trackd0beam);
   fChain->SetBranchAddress("mu_trackz0beam", &mu_trackz0beam, &b_mu_trackz0beam);
   fChain->SetBranchAddress("mu_tracksigd0beam", &mu_tracksigd0beam, &b_mu_tracksigd0beam);
   fChain->SetBranchAddress("mu_tracksigz0beam", &mu_tracksigz0beam, &b_mu_tracksigz0beam);
   fChain->SetBranchAddress("mu_trackd0pv", &mu_trackd0pv, &b_mu_trackd0pv);
   fChain->SetBranchAddress("mu_trackz0pv", &mu_trackz0pv, &b_mu_trackz0pv);
   fChain->SetBranchAddress("mu_tracksigd0pv", &mu_tracksigd0pv, &b_mu_tracksigd0pv);
   fChain->SetBranchAddress("mu_tracksigz0pv", &mu_tracksigz0pv, &b_mu_tracksigz0pv);
   fChain->SetBranchAddress("mu_trackIPEstimate_d0_biasedpvunbiased", &mu_trackIPEstimate_d0_biasedpvunbiased, &b_mu_trackIPEstimate_d0_biasedpvunbiased);
   fChain->SetBranchAddress("mu_trackIPEstimate_z0_biasedpvunbiased", &mu_trackIPEstimate_z0_biasedpvunbiased, &b_mu_trackIPEstimate_z0_biasedpvunbiased);
   fChain->SetBranchAddress("mu_trackIPEstimate_d0_unbiasedpvunbiased", &mu_trackIPEstimate_d0_unbiasedpvunbiased, &b_mu_trackIPEstimate_d0_unbiasedpvunbiased);
   fChain->SetBranchAddress("mu_trackIPEstimate_z0_unbiasedpvunbiased", &mu_trackIPEstimate_z0_unbiasedpvunbiased, &b_mu_trackIPEstimate_z0_unbiasedpvunbiased);
   fChain->SetBranchAddress("mu_trackIPEstimate_sigd0_biasedpvunbiased", &mu_trackIPEstimate_sigd0_biasedpvunbiased, &b_mu_trackIPEstimate_sigd0_biasedpvunbiased);
   fChain->SetBranchAddress("mu_trackIPEstimate_sigz0_biasedpvunbiased", &mu_trackIPEstimate_sigz0_biasedpvunbiased, &b_mu_trackIPEstimate_sigz0_biasedpvunbiased);
   fChain->SetBranchAddress("mu_trackIPEstimate_sigd0_unbiasedpvunbiased", &mu_trackIPEstimate_sigd0_unbiasedpvunbiased, &b_mu_trackIPEstimate_sigd0_unbiasedpvunbiased);
   fChain->SetBranchAddress("mu_trackIPEstimate_sigz0_unbiasedpvunbiased", &mu_trackIPEstimate_sigz0_unbiasedpvunbiased, &b_mu_trackIPEstimate_sigz0_unbiasedpvunbiased);
   fChain->SetBranchAddress("mu_EFCB_dr", &mu_EFCB_dr, &b_mu_EFCB_dr);
   fChain->SetBranchAddress("mu_EFCB_index", &mu_EFCB_index, &b_mu_EFCB_index);
   fChain->SetBranchAddress("mu_EFMG_dr", &mu_EFMG_dr, &b_mu_EFMG_dr);
   fChain->SetBranchAddress("mu_EFME_dr", &mu_EFME_dr, &b_mu_EFME_dr);
   fChain->SetBranchAddress("mu_EFME_index", &mu_EFME_index, &b_mu_EFME_index);
   fChain->SetBranchAddress("mu_L2CB_dr", &mu_L2CB_dr, &b_mu_L2CB_dr);
   fChain->SetBranchAddress("mu_L2CB_index", &mu_L2CB_index, &b_mu_L2CB_index);
   fChain->SetBranchAddress("mu_L1_dr", &mu_L1_dr, &b_mu_L1_dr);
   fChain->SetBranchAddress("mu_L1_index", &mu_L1_index, &b_mu_L1_index);
   fChain->SetBranchAddress("tau_n", &tau_n, &b_tau_n);
   fChain->SetBranchAddress("tau_Et", &tau_Et, &b_tau_Et);
   fChain->SetBranchAddress("tau_pt", &tau_pt, &b_tau_pt);
   fChain->SetBranchAddress("tau_m", &tau_m, &b_tau_m);
   fChain->SetBranchAddress("tau_eta", &tau_eta, &b_tau_eta);
   fChain->SetBranchAddress("tau_phi", &tau_phi, &b_tau_phi);
   fChain->SetBranchAddress("tau_charge", &tau_charge, &b_tau_charge);
   fChain->SetBranchAddress("tau_BDTEleScore", &tau_BDTEleScore, &b_tau_BDTEleScore);
   fChain->SetBranchAddress("tau_BDTJetScore", &tau_BDTJetScore, &b_tau_BDTJetScore);
   fChain->SetBranchAddress("tau_likelihood", &tau_likelihood, &b_tau_likelihood);
   fChain->SetBranchAddress("tau_SafeLikelihood", &tau_SafeLikelihood, &b_tau_SafeLikelihood);
   fChain->SetBranchAddress("tau_electronVetoLoose", &tau_electronVetoLoose, &b_tau_electronVetoLoose);
   fChain->SetBranchAddress("tau_electronVetoMedium", &tau_electronVetoMedium, &b_tau_electronVetoMedium);
   fChain->SetBranchAddress("tau_electronVetoTight", &tau_electronVetoTight, &b_tau_electronVetoTight);
   fChain->SetBranchAddress("tau_muonVeto", &tau_muonVeto, &b_tau_muonVeto);
   fChain->SetBranchAddress("tau_tauCutLoose", &tau_tauCutLoose, &b_tau_tauCutLoose);
   fChain->SetBranchAddress("tau_tauCutMedium", &tau_tauCutMedium, &b_tau_tauCutMedium);
   fChain->SetBranchAddress("tau_tauCutTight", &tau_tauCutTight, &b_tau_tauCutTight);
   fChain->SetBranchAddress("tau_tauLlhLoose", &tau_tauLlhLoose, &b_tau_tauLlhLoose);
   fChain->SetBranchAddress("tau_tauLlhMedium", &tau_tauLlhMedium, &b_tau_tauLlhMedium);
   fChain->SetBranchAddress("tau_tauLlhTight", &tau_tauLlhTight, &b_tau_tauLlhTight);
   fChain->SetBranchAddress("tau_JetBDTSigLoose", &tau_JetBDTSigLoose, &b_tau_JetBDTSigLoose);
   fChain->SetBranchAddress("tau_JetBDTSigMedium", &tau_JetBDTSigMedium, &b_tau_JetBDTSigMedium);
   fChain->SetBranchAddress("tau_JetBDTSigTight", &tau_JetBDTSigTight, &b_tau_JetBDTSigTight);
   fChain->SetBranchAddress("tau_EleBDTLoose", &tau_EleBDTLoose, &b_tau_EleBDTLoose);
   fChain->SetBranchAddress("tau_EleBDTMedium", &tau_EleBDTMedium, &b_tau_EleBDTMedium);
   fChain->SetBranchAddress("tau_EleBDTTight", &tau_EleBDTTight, &b_tau_EleBDTTight);
   fChain->SetBranchAddress("tau_author", &tau_author, &b_tau_author);
   fChain->SetBranchAddress("tau_ROIword", &tau_ROIword, &b_tau_ROIword);
   fChain->SetBranchAddress("tau_nProng", &tau_nProng, &b_tau_nProng);
   fChain->SetBranchAddress("tau_numTrack", &tau_numTrack, &b_tau_numTrack);
   fChain->SetBranchAddress("tau_seedCalo_numTrack", &tau_seedCalo_numTrack, &b_tau_seedCalo_numTrack);
   fChain->SetBranchAddress("tau_etOverPtLeadTrk", &tau_etOverPtLeadTrk, &b_tau_etOverPtLeadTrk);
   fChain->SetBranchAddress("tau_ipZ0SinThetaSigLeadTrk", &tau_ipZ0SinThetaSigLeadTrk, &b_tau_ipZ0SinThetaSigLeadTrk);
   fChain->SetBranchAddress("tau_leadTrkPt", &tau_leadTrkPt, &b_tau_leadTrkPt);
   fChain->SetBranchAddress("tau_nLooseTrk", &tau_nLooseTrk, &b_tau_nLooseTrk);
   fChain->SetBranchAddress("tau_nLooseConvTrk", &tau_nLooseConvTrk, &b_tau_nLooseConvTrk);
   fChain->SetBranchAddress("tau_nProngLoose", &tau_nProngLoose, &b_tau_nProngLoose);
   fChain->SetBranchAddress("tau_ipSigLeadTrk", &tau_ipSigLeadTrk, &b_tau_ipSigLeadTrk);
   fChain->SetBranchAddress("tau_ipSigLeadLooseTrk", &tau_ipSigLeadLooseTrk, &b_tau_ipSigLeadLooseTrk);
   fChain->SetBranchAddress("tau_etOverPtLeadLooseTrk", &tau_etOverPtLeadLooseTrk, &b_tau_etOverPtLeadLooseTrk);
   fChain->SetBranchAddress("tau_leadLooseTrkPt", &tau_leadLooseTrkPt, &b_tau_leadLooseTrkPt);
   fChain->SetBranchAddress("tau_chrgLooseTrk", &tau_chrgLooseTrk, &b_tau_chrgLooseTrk);
   fChain->SetBranchAddress("tau_massTrkSys", &tau_massTrkSys, &b_tau_massTrkSys);
   fChain->SetBranchAddress("tau_trkWidth2", &tau_trkWidth2, &b_tau_trkWidth2);
   fChain->SetBranchAddress("tau_trFlightPathSig", &tau_trFlightPathSig, &b_tau_trFlightPathSig);
   fChain->SetBranchAddress("tau_etEflow", &tau_etEflow, &b_tau_etEflow);
   fChain->SetBranchAddress("tau_mEflow", &tau_mEflow, &b_tau_mEflow);
   fChain->SetBranchAddress("tau_nPi0", &tau_nPi0, &b_tau_nPi0);
   fChain->SetBranchAddress("tau_ele_E237E277", &tau_ele_E237E277, &b_tau_ele_E237E277);
   fChain->SetBranchAddress("tau_ele_PresamplerFraction", &tau_ele_PresamplerFraction, &b_tau_ele_PresamplerFraction);
   fChain->SetBranchAddress("tau_ele_ECALFirstFraction", &tau_ele_ECALFirstFraction, &b_tau_ele_ECALFirstFraction);
   fChain->SetBranchAddress("tau_seedCalo_EMRadius", &tau_seedCalo_EMRadius, &b_tau_seedCalo_EMRadius);
   fChain->SetBranchAddress("tau_seedCalo_hadRadius", &tau_seedCalo_hadRadius, &b_tau_seedCalo_hadRadius);
   fChain->SetBranchAddress("tau_seedCalo_etEMAtEMScale", &tau_seedCalo_etEMAtEMScale, &b_tau_seedCalo_etEMAtEMScale);
   fChain->SetBranchAddress("tau_seedCalo_etHadAtEMScale", &tau_seedCalo_etHadAtEMScale, &b_tau_seedCalo_etHadAtEMScale);
   fChain->SetBranchAddress("tau_seedCalo_isolFrac", &tau_seedCalo_isolFrac, &b_tau_seedCalo_isolFrac);
   fChain->SetBranchAddress("tau_seedCalo_centFrac", &tau_seedCalo_centFrac, &b_tau_seedCalo_centFrac);
   fChain->SetBranchAddress("tau_seedCalo_stripWidth2", &tau_seedCalo_stripWidth2, &b_tau_seedCalo_stripWidth2);
   fChain->SetBranchAddress("tau_seedCalo_nStrip", &tau_seedCalo_nStrip, &b_tau_seedCalo_nStrip);
   fChain->SetBranchAddress("tau_seedCalo_etEMCalib", &tau_seedCalo_etEMCalib, &b_tau_seedCalo_etEMCalib);
   fChain->SetBranchAddress("tau_seedCalo_etHadCalib", &tau_seedCalo_etHadCalib, &b_tau_seedCalo_etHadCalib);
   fChain->SetBranchAddress("tau_seedCalo_eta", &tau_seedCalo_eta, &b_tau_seedCalo_eta);
   fChain->SetBranchAddress("tau_seedCalo_phi", &tau_seedCalo_phi, &b_tau_seedCalo_phi);
   fChain->SetBranchAddress("tau_seedCalo_nIsolLooseTrk", &tau_seedCalo_nIsolLooseTrk, &b_tau_seedCalo_nIsolLooseTrk);
   fChain->SetBranchAddress("tau_seedCalo_trkAvgDist", &tau_seedCalo_trkAvgDist, &b_tau_seedCalo_trkAvgDist);
   fChain->SetBranchAddress("tau_seedCalo_trkRmsDist", &tau_seedCalo_trkRmsDist, &b_tau_seedCalo_trkRmsDist);
   fChain->SetBranchAddress("tau_numTopoClusters", &tau_numTopoClusters, &b_tau_numTopoClusters);
   fChain->SetBranchAddress("tau_numEffTopoClusters", &tau_numEffTopoClusters, &b_tau_numEffTopoClusters);
   fChain->SetBranchAddress("tau_topoInvMass", &tau_topoInvMass, &b_tau_topoInvMass);
   fChain->SetBranchAddress("tau_effTopoInvMass", &tau_effTopoInvMass, &b_tau_effTopoInvMass);
   fChain->SetBranchAddress("tau_topoMeanDeltaR", &tau_topoMeanDeltaR, &b_tau_topoMeanDeltaR);
   fChain->SetBranchAddress("tau_effTopoMeanDeltaR", &tau_effTopoMeanDeltaR, &b_tau_effTopoMeanDeltaR);
   fChain->SetBranchAddress("tau_numCells", &tau_numCells, &b_tau_numCells);
   fChain->SetBranchAddress("tau_seedTrk_EMRadius", &tau_seedTrk_EMRadius, &b_tau_seedTrk_EMRadius);
   fChain->SetBranchAddress("tau_seedTrk_isolFrac", &tau_seedTrk_isolFrac, &b_tau_seedTrk_isolFrac);
   fChain->SetBranchAddress("tau_seedTrk_etChrgHadOverSumTrkPt", &tau_seedTrk_etChrgHadOverSumTrkPt, &b_tau_seedTrk_etChrgHadOverSumTrkPt);
   fChain->SetBranchAddress("tau_seedTrk_isolFracWide", &tau_seedTrk_isolFracWide, &b_tau_seedTrk_isolFracWide);
   fChain->SetBranchAddress("tau_seedTrk_etHadAtEMScale", &tau_seedTrk_etHadAtEMScale, &b_tau_seedTrk_etHadAtEMScale);
   fChain->SetBranchAddress("tau_seedTrk_etEMAtEMScale", &tau_seedTrk_etEMAtEMScale, &b_tau_seedTrk_etEMAtEMScale);
   fChain->SetBranchAddress("tau_seedTrk_etEMCL", &tau_seedTrk_etEMCL, &b_tau_seedTrk_etEMCL);
   fChain->SetBranchAddress("tau_seedTrk_etChrgEM", &tau_seedTrk_etChrgEM, &b_tau_seedTrk_etChrgEM);
   fChain->SetBranchAddress("tau_seedTrk_etNeuEM", &tau_seedTrk_etNeuEM, &b_tau_seedTrk_etNeuEM);
   fChain->SetBranchAddress("tau_seedTrk_etResNeuEM", &tau_seedTrk_etResNeuEM, &b_tau_seedTrk_etResNeuEM);
   fChain->SetBranchAddress("tau_seedTrk_hadLeakEt", &tau_seedTrk_hadLeakEt, &b_tau_seedTrk_hadLeakEt);
   fChain->SetBranchAddress("tau_seedTrk_sumEMCellEtOverLeadTrkPt", &tau_seedTrk_sumEMCellEtOverLeadTrkPt, &b_tau_seedTrk_sumEMCellEtOverLeadTrkPt);
   fChain->SetBranchAddress("tau_seedTrk_secMaxStripEt", &tau_seedTrk_secMaxStripEt, &b_tau_seedTrk_secMaxStripEt);
   fChain->SetBranchAddress("tau_seedTrk_stripWidth2", &tau_seedTrk_stripWidth2, &b_tau_seedTrk_stripWidth2);
   fChain->SetBranchAddress("tau_seedTrk_nStrip", &tau_seedTrk_nStrip, &b_tau_seedTrk_nStrip);
   fChain->SetBranchAddress("tau_seedTrk_etChrgHad", &tau_seedTrk_etChrgHad, &b_tau_seedTrk_etChrgHad);
   fChain->SetBranchAddress("tau_seedTrk_nOtherCoreTrk", &tau_seedTrk_nOtherCoreTrk, &b_tau_seedTrk_nOtherCoreTrk);
   fChain->SetBranchAddress("tau_seedTrk_nIsolTrk", &tau_seedTrk_nIsolTrk, &b_tau_seedTrk_nIsolTrk);
   fChain->SetBranchAddress("tau_seedTrk_etIsolEM", &tau_seedTrk_etIsolEM, &b_tau_seedTrk_etIsolEM);
   fChain->SetBranchAddress("tau_seedTrk_etIsolHad", &tau_seedTrk_etIsolHad, &b_tau_seedTrk_etIsolHad);
   fChain->SetBranchAddress("tau_calcVars_etHad_EMScale_Pt3Trks", &tau_calcVars_etHad_EMScale_Pt3Trks, &b_tau_calcVars_etHad_EMScale_Pt3Trks);
   fChain->SetBranchAddress("tau_calcVars_etEM_EMScale_Pt3Trks", &tau_calcVars_etEM_EMScale_Pt3Trks, &b_tau_calcVars_etEM_EMScale_Pt3Trks);
   fChain->SetBranchAddress("tau_calcVars_ipSigLeadLooseTrk", &tau_calcVars_ipSigLeadLooseTrk, &b_tau_calcVars_ipSigLeadLooseTrk);
   fChain->SetBranchAddress("tau_calcVars_drMax", &tau_calcVars_drMax, &b_tau_calcVars_drMax);
   fChain->SetBranchAddress("tau_calcVars_drMin", &tau_calcVars_drMin, &b_tau_calcVars_drMin);
   fChain->SetBranchAddress("tau_calcVars_TRTHTOverLT_LeadTrk", &tau_calcVars_TRTHTOverLT_LeadTrk, &b_tau_calcVars_TRTHTOverLT_LeadTrk);
   fChain->SetBranchAddress("tau_calcVars_calRadius", &tau_calcVars_calRadius, &b_tau_calcVars_calRadius);
   fChain->SetBranchAddress("tau_calcVars_EMFractionAtEMScale", &tau_calcVars_EMFractionAtEMScale, &b_tau_calcVars_EMFractionAtEMScale);
   fChain->SetBranchAddress("tau_calcVars_lead2ClusterEOverAllClusterE", &tau_calcVars_lead2ClusterEOverAllClusterE, &b_tau_calcVars_lead2ClusterEOverAllClusterE);
   fChain->SetBranchAddress("tau_calcVars_lead3ClusterEOverAllClusterE", &tau_calcVars_lead3ClusterEOverAllClusterE, &b_tau_calcVars_lead3ClusterEOverAllClusterE);
   fChain->SetBranchAddress("tau_calcVars_caloIso", &tau_calcVars_caloIso, &b_tau_calcVars_caloIso);
   fChain->SetBranchAddress("tau_calcVars_trackIso", &tau_calcVars_trackIso, &b_tau_calcVars_trackIso);
   fChain->SetBranchAddress("tau_calcVars_caloIsoCorrected", &tau_calcVars_caloIsoCorrected, &b_tau_calcVars_caloIsoCorrected);
   fChain->SetBranchAddress("tau_calcVars_BDTSigTrans", &tau_calcVars_BDTSigTrans, &b_tau_calcVars_BDTSigTrans);
   fChain->SetBranchAddress("tau_calcVars_BDTLooseBkg", &tau_calcVars_BDTLooseBkg, &b_tau_calcVars_BDTLooseBkg);
   fChain->SetBranchAddress("tau_calcVars_BDTMediumBkg", &tau_calcVars_BDTMediumBkg, &b_tau_calcVars_BDTMediumBkg);
   fChain->SetBranchAddress("tau_calcVars_BDTTightBkg", &tau_calcVars_BDTTightBkg, &b_tau_calcVars_BDTTightBkg);
   fChain->SetBranchAddress("tau_cluster_E", &tau_cluster_E, &b_tau_cluster_E);
   fChain->SetBranchAddress("tau_cluster_eta", &tau_cluster_eta, &b_tau_cluster_eta);
   fChain->SetBranchAddress("tau_cluster_phi", &tau_cluster_phi, &b_tau_cluster_phi);
   fChain->SetBranchAddress("tau_cluster_n", &tau_cluster_n, &b_tau_cluster_n);
   fChain->SetBranchAddress("tau_cluster_emfraction", &tau_cluster_emfraction, &b_tau_cluster_emfraction);
   fChain->SetBranchAddress("tau_Pi0Cluster_pt", &tau_Pi0Cluster_pt, &b_tau_Pi0Cluster_pt);
   fChain->SetBranchAddress("tau_Pi0Cluster_eta", &tau_Pi0Cluster_eta, &b_tau_Pi0Cluster_eta);
   fChain->SetBranchAddress("tau_Pi0Cluster_phi", &tau_Pi0Cluster_phi, &b_tau_Pi0Cluster_phi);
   fChain->SetBranchAddress("tau_secvtx_x", &tau_secvtx_x, &b_tau_secvtx_x);
   fChain->SetBranchAddress("tau_secvtx_y", &tau_secvtx_y, &b_tau_secvtx_y);
   fChain->SetBranchAddress("tau_secvtx_z", &tau_secvtx_z, &b_tau_secvtx_z);
   fChain->SetBranchAddress("tau_secvtx_chiSquared", &tau_secvtx_chiSquared, &b_tau_secvtx_chiSquared);
   fChain->SetBranchAddress("tau_secvtx_numberDoF", &tau_secvtx_numberDoF, &b_tau_secvtx_numberDoF);
   fChain->SetBranchAddress("tau_jet_Et", &tau_jet_Et, &b_tau_jet_Et);
   fChain->SetBranchAddress("tau_jet_pt", &tau_jet_pt, &b_tau_jet_pt);
   fChain->SetBranchAddress("tau_jet_m", &tau_jet_m, &b_tau_jet_m);
   fChain->SetBranchAddress("tau_jet_eta", &tau_jet_eta, &b_tau_jet_eta);
   fChain->SetBranchAddress("tau_jet_phi", &tau_jet_phi, &b_tau_jet_phi);
   fChain->SetBranchAddress("tau_jet_SamplingMax", &tau_jet_SamplingMax, &b_tau_jet_SamplingMax);
   fChain->SetBranchAddress("tau_jet_fracSamplingMax", &tau_jet_fracSamplingMax, &b_tau_jet_fracSamplingMax);
   fChain->SetBranchAddress("tau_jet_emfrac", &tau_jet_emfrac, &b_tau_jet_emfrac);
   fChain->SetBranchAddress("tau_jet_GCWJES", &tau_jet_GCWJES, &b_tau_jet_GCWJES);
   fChain->SetBranchAddress("tau_jet_EMJES", &tau_jet_EMJES, &b_tau_jet_EMJES);
   fChain->SetBranchAddress("tau_jet_emscale_E", &tau_jet_emscale_E, &b_tau_jet_emscale_E);
   fChain->SetBranchAddress("tau_jet_emscale_pt", &tau_jet_emscale_pt, &b_tau_jet_emscale_pt);
   fChain->SetBranchAddress("tau_jet_emscale_m", &tau_jet_emscale_m, &b_tau_jet_emscale_m);
   fChain->SetBranchAddress("tau_jet_emscale_eta", &tau_jet_emscale_eta, &b_tau_jet_emscale_eta);
   fChain->SetBranchAddress("tau_jet_emscale_phi", &tau_jet_emscale_phi, &b_tau_jet_emscale_phi);
   fChain->SetBranchAddress("tau_jet_flavor_weight_TrackCounting2D", &tau_jet_flavor_weight_TrackCounting2D, &b_tau_jet_flavor_weight_TrackCounting2D);
   fChain->SetBranchAddress("tau_jet_flavor_weight_JetProb", &tau_jet_flavor_weight_JetProb, &b_tau_jet_flavor_weight_JetProb);
   fChain->SetBranchAddress("tau_jet_flavor_weight_IP1D", &tau_jet_flavor_weight_IP1D, &b_tau_jet_flavor_weight_IP1D);
   fChain->SetBranchAddress("tau_jet_flavor_weight_IP2D", &tau_jet_flavor_weight_IP2D, &b_tau_jet_flavor_weight_IP2D);
   fChain->SetBranchAddress("tau_jet_flavor_weight_IP3D", &tau_jet_flavor_weight_IP3D, &b_tau_jet_flavor_weight_IP3D);
   fChain->SetBranchAddress("tau_jet_flavor_weight_SV0", &tau_jet_flavor_weight_SV0, &b_tau_jet_flavor_weight_SV0);
   fChain->SetBranchAddress("tau_jet_flavor_weight_SV1", &tau_jet_flavor_weight_SV1, &b_tau_jet_flavor_weight_SV1);
   fChain->SetBranchAddress("tau_jet_flavor_weight_SV2", &tau_jet_flavor_weight_SV2, &b_tau_jet_flavor_weight_SV2);
   fChain->SetBranchAddress("tau_jet_flavor_weight_JetFitterTag", &tau_jet_flavor_weight_JetFitterTag, &b_tau_jet_flavor_weight_JetFitterTag);
   fChain->SetBranchAddress("tau_jet_flavor_weight_JetFitterCOMB", &tau_jet_flavor_weight_JetFitterCOMB, &b_tau_jet_flavor_weight_JetFitterCOMB);
   fChain->SetBranchAddress("tau_jet_flavor_weight_JetFitterTagNN", &tau_jet_flavor_weight_JetFitterTagNN, &b_tau_jet_flavor_weight_JetFitterTagNN);
   fChain->SetBranchAddress("tau_jet_flavor_weight_JetFitterCOMBNN", &tau_jet_flavor_weight_JetFitterCOMBNN, &b_tau_jet_flavor_weight_JetFitterCOMBNN);
   fChain->SetBranchAddress("tau_jet_flavor_weight_SoftMuonTag", &tau_jet_flavor_weight_SoftMuonTag, &b_tau_jet_flavor_weight_SoftMuonTag);
   fChain->SetBranchAddress("tau_jet_flavor_weight_SoftElectronTag", &tau_jet_flavor_weight_SoftElectronTag, &b_tau_jet_flavor_weight_SoftElectronTag);
   fChain->SetBranchAddress("tau_jet_flavor_weight_IP3DSV1", &tau_jet_flavor_weight_IP3DSV1, &b_tau_jet_flavor_weight_IP3DSV1);
   fChain->SetBranchAddress("tau_seedCalo_track_n", &tau_seedCalo_track_n, &b_tau_seedCalo_track_n);
   fChain->SetBranchAddress("tau_seedCalo_wideTrk_n", &tau_seedCalo_wideTrk_n, &b_tau_seedCalo_wideTrk_n);
   fChain->SetBranchAddress("tau_otherTrk_n", &tau_otherTrk_n, &b_tau_otherTrk_n);
   fChain->SetBranchAddress("tau_EF_dr", &tau_EF_dr, &b_tau_EF_dr);
   fChain->SetBranchAddress("tau_EF_E", &tau_EF_E, &b_tau_EF_E);
   fChain->SetBranchAddress("tau_EF_Et", &tau_EF_Et, &b_tau_EF_Et);
   fChain->SetBranchAddress("tau_EF_pt", &tau_EF_pt, &b_tau_EF_pt);
   fChain->SetBranchAddress("tau_EF_eta", &tau_EF_eta, &b_tau_EF_eta);
   fChain->SetBranchAddress("tau_EF_phi", &tau_EF_phi, &b_tau_EF_phi);
   fChain->SetBranchAddress("tau_EF_matched", &tau_EF_matched, &b_tau_EF_matched);
   fChain->SetBranchAddress("tau_L2_dr", &tau_L2_dr, &b_tau_L2_dr);
   fChain->SetBranchAddress("tau_L2_E", &tau_L2_E, &b_tau_L2_E);
   fChain->SetBranchAddress("tau_L2_Et", &tau_L2_Et, &b_tau_L2_Et);
   fChain->SetBranchAddress("tau_L2_pt", &tau_L2_pt, &b_tau_L2_pt);
   fChain->SetBranchAddress("tau_L2_eta", &tau_L2_eta, &b_tau_L2_eta);
   fChain->SetBranchAddress("tau_L2_phi", &tau_L2_phi, &b_tau_L2_phi);
   fChain->SetBranchAddress("tau_L2_matched", &tau_L2_matched, &b_tau_L2_matched);
   fChain->SetBranchAddress("tau_L1_dr", &tau_L1_dr, &b_tau_L1_dr);
   fChain->SetBranchAddress("tau_L1_Et", &tau_L1_Et, &b_tau_L1_Et);
   fChain->SetBranchAddress("tau_L1_pt", &tau_L1_pt, &b_tau_L1_pt);
   fChain->SetBranchAddress("tau_L1_eta", &tau_L1_eta, &b_tau_L1_eta);
   fChain->SetBranchAddress("tau_L1_phi", &tau_L1_phi, &b_tau_L1_phi);
   fChain->SetBranchAddress("tau_L1_matched", &tau_L1_matched, &b_tau_L1_matched);
   fChain->SetBranchAddress("trk_n", &trk_n, &b_trk_n);
   fChain->SetBranchAddress("trk_pt", &trk_pt, &b_trk_pt);
   fChain->SetBranchAddress("trk_eta", &trk_eta, &b_trk_eta);
   fChain->SetBranchAddress("trk_d0_wrtPV", &trk_d0_wrtPV, &b_trk_d0_wrtPV);
   fChain->SetBranchAddress("trk_z0_wrtPV", &trk_z0_wrtPV, &b_trk_z0_wrtPV);
   fChain->SetBranchAddress("trk_phi_wrtPV", &trk_phi_wrtPV, &b_trk_phi_wrtPV);
   fChain->SetBranchAddress("trk_theta_wrtPV", &trk_theta_wrtPV, &b_trk_theta_wrtPV);
   fChain->SetBranchAddress("trk_qoverp_wrtPV", &trk_qoverp_wrtPV, &b_trk_qoverp_wrtPV);
   fChain->SetBranchAddress("trk_err_d0_wrtPV", &trk_err_d0_wrtPV, &b_trk_err_d0_wrtPV);
   fChain->SetBranchAddress("trk_err_z0_wrtPV", &trk_err_z0_wrtPV, &b_trk_err_z0_wrtPV);
   fChain->SetBranchAddress("trk_err_phi_wrtPV", &trk_err_phi_wrtPV, &b_trk_err_phi_wrtPV);
   fChain->SetBranchAddress("trk_err_theta_wrtPV", &trk_err_theta_wrtPV, &b_trk_err_theta_wrtPV);
   fChain->SetBranchAddress("trk_err_qoverp_wrtPV", &trk_err_qoverp_wrtPV, &b_trk_err_qoverp_wrtPV);
   fChain->SetBranchAddress("trk_chi2", &trk_chi2, &b_trk_chi2);
   fChain->SetBranchAddress("trk_ndof", &trk_ndof, &b_trk_ndof);
   fChain->SetBranchAddress("trk_nBLHits", &trk_nBLHits, &b_trk_nBLHits);
   fChain->SetBranchAddress("trk_nPixHits", &trk_nPixHits, &b_trk_nPixHits);
   fChain->SetBranchAddress("trk_nSCTHits", &trk_nSCTHits, &b_trk_nSCTHits);
   fChain->SetBranchAddress("trk_nTRTHits", &trk_nTRTHits, &b_trk_nTRTHits);
   fChain->SetBranchAddress("trk_nTRTHighTHits", &trk_nTRTHighTHits, &b_trk_nTRTHighTHits);
   fChain->SetBranchAddress("trk_nPixHoles", &trk_nPixHoles, &b_trk_nPixHoles);
   fChain->SetBranchAddress("trk_nSCTHoles", &trk_nSCTHoles, &b_trk_nSCTHoles);
   fChain->SetBranchAddress("trk_nTRTHoles", &trk_nTRTHoles, &b_trk_nTRTHoles);
   fChain->SetBranchAddress("trk_nBLayerOutliers", &trk_nBLayerOutliers, &b_trk_nBLayerOutliers);
   fChain->SetBranchAddress("trk_nPixelOutliers", &trk_nPixelOutliers, &b_trk_nPixelOutliers);
   fChain->SetBranchAddress("trk_nSCTOutliers", &trk_nSCTOutliers, &b_trk_nSCTOutliers);
   fChain->SetBranchAddress("trk_nTRTOutliers", &trk_nTRTOutliers, &b_trk_nTRTOutliers);
   fChain->SetBranchAddress("trk_nTRTHighTOutliers", &trk_nTRTHighTOutliers, &b_trk_nTRTHighTOutliers);
   fChain->SetBranchAddress("trk_nContribPixelLayers", &trk_nContribPixelLayers, &b_trk_nContribPixelLayers);
   fChain->SetBranchAddress("trk_nGangedPixels", &trk_nGangedPixels, &b_trk_nGangedPixels);
   fChain->SetBranchAddress("trk_nGangedFlaggedFakes", &trk_nGangedFlaggedFakes, &b_trk_nGangedFlaggedFakes);
   fChain->SetBranchAddress("trk_nPixelDeadSensors", &trk_nPixelDeadSensors, &b_trk_nPixelDeadSensors);
   fChain->SetBranchAddress("trk_nPixelSpoiltHits", &trk_nPixelSpoiltHits, &b_trk_nPixelSpoiltHits);
   fChain->SetBranchAddress("trk_nSCTDoubleHoles", &trk_nSCTDoubleHoles, &b_trk_nSCTDoubleHoles);
   fChain->SetBranchAddress("trk_nSCTDeadSensors", &trk_nSCTDeadSensors, &b_trk_nSCTDeadSensors);
   fChain->SetBranchAddress("trk_nSCTSpoiltHits", &trk_nSCTSpoiltHits, &b_trk_nSCTSpoiltHits);
   fChain->SetBranchAddress("trk_nTRTDeadStraws", &trk_nTRTDeadStraws, &b_trk_nTRTDeadStraws);
   fChain->SetBranchAddress("trk_nTRTTubeHits", &trk_nTRTTubeHits, &b_trk_nTRTTubeHits);
   fChain->SetBranchAddress("trk_expectBLayerHit", &trk_expectBLayerHit, &b_trk_expectBLayerHit);
   fChain->SetBranchAddress("trk_20_trackIso", &trk_20_trackIso, &b_trk_20_trackIso);
   fChain->SetBranchAddress("trk_20_caloIso", &trk_20_caloIso, &b_trk_20_caloIso);
   fChain->SetBranchAddress("trk_20_nTrackIso", &trk_20_nTrackIso, &b_trk_20_nTrackIso);
   fChain->SetBranchAddress("trk_30_trackIso", &trk_30_trackIso, &b_trk_30_trackIso);
   fChain->SetBranchAddress("trk_30_caloIso", &trk_30_caloIso, &b_trk_30_caloIso);
   fChain->SetBranchAddress("trk_30_nTrackIso", &trk_30_nTrackIso, &b_trk_30_nTrackIso);
   fChain->SetBranchAddress("trk_40_trackIso", &trk_40_trackIso, &b_trk_40_trackIso);
   fChain->SetBranchAddress("trk_40_caloIso", &trk_40_caloIso, &b_trk_40_caloIso);
   fChain->SetBranchAddress("trk_40_nTrackIso", &trk_40_nTrackIso, &b_trk_40_nTrackIso);
   fChain->SetBranchAddress("jet_antiKtZ4Track_n", &jet_antiKtZ4Track_n, &b_jet_antiKtZ4Track_n);
   fChain->SetBranchAddress("jet_antiKtZ4Track_E", &jet_antiKtZ4Track_E, &b_jet_antiKtZ4Track_E);
   fChain->SetBranchAddress("jet_antiKtZ4Track_pt", &jet_antiKtZ4Track_pt, &b_jet_antiKtZ4Track_pt);
   fChain->SetBranchAddress("jet_antiKtZ4Track_m", &jet_antiKtZ4Track_m, &b_jet_antiKtZ4Track_m);
   fChain->SetBranchAddress("jet_antiKtZ4Track_eta", &jet_antiKtZ4Track_eta, &b_jet_antiKtZ4Track_eta);
   fChain->SetBranchAddress("jet_antiKtZ4Track_phi", &jet_antiKtZ4Track_phi, &b_jet_antiKtZ4Track_phi);
   fChain->SetBranchAddress("jet_antiKtZ4Track_EtaOrigin", &jet_antiKtZ4Track_EtaOrigin, &b_jet_antiKtZ4Track_EtaOrigin);
   fChain->SetBranchAddress("jet_antiKtZ4Track_PhiOrigin", &jet_antiKtZ4Track_PhiOrigin, &b_jet_antiKtZ4Track_PhiOrigin);
   fChain->SetBranchAddress("jet_antiKtZ4Track_MOrigin", &jet_antiKtZ4Track_MOrigin, &b_jet_antiKtZ4Track_MOrigin);
   fChain->SetBranchAddress("jet_antiKtZ4Track_EtaOriginEM", &jet_antiKtZ4Track_EtaOriginEM, &b_jet_antiKtZ4Track_EtaOriginEM);
   fChain->SetBranchAddress("jet_antiKtZ4Track_PhiOriginEM", &jet_antiKtZ4Track_PhiOriginEM, &b_jet_antiKtZ4Track_PhiOriginEM);
   fChain->SetBranchAddress("jet_antiKtZ4Track_MOriginEM", &jet_antiKtZ4Track_MOriginEM, &b_jet_antiKtZ4Track_MOriginEM);
   fChain->SetBranchAddress("jet_antiKtZ4Track_WIDTH", &jet_antiKtZ4Track_WIDTH, &b_jet_antiKtZ4Track_WIDTH);
   fChain->SetBranchAddress("jet_antiKtZ4Track_n90", &jet_antiKtZ4Track_n90, &b_jet_antiKtZ4Track_n90);
   fChain->SetBranchAddress("jet_antiKtZ4Track_Timing", &jet_antiKtZ4Track_Timing, &b_jet_antiKtZ4Track_Timing);
   fChain->SetBranchAddress("jet_antiKtZ4Track_LArQuality", &jet_antiKtZ4Track_LArQuality, &b_jet_antiKtZ4Track_LArQuality);
   fChain->SetBranchAddress("jet_antiKtZ4Track_nTrk", &jet_antiKtZ4Track_nTrk, &b_jet_antiKtZ4Track_nTrk);
   fChain->SetBranchAddress("jet_antiKtZ4Track_sumPtTrk", &jet_antiKtZ4Track_sumPtTrk, &b_jet_antiKtZ4Track_sumPtTrk);
   fChain->SetBranchAddress("jet_antiKtZ4Track_OriginIndex", &jet_antiKtZ4Track_OriginIndex, &b_jet_antiKtZ4Track_OriginIndex);
   fChain->SetBranchAddress("jet_antiKtZ4Track_HECQuality", &jet_antiKtZ4Track_HECQuality, &b_jet_antiKtZ4Track_HECQuality);
   fChain->SetBranchAddress("jet_antiKtZ4Track_NegativeE", &jet_antiKtZ4Track_NegativeE, &b_jet_antiKtZ4Track_NegativeE);
   fChain->SetBranchAddress("jet_antiKtZ4Track_AverageLArQF", &jet_antiKtZ4Track_AverageLArQF, &b_jet_antiKtZ4Track_AverageLArQF);
   fChain->SetBranchAddress("jet_antiKtZ4Track_YFlip12", &jet_antiKtZ4Track_YFlip12, &b_jet_antiKtZ4Track_YFlip12);
   fChain->SetBranchAddress("jet_antiKtZ4Track_YFlip23", &jet_antiKtZ4Track_YFlip23, &b_jet_antiKtZ4Track_YFlip23);
   fChain->SetBranchAddress("jet_antiKtZ4Track_BCH_CORR_CELL", &jet_antiKtZ4Track_BCH_CORR_CELL, &b_jet_antiKtZ4Track_BCH_CORR_CELL);
   fChain->SetBranchAddress("jet_antiKtZ4Track_BCH_CORR_DOTX", &jet_antiKtZ4Track_BCH_CORR_DOTX, &b_jet_antiKtZ4Track_BCH_CORR_DOTX);
   fChain->SetBranchAddress("jet_antiKtZ4Track_BCH_CORR_JET", &jet_antiKtZ4Track_BCH_CORR_JET, &b_jet_antiKtZ4Track_BCH_CORR_JET);
   fChain->SetBranchAddress("jet_antiKtZ4Track_BCH_CORR_JET_FORCELL", &jet_antiKtZ4Track_BCH_CORR_JET_FORCELL, &b_jet_antiKtZ4Track_BCH_CORR_JET_FORCELL);
   fChain->SetBranchAddress("jet_antiKtZ4Track_ENG_BAD_CELLS", &jet_antiKtZ4Track_ENG_BAD_CELLS, &b_jet_antiKtZ4Track_ENG_BAD_CELLS);
   fChain->SetBranchAddress("jet_antiKtZ4Track_N_BAD_CELLS", &jet_antiKtZ4Track_N_BAD_CELLS, &b_jet_antiKtZ4Track_N_BAD_CELLS);
   fChain->SetBranchAddress("jet_antiKtZ4Track_N_BAD_CELLS_CORR", &jet_antiKtZ4Track_N_BAD_CELLS_CORR, &b_jet_antiKtZ4Track_N_BAD_CELLS_CORR);
   fChain->SetBranchAddress("jet_antiKtZ4Track_BAD_CELLS_CORR_E", &jet_antiKtZ4Track_BAD_CELLS_CORR_E, &b_jet_antiKtZ4Track_BAD_CELLS_CORR_E);
   fChain->SetBranchAddress("jet_antiKtZ4Track_NumTowers", &jet_antiKtZ4Track_NumTowers, &b_jet_antiKtZ4Track_NumTowers);
   fChain->SetBranchAddress("jet_antiKtZ4Track_SamplingMax", &jet_antiKtZ4Track_SamplingMax, &b_jet_antiKtZ4Track_SamplingMax);
   fChain->SetBranchAddress("jet_antiKtZ4Track_fracSamplingMax", &jet_antiKtZ4Track_fracSamplingMax, &b_jet_antiKtZ4Track_fracSamplingMax);
   fChain->SetBranchAddress("jet_antiKtZ4Track_hecf", &jet_antiKtZ4Track_hecf, &b_jet_antiKtZ4Track_hecf);
   fChain->SetBranchAddress("jet_antiKtZ4Track_tgap3f", &jet_antiKtZ4Track_tgap3f, &b_jet_antiKtZ4Track_tgap3f);
   fChain->SetBranchAddress("jet_antiKtZ4Track_isUgly", &jet_antiKtZ4Track_isUgly, &b_jet_antiKtZ4Track_isUgly);
   fChain->SetBranchAddress("jet_antiKtZ4Track_isBadLoose", &jet_antiKtZ4Track_isBadLoose, &b_jet_antiKtZ4Track_isBadLoose);
   fChain->SetBranchAddress("jet_antiKtZ4Track_isBadMedium", &jet_antiKtZ4Track_isBadMedium, &b_jet_antiKtZ4Track_isBadMedium);
   fChain->SetBranchAddress("jet_antiKtZ4Track_isBadTight", &jet_antiKtZ4Track_isBadTight, &b_jet_antiKtZ4Track_isBadTight);
   fChain->SetBranchAddress("jet_antiKtZ4Track_emfrac", &jet_antiKtZ4Track_emfrac, &b_jet_antiKtZ4Track_emfrac);
   fChain->SetBranchAddress("jet_antiKtZ4Track_Offset", &jet_antiKtZ4Track_Offset, &b_jet_antiKtZ4Track_Offset);
   fChain->SetBranchAddress("jet_antiKtZ4Track_EMJES", &jet_antiKtZ4Track_EMJES, &b_jet_antiKtZ4Track_EMJES);
   fChain->SetBranchAddress("jet_antiKtZ4Track_EMJES_EtaCorr", &jet_antiKtZ4Track_EMJES_EtaCorr, &b_jet_antiKtZ4Track_EMJES_EtaCorr);
   fChain->SetBranchAddress("jet_antiKtZ4Track_EMJESnooffset", &jet_antiKtZ4Track_EMJESnooffset, &b_jet_antiKtZ4Track_EMJESnooffset);
   fChain->SetBranchAddress("jet_antiKtZ4Track_GCWJES", &jet_antiKtZ4Track_GCWJES, &b_jet_antiKtZ4Track_GCWJES);
   fChain->SetBranchAddress("jet_antiKtZ4Track_GCWJES_EtaCorr", &jet_antiKtZ4Track_GCWJES_EtaCorr, &b_jet_antiKtZ4Track_GCWJES_EtaCorr);
   fChain->SetBranchAddress("jet_antiKtZ4Track_CB", &jet_antiKtZ4Track_CB, &b_jet_antiKtZ4Track_CB);
   fChain->SetBranchAddress("jet_antiKtZ4Track_LCJES", &jet_antiKtZ4Track_LCJES, &b_jet_antiKtZ4Track_LCJES);
   fChain->SetBranchAddress("jet_antiKtZ4Track_emscale_E", &jet_antiKtZ4Track_emscale_E, &b_jet_antiKtZ4Track_emscale_E);
   fChain->SetBranchAddress("jet_antiKtZ4Track_emscale_pt", &jet_antiKtZ4Track_emscale_pt, &b_jet_antiKtZ4Track_emscale_pt);
   fChain->SetBranchAddress("jet_antiKtZ4Track_emscale_m", &jet_antiKtZ4Track_emscale_m, &b_jet_antiKtZ4Track_emscale_m);
   fChain->SetBranchAddress("jet_antiKtZ4Track_emscale_eta", &jet_antiKtZ4Track_emscale_eta, &b_jet_antiKtZ4Track_emscale_eta);
   fChain->SetBranchAddress("jet_antiKtZ4Track_emscale_phi", &jet_antiKtZ4Track_emscale_phi, &b_jet_antiKtZ4Track_emscale_phi);
   fChain->SetBranchAddress("jet_antiKtZ4Track_jvtx_x", &jet_antiKtZ4Track_jvtx_x, &b_jet_antiKtZ4Track_jvtx_x);
   fChain->SetBranchAddress("jet_antiKtZ4Track_jvtx_y", &jet_antiKtZ4Track_jvtx_y, &b_jet_antiKtZ4Track_jvtx_y);
   fChain->SetBranchAddress("jet_antiKtZ4Track_jvtx_z", &jet_antiKtZ4Track_jvtx_z, &b_jet_antiKtZ4Track_jvtx_z);
   fChain->SetBranchAddress("jet_antiKtZ4Track_jvtxf", &jet_antiKtZ4Track_jvtxf, &b_jet_antiKtZ4Track_jvtxf);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_weight_Comb", &jet_antiKtZ4Track_flavor_weight_Comb, &b_jet_antiKtZ4Track_flavor_weight_Comb);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_weight_IP2D", &jet_antiKtZ4Track_flavor_weight_IP2D, &b_jet_antiKtZ4Track_flavor_weight_IP2D);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_weight_IP3D", &jet_antiKtZ4Track_flavor_weight_IP3D, &b_jet_antiKtZ4Track_flavor_weight_IP3D);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_weight_SV0", &jet_antiKtZ4Track_flavor_weight_SV0, &b_jet_antiKtZ4Track_flavor_weight_SV0);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_weight_SV1", &jet_antiKtZ4Track_flavor_weight_SV1, &b_jet_antiKtZ4Track_flavor_weight_SV1);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_weight_SV2", &jet_antiKtZ4Track_flavor_weight_SV2, &b_jet_antiKtZ4Track_flavor_weight_SV2);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_weight_JetProb", &jet_antiKtZ4Track_flavor_weight_JetProb, &b_jet_antiKtZ4Track_flavor_weight_JetProb);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_weight_SoftMuonTag", &jet_antiKtZ4Track_flavor_weight_SoftMuonTag, &b_jet_antiKtZ4Track_flavor_weight_SoftMuonTag);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_weight_JetFitterTagNN", &jet_antiKtZ4Track_flavor_weight_JetFitterTagNN, &b_jet_antiKtZ4Track_flavor_weight_JetFitterTagNN);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_weight_JetFitterCOMBNN", &jet_antiKtZ4Track_flavor_weight_JetFitterCOMBNN, &b_jet_antiKtZ4Track_flavor_weight_JetFitterCOMBNN);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_weight_GbbNN", &jet_antiKtZ4Track_flavor_weight_GbbNN, &b_jet_antiKtZ4Track_flavor_weight_GbbNN);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_isValid", &jet_antiKtZ4Track_flavor_component_svp_isValid, &b_jet_antiKtZ4Track_flavor_component_svp_isValid);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_ntrkv", &jet_antiKtZ4Track_flavor_component_svp_ntrkv, &b_jet_antiKtZ4Track_flavor_component_svp_ntrkv);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_ntrkj", &jet_antiKtZ4Track_flavor_component_svp_ntrkj, &b_jet_antiKtZ4Track_flavor_component_svp_ntrkj);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_n2t", &jet_antiKtZ4Track_flavor_component_svp_n2t, &b_jet_antiKtZ4Track_flavor_component_svp_n2t);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_mass", &jet_antiKtZ4Track_flavor_component_svp_mass, &b_jet_antiKtZ4Track_flavor_component_svp_mass);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_efrc", &jet_antiKtZ4Track_flavor_component_svp_efrc, &b_jet_antiKtZ4Track_flavor_component_svp_efrc);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_x", &jet_antiKtZ4Track_flavor_component_svp_x, &b_jet_antiKtZ4Track_flavor_component_svp_x);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_y", &jet_antiKtZ4Track_flavor_component_svp_y, &b_jet_antiKtZ4Track_flavor_component_svp_y);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_z", &jet_antiKtZ4Track_flavor_component_svp_z, &b_jet_antiKtZ4Track_flavor_component_svp_z);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_err_x", &jet_antiKtZ4Track_flavor_component_svp_err_x, &b_jet_antiKtZ4Track_flavor_component_svp_err_x);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_err_y", &jet_antiKtZ4Track_flavor_component_svp_err_y, &b_jet_antiKtZ4Track_flavor_component_svp_err_y);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_err_z", &jet_antiKtZ4Track_flavor_component_svp_err_z, &b_jet_antiKtZ4Track_flavor_component_svp_err_z);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_cov_xy", &jet_antiKtZ4Track_flavor_component_svp_cov_xy, &b_jet_antiKtZ4Track_flavor_component_svp_cov_xy);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_cov_xz", &jet_antiKtZ4Track_flavor_component_svp_cov_xz, &b_jet_antiKtZ4Track_flavor_component_svp_cov_xz);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_cov_yz", &jet_antiKtZ4Track_flavor_component_svp_cov_yz, &b_jet_antiKtZ4Track_flavor_component_svp_cov_yz);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_chi2", &jet_antiKtZ4Track_flavor_component_svp_chi2, &b_jet_antiKtZ4Track_flavor_component_svp_chi2);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_ndof", &jet_antiKtZ4Track_flavor_component_svp_ndof, &b_jet_antiKtZ4Track_flavor_component_svp_ndof);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_svp_ntrk", &jet_antiKtZ4Track_flavor_component_svp_ntrk, &b_jet_antiKtZ4Track_flavor_component_svp_ntrk);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_isValid", &jet_antiKtZ4Track_flavor_component_sv0p_isValid, &b_jet_antiKtZ4Track_flavor_component_sv0p_isValid);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_ntrkv", &jet_antiKtZ4Track_flavor_component_sv0p_ntrkv, &b_jet_antiKtZ4Track_flavor_component_sv0p_ntrkv);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_ntrkj", &jet_antiKtZ4Track_flavor_component_sv0p_ntrkj, &b_jet_antiKtZ4Track_flavor_component_sv0p_ntrkj);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_n2t", &jet_antiKtZ4Track_flavor_component_sv0p_n2t, &b_jet_antiKtZ4Track_flavor_component_sv0p_n2t);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_mass", &jet_antiKtZ4Track_flavor_component_sv0p_mass, &b_jet_antiKtZ4Track_flavor_component_sv0p_mass);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_efrc", &jet_antiKtZ4Track_flavor_component_sv0p_efrc, &b_jet_antiKtZ4Track_flavor_component_sv0p_efrc);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_x", &jet_antiKtZ4Track_flavor_component_sv0p_x, &b_jet_antiKtZ4Track_flavor_component_sv0p_x);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_y", &jet_antiKtZ4Track_flavor_component_sv0p_y, &b_jet_antiKtZ4Track_flavor_component_sv0p_y);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_z", &jet_antiKtZ4Track_flavor_component_sv0p_z, &b_jet_antiKtZ4Track_flavor_component_sv0p_z);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_err_x", &jet_antiKtZ4Track_flavor_component_sv0p_err_x, &b_jet_antiKtZ4Track_flavor_component_sv0p_err_x);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_err_y", &jet_antiKtZ4Track_flavor_component_sv0p_err_y, &b_jet_antiKtZ4Track_flavor_component_sv0p_err_y);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_err_z", &jet_antiKtZ4Track_flavor_component_sv0p_err_z, &b_jet_antiKtZ4Track_flavor_component_sv0p_err_z);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_cov_xy", &jet_antiKtZ4Track_flavor_component_sv0p_cov_xy, &b_jet_antiKtZ4Track_flavor_component_sv0p_cov_xy);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_cov_xz", &jet_antiKtZ4Track_flavor_component_sv0p_cov_xz, &b_jet_antiKtZ4Track_flavor_component_sv0p_cov_xz);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_cov_yz", &jet_antiKtZ4Track_flavor_component_sv0p_cov_yz, &b_jet_antiKtZ4Track_flavor_component_sv0p_cov_yz);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_chi2", &jet_antiKtZ4Track_flavor_component_sv0p_chi2, &b_jet_antiKtZ4Track_flavor_component_sv0p_chi2);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_ndof", &jet_antiKtZ4Track_flavor_component_sv0p_ndof, &b_jet_antiKtZ4Track_flavor_component_sv0p_ndof);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_component_sv0p_ntrk", &jet_antiKtZ4Track_flavor_component_sv0p_ntrk, &b_jet_antiKtZ4Track_flavor_component_sv0p_ntrk);
   fChain->SetBranchAddress("jet_antiKtZ4Track_flavor_assoctrk_index", &jet_antiKtZ4Track_flavor_assoctrk_index, &b_jet_antiKtZ4Track_flavor_assoctrk_index);
   fChain->SetBranchAddress("jet_antiKtZ4Track_el_dr", &jet_antiKtZ4Track_el_dr, &b_jet_antiKtZ4Track_el_dr);
   fChain->SetBranchAddress("jet_antiKtZ4Track_el_matched", &jet_antiKtZ4Track_el_matched, &b_jet_antiKtZ4Track_el_matched);
   fChain->SetBranchAddress("jet_antiKtZ4Track_mu_dr", &jet_antiKtZ4Track_mu_dr, &b_jet_antiKtZ4Track_mu_dr);
   fChain->SetBranchAddress("jet_antiKtZ4Track_mu_matched", &jet_antiKtZ4Track_mu_matched, &b_jet_antiKtZ4Track_mu_matched);
   fChain->SetBranchAddress("jet_antiKtZ4Track_L1_dr", &jet_antiKtZ4Track_L1_dr, &b_jet_antiKtZ4Track_L1_dr);
   fChain->SetBranchAddress("jet_antiKtZ4Track_L1_matched", &jet_antiKtZ4Track_L1_matched, &b_jet_antiKtZ4Track_L1_matched);
   fChain->SetBranchAddress("jet_antiKtZ4Track_L2_dr", &jet_antiKtZ4Track_L2_dr, &b_jet_antiKtZ4Track_L2_dr);
   fChain->SetBranchAddress("jet_antiKtZ4Track_L2_matched", &jet_antiKtZ4Track_L2_matched, &b_jet_antiKtZ4Track_L2_matched);
   fChain->SetBranchAddress("jet_antiKtZ4Track_EF_dr", &jet_antiKtZ4Track_EF_dr, &b_jet_antiKtZ4Track_EF_dr);
   fChain->SetBranchAddress("jet_antiKtZ4Track_EF_matched", &jet_antiKtZ4Track_EF_matched, &b_jet_antiKtZ4Track_EF_matched);
   fChain->SetBranchAddress("jet_n", &jet_n, &b_jet_n);
   fChain->SetBranchAddress("jet_E", &jet_E, &b_jet_E);
   fChain->SetBranchAddress("jet_pt", &jet_pt, &b_jet_pt);
   fChain->SetBranchAddress("jet_m", &jet_m, &b_jet_m);
   fChain->SetBranchAddress("jet_eta", &jet_eta, &b_jet_eta);
   fChain->SetBranchAddress("jet_phi", &jet_phi, &b_jet_phi);
   fChain->SetBranchAddress("jet_EtaOrigin", &jet_EtaOrigin, &b_jet_EtaOrigin);
   fChain->SetBranchAddress("jet_PhiOrigin", &jet_PhiOrigin, &b_jet_PhiOrigin);
   fChain->SetBranchAddress("jet_MOrigin", &jet_MOrigin, &b_jet_MOrigin);
   fChain->SetBranchAddress("jet_EtaOriginEM", &jet_EtaOriginEM, &b_jet_EtaOriginEM);
   fChain->SetBranchAddress("jet_PhiOriginEM", &jet_PhiOriginEM, &b_jet_PhiOriginEM);
   fChain->SetBranchAddress("jet_MOriginEM", &jet_MOriginEM, &b_jet_MOriginEM);
   fChain->SetBranchAddress("jet_WIDTH", &jet_WIDTH, &b_jet_WIDTH);
   fChain->SetBranchAddress("jet_n90", &jet_n90, &b_jet_n90);
   fChain->SetBranchAddress("jet_Timing", &jet_Timing, &b_jet_Timing);
   fChain->SetBranchAddress("jet_LArQuality", &jet_LArQuality, &b_jet_LArQuality);
   fChain->SetBranchAddress("jet_nTrk", &jet_nTrk, &b_jet_nTrk);
   fChain->SetBranchAddress("jet_sumPtTrk", &jet_sumPtTrk, &b_jet_sumPtTrk);
   fChain->SetBranchAddress("jet_OriginIndex", &jet_OriginIndex, &b_jet_OriginIndex);
   fChain->SetBranchAddress("jet_HECQuality", &jet_HECQuality, &b_jet_HECQuality);
   fChain->SetBranchAddress("jet_NegativeE", &jet_NegativeE, &b_jet_NegativeE);
   fChain->SetBranchAddress("jet_AverageLArQF", &jet_AverageLArQF, &b_jet_AverageLArQF);
   fChain->SetBranchAddress("jet_YFlip12", &jet_YFlip12, &b_jet_YFlip12);
   fChain->SetBranchAddress("jet_YFlip23", &jet_YFlip23, &b_jet_YFlip23);
   fChain->SetBranchAddress("jet_BCH_CORR_CELL", &jet_BCH_CORR_CELL, &b_jet_BCH_CORR_CELL);
   fChain->SetBranchAddress("jet_BCH_CORR_DOTX", &jet_BCH_CORR_DOTX, &b_jet_BCH_CORR_DOTX);
   fChain->SetBranchAddress("jet_BCH_CORR_JET", &jet_BCH_CORR_JET, &b_jet_BCH_CORR_JET);
   fChain->SetBranchAddress("jet_BCH_CORR_JET_FORCELL", &jet_BCH_CORR_JET_FORCELL, &b_jet_BCH_CORR_JET_FORCELL);
   fChain->SetBranchAddress("jet_ENG_BAD_CELLS", &jet_ENG_BAD_CELLS, &b_jet_ENG_BAD_CELLS);
   fChain->SetBranchAddress("jet_N_BAD_CELLS", &jet_N_BAD_CELLS, &b_jet_N_BAD_CELLS);
   fChain->SetBranchAddress("jet_N_BAD_CELLS_CORR", &jet_N_BAD_CELLS_CORR, &b_jet_N_BAD_CELLS_CORR);
   fChain->SetBranchAddress("jet_BAD_CELLS_CORR_E", &jet_BAD_CELLS_CORR_E, &b_jet_BAD_CELLS_CORR_E);
   fChain->SetBranchAddress("jet_NumTowers", &jet_NumTowers, &b_jet_NumTowers);
   fChain->SetBranchAddress("jet_SamplingMax", &jet_SamplingMax, &b_jet_SamplingMax);
   fChain->SetBranchAddress("jet_fracSamplingMax", &jet_fracSamplingMax, &b_jet_fracSamplingMax);
   fChain->SetBranchAddress("jet_hecf", &jet_hecf, &b_jet_hecf);
   fChain->SetBranchAddress("jet_tgap3f", &jet_tgap3f, &b_jet_tgap3f);
   fChain->SetBranchAddress("jet_isUgly", &jet_isUgly, &b_jet_isUgly);
   fChain->SetBranchAddress("jet_isBadLoose", &jet_isBadLoose, &b_jet_isBadLoose);
   fChain->SetBranchAddress("jet_isBadMedium", &jet_isBadMedium, &b_jet_isBadMedium);
   fChain->SetBranchAddress("jet_isBadTight", &jet_isBadTight, &b_jet_isBadTight);
   fChain->SetBranchAddress("jet_emfrac", &jet_emfrac, &b_jet_emfrac);
   fChain->SetBranchAddress("jet_Offset", &jet_Offset, &b_jet_Offset);
   fChain->SetBranchAddress("jet_EMJES", &jet_EMJES, &b_jet_EMJES);
   fChain->SetBranchAddress("jet_EMJES_EtaCorr", &jet_EMJES_EtaCorr, &b_jet_EMJES_EtaCorr);
   fChain->SetBranchAddress("jet_EMJESnooffset", &jet_EMJESnooffset, &b_jet_EMJESnooffset);
   fChain->SetBranchAddress("jet_GCWJES", &jet_GCWJES, &b_jet_GCWJES);
   fChain->SetBranchAddress("jet_GCWJES_EtaCorr", &jet_GCWJES_EtaCorr, &b_jet_GCWJES_EtaCorr);
   fChain->SetBranchAddress("jet_CB", &jet_CB, &b_jet_CB);
   fChain->SetBranchAddress("jet_LCJES", &jet_LCJES, &b_jet_LCJES);
   fChain->SetBranchAddress("jet_emscale_E", &jet_emscale_E, &b_jet_emscale_E);
   fChain->SetBranchAddress("jet_emscale_pt", &jet_emscale_pt, &b_jet_emscale_pt);
   fChain->SetBranchAddress("jet_emscale_m", &jet_emscale_m, &b_jet_emscale_m);
   fChain->SetBranchAddress("jet_emscale_eta", &jet_emscale_eta, &b_jet_emscale_eta);
   fChain->SetBranchAddress("jet_emscale_phi", &jet_emscale_phi, &b_jet_emscale_phi);
   fChain->SetBranchAddress("jet_jvtx_x", &jet_jvtx_x, &b_jet_jvtx_x);
   fChain->SetBranchAddress("jet_jvtx_y", &jet_jvtx_y, &b_jet_jvtx_y);
   fChain->SetBranchAddress("jet_jvtx_z", &jet_jvtx_z, &b_jet_jvtx_z);
   fChain->SetBranchAddress("jet_jvtxf", &jet_jvtxf, &b_jet_jvtxf);
   fChain->SetBranchAddress("jet_GSCFactorF", &jet_GSCFactorF, &b_jet_GSCFactorF);
   fChain->SetBranchAddress("jet_WidthFraction", &jet_WidthFraction, &b_jet_WidthFraction);
   fChain->SetBranchAddress("jet_e_PreSamplerB", &jet_e_PreSamplerB, &b_jet_e_PreSamplerB);
   fChain->SetBranchAddress("jet_e_EMB1", &jet_e_EMB1, &b_jet_e_EMB1);
   fChain->SetBranchAddress("jet_e_EMB2", &jet_e_EMB2, &b_jet_e_EMB2);
   fChain->SetBranchAddress("jet_e_EMB3", &jet_e_EMB3, &b_jet_e_EMB3);
   fChain->SetBranchAddress("jet_e_PreSamplerE", &jet_e_PreSamplerE, &b_jet_e_PreSamplerE);
   fChain->SetBranchAddress("jet_e_EME1", &jet_e_EME1, &b_jet_e_EME1);
   fChain->SetBranchAddress("jet_e_EME2", &jet_e_EME2, &b_jet_e_EME2);
   fChain->SetBranchAddress("jet_e_EME3", &jet_e_EME3, &b_jet_e_EME3);
   fChain->SetBranchAddress("jet_e_HEC0", &jet_e_HEC0, &b_jet_e_HEC0);
   fChain->SetBranchAddress("jet_e_HEC1", &jet_e_HEC1, &b_jet_e_HEC1);
   fChain->SetBranchAddress("jet_e_HEC2", &jet_e_HEC2, &b_jet_e_HEC2);
   fChain->SetBranchAddress("jet_e_HEC3", &jet_e_HEC3, &b_jet_e_HEC3);
   fChain->SetBranchAddress("jet_e_TileBar0", &jet_e_TileBar0, &b_jet_e_TileBar0);
   fChain->SetBranchAddress("jet_e_TileBar1", &jet_e_TileBar1, &b_jet_e_TileBar1);
   fChain->SetBranchAddress("jet_e_TileBar2", &jet_e_TileBar2, &b_jet_e_TileBar2);
   fChain->SetBranchAddress("jet_e_TileGap1", &jet_e_TileGap1, &b_jet_e_TileGap1);
   fChain->SetBranchAddress("jet_e_TileGap2", &jet_e_TileGap2, &b_jet_e_TileGap2);
   fChain->SetBranchAddress("jet_e_TileGap3", &jet_e_TileGap3, &b_jet_e_TileGap3);
   fChain->SetBranchAddress("jet_e_TileExt0", &jet_e_TileExt0, &b_jet_e_TileExt0);
   fChain->SetBranchAddress("jet_e_TileExt1", &jet_e_TileExt1, &b_jet_e_TileExt1);
   fChain->SetBranchAddress("jet_e_TileExt2", &jet_e_TileExt2, &b_jet_e_TileExt2);
   fChain->SetBranchAddress("jet_e_FCAL0", &jet_e_FCAL0, &b_jet_e_FCAL0);
   fChain->SetBranchAddress("jet_e_FCAL1", &jet_e_FCAL1, &b_jet_e_FCAL1);
   fChain->SetBranchAddress("jet_e_FCAL2", &jet_e_FCAL2, &b_jet_e_FCAL2);
   fChain->SetBranchAddress("jet_flavor_weight_Comb", &jet_flavor_weight_Comb, &b_jet_flavor_weight_Comb);
   fChain->SetBranchAddress("jet_flavor_weight_IP2D", &jet_flavor_weight_IP2D, &b_jet_flavor_weight_IP2D);
   fChain->SetBranchAddress("jet_flavor_weight_IP3D", &jet_flavor_weight_IP3D, &b_jet_flavor_weight_IP3D);
   fChain->SetBranchAddress("jet_flavor_weight_SV0", &jet_flavor_weight_SV0, &b_jet_flavor_weight_SV0);
   fChain->SetBranchAddress("jet_flavor_weight_SV1", &jet_flavor_weight_SV1, &b_jet_flavor_weight_SV1);
   fChain->SetBranchAddress("jet_flavor_weight_SV2", &jet_flavor_weight_SV2, &b_jet_flavor_weight_SV2);
   fChain->SetBranchAddress("jet_flavor_weight_JetProb", &jet_flavor_weight_JetProb, &b_jet_flavor_weight_JetProb);
   fChain->SetBranchAddress("jet_flavor_weight_SoftMuonTag", &jet_flavor_weight_SoftMuonTag, &b_jet_flavor_weight_SoftMuonTag);
   fChain->SetBranchAddress("jet_flavor_weight_JetFitterTagNN", &jet_flavor_weight_JetFitterTagNN, &b_jet_flavor_weight_JetFitterTagNN);
   fChain->SetBranchAddress("jet_flavor_weight_JetFitterCOMBNN", &jet_flavor_weight_JetFitterCOMBNN, &b_jet_flavor_weight_JetFitterCOMBNN);
   fChain->SetBranchAddress("jet_flavor_weight_GbbNN", &jet_flavor_weight_GbbNN, &b_jet_flavor_weight_GbbNN);
   fChain->SetBranchAddress("jet_flavor_component_svp_isValid", &jet_flavor_component_svp_isValid, &b_jet_flavor_component_svp_isValid);
   fChain->SetBranchAddress("jet_flavor_component_svp_ntrkv", &jet_flavor_component_svp_ntrkv, &b_jet_flavor_component_svp_ntrkv);
   fChain->SetBranchAddress("jet_flavor_component_svp_ntrkj", &jet_flavor_component_svp_ntrkj, &b_jet_flavor_component_svp_ntrkj);
   fChain->SetBranchAddress("jet_flavor_component_svp_n2t", &jet_flavor_component_svp_n2t, &b_jet_flavor_component_svp_n2t);
   fChain->SetBranchAddress("jet_flavor_component_svp_mass", &jet_flavor_component_svp_mass, &b_jet_flavor_component_svp_mass);
   fChain->SetBranchAddress("jet_flavor_component_svp_efrc", &jet_flavor_component_svp_efrc, &b_jet_flavor_component_svp_efrc);
   fChain->SetBranchAddress("jet_flavor_component_svp_x", &jet_flavor_component_svp_x, &b_jet_flavor_component_svp_x);
   fChain->SetBranchAddress("jet_flavor_component_svp_y", &jet_flavor_component_svp_y, &b_jet_flavor_component_svp_y);
   fChain->SetBranchAddress("jet_flavor_component_svp_z", &jet_flavor_component_svp_z, &b_jet_flavor_component_svp_z);
   fChain->SetBranchAddress("jet_flavor_component_svp_err_x", &jet_flavor_component_svp_err_x, &b_jet_flavor_component_svp_err_x);
   fChain->SetBranchAddress("jet_flavor_component_svp_err_y", &jet_flavor_component_svp_err_y, &b_jet_flavor_component_svp_err_y);
   fChain->SetBranchAddress("jet_flavor_component_svp_err_z", &jet_flavor_component_svp_err_z, &b_jet_flavor_component_svp_err_z);
   fChain->SetBranchAddress("jet_flavor_component_svp_cov_xy", &jet_flavor_component_svp_cov_xy, &b_jet_flavor_component_svp_cov_xy);
   fChain->SetBranchAddress("jet_flavor_component_svp_cov_xz", &jet_flavor_component_svp_cov_xz, &b_jet_flavor_component_svp_cov_xz);
   fChain->SetBranchAddress("jet_flavor_component_svp_cov_yz", &jet_flavor_component_svp_cov_yz, &b_jet_flavor_component_svp_cov_yz);
   fChain->SetBranchAddress("jet_flavor_component_svp_chi2", &jet_flavor_component_svp_chi2, &b_jet_flavor_component_svp_chi2);
   fChain->SetBranchAddress("jet_flavor_component_svp_ndof", &jet_flavor_component_svp_ndof, &b_jet_flavor_component_svp_ndof);
   fChain->SetBranchAddress("jet_flavor_component_svp_ntrk", &jet_flavor_component_svp_ntrk, &b_jet_flavor_component_svp_ntrk);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_isValid", &jet_flavor_component_sv0p_isValid, &b_jet_flavor_component_sv0p_isValid);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_ntrkv", &jet_flavor_component_sv0p_ntrkv, &b_jet_flavor_component_sv0p_ntrkv);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_ntrkj", &jet_flavor_component_sv0p_ntrkj, &b_jet_flavor_component_sv0p_ntrkj);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_n2t", &jet_flavor_component_sv0p_n2t, &b_jet_flavor_component_sv0p_n2t);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_mass", &jet_flavor_component_sv0p_mass, &b_jet_flavor_component_sv0p_mass);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_efrc", &jet_flavor_component_sv0p_efrc, &b_jet_flavor_component_sv0p_efrc);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_x", &jet_flavor_component_sv0p_x, &b_jet_flavor_component_sv0p_x);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_y", &jet_flavor_component_sv0p_y, &b_jet_flavor_component_sv0p_y);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_z", &jet_flavor_component_sv0p_z, &b_jet_flavor_component_sv0p_z);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_err_x", &jet_flavor_component_sv0p_err_x, &b_jet_flavor_component_sv0p_err_x);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_err_y", &jet_flavor_component_sv0p_err_y, &b_jet_flavor_component_sv0p_err_y);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_err_z", &jet_flavor_component_sv0p_err_z, &b_jet_flavor_component_sv0p_err_z);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_cov_xy", &jet_flavor_component_sv0p_cov_xy, &b_jet_flavor_component_sv0p_cov_xy);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_cov_xz", &jet_flavor_component_sv0p_cov_xz, &b_jet_flavor_component_sv0p_cov_xz);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_cov_yz", &jet_flavor_component_sv0p_cov_yz, &b_jet_flavor_component_sv0p_cov_yz);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_chi2", &jet_flavor_component_sv0p_chi2, &b_jet_flavor_component_sv0p_chi2);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_ndof", &jet_flavor_component_sv0p_ndof, &b_jet_flavor_component_sv0p_ndof);
   fChain->SetBranchAddress("jet_flavor_component_sv0p_ntrk", &jet_flavor_component_sv0p_ntrk, &b_jet_flavor_component_sv0p_ntrk);
   fChain->SetBranchAddress("jet_flavor_assoctrk_index", &jet_flavor_assoctrk_index, &b_jet_flavor_assoctrk_index);
   fChain->SetBranchAddress("jet_el_dr", &jet_el_dr, &b_jet_el_dr);
   fChain->SetBranchAddress("jet_el_matched", &jet_el_matched, &b_jet_el_matched);
   fChain->SetBranchAddress("jet_mu_dr", &jet_mu_dr, &b_jet_mu_dr);
   fChain->SetBranchAddress("jet_mu_matched", &jet_mu_matched, &b_jet_mu_matched);
   fChain->SetBranchAddress("jet_L1_dr", &jet_L1_dr, &b_jet_L1_dr);
   fChain->SetBranchAddress("jet_L1_matched", &jet_L1_matched, &b_jet_L1_matched);
   fChain->SetBranchAddress("jet_L2_dr", &jet_L2_dr, &b_jet_L2_dr);
   fChain->SetBranchAddress("jet_L2_matched", &jet_L2_matched, &b_jet_L2_matched);
   fChain->SetBranchAddress("jet_EF_dr", &jet_EF_dr, &b_jet_EF_dr);
   fChain->SetBranchAddress("jet_EF_matched", &jet_EF_matched, &b_jet_EF_matched);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_n", &jet_AntiKt4LCTopoJets_n, &b_jet_AntiKt4LCTopoJets_n);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_E", &jet_AntiKt4LCTopoJets_E, &b_jet_AntiKt4LCTopoJets_E);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_pt", &jet_AntiKt4LCTopoJets_pt, &b_jet_AntiKt4LCTopoJets_pt);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_m", &jet_AntiKt4LCTopoJets_m, &b_jet_AntiKt4LCTopoJets_m);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_eta", &jet_AntiKt4LCTopoJets_eta, &b_jet_AntiKt4LCTopoJets_eta);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_phi", &jet_AntiKt4LCTopoJets_phi, &b_jet_AntiKt4LCTopoJets_phi);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_EtaOrigin", &jet_AntiKt4LCTopoJets_EtaOrigin, &b_jet_AntiKt4LCTopoJets_EtaOrigin);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_PhiOrigin", &jet_AntiKt4LCTopoJets_PhiOrigin, &b_jet_AntiKt4LCTopoJets_PhiOrigin);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_MOrigin", &jet_AntiKt4LCTopoJets_MOrigin, &b_jet_AntiKt4LCTopoJets_MOrigin);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_EtaOriginEM", &jet_AntiKt4LCTopoJets_EtaOriginEM, &b_jet_AntiKt4LCTopoJets_EtaOriginEM);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_PhiOriginEM", &jet_AntiKt4LCTopoJets_PhiOriginEM, &b_jet_AntiKt4LCTopoJets_PhiOriginEM);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_MOriginEM", &jet_AntiKt4LCTopoJets_MOriginEM, &b_jet_AntiKt4LCTopoJets_MOriginEM);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_WIDTH", &jet_AntiKt4LCTopoJets_WIDTH, &b_jet_AntiKt4LCTopoJets_WIDTH);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_n90", &jet_AntiKt4LCTopoJets_n90, &b_jet_AntiKt4LCTopoJets_n90);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_Timing", &jet_AntiKt4LCTopoJets_Timing, &b_jet_AntiKt4LCTopoJets_Timing);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_LArQuality", &jet_AntiKt4LCTopoJets_LArQuality, &b_jet_AntiKt4LCTopoJets_LArQuality);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_nTrk", &jet_AntiKt4LCTopoJets_nTrk, &b_jet_AntiKt4LCTopoJets_nTrk);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_sumPtTrk", &jet_AntiKt4LCTopoJets_sumPtTrk, &b_jet_AntiKt4LCTopoJets_sumPtTrk);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_OriginIndex", &jet_AntiKt4LCTopoJets_OriginIndex, &b_jet_AntiKt4LCTopoJets_OriginIndex);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_HECQuality", &jet_AntiKt4LCTopoJets_HECQuality, &b_jet_AntiKt4LCTopoJets_HECQuality);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_NegativeE", &jet_AntiKt4LCTopoJets_NegativeE, &b_jet_AntiKt4LCTopoJets_NegativeE);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_AverageLArQF", &jet_AntiKt4LCTopoJets_AverageLArQF, &b_jet_AntiKt4LCTopoJets_AverageLArQF);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_YFlip12", &jet_AntiKt4LCTopoJets_YFlip12, &b_jet_AntiKt4LCTopoJets_YFlip12);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_YFlip23", &jet_AntiKt4LCTopoJets_YFlip23, &b_jet_AntiKt4LCTopoJets_YFlip23);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_BCH_CORR_CELL", &jet_AntiKt4LCTopoJets_BCH_CORR_CELL, &b_jet_AntiKt4LCTopoJets_BCH_CORR_CELL);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_BCH_CORR_DOTX", &jet_AntiKt4LCTopoJets_BCH_CORR_DOTX, &b_jet_AntiKt4LCTopoJets_BCH_CORR_DOTX);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_BCH_CORR_JET", &jet_AntiKt4LCTopoJets_BCH_CORR_JET, &b_jet_AntiKt4LCTopoJets_BCH_CORR_JET);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_BCH_CORR_JET_FORCELL", &jet_AntiKt4LCTopoJets_BCH_CORR_JET_FORCELL, &b_jet_AntiKt4LCTopoJets_BCH_CORR_JET_FORCELL);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_ENG_BAD_CELLS", &jet_AntiKt4LCTopoJets_ENG_BAD_CELLS, &b_jet_AntiKt4LCTopoJets_ENG_BAD_CELLS);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_N_BAD_CELLS", &jet_AntiKt4LCTopoJets_N_BAD_CELLS, &b_jet_AntiKt4LCTopoJets_N_BAD_CELLS);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_N_BAD_CELLS_CORR", &jet_AntiKt4LCTopoJets_N_BAD_CELLS_CORR, &b_jet_AntiKt4LCTopoJets_N_BAD_CELLS_CORR);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_BAD_CELLS_CORR_E", &jet_AntiKt4LCTopoJets_BAD_CELLS_CORR_E, &b_jet_AntiKt4LCTopoJets_BAD_CELLS_CORR_E);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_NumTowers", &jet_AntiKt4LCTopoJets_NumTowers, &b_jet_AntiKt4LCTopoJets_NumTowers);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_SamplingMax", &jet_AntiKt4LCTopoJets_SamplingMax, &b_jet_AntiKt4LCTopoJets_SamplingMax);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_fracSamplingMax", &jet_AntiKt4LCTopoJets_fracSamplingMax, &b_jet_AntiKt4LCTopoJets_fracSamplingMax);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_hecf", &jet_AntiKt4LCTopoJets_hecf, &b_jet_AntiKt4LCTopoJets_hecf);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_tgap3f", &jet_AntiKt4LCTopoJets_tgap3f, &b_jet_AntiKt4LCTopoJets_tgap3f);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_isUgly", &jet_AntiKt4LCTopoJets_isUgly, &b_jet_AntiKt4LCTopoJets_isUgly);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_isBadLoose", &jet_AntiKt4LCTopoJets_isBadLoose, &b_jet_AntiKt4LCTopoJets_isBadLoose);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_isBadMedium", &jet_AntiKt4LCTopoJets_isBadMedium, &b_jet_AntiKt4LCTopoJets_isBadMedium);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_isBadTight", &jet_AntiKt4LCTopoJets_isBadTight, &b_jet_AntiKt4LCTopoJets_isBadTight);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_emfrac", &jet_AntiKt4LCTopoJets_emfrac, &b_jet_AntiKt4LCTopoJets_emfrac);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_Offset", &jet_AntiKt4LCTopoJets_Offset, &b_jet_AntiKt4LCTopoJets_Offset);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_EMJES", &jet_AntiKt4LCTopoJets_EMJES, &b_jet_AntiKt4LCTopoJets_EMJES);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_EMJES_EtaCorr", &jet_AntiKt4LCTopoJets_EMJES_EtaCorr, &b_jet_AntiKt4LCTopoJets_EMJES_EtaCorr);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_EMJESnooffset", &jet_AntiKt4LCTopoJets_EMJESnooffset, &b_jet_AntiKt4LCTopoJets_EMJESnooffset);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_GCWJES", &jet_AntiKt4LCTopoJets_GCWJES, &b_jet_AntiKt4LCTopoJets_GCWJES);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_GCWJES_EtaCorr", &jet_AntiKt4LCTopoJets_GCWJES_EtaCorr, &b_jet_AntiKt4LCTopoJets_GCWJES_EtaCorr);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_CB", &jet_AntiKt4LCTopoJets_CB, &b_jet_AntiKt4LCTopoJets_CB);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_LCJES", &jet_AntiKt4LCTopoJets_LCJES, &b_jet_AntiKt4LCTopoJets_LCJES);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_emscale_E", &jet_AntiKt4LCTopoJets_emscale_E, &b_jet_AntiKt4LCTopoJets_emscale_E);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_emscale_pt", &jet_AntiKt4LCTopoJets_emscale_pt, &b_jet_AntiKt4LCTopoJets_emscale_pt);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_emscale_m", &jet_AntiKt4LCTopoJets_emscale_m, &b_jet_AntiKt4LCTopoJets_emscale_m);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_emscale_eta", &jet_AntiKt4LCTopoJets_emscale_eta, &b_jet_AntiKt4LCTopoJets_emscale_eta);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_emscale_phi", &jet_AntiKt4LCTopoJets_emscale_phi, &b_jet_AntiKt4LCTopoJets_emscale_phi);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_jvtx_x", &jet_AntiKt4LCTopoJets_jvtx_x, &b_jet_AntiKt4LCTopoJets_jvtx_x);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_jvtx_y", &jet_AntiKt4LCTopoJets_jvtx_y, &b_jet_AntiKt4LCTopoJets_jvtx_y);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_jvtx_z", &jet_AntiKt4LCTopoJets_jvtx_z, &b_jet_AntiKt4LCTopoJets_jvtx_z);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_jvtxf", &jet_AntiKt4LCTopoJets_jvtxf, &b_jet_AntiKt4LCTopoJets_jvtxf);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_GSCFactorF", &jet_AntiKt4LCTopoJets_GSCFactorF, &b_jet_AntiKt4LCTopoJets_GSCFactorF);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_WidthFraction", &jet_AntiKt4LCTopoJets_WidthFraction, &b_jet_AntiKt4LCTopoJets_WidthFraction);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_PreSamplerB", &jet_AntiKt4LCTopoJets_e_PreSamplerB, &b_jet_AntiKt4LCTopoJets_e_PreSamplerB);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_EMB1", &jet_AntiKt4LCTopoJets_e_EMB1, &b_jet_AntiKt4LCTopoJets_e_EMB1);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_EMB2", &jet_AntiKt4LCTopoJets_e_EMB2, &b_jet_AntiKt4LCTopoJets_e_EMB2);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_EMB3", &jet_AntiKt4LCTopoJets_e_EMB3, &b_jet_AntiKt4LCTopoJets_e_EMB3);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_PreSamplerE", &jet_AntiKt4LCTopoJets_e_PreSamplerE, &b_jet_AntiKt4LCTopoJets_e_PreSamplerE);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_EME1", &jet_AntiKt4LCTopoJets_e_EME1, &b_jet_AntiKt4LCTopoJets_e_EME1);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_EME2", &jet_AntiKt4LCTopoJets_e_EME2, &b_jet_AntiKt4LCTopoJets_e_EME2);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_EME3", &jet_AntiKt4LCTopoJets_e_EME3, &b_jet_AntiKt4LCTopoJets_e_EME3);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_HEC0", &jet_AntiKt4LCTopoJets_e_HEC0, &b_jet_AntiKt4LCTopoJets_e_HEC0);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_HEC1", &jet_AntiKt4LCTopoJets_e_HEC1, &b_jet_AntiKt4LCTopoJets_e_HEC1);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_HEC2", &jet_AntiKt4LCTopoJets_e_HEC2, &b_jet_AntiKt4LCTopoJets_e_HEC2);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_HEC3", &jet_AntiKt4LCTopoJets_e_HEC3, &b_jet_AntiKt4LCTopoJets_e_HEC3);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_TileBar0", &jet_AntiKt4LCTopoJets_e_TileBar0, &b_jet_AntiKt4LCTopoJets_e_TileBar0);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_TileBar1", &jet_AntiKt4LCTopoJets_e_TileBar1, &b_jet_AntiKt4LCTopoJets_e_TileBar1);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_TileBar2", &jet_AntiKt4LCTopoJets_e_TileBar2, &b_jet_AntiKt4LCTopoJets_e_TileBar2);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_TileGap1", &jet_AntiKt4LCTopoJets_e_TileGap1, &b_jet_AntiKt4LCTopoJets_e_TileGap1);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_TileGap2", &jet_AntiKt4LCTopoJets_e_TileGap2, &b_jet_AntiKt4LCTopoJets_e_TileGap2);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_TileGap3", &jet_AntiKt4LCTopoJets_e_TileGap3, &b_jet_AntiKt4LCTopoJets_e_TileGap3);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_TileExt0", &jet_AntiKt4LCTopoJets_e_TileExt0, &b_jet_AntiKt4LCTopoJets_e_TileExt0);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_TileExt1", &jet_AntiKt4LCTopoJets_e_TileExt1, &b_jet_AntiKt4LCTopoJets_e_TileExt1);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_TileExt2", &jet_AntiKt4LCTopoJets_e_TileExt2, &b_jet_AntiKt4LCTopoJets_e_TileExt2);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_FCAL0", &jet_AntiKt4LCTopoJets_e_FCAL0, &b_jet_AntiKt4LCTopoJets_e_FCAL0);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_FCAL1", &jet_AntiKt4LCTopoJets_e_FCAL1, &b_jet_AntiKt4LCTopoJets_e_FCAL1);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_e_FCAL2", &jet_AntiKt4LCTopoJets_e_FCAL2, &b_jet_AntiKt4LCTopoJets_e_FCAL2);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_weight_Comb", &jet_AntiKt4LCTopoJets_flavor_weight_Comb, &b_jet_AntiKt4LCTopoJets_flavor_weight_Comb);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_weight_IP2D", &jet_AntiKt4LCTopoJets_flavor_weight_IP2D, &b_jet_AntiKt4LCTopoJets_flavor_weight_IP2D);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_weight_IP3D", &jet_AntiKt4LCTopoJets_flavor_weight_IP3D, &b_jet_AntiKt4LCTopoJets_flavor_weight_IP3D);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_weight_SV0", &jet_AntiKt4LCTopoJets_flavor_weight_SV0, &b_jet_AntiKt4LCTopoJets_flavor_weight_SV0);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_weight_SV1", &jet_AntiKt4LCTopoJets_flavor_weight_SV1, &b_jet_AntiKt4LCTopoJets_flavor_weight_SV1);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_weight_SV2", &jet_AntiKt4LCTopoJets_flavor_weight_SV2, &b_jet_AntiKt4LCTopoJets_flavor_weight_SV2);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_weight_JetProb", &jet_AntiKt4LCTopoJets_flavor_weight_JetProb, &b_jet_AntiKt4LCTopoJets_flavor_weight_JetProb);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_weight_SoftMuonTag", &jet_AntiKt4LCTopoJets_flavor_weight_SoftMuonTag, &b_jet_AntiKt4LCTopoJets_flavor_weight_SoftMuonTag);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_weight_JetFitterTagNN", &jet_AntiKt4LCTopoJets_flavor_weight_JetFitterTagNN, &b_jet_AntiKt4LCTopoJets_flavor_weight_JetFitterTagNN);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_weight_JetFitterCOMBNN", &jet_AntiKt4LCTopoJets_flavor_weight_JetFitterCOMBNN, &b_jet_AntiKt4LCTopoJets_flavor_weight_JetFitterCOMBNN);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_weight_GbbNN", &jet_AntiKt4LCTopoJets_flavor_weight_GbbNN, &b_jet_AntiKt4LCTopoJets_flavor_weight_GbbNN);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_isValid", &jet_AntiKt4LCTopoJets_flavor_component_svp_isValid, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_isValid);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_ntrkv", &jet_AntiKt4LCTopoJets_flavor_component_svp_ntrkv, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_ntrkv);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_ntrkj", &jet_AntiKt4LCTopoJets_flavor_component_svp_ntrkj, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_ntrkj);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_n2t", &jet_AntiKt4LCTopoJets_flavor_component_svp_n2t, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_n2t);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_mass", &jet_AntiKt4LCTopoJets_flavor_component_svp_mass, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_mass);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_efrc", &jet_AntiKt4LCTopoJets_flavor_component_svp_efrc, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_efrc);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_x", &jet_AntiKt4LCTopoJets_flavor_component_svp_x, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_x);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_y", &jet_AntiKt4LCTopoJets_flavor_component_svp_y, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_y);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_z", &jet_AntiKt4LCTopoJets_flavor_component_svp_z, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_z);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_err_x", &jet_AntiKt4LCTopoJets_flavor_component_svp_err_x, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_err_x);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_err_y", &jet_AntiKt4LCTopoJets_flavor_component_svp_err_y, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_err_y);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_err_z", &jet_AntiKt4LCTopoJets_flavor_component_svp_err_z, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_err_z);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_cov_xy", &jet_AntiKt4LCTopoJets_flavor_component_svp_cov_xy, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_cov_xy);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_cov_xz", &jet_AntiKt4LCTopoJets_flavor_component_svp_cov_xz, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_cov_xz);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_cov_yz", &jet_AntiKt4LCTopoJets_flavor_component_svp_cov_yz, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_cov_yz);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_chi2", &jet_AntiKt4LCTopoJets_flavor_component_svp_chi2, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_chi2);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_ndof", &jet_AntiKt4LCTopoJets_flavor_component_svp_ndof, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_ndof);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_svp_ntrk", &jet_AntiKt4LCTopoJets_flavor_component_svp_ntrk, &b_jet_AntiKt4LCTopoJets_flavor_component_svp_ntrk);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_isValid", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_isValid, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_isValid);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrkv", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrkv, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrkv);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrkj", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrkj, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrkj);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_n2t", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_n2t, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_n2t);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_mass", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_mass, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_mass);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_efrc", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_efrc, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_efrc);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_x", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_x, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_x);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_y", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_y, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_y);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_z", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_z, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_z);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_x", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_x, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_x);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_y", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_y, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_y);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_z", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_z, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_err_z);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_xy", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_xy, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_xy);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_xz", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_xz, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_xz);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_yz", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_yz, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_cov_yz);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_chi2", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_chi2, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_chi2);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_ndof", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_ndof, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_ndof);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrk", &jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrk, &b_jet_AntiKt4LCTopoJets_flavor_component_sv0p_ntrk);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_el_dr", &jet_AntiKt4LCTopoJets_el_dr, &b_jet_AntiKt4LCTopoJets_el_dr);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_el_matched", &jet_AntiKt4LCTopoJets_el_matched, &b_jet_AntiKt4LCTopoJets_el_matched);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_mu_dr", &jet_AntiKt4LCTopoJets_mu_dr, &b_jet_AntiKt4LCTopoJets_mu_dr);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_mu_matched", &jet_AntiKt4LCTopoJets_mu_matched, &b_jet_AntiKt4LCTopoJets_mu_matched);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_L1_dr", &jet_AntiKt4LCTopoJets_L1_dr, &b_jet_AntiKt4LCTopoJets_L1_dr);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_L1_matched", &jet_AntiKt4LCTopoJets_L1_matched, &b_jet_AntiKt4LCTopoJets_L1_matched);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_L2_dr", &jet_AntiKt4LCTopoJets_L2_dr, &b_jet_AntiKt4LCTopoJets_L2_dr);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_L2_matched", &jet_AntiKt4LCTopoJets_L2_matched, &b_jet_AntiKt4LCTopoJets_L2_matched);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_EF_dr", &jet_AntiKt4LCTopoJets_EF_dr, &b_jet_AntiKt4LCTopoJets_EF_dr);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_EF_matched", &jet_AntiKt4LCTopoJets_EF_matched, &b_jet_AntiKt4LCTopoJets_EF_matched);
   fChain->SetBranchAddress("vxp_n", &vxp_n, &b_vxp_n);
   fChain->SetBranchAddress("vxp_x", &vxp_x, &b_vxp_x);
   fChain->SetBranchAddress("vxp_y", &vxp_y, &b_vxp_y);
   fChain->SetBranchAddress("vxp_z", &vxp_z, &b_vxp_z);
   fChain->SetBranchAddress("vxp_err_x", &vxp_err_x, &b_vxp_err_x);
   fChain->SetBranchAddress("vxp_err_y", &vxp_err_y, &b_vxp_err_y);
   fChain->SetBranchAddress("vxp_err_z", &vxp_err_z, &b_vxp_err_z);
   fChain->SetBranchAddress("vxp_cov_xy", &vxp_cov_xy, &b_vxp_cov_xy);
   fChain->SetBranchAddress("vxp_cov_xz", &vxp_cov_xz, &b_vxp_cov_xz);
   fChain->SetBranchAddress("vxp_cov_yz", &vxp_cov_yz, &b_vxp_cov_yz);
   fChain->SetBranchAddress("vxp_type", &vxp_type, &b_vxp_type);
   fChain->SetBranchAddress("vxp_chi2", &vxp_chi2, &b_vxp_chi2);
   fChain->SetBranchAddress("vxp_ndof", &vxp_ndof, &b_vxp_ndof);
   fChain->SetBranchAddress("vxp_px", &vxp_px, &b_vxp_px);
   fChain->SetBranchAddress("vxp_py", &vxp_py, &b_vxp_py);
   fChain->SetBranchAddress("vxp_pz", &vxp_pz, &b_vxp_pz);
   fChain->SetBranchAddress("vxp_E", &vxp_E, &b_vxp_E);
   fChain->SetBranchAddress("vxp_m", &vxp_m, &b_vxp_m);
   fChain->SetBranchAddress("vxp_nTracks", &vxp_nTracks, &b_vxp_nTracks);
   fChain->SetBranchAddress("vxp_sumPt", &vxp_sumPt, &b_vxp_sumPt);
   fChain->SetBranchAddress("vxp_trk_n", &vxp_trk_n, &b_vxp_trk_n);
   fChain->SetBranchAddress("vxp_trk_weight", &vxp_trk_weight, &b_vxp_trk_weight);
   fChain->SetBranchAddress("vxp_trk_index", &vxp_trk_index, &b_vxp_trk_index);
   fChain->SetBranchAddress("top_hfor_type", &top_hfor_type, &b_top_hfor_type);
   fChain->SetBranchAddress("MET_RefEle_em_tight_etx", &MET_RefEle_em_tight_etx, &b_MET_RefEle_em_tight_etx);
   fChain->SetBranchAddress("MET_RefEle_em_tight_ety", &MET_RefEle_em_tight_ety, &b_MET_RefEle_em_tight_ety);
   fChain->SetBranchAddress("MET_RefEle_em_tight_phi", &MET_RefEle_em_tight_phi, &b_MET_RefEle_em_tight_phi);
   fChain->SetBranchAddress("MET_RefEle_em_tight_et", &MET_RefEle_em_tight_et, &b_MET_RefEle_em_tight_et);
   fChain->SetBranchAddress("MET_RefEle_em_tight_sumet", &MET_RefEle_em_tight_sumet, &b_MET_RefEle_em_tight_sumet);
   fChain->SetBranchAddress("MET_RefEle_em_medium_etx", &MET_RefEle_em_medium_etx, &b_MET_RefEle_em_medium_etx);
   fChain->SetBranchAddress("MET_RefEle_em_medium_ety", &MET_RefEle_em_medium_ety, &b_MET_RefEle_em_medium_ety);
   fChain->SetBranchAddress("MET_RefEle_em_medium_phi", &MET_RefEle_em_medium_phi, &b_MET_RefEle_em_medium_phi);
   fChain->SetBranchAddress("MET_RefEle_em_medium_et", &MET_RefEle_em_medium_et, &b_MET_RefEle_em_medium_et);
   fChain->SetBranchAddress("MET_RefEle_em_medium_sumet", &MET_RefEle_em_medium_sumet, &b_MET_RefEle_em_medium_sumet);
   fChain->SetBranchAddress("MET_RefEle_em_loose_etx", &MET_RefEle_em_loose_etx, &b_MET_RefEle_em_loose_etx);
   fChain->SetBranchAddress("MET_RefEle_em_loose_ety", &MET_RefEle_em_loose_ety, &b_MET_RefEle_em_loose_ety);
   fChain->SetBranchAddress("MET_RefEle_em_loose_phi", &MET_RefEle_em_loose_phi, &b_MET_RefEle_em_loose_phi);
   fChain->SetBranchAddress("MET_RefEle_em_loose_et", &MET_RefEle_em_loose_et, &b_MET_RefEle_em_loose_et);
   fChain->SetBranchAddress("MET_RefEle_em_loose_sumet", &MET_RefEle_em_loose_sumet, &b_MET_RefEle_em_loose_sumet);
   fChain->SetBranchAddress("MET_RefEle_4lc_tight_etx", &MET_RefEle_4lc_tight_etx, &b_MET_RefEle_4lc_tight_etx);
   fChain->SetBranchAddress("MET_RefEle_4lc_tight_ety", &MET_RefEle_4lc_tight_ety, &b_MET_RefEle_4lc_tight_ety);
   fChain->SetBranchAddress("MET_RefEle_4lc_tight_phi", &MET_RefEle_4lc_tight_phi, &b_MET_RefEle_4lc_tight_phi);
   fChain->SetBranchAddress("MET_RefEle_4lc_tight_et", &MET_RefEle_4lc_tight_et, &b_MET_RefEle_4lc_tight_et);
   fChain->SetBranchAddress("MET_RefEle_4lc_tight_sumet", &MET_RefEle_4lc_tight_sumet, &b_MET_RefEle_4lc_tight_sumet);
   fChain->SetBranchAddress("MET_RefEle_4lc_medium_etx", &MET_RefEle_4lc_medium_etx, &b_MET_RefEle_4lc_medium_etx);
   fChain->SetBranchAddress("MET_RefEle_4lc_medium_ety", &MET_RefEle_4lc_medium_ety, &b_MET_RefEle_4lc_medium_ety);
   fChain->SetBranchAddress("MET_RefEle_4lc_medium_phi", &MET_RefEle_4lc_medium_phi, &b_MET_RefEle_4lc_medium_phi);
   fChain->SetBranchAddress("MET_RefEle_4lc_medium_et", &MET_RefEle_4lc_medium_et, &b_MET_RefEle_4lc_medium_et);
   fChain->SetBranchAddress("MET_RefEle_4lc_medium_sumet", &MET_RefEle_4lc_medium_sumet, &b_MET_RefEle_4lc_medium_sumet);
   fChain->SetBranchAddress("MET_RefEle_4lc_loose_etx", &MET_RefEle_4lc_loose_etx, &b_MET_RefEle_4lc_loose_etx);
   fChain->SetBranchAddress("MET_RefEle_4lc_loose_ety", &MET_RefEle_4lc_loose_ety, &b_MET_RefEle_4lc_loose_ety);
   fChain->SetBranchAddress("MET_RefEle_4lc_loose_phi", &MET_RefEle_4lc_loose_phi, &b_MET_RefEle_4lc_loose_phi);
   fChain->SetBranchAddress("MET_RefEle_4lc_loose_et", &MET_RefEle_4lc_loose_et, &b_MET_RefEle_4lc_loose_et);
   fChain->SetBranchAddress("MET_RefEle_4lc_loose_sumet", &MET_RefEle_4lc_loose_sumet, &b_MET_RefEle_4lc_loose_sumet);
   fChain->SetBranchAddress("MET_RefEle_em_medium_photon_etx", &MET_RefEle_em_medium_photon_etx, &b_MET_RefEle_em_medium_photon_etx);
   fChain->SetBranchAddress("MET_RefEle_em_medium_photon_ety", &MET_RefEle_em_medium_photon_ety, &b_MET_RefEle_em_medium_photon_ety);
   fChain->SetBranchAddress("MET_RefEle_em_medium_photon_phi", &MET_RefEle_em_medium_photon_phi, &b_MET_RefEle_em_medium_photon_phi);
   fChain->SetBranchAddress("MET_RefEle_em_medium_photon_et", &MET_RefEle_em_medium_photon_et, &b_MET_RefEle_em_medium_photon_et);
   fChain->SetBranchAddress("MET_RefEle_em_medium_photon_sumet", &MET_RefEle_em_medium_photon_sumet, &b_MET_RefEle_em_medium_photon_sumet);
   fChain->SetBranchAddress("MET_RefEle_em_tight_photon_etx", &MET_RefEle_em_tight_photon_etx, &b_MET_RefEle_em_tight_photon_etx);
   fChain->SetBranchAddress("MET_RefEle_em_tight_photon_ety", &MET_RefEle_em_tight_photon_ety, &b_MET_RefEle_em_tight_photon_ety);
   fChain->SetBranchAddress("MET_RefEle_em_tight_photon_phi", &MET_RefEle_em_tight_photon_phi, &b_MET_RefEle_em_tight_photon_phi);
   fChain->SetBranchAddress("MET_RefEle_em_tight_photon_et", &MET_RefEle_em_tight_photon_et, &b_MET_RefEle_em_tight_photon_et);
   fChain->SetBranchAddress("MET_RefEle_em_tight_photon_sumet", &MET_RefEle_em_tight_photon_sumet, &b_MET_RefEle_em_tight_photon_sumet);
   fChain->SetBranchAddress("MET_RefEle_4lc_tight_photon_etx", &MET_RefEle_4lc_tight_photon_etx, &b_MET_RefEle_4lc_tight_photon_etx);
   fChain->SetBranchAddress("MET_RefEle_4lc_tight_photon_ety", &MET_RefEle_4lc_tight_photon_ety, &b_MET_RefEle_4lc_tight_photon_ety);
   fChain->SetBranchAddress("MET_RefEle_4lc_tight_photon_phi", &MET_RefEle_4lc_tight_photon_phi, &b_MET_RefEle_4lc_tight_photon_phi);
   fChain->SetBranchAddress("MET_RefEle_4lc_tight_photon_et", &MET_RefEle_4lc_tight_photon_et, &b_MET_RefEle_4lc_tight_photon_et);
   fChain->SetBranchAddress("MET_RefEle_4lc_tight_photon_sumet", &MET_RefEle_4lc_tight_photon_sumet, &b_MET_RefEle_4lc_tight_photon_sumet);
   fChain->SetBranchAddress("MET_RefEle_4lc_medium_photon_etx", &MET_RefEle_4lc_medium_photon_etx, &b_MET_RefEle_4lc_medium_photon_etx);
   fChain->SetBranchAddress("MET_RefEle_4lc_medium_photon_ety", &MET_RefEle_4lc_medium_photon_ety, &b_MET_RefEle_4lc_medium_photon_ety);
   fChain->SetBranchAddress("MET_RefEle_4lc_medium_photon_phi", &MET_RefEle_4lc_medium_photon_phi, &b_MET_RefEle_4lc_medium_photon_phi);
   fChain->SetBranchAddress("MET_RefEle_4lc_medium_photon_et", &MET_RefEle_4lc_medium_photon_et, &b_MET_RefEle_4lc_medium_photon_et);
   fChain->SetBranchAddress("MET_RefEle_4lc_medium_photon_sumet", &MET_RefEle_4lc_medium_photon_sumet, &b_MET_RefEle_4lc_medium_photon_sumet);
   fChain->SetBranchAddress("MET_RefJet_em_tight_etx", &MET_RefJet_em_tight_etx, &b_MET_RefJet_em_tight_etx);
   fChain->SetBranchAddress("MET_RefJet_em_tight_ety", &MET_RefJet_em_tight_ety, &b_MET_RefJet_em_tight_ety);
   fChain->SetBranchAddress("MET_RefJet_em_tight_phi", &MET_RefJet_em_tight_phi, &b_MET_RefJet_em_tight_phi);
   fChain->SetBranchAddress("MET_RefJet_em_tight_et", &MET_RefJet_em_tight_et, &b_MET_RefJet_em_tight_et);
   fChain->SetBranchAddress("MET_RefJet_em_tight_sumet", &MET_RefJet_em_tight_sumet, &b_MET_RefJet_em_tight_sumet);
   fChain->SetBranchAddress("MET_RefJet_em_medium_etx", &MET_RefJet_em_medium_etx, &b_MET_RefJet_em_medium_etx);
   fChain->SetBranchAddress("MET_RefJet_em_medium_ety", &MET_RefJet_em_medium_ety, &b_MET_RefJet_em_medium_ety);
   fChain->SetBranchAddress("MET_RefJet_em_medium_phi", &MET_RefJet_em_medium_phi, &b_MET_RefJet_em_medium_phi);
   fChain->SetBranchAddress("MET_RefJet_em_medium_et", &MET_RefJet_em_medium_et, &b_MET_RefJet_em_medium_et);
   fChain->SetBranchAddress("MET_RefJet_em_medium_sumet", &MET_RefJet_em_medium_sumet, &b_MET_RefJet_em_medium_sumet);
   fChain->SetBranchAddress("MET_RefJet_em_loose_etx", &MET_RefJet_em_loose_etx, &b_MET_RefJet_em_loose_etx);
   fChain->SetBranchAddress("MET_RefJet_em_loose_ety", &MET_RefJet_em_loose_ety, &b_MET_RefJet_em_loose_ety);
   fChain->SetBranchAddress("MET_RefJet_em_loose_phi", &MET_RefJet_em_loose_phi, &b_MET_RefJet_em_loose_phi);
   fChain->SetBranchAddress("MET_RefJet_em_loose_et", &MET_RefJet_em_loose_et, &b_MET_RefJet_em_loose_et);
   fChain->SetBranchAddress("MET_RefJet_em_loose_sumet", &MET_RefJet_em_loose_sumet, &b_MET_RefJet_em_loose_sumet);
   fChain->SetBranchAddress("MET_RefJet_4lc_tight_etx", &MET_RefJet_4lc_tight_etx, &b_MET_RefJet_4lc_tight_etx);
   fChain->SetBranchAddress("MET_RefJet_4lc_tight_ety", &MET_RefJet_4lc_tight_ety, &b_MET_RefJet_4lc_tight_ety);
   fChain->SetBranchAddress("MET_RefJet_4lc_tight_phi", &MET_RefJet_4lc_tight_phi, &b_MET_RefJet_4lc_tight_phi);
   fChain->SetBranchAddress("MET_RefJet_4lc_tight_et", &MET_RefJet_4lc_tight_et, &b_MET_RefJet_4lc_tight_et);
   fChain->SetBranchAddress("MET_RefJet_4lc_tight_sumet", &MET_RefJet_4lc_tight_sumet, &b_MET_RefJet_4lc_tight_sumet);
   fChain->SetBranchAddress("MET_RefJet_4lc_medium_etx", &MET_RefJet_4lc_medium_etx, &b_MET_RefJet_4lc_medium_etx);
   fChain->SetBranchAddress("MET_RefJet_4lc_medium_ety", &MET_RefJet_4lc_medium_ety, &b_MET_RefJet_4lc_medium_ety);
   fChain->SetBranchAddress("MET_RefJet_4lc_medium_phi", &MET_RefJet_4lc_medium_phi, &b_MET_RefJet_4lc_medium_phi);
   fChain->SetBranchAddress("MET_RefJet_4lc_medium_et", &MET_RefJet_4lc_medium_et, &b_MET_RefJet_4lc_medium_et);
   fChain->SetBranchAddress("MET_RefJet_4lc_medium_sumet", &MET_RefJet_4lc_medium_sumet, &b_MET_RefJet_4lc_medium_sumet);
   fChain->SetBranchAddress("MET_RefJet_4lc_loose_etx", &MET_RefJet_4lc_loose_etx, &b_MET_RefJet_4lc_loose_etx);
   fChain->SetBranchAddress("MET_RefJet_4lc_loose_ety", &MET_RefJet_4lc_loose_ety, &b_MET_RefJet_4lc_loose_ety);
   fChain->SetBranchAddress("MET_RefJet_4lc_loose_phi", &MET_RefJet_4lc_loose_phi, &b_MET_RefJet_4lc_loose_phi);
   fChain->SetBranchAddress("MET_RefJet_4lc_loose_et", &MET_RefJet_4lc_loose_et, &b_MET_RefJet_4lc_loose_et);
   fChain->SetBranchAddress("MET_RefJet_4lc_loose_sumet", &MET_RefJet_4lc_loose_sumet, &b_MET_RefJet_4lc_loose_sumet);
   fChain->SetBranchAddress("MET_RefJet_em_medium_photon_etx", &MET_RefJet_em_medium_photon_etx, &b_MET_RefJet_em_medium_photon_etx);
   fChain->SetBranchAddress("MET_RefJet_em_medium_photon_ety", &MET_RefJet_em_medium_photon_ety, &b_MET_RefJet_em_medium_photon_ety);
   fChain->SetBranchAddress("MET_RefJet_em_medium_photon_phi", &MET_RefJet_em_medium_photon_phi, &b_MET_RefJet_em_medium_photon_phi);
   fChain->SetBranchAddress("MET_RefJet_em_medium_photon_et", &MET_RefJet_em_medium_photon_et, &b_MET_RefJet_em_medium_photon_et);
   fChain->SetBranchAddress("MET_RefJet_em_medium_photon_sumet", &MET_RefJet_em_medium_photon_sumet, &b_MET_RefJet_em_medium_photon_sumet);
   fChain->SetBranchAddress("MET_RefJet_em_tight_photon_etx", &MET_RefJet_em_tight_photon_etx, &b_MET_RefJet_em_tight_photon_etx);
   fChain->SetBranchAddress("MET_RefJet_em_tight_photon_ety", &MET_RefJet_em_tight_photon_ety, &b_MET_RefJet_em_tight_photon_ety);
   fChain->SetBranchAddress("MET_RefJet_em_tight_photon_phi", &MET_RefJet_em_tight_photon_phi, &b_MET_RefJet_em_tight_photon_phi);
   fChain->SetBranchAddress("MET_RefJet_em_tight_photon_et", &MET_RefJet_em_tight_photon_et, &b_MET_RefJet_em_tight_photon_et);
   fChain->SetBranchAddress("MET_RefJet_em_tight_photon_sumet", &MET_RefJet_em_tight_photon_sumet, &b_MET_RefJet_em_tight_photon_sumet);
   fChain->SetBranchAddress("MET_RefJet_4lc_tight_photon_etx", &MET_RefJet_4lc_tight_photon_etx, &b_MET_RefJet_4lc_tight_photon_etx);
   fChain->SetBranchAddress("MET_RefJet_4lc_tight_photon_ety", &MET_RefJet_4lc_tight_photon_ety, &b_MET_RefJet_4lc_tight_photon_ety);
   fChain->SetBranchAddress("MET_RefJet_4lc_tight_photon_phi", &MET_RefJet_4lc_tight_photon_phi, &b_MET_RefJet_4lc_tight_photon_phi);
   fChain->SetBranchAddress("MET_RefJet_4lc_tight_photon_et", &MET_RefJet_4lc_tight_photon_et, &b_MET_RefJet_4lc_tight_photon_et);
   fChain->SetBranchAddress("MET_RefJet_4lc_tight_photon_sumet", &MET_RefJet_4lc_tight_photon_sumet, &b_MET_RefJet_4lc_tight_photon_sumet);
   fChain->SetBranchAddress("MET_RefJet_4lc_medium_photon_etx", &MET_RefJet_4lc_medium_photon_etx, &b_MET_RefJet_4lc_medium_photon_etx);
   fChain->SetBranchAddress("MET_RefJet_4lc_medium_photon_ety", &MET_RefJet_4lc_medium_photon_ety, &b_MET_RefJet_4lc_medium_photon_ety);
   fChain->SetBranchAddress("MET_RefJet_4lc_medium_photon_phi", &MET_RefJet_4lc_medium_photon_phi, &b_MET_RefJet_4lc_medium_photon_phi);
   fChain->SetBranchAddress("MET_RefJet_4lc_medium_photon_et", &MET_RefJet_4lc_medium_photon_et, &b_MET_RefJet_4lc_medium_photon_et);
   fChain->SetBranchAddress("MET_RefJet_4lc_medium_photon_sumet", &MET_RefJet_4lc_medium_photon_sumet, &b_MET_RefJet_4lc_medium_photon_sumet);
   fChain->SetBranchAddress("MET_SoftJets_em_tight_etx", &MET_SoftJets_em_tight_etx, &b_MET_SoftJets_em_tight_etx);
   fChain->SetBranchAddress("MET_SoftJets_em_tight_ety", &MET_SoftJets_em_tight_ety, &b_MET_SoftJets_em_tight_ety);
   fChain->SetBranchAddress("MET_SoftJets_em_tight_phi", &MET_SoftJets_em_tight_phi, &b_MET_SoftJets_em_tight_phi);
   fChain->SetBranchAddress("MET_SoftJets_em_tight_et", &MET_SoftJets_em_tight_et, &b_MET_SoftJets_em_tight_et);
   fChain->SetBranchAddress("MET_SoftJets_em_tight_sumet", &MET_SoftJets_em_tight_sumet, &b_MET_SoftJets_em_tight_sumet);
   fChain->SetBranchAddress("MET_SoftJets_em_medium_etx", &MET_SoftJets_em_medium_etx, &b_MET_SoftJets_em_medium_etx);
   fChain->SetBranchAddress("MET_SoftJets_em_medium_ety", &MET_SoftJets_em_medium_ety, &b_MET_SoftJets_em_medium_ety);
   fChain->SetBranchAddress("MET_SoftJets_em_medium_phi", &MET_SoftJets_em_medium_phi, &b_MET_SoftJets_em_medium_phi);
   fChain->SetBranchAddress("MET_SoftJets_em_medium_et", &MET_SoftJets_em_medium_et, &b_MET_SoftJets_em_medium_et);
   fChain->SetBranchAddress("MET_SoftJets_em_medium_sumet", &MET_SoftJets_em_medium_sumet, &b_MET_SoftJets_em_medium_sumet);
   fChain->SetBranchAddress("MET_SoftJets_em_loose_etx", &MET_SoftJets_em_loose_etx, &b_MET_SoftJets_em_loose_etx);
   fChain->SetBranchAddress("MET_SoftJets_em_loose_ety", &MET_SoftJets_em_loose_ety, &b_MET_SoftJets_em_loose_ety);
   fChain->SetBranchAddress("MET_SoftJets_em_loose_phi", &MET_SoftJets_em_loose_phi, &b_MET_SoftJets_em_loose_phi);
   fChain->SetBranchAddress("MET_SoftJets_em_loose_et", &MET_SoftJets_em_loose_et, &b_MET_SoftJets_em_loose_et);
   fChain->SetBranchAddress("MET_SoftJets_em_loose_sumet", &MET_SoftJets_em_loose_sumet, &b_MET_SoftJets_em_loose_sumet);
   fChain->SetBranchAddress("MET_SoftJets_4lc_tight_etx", &MET_SoftJets_4lc_tight_etx, &b_MET_SoftJets_4lc_tight_etx);
   fChain->SetBranchAddress("MET_SoftJets_4lc_tight_ety", &MET_SoftJets_4lc_tight_ety, &b_MET_SoftJets_4lc_tight_ety);
   fChain->SetBranchAddress("MET_SoftJets_4lc_tight_phi", &MET_SoftJets_4lc_tight_phi, &b_MET_SoftJets_4lc_tight_phi);
   fChain->SetBranchAddress("MET_SoftJets_4lc_tight_et", &MET_SoftJets_4lc_tight_et, &b_MET_SoftJets_4lc_tight_et);
   fChain->SetBranchAddress("MET_SoftJets_4lc_tight_sumet", &MET_SoftJets_4lc_tight_sumet, &b_MET_SoftJets_4lc_tight_sumet);
   fChain->SetBranchAddress("MET_SoftJets_4lc_medium_etx", &MET_SoftJets_4lc_medium_etx, &b_MET_SoftJets_4lc_medium_etx);
   fChain->SetBranchAddress("MET_SoftJets_4lc_medium_ety", &MET_SoftJets_4lc_medium_ety, &b_MET_SoftJets_4lc_medium_ety);
   fChain->SetBranchAddress("MET_SoftJets_4lc_medium_phi", &MET_SoftJets_4lc_medium_phi, &b_MET_SoftJets_4lc_medium_phi);
   fChain->SetBranchAddress("MET_SoftJets_4lc_medium_et", &MET_SoftJets_4lc_medium_et, &b_MET_SoftJets_4lc_medium_et);
   fChain->SetBranchAddress("MET_SoftJets_4lc_medium_sumet", &MET_SoftJets_4lc_medium_sumet, &b_MET_SoftJets_4lc_medium_sumet);
   fChain->SetBranchAddress("MET_SoftJets_4lc_loose_etx", &MET_SoftJets_4lc_loose_etx, &b_MET_SoftJets_4lc_loose_etx);
   fChain->SetBranchAddress("MET_SoftJets_4lc_loose_ety", &MET_SoftJets_4lc_loose_ety, &b_MET_SoftJets_4lc_loose_ety);
   fChain->SetBranchAddress("MET_SoftJets_4lc_loose_phi", &MET_SoftJets_4lc_loose_phi, &b_MET_SoftJets_4lc_loose_phi);
   fChain->SetBranchAddress("MET_SoftJets_4lc_loose_et", &MET_SoftJets_4lc_loose_et, &b_MET_SoftJets_4lc_loose_et);
   fChain->SetBranchAddress("MET_SoftJets_4lc_loose_sumet", &MET_SoftJets_4lc_loose_sumet, &b_MET_SoftJets_4lc_loose_sumet);
   fChain->SetBranchAddress("MET_SoftJets_em_medium_photon_etx", &MET_SoftJets_em_medium_photon_etx, &b_MET_SoftJets_em_medium_photon_etx);
   fChain->SetBranchAddress("MET_SoftJets_em_medium_photon_ety", &MET_SoftJets_em_medium_photon_ety, &b_MET_SoftJets_em_medium_photon_ety);
   fChain->SetBranchAddress("MET_SoftJets_em_medium_photon_phi", &MET_SoftJets_em_medium_photon_phi, &b_MET_SoftJets_em_medium_photon_phi);
   fChain->SetBranchAddress("MET_SoftJets_em_medium_photon_et", &MET_SoftJets_em_medium_photon_et, &b_MET_SoftJets_em_medium_photon_et);
   fChain->SetBranchAddress("MET_SoftJets_em_medium_photon_sumet", &MET_SoftJets_em_medium_photon_sumet, &b_MET_SoftJets_em_medium_photon_sumet);
   fChain->SetBranchAddress("MET_SoftJets_em_tight_photon_etx", &MET_SoftJets_em_tight_photon_etx, &b_MET_SoftJets_em_tight_photon_etx);
   fChain->SetBranchAddress("MET_SoftJets_em_tight_photon_ety", &MET_SoftJets_em_tight_photon_ety, &b_MET_SoftJets_em_tight_photon_ety);
   fChain->SetBranchAddress("MET_SoftJets_em_tight_photon_phi", &MET_SoftJets_em_tight_photon_phi, &b_MET_SoftJets_em_tight_photon_phi);
   fChain->SetBranchAddress("MET_SoftJets_em_tight_photon_et", &MET_SoftJets_em_tight_photon_et, &b_MET_SoftJets_em_tight_photon_et);
   fChain->SetBranchAddress("MET_SoftJets_em_tight_photon_sumet", &MET_SoftJets_em_tight_photon_sumet, &b_MET_SoftJets_em_tight_photon_sumet);
   fChain->SetBranchAddress("MET_SoftJets_4lc_tight_photon_etx", &MET_SoftJets_4lc_tight_photon_etx, &b_MET_SoftJets_4lc_tight_photon_etx);
   fChain->SetBranchAddress("MET_SoftJets_4lc_tight_photon_ety", &MET_SoftJets_4lc_tight_photon_ety, &b_MET_SoftJets_4lc_tight_photon_ety);
   fChain->SetBranchAddress("MET_SoftJets_4lc_tight_photon_phi", &MET_SoftJets_4lc_tight_photon_phi, &b_MET_SoftJets_4lc_tight_photon_phi);
   fChain->SetBranchAddress("MET_SoftJets_4lc_tight_photon_et", &MET_SoftJets_4lc_tight_photon_et, &b_MET_SoftJets_4lc_tight_photon_et);
   fChain->SetBranchAddress("MET_SoftJets_4lc_tight_photon_sumet", &MET_SoftJets_4lc_tight_photon_sumet, &b_MET_SoftJets_4lc_tight_photon_sumet);
   fChain->SetBranchAddress("MET_SoftJets_4lc_medium_photon_etx", &MET_SoftJets_4lc_medium_photon_etx, &b_MET_SoftJets_4lc_medium_photon_etx);
   fChain->SetBranchAddress("MET_SoftJets_4lc_medium_photon_ety", &MET_SoftJets_4lc_medium_photon_ety, &b_MET_SoftJets_4lc_medium_photon_ety);
   fChain->SetBranchAddress("MET_SoftJets_4lc_medium_photon_phi", &MET_SoftJets_4lc_medium_photon_phi, &b_MET_SoftJets_4lc_medium_photon_phi);
   fChain->SetBranchAddress("MET_SoftJets_4lc_medium_photon_et", &MET_SoftJets_4lc_medium_photon_et, &b_MET_SoftJets_4lc_medium_photon_et);
   fChain->SetBranchAddress("MET_SoftJets_4lc_medium_photon_sumet", &MET_SoftJets_4lc_medium_photon_sumet, &b_MET_SoftJets_4lc_medium_photon_sumet);
   fChain->SetBranchAddress("MET_CellOut_em_tight_etx", &MET_CellOut_em_tight_etx, &b_MET_CellOut_em_tight_etx);
   fChain->SetBranchAddress("MET_CellOut_em_tight_ety", &MET_CellOut_em_tight_ety, &b_MET_CellOut_em_tight_ety);
   fChain->SetBranchAddress("MET_CellOut_em_tight_phi", &MET_CellOut_em_tight_phi, &b_MET_CellOut_em_tight_phi);
   fChain->SetBranchAddress("MET_CellOut_em_tight_et", &MET_CellOut_em_tight_et, &b_MET_CellOut_em_tight_et);
   fChain->SetBranchAddress("MET_CellOut_em_tight_sumet", &MET_CellOut_em_tight_sumet, &b_MET_CellOut_em_tight_sumet);
   fChain->SetBranchAddress("MET_CellOut_em_medium_etx", &MET_CellOut_em_medium_etx, &b_MET_CellOut_em_medium_etx);
   fChain->SetBranchAddress("MET_CellOut_em_medium_ety", &MET_CellOut_em_medium_ety, &b_MET_CellOut_em_medium_ety);
   fChain->SetBranchAddress("MET_CellOut_em_medium_phi", &MET_CellOut_em_medium_phi, &b_MET_CellOut_em_medium_phi);
   fChain->SetBranchAddress("MET_CellOut_em_medium_et", &MET_CellOut_em_medium_et, &b_MET_CellOut_em_medium_et);
   fChain->SetBranchAddress("MET_CellOut_em_medium_sumet", &MET_CellOut_em_medium_sumet, &b_MET_CellOut_em_medium_sumet);
   fChain->SetBranchAddress("MET_CellOut_em_loose_etx", &MET_CellOut_em_loose_etx, &b_MET_CellOut_em_loose_etx);
   fChain->SetBranchAddress("MET_CellOut_em_loose_ety", &MET_CellOut_em_loose_ety, &b_MET_CellOut_em_loose_ety);
   fChain->SetBranchAddress("MET_CellOut_em_loose_phi", &MET_CellOut_em_loose_phi, &b_MET_CellOut_em_loose_phi);
   fChain->SetBranchAddress("MET_CellOut_em_loose_et", &MET_CellOut_em_loose_et, &b_MET_CellOut_em_loose_et);
   fChain->SetBranchAddress("MET_CellOut_em_loose_sumet", &MET_CellOut_em_loose_sumet, &b_MET_CellOut_em_loose_sumet);
   fChain->SetBranchAddress("MET_CellOut_4lc_tight_etx", &MET_CellOut_4lc_tight_etx, &b_MET_CellOut_4lc_tight_etx);
   fChain->SetBranchAddress("MET_CellOut_4lc_tight_ety", &MET_CellOut_4lc_tight_ety, &b_MET_CellOut_4lc_tight_ety);
   fChain->SetBranchAddress("MET_CellOut_4lc_tight_phi", &MET_CellOut_4lc_tight_phi, &b_MET_CellOut_4lc_tight_phi);
   fChain->SetBranchAddress("MET_CellOut_4lc_tight_et", &MET_CellOut_4lc_tight_et, &b_MET_CellOut_4lc_tight_et);
   fChain->SetBranchAddress("MET_CellOut_4lc_tight_sumet", &MET_CellOut_4lc_tight_sumet, &b_MET_CellOut_4lc_tight_sumet);
   fChain->SetBranchAddress("MET_CellOut_4lc_medium_etx", &MET_CellOut_4lc_medium_etx, &b_MET_CellOut_4lc_medium_etx);
   fChain->SetBranchAddress("MET_CellOut_4lc_medium_ety", &MET_CellOut_4lc_medium_ety, &b_MET_CellOut_4lc_medium_ety);
   fChain->SetBranchAddress("MET_CellOut_4lc_medium_phi", &MET_CellOut_4lc_medium_phi, &b_MET_CellOut_4lc_medium_phi);
   fChain->SetBranchAddress("MET_CellOut_4lc_medium_et", &MET_CellOut_4lc_medium_et, &b_MET_CellOut_4lc_medium_et);
   fChain->SetBranchAddress("MET_CellOut_4lc_medium_sumet", &MET_CellOut_4lc_medium_sumet, &b_MET_CellOut_4lc_medium_sumet);
   fChain->SetBranchAddress("MET_CellOut_4lc_loose_etx", &MET_CellOut_4lc_loose_etx, &b_MET_CellOut_4lc_loose_etx);
   fChain->SetBranchAddress("MET_CellOut_4lc_loose_ety", &MET_CellOut_4lc_loose_ety, &b_MET_CellOut_4lc_loose_ety);
   fChain->SetBranchAddress("MET_CellOut_4lc_loose_phi", &MET_CellOut_4lc_loose_phi, &b_MET_CellOut_4lc_loose_phi);
   fChain->SetBranchAddress("MET_CellOut_4lc_loose_et", &MET_CellOut_4lc_loose_et, &b_MET_CellOut_4lc_loose_et);
   fChain->SetBranchAddress("MET_CellOut_4lc_loose_sumet", &MET_CellOut_4lc_loose_sumet, &b_MET_CellOut_4lc_loose_sumet);
   fChain->SetBranchAddress("MET_CellOut_em_medium_photon_etx", &MET_CellOut_em_medium_photon_etx, &b_MET_CellOut_em_medium_photon_etx);
   fChain->SetBranchAddress("MET_CellOut_em_medium_photon_ety", &MET_CellOut_em_medium_photon_ety, &b_MET_CellOut_em_medium_photon_ety);
   fChain->SetBranchAddress("MET_CellOut_em_medium_photon_phi", &MET_CellOut_em_medium_photon_phi, &b_MET_CellOut_em_medium_photon_phi);
   fChain->SetBranchAddress("MET_CellOut_em_medium_photon_et", &MET_CellOut_em_medium_photon_et, &b_MET_CellOut_em_medium_photon_et);
   fChain->SetBranchAddress("MET_CellOut_em_medium_photon_sumet", &MET_CellOut_em_medium_photon_sumet, &b_MET_CellOut_em_medium_photon_sumet);
   fChain->SetBranchAddress("MET_CellOut_em_tight_photon_etx", &MET_CellOut_em_tight_photon_etx, &b_MET_CellOut_em_tight_photon_etx);
   fChain->SetBranchAddress("MET_CellOut_em_tight_photon_ety", &MET_CellOut_em_tight_photon_ety, &b_MET_CellOut_em_tight_photon_ety);
   fChain->SetBranchAddress("MET_CellOut_em_tight_photon_phi", &MET_CellOut_em_tight_photon_phi, &b_MET_CellOut_em_tight_photon_phi);
   fChain->SetBranchAddress("MET_CellOut_em_tight_photon_et", &MET_CellOut_em_tight_photon_et, &b_MET_CellOut_em_tight_photon_et);
   fChain->SetBranchAddress("MET_CellOut_em_tight_photon_sumet", &MET_CellOut_em_tight_photon_sumet, &b_MET_CellOut_em_tight_photon_sumet);
   fChain->SetBranchAddress("MET_CellOut_4lc_tight_photon_etx", &MET_CellOut_4lc_tight_photon_etx, &b_MET_CellOut_4lc_tight_photon_etx);
   fChain->SetBranchAddress("MET_CellOut_4lc_tight_photon_ety", &MET_CellOut_4lc_tight_photon_ety, &b_MET_CellOut_4lc_tight_photon_ety);
   fChain->SetBranchAddress("MET_CellOut_4lc_tight_photon_phi", &MET_CellOut_4lc_tight_photon_phi, &b_MET_CellOut_4lc_tight_photon_phi);
   fChain->SetBranchAddress("MET_CellOut_4lc_tight_photon_et", &MET_CellOut_4lc_tight_photon_et, &b_MET_CellOut_4lc_tight_photon_et);
   fChain->SetBranchAddress("MET_CellOut_4lc_tight_photon_sumet", &MET_CellOut_4lc_tight_photon_sumet, &b_MET_CellOut_4lc_tight_photon_sumet);
   fChain->SetBranchAddress("MET_CellOut_4lc_medium_photon_etx", &MET_CellOut_4lc_medium_photon_etx, &b_MET_CellOut_4lc_medium_photon_etx);
   fChain->SetBranchAddress("MET_CellOut_4lc_medium_photon_ety", &MET_CellOut_4lc_medium_photon_ety, &b_MET_CellOut_4lc_medium_photon_ety);
   fChain->SetBranchAddress("MET_CellOut_4lc_medium_photon_phi", &MET_CellOut_4lc_medium_photon_phi, &b_MET_CellOut_4lc_medium_photon_phi);
   fChain->SetBranchAddress("MET_CellOut_4lc_medium_photon_et", &MET_CellOut_4lc_medium_photon_et, &b_MET_CellOut_4lc_medium_photon_et);
   fChain->SetBranchAddress("MET_CellOut_4lc_medium_photon_sumet", &MET_CellOut_4lc_medium_photon_sumet, &b_MET_CellOut_4lc_medium_photon_sumet);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_tight_etx", &MET_Muon_Isol_Muid_em_tight_etx, &b_MET_Muon_Isol_Muid_em_tight_etx);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_tight_ety", &MET_Muon_Isol_Muid_em_tight_ety, &b_MET_Muon_Isol_Muid_em_tight_ety);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_tight_phi", &MET_Muon_Isol_Muid_em_tight_phi, &b_MET_Muon_Isol_Muid_em_tight_phi);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_tight_et", &MET_Muon_Isol_Muid_em_tight_et, &b_MET_Muon_Isol_Muid_em_tight_et);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_tight_sumet", &MET_Muon_Isol_Muid_em_tight_sumet, &b_MET_Muon_Isol_Muid_em_tight_sumet);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_medium_etx", &MET_Muon_Isol_Muid_em_medium_etx, &b_MET_Muon_Isol_Muid_em_medium_etx);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_medium_ety", &MET_Muon_Isol_Muid_em_medium_ety, &b_MET_Muon_Isol_Muid_em_medium_ety);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_medium_phi", &MET_Muon_Isol_Muid_em_medium_phi, &b_MET_Muon_Isol_Muid_em_medium_phi);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_medium_et", &MET_Muon_Isol_Muid_em_medium_et, &b_MET_Muon_Isol_Muid_em_medium_et);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_medium_sumet", &MET_Muon_Isol_Muid_em_medium_sumet, &b_MET_Muon_Isol_Muid_em_medium_sumet);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_loose_etx", &MET_Muon_Isol_Muid_em_loose_etx, &b_MET_Muon_Isol_Muid_em_loose_etx);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_loose_ety", &MET_Muon_Isol_Muid_em_loose_ety, &b_MET_Muon_Isol_Muid_em_loose_ety);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_loose_phi", &MET_Muon_Isol_Muid_em_loose_phi, &b_MET_Muon_Isol_Muid_em_loose_phi);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_loose_et", &MET_Muon_Isol_Muid_em_loose_et, &b_MET_Muon_Isol_Muid_em_loose_et);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_loose_sumet", &MET_Muon_Isol_Muid_em_loose_sumet, &b_MET_Muon_Isol_Muid_em_loose_sumet);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_tight_etx", &MET_Muon_Isol_Muid_4lc_tight_etx, &b_MET_Muon_Isol_Muid_4lc_tight_etx);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_tight_ety", &MET_Muon_Isol_Muid_4lc_tight_ety, &b_MET_Muon_Isol_Muid_4lc_tight_ety);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_tight_phi", &MET_Muon_Isol_Muid_4lc_tight_phi, &b_MET_Muon_Isol_Muid_4lc_tight_phi);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_tight_et", &MET_Muon_Isol_Muid_4lc_tight_et, &b_MET_Muon_Isol_Muid_4lc_tight_et);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_tight_sumet", &MET_Muon_Isol_Muid_4lc_tight_sumet, &b_MET_Muon_Isol_Muid_4lc_tight_sumet);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_medium_etx", &MET_Muon_Isol_Muid_4lc_medium_etx, &b_MET_Muon_Isol_Muid_4lc_medium_etx);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_medium_ety", &MET_Muon_Isol_Muid_4lc_medium_ety, &b_MET_Muon_Isol_Muid_4lc_medium_ety);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_medium_phi", &MET_Muon_Isol_Muid_4lc_medium_phi, &b_MET_Muon_Isol_Muid_4lc_medium_phi);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_medium_et", &MET_Muon_Isol_Muid_4lc_medium_et, &b_MET_Muon_Isol_Muid_4lc_medium_et);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_medium_sumet", &MET_Muon_Isol_Muid_4lc_medium_sumet, &b_MET_Muon_Isol_Muid_4lc_medium_sumet);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_loose_etx", &MET_Muon_Isol_Muid_4lc_loose_etx, &b_MET_Muon_Isol_Muid_4lc_loose_etx);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_loose_ety", &MET_Muon_Isol_Muid_4lc_loose_ety, &b_MET_Muon_Isol_Muid_4lc_loose_ety);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_loose_phi", &MET_Muon_Isol_Muid_4lc_loose_phi, &b_MET_Muon_Isol_Muid_4lc_loose_phi);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_loose_et", &MET_Muon_Isol_Muid_4lc_loose_et, &b_MET_Muon_Isol_Muid_4lc_loose_et);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_loose_sumet", &MET_Muon_Isol_Muid_4lc_loose_sumet, &b_MET_Muon_Isol_Muid_4lc_loose_sumet);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_medium_photon_etx", &MET_Muon_Isol_Muid_em_medium_photon_etx, &b_MET_Muon_Isol_Muid_em_medium_photon_etx);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_medium_photon_ety", &MET_Muon_Isol_Muid_em_medium_photon_ety, &b_MET_Muon_Isol_Muid_em_medium_photon_ety);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_medium_photon_phi", &MET_Muon_Isol_Muid_em_medium_photon_phi, &b_MET_Muon_Isol_Muid_em_medium_photon_phi);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_medium_photon_et", &MET_Muon_Isol_Muid_em_medium_photon_et, &b_MET_Muon_Isol_Muid_em_medium_photon_et);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_medium_photon_sumet", &MET_Muon_Isol_Muid_em_medium_photon_sumet, &b_MET_Muon_Isol_Muid_em_medium_photon_sumet);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_tight_photon_etx", &MET_Muon_Isol_Muid_em_tight_photon_etx, &b_MET_Muon_Isol_Muid_em_tight_photon_etx);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_tight_photon_ety", &MET_Muon_Isol_Muid_em_tight_photon_ety, &b_MET_Muon_Isol_Muid_em_tight_photon_ety);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_tight_photon_phi", &MET_Muon_Isol_Muid_em_tight_photon_phi, &b_MET_Muon_Isol_Muid_em_tight_photon_phi);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_tight_photon_et", &MET_Muon_Isol_Muid_em_tight_photon_et, &b_MET_Muon_Isol_Muid_em_tight_photon_et);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_em_tight_photon_sumet", &MET_Muon_Isol_Muid_em_tight_photon_sumet, &b_MET_Muon_Isol_Muid_em_tight_photon_sumet);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_tight_photon_etx", &MET_Muon_Isol_Muid_4lc_tight_photon_etx, &b_MET_Muon_Isol_Muid_4lc_tight_photon_etx);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_tight_photon_ety", &MET_Muon_Isol_Muid_4lc_tight_photon_ety, &b_MET_Muon_Isol_Muid_4lc_tight_photon_ety);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_tight_photon_phi", &MET_Muon_Isol_Muid_4lc_tight_photon_phi, &b_MET_Muon_Isol_Muid_4lc_tight_photon_phi);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_tight_photon_et", &MET_Muon_Isol_Muid_4lc_tight_photon_et, &b_MET_Muon_Isol_Muid_4lc_tight_photon_et);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_tight_photon_sumet", &MET_Muon_Isol_Muid_4lc_tight_photon_sumet, &b_MET_Muon_Isol_Muid_4lc_tight_photon_sumet);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_medium_photon_etx", &MET_Muon_Isol_Muid_4lc_medium_photon_etx, &b_MET_Muon_Isol_Muid_4lc_medium_photon_etx);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_medium_photon_ety", &MET_Muon_Isol_Muid_4lc_medium_photon_ety, &b_MET_Muon_Isol_Muid_4lc_medium_photon_ety);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_medium_photon_phi", &MET_Muon_Isol_Muid_4lc_medium_photon_phi, &b_MET_Muon_Isol_Muid_4lc_medium_photon_phi);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_medium_photon_et", &MET_Muon_Isol_Muid_4lc_medium_photon_et, &b_MET_Muon_Isol_Muid_4lc_medium_photon_et);
   fChain->SetBranchAddress("MET_Muon_Isol_Muid_4lc_medium_photon_sumet", &MET_Muon_Isol_Muid_4lc_medium_photon_sumet, &b_MET_Muon_Isol_Muid_4lc_medium_photon_sumet);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_tight_etx", &MET_Muon_NonIsol_Muid_em_tight_etx, &b_MET_Muon_NonIsol_Muid_em_tight_etx);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_tight_ety", &MET_Muon_NonIsol_Muid_em_tight_ety, &b_MET_Muon_NonIsol_Muid_em_tight_ety);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_tight_phi", &MET_Muon_NonIsol_Muid_em_tight_phi, &b_MET_Muon_NonIsol_Muid_em_tight_phi);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_tight_et", &MET_Muon_NonIsol_Muid_em_tight_et, &b_MET_Muon_NonIsol_Muid_em_tight_et);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_tight_sumet", &MET_Muon_NonIsol_Muid_em_tight_sumet, &b_MET_Muon_NonIsol_Muid_em_tight_sumet);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_medium_etx", &MET_Muon_NonIsol_Muid_em_medium_etx, &b_MET_Muon_NonIsol_Muid_em_medium_etx);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_medium_ety", &MET_Muon_NonIsol_Muid_em_medium_ety, &b_MET_Muon_NonIsol_Muid_em_medium_ety);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_medium_phi", &MET_Muon_NonIsol_Muid_em_medium_phi, &b_MET_Muon_NonIsol_Muid_em_medium_phi);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_medium_et", &MET_Muon_NonIsol_Muid_em_medium_et, &b_MET_Muon_NonIsol_Muid_em_medium_et);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_medium_sumet", &MET_Muon_NonIsol_Muid_em_medium_sumet, &b_MET_Muon_NonIsol_Muid_em_medium_sumet);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_loose_etx", &MET_Muon_NonIsol_Muid_em_loose_etx, &b_MET_Muon_NonIsol_Muid_em_loose_etx);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_loose_ety", &MET_Muon_NonIsol_Muid_em_loose_ety, &b_MET_Muon_NonIsol_Muid_em_loose_ety);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_loose_phi", &MET_Muon_NonIsol_Muid_em_loose_phi, &b_MET_Muon_NonIsol_Muid_em_loose_phi);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_loose_et", &MET_Muon_NonIsol_Muid_em_loose_et, &b_MET_Muon_NonIsol_Muid_em_loose_et);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_loose_sumet", &MET_Muon_NonIsol_Muid_em_loose_sumet, &b_MET_Muon_NonIsol_Muid_em_loose_sumet);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_tight_etx", &MET_Muon_NonIsol_Muid_4lc_tight_etx, &b_MET_Muon_NonIsol_Muid_4lc_tight_etx);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_tight_ety", &MET_Muon_NonIsol_Muid_4lc_tight_ety, &b_MET_Muon_NonIsol_Muid_4lc_tight_ety);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_tight_phi", &MET_Muon_NonIsol_Muid_4lc_tight_phi, &b_MET_Muon_NonIsol_Muid_4lc_tight_phi);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_tight_et", &MET_Muon_NonIsol_Muid_4lc_tight_et, &b_MET_Muon_NonIsol_Muid_4lc_tight_et);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_tight_sumet", &MET_Muon_NonIsol_Muid_4lc_tight_sumet, &b_MET_Muon_NonIsol_Muid_4lc_tight_sumet);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_medium_etx", &MET_Muon_NonIsol_Muid_4lc_medium_etx, &b_MET_Muon_NonIsol_Muid_4lc_medium_etx);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_medium_ety", &MET_Muon_NonIsol_Muid_4lc_medium_ety, &b_MET_Muon_NonIsol_Muid_4lc_medium_ety);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_medium_phi", &MET_Muon_NonIsol_Muid_4lc_medium_phi, &b_MET_Muon_NonIsol_Muid_4lc_medium_phi);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_medium_et", &MET_Muon_NonIsol_Muid_4lc_medium_et, &b_MET_Muon_NonIsol_Muid_4lc_medium_et);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_medium_sumet", &MET_Muon_NonIsol_Muid_4lc_medium_sumet, &b_MET_Muon_NonIsol_Muid_4lc_medium_sumet);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_loose_etx", &MET_Muon_NonIsol_Muid_4lc_loose_etx, &b_MET_Muon_NonIsol_Muid_4lc_loose_etx);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_loose_ety", &MET_Muon_NonIsol_Muid_4lc_loose_ety, &b_MET_Muon_NonIsol_Muid_4lc_loose_ety);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_loose_phi", &MET_Muon_NonIsol_Muid_4lc_loose_phi, &b_MET_Muon_NonIsol_Muid_4lc_loose_phi);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_loose_et", &MET_Muon_NonIsol_Muid_4lc_loose_et, &b_MET_Muon_NonIsol_Muid_4lc_loose_et);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_loose_sumet", &MET_Muon_NonIsol_Muid_4lc_loose_sumet, &b_MET_Muon_NonIsol_Muid_4lc_loose_sumet);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_medium_photon_etx", &MET_Muon_NonIsol_Muid_em_medium_photon_etx, &b_MET_Muon_NonIsol_Muid_em_medium_photon_etx);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_medium_photon_ety", &MET_Muon_NonIsol_Muid_em_medium_photon_ety, &b_MET_Muon_NonIsol_Muid_em_medium_photon_ety);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_medium_photon_phi", &MET_Muon_NonIsol_Muid_em_medium_photon_phi, &b_MET_Muon_NonIsol_Muid_em_medium_photon_phi);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_medium_photon_et", &MET_Muon_NonIsol_Muid_em_medium_photon_et, &b_MET_Muon_NonIsol_Muid_em_medium_photon_et);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_medium_photon_sumet", &MET_Muon_NonIsol_Muid_em_medium_photon_sumet, &b_MET_Muon_NonIsol_Muid_em_medium_photon_sumet);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_tight_photon_etx", &MET_Muon_NonIsol_Muid_em_tight_photon_etx, &b_MET_Muon_NonIsol_Muid_em_tight_photon_etx);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_tight_photon_ety", &MET_Muon_NonIsol_Muid_em_tight_photon_ety, &b_MET_Muon_NonIsol_Muid_em_tight_photon_ety);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_tight_photon_phi", &MET_Muon_NonIsol_Muid_em_tight_photon_phi, &b_MET_Muon_NonIsol_Muid_em_tight_photon_phi);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_tight_photon_et", &MET_Muon_NonIsol_Muid_em_tight_photon_et, &b_MET_Muon_NonIsol_Muid_em_tight_photon_et);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_em_tight_photon_sumet", &MET_Muon_NonIsol_Muid_em_tight_photon_sumet, &b_MET_Muon_NonIsol_Muid_em_tight_photon_sumet);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_tight_photon_etx", &MET_Muon_NonIsol_Muid_4lc_tight_photon_etx, &b_MET_Muon_NonIsol_Muid_4lc_tight_photon_etx);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_tight_photon_ety", &MET_Muon_NonIsol_Muid_4lc_tight_photon_ety, &b_MET_Muon_NonIsol_Muid_4lc_tight_photon_ety);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_tight_photon_phi", &MET_Muon_NonIsol_Muid_4lc_tight_photon_phi, &b_MET_Muon_NonIsol_Muid_4lc_tight_photon_phi);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_tight_photon_et", &MET_Muon_NonIsol_Muid_4lc_tight_photon_et, &b_MET_Muon_NonIsol_Muid_4lc_tight_photon_et);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_tight_photon_sumet", &MET_Muon_NonIsol_Muid_4lc_tight_photon_sumet, &b_MET_Muon_NonIsol_Muid_4lc_tight_photon_sumet);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_medium_photon_etx", &MET_Muon_NonIsol_Muid_4lc_medium_photon_etx, &b_MET_Muon_NonIsol_Muid_4lc_medium_photon_etx);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_medium_photon_ety", &MET_Muon_NonIsol_Muid_4lc_medium_photon_ety, &b_MET_Muon_NonIsol_Muid_4lc_medium_photon_ety);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_medium_photon_phi", &MET_Muon_NonIsol_Muid_4lc_medium_photon_phi, &b_MET_Muon_NonIsol_Muid_4lc_medium_photon_phi);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_medium_photon_et", &MET_Muon_NonIsol_Muid_4lc_medium_photon_et, &b_MET_Muon_NonIsol_Muid_4lc_medium_photon_et);
   fChain->SetBranchAddress("MET_Muon_NonIsol_Muid_4lc_medium_photon_sumet", &MET_Muon_NonIsol_Muid_4lc_medium_photon_sumet, &b_MET_Muon_NonIsol_Muid_4lc_medium_photon_sumet);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_tight_etx", &MET_Muon_Total_Muid_em_tight_etx, &b_MET_Muon_Total_Muid_em_tight_etx);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_tight_ety", &MET_Muon_Total_Muid_em_tight_ety, &b_MET_Muon_Total_Muid_em_tight_ety);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_tight_phi", &MET_Muon_Total_Muid_em_tight_phi, &b_MET_Muon_Total_Muid_em_tight_phi);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_tight_et", &MET_Muon_Total_Muid_em_tight_et, &b_MET_Muon_Total_Muid_em_tight_et);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_tight_sumet", &MET_Muon_Total_Muid_em_tight_sumet, &b_MET_Muon_Total_Muid_em_tight_sumet);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_medium_etx", &MET_Muon_Total_Muid_em_medium_etx, &b_MET_Muon_Total_Muid_em_medium_etx);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_medium_ety", &MET_Muon_Total_Muid_em_medium_ety, &b_MET_Muon_Total_Muid_em_medium_ety);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_medium_phi", &MET_Muon_Total_Muid_em_medium_phi, &b_MET_Muon_Total_Muid_em_medium_phi);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_medium_et", &MET_Muon_Total_Muid_em_medium_et, &b_MET_Muon_Total_Muid_em_medium_et);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_medium_sumet", &MET_Muon_Total_Muid_em_medium_sumet, &b_MET_Muon_Total_Muid_em_medium_sumet);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_loose_etx", &MET_Muon_Total_Muid_em_loose_etx, &b_MET_Muon_Total_Muid_em_loose_etx);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_loose_ety", &MET_Muon_Total_Muid_em_loose_ety, &b_MET_Muon_Total_Muid_em_loose_ety);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_loose_phi", &MET_Muon_Total_Muid_em_loose_phi, &b_MET_Muon_Total_Muid_em_loose_phi);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_loose_et", &MET_Muon_Total_Muid_em_loose_et, &b_MET_Muon_Total_Muid_em_loose_et);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_loose_sumet", &MET_Muon_Total_Muid_em_loose_sumet, &b_MET_Muon_Total_Muid_em_loose_sumet);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_tight_etx", &MET_Muon_Total_Muid_4lc_tight_etx, &b_MET_Muon_Total_Muid_4lc_tight_etx);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_tight_ety", &MET_Muon_Total_Muid_4lc_tight_ety, &b_MET_Muon_Total_Muid_4lc_tight_ety);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_tight_phi", &MET_Muon_Total_Muid_4lc_tight_phi, &b_MET_Muon_Total_Muid_4lc_tight_phi);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_tight_et", &MET_Muon_Total_Muid_4lc_tight_et, &b_MET_Muon_Total_Muid_4lc_tight_et);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_tight_sumet", &MET_Muon_Total_Muid_4lc_tight_sumet, &b_MET_Muon_Total_Muid_4lc_tight_sumet);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_medium_etx", &MET_Muon_Total_Muid_4lc_medium_etx, &b_MET_Muon_Total_Muid_4lc_medium_etx);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_medium_ety", &MET_Muon_Total_Muid_4lc_medium_ety, &b_MET_Muon_Total_Muid_4lc_medium_ety);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_medium_phi", &MET_Muon_Total_Muid_4lc_medium_phi, &b_MET_Muon_Total_Muid_4lc_medium_phi);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_medium_et", &MET_Muon_Total_Muid_4lc_medium_et, &b_MET_Muon_Total_Muid_4lc_medium_et);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_medium_sumet", &MET_Muon_Total_Muid_4lc_medium_sumet, &b_MET_Muon_Total_Muid_4lc_medium_sumet);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_loose_etx", &MET_Muon_Total_Muid_4lc_loose_etx, &b_MET_Muon_Total_Muid_4lc_loose_etx);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_loose_ety", &MET_Muon_Total_Muid_4lc_loose_ety, &b_MET_Muon_Total_Muid_4lc_loose_ety);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_loose_phi", &MET_Muon_Total_Muid_4lc_loose_phi, &b_MET_Muon_Total_Muid_4lc_loose_phi);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_loose_et", &MET_Muon_Total_Muid_4lc_loose_et, &b_MET_Muon_Total_Muid_4lc_loose_et);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_loose_sumet", &MET_Muon_Total_Muid_4lc_loose_sumet, &b_MET_Muon_Total_Muid_4lc_loose_sumet);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_medium_photon_etx", &MET_Muon_Total_Muid_em_medium_photon_etx, &b_MET_Muon_Total_Muid_em_medium_photon_etx);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_medium_photon_ety", &MET_Muon_Total_Muid_em_medium_photon_ety, &b_MET_Muon_Total_Muid_em_medium_photon_ety);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_medium_photon_phi", &MET_Muon_Total_Muid_em_medium_photon_phi, &b_MET_Muon_Total_Muid_em_medium_photon_phi);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_medium_photon_et", &MET_Muon_Total_Muid_em_medium_photon_et, &b_MET_Muon_Total_Muid_em_medium_photon_et);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_medium_photon_sumet", &MET_Muon_Total_Muid_em_medium_photon_sumet, &b_MET_Muon_Total_Muid_em_medium_photon_sumet);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_tight_photon_etx", &MET_Muon_Total_Muid_em_tight_photon_etx, &b_MET_Muon_Total_Muid_em_tight_photon_etx);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_tight_photon_ety", &MET_Muon_Total_Muid_em_tight_photon_ety, &b_MET_Muon_Total_Muid_em_tight_photon_ety);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_tight_photon_phi", &MET_Muon_Total_Muid_em_tight_photon_phi, &b_MET_Muon_Total_Muid_em_tight_photon_phi);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_tight_photon_et", &MET_Muon_Total_Muid_em_tight_photon_et, &b_MET_Muon_Total_Muid_em_tight_photon_et);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_em_tight_photon_sumet", &MET_Muon_Total_Muid_em_tight_photon_sumet, &b_MET_Muon_Total_Muid_em_tight_photon_sumet);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_tight_photon_etx", &MET_Muon_Total_Muid_4lc_tight_photon_etx, &b_MET_Muon_Total_Muid_4lc_tight_photon_etx);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_tight_photon_ety", &MET_Muon_Total_Muid_4lc_tight_photon_ety, &b_MET_Muon_Total_Muid_4lc_tight_photon_ety);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_tight_photon_phi", &MET_Muon_Total_Muid_4lc_tight_photon_phi, &b_MET_Muon_Total_Muid_4lc_tight_photon_phi);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_tight_photon_et", &MET_Muon_Total_Muid_4lc_tight_photon_et, &b_MET_Muon_Total_Muid_4lc_tight_photon_et);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_tight_photon_sumet", &MET_Muon_Total_Muid_4lc_tight_photon_sumet, &b_MET_Muon_Total_Muid_4lc_tight_photon_sumet);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_medium_photon_etx", &MET_Muon_Total_Muid_4lc_medium_photon_etx, &b_MET_Muon_Total_Muid_4lc_medium_photon_etx);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_medium_photon_ety", &MET_Muon_Total_Muid_4lc_medium_photon_ety, &b_MET_Muon_Total_Muid_4lc_medium_photon_ety);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_medium_photon_phi", &MET_Muon_Total_Muid_4lc_medium_photon_phi, &b_MET_Muon_Total_Muid_4lc_medium_photon_phi);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_medium_photon_et", &MET_Muon_Total_Muid_4lc_medium_photon_et, &b_MET_Muon_Total_Muid_4lc_medium_photon_et);
   fChain->SetBranchAddress("MET_Muon_Total_Muid_4lc_medium_photon_sumet", &MET_Muon_Total_Muid_4lc_medium_photon_sumet, &b_MET_Muon_Total_Muid_4lc_medium_photon_sumet);
   fChain->SetBranchAddress("MET_RefGamma_em_tight_etx", &MET_RefGamma_em_tight_etx, &b_MET_RefGamma_em_tight_etx);
   fChain->SetBranchAddress("MET_RefGamma_em_tight_ety", &MET_RefGamma_em_tight_ety, &b_MET_RefGamma_em_tight_ety);
   fChain->SetBranchAddress("MET_RefGamma_em_tight_phi", &MET_RefGamma_em_tight_phi, &b_MET_RefGamma_em_tight_phi);
   fChain->SetBranchAddress("MET_RefGamma_em_tight_et", &MET_RefGamma_em_tight_et, &b_MET_RefGamma_em_tight_et);
   fChain->SetBranchAddress("MET_RefGamma_em_tight_sumet", &MET_RefGamma_em_tight_sumet, &b_MET_RefGamma_em_tight_sumet);
   fChain->SetBranchAddress("MET_RefGamma_em_medium_etx", &MET_RefGamma_em_medium_etx, &b_MET_RefGamma_em_medium_etx);
   fChain->SetBranchAddress("MET_RefGamma_em_medium_ety", &MET_RefGamma_em_medium_ety, &b_MET_RefGamma_em_medium_ety);
   fChain->SetBranchAddress("MET_RefGamma_em_medium_phi", &MET_RefGamma_em_medium_phi, &b_MET_RefGamma_em_medium_phi);
   fChain->SetBranchAddress("MET_RefGamma_em_medium_et", &MET_RefGamma_em_medium_et, &b_MET_RefGamma_em_medium_et);
   fChain->SetBranchAddress("MET_RefGamma_em_medium_sumet", &MET_RefGamma_em_medium_sumet, &b_MET_RefGamma_em_medium_sumet);
   fChain->SetBranchAddress("MET_RefGamma_em_loose_etx", &MET_RefGamma_em_loose_etx, &b_MET_RefGamma_em_loose_etx);
   fChain->SetBranchAddress("MET_RefGamma_em_loose_ety", &MET_RefGamma_em_loose_ety, &b_MET_RefGamma_em_loose_ety);
   fChain->SetBranchAddress("MET_RefGamma_em_loose_phi", &MET_RefGamma_em_loose_phi, &b_MET_RefGamma_em_loose_phi);
   fChain->SetBranchAddress("MET_RefGamma_em_loose_et", &MET_RefGamma_em_loose_et, &b_MET_RefGamma_em_loose_et);
   fChain->SetBranchAddress("MET_RefGamma_em_loose_sumet", &MET_RefGamma_em_loose_sumet, &b_MET_RefGamma_em_loose_sumet);
   fChain->SetBranchAddress("MET_RefGamma_4lc_tight_etx", &MET_RefGamma_4lc_tight_etx, &b_MET_RefGamma_4lc_tight_etx);
   fChain->SetBranchAddress("MET_RefGamma_4lc_tight_ety", &MET_RefGamma_4lc_tight_ety, &b_MET_RefGamma_4lc_tight_ety);
   fChain->SetBranchAddress("MET_RefGamma_4lc_tight_phi", &MET_RefGamma_4lc_tight_phi, &b_MET_RefGamma_4lc_tight_phi);
   fChain->SetBranchAddress("MET_RefGamma_4lc_tight_et", &MET_RefGamma_4lc_tight_et, &b_MET_RefGamma_4lc_tight_et);
   fChain->SetBranchAddress("MET_RefGamma_4lc_tight_sumet", &MET_RefGamma_4lc_tight_sumet, &b_MET_RefGamma_4lc_tight_sumet);
   fChain->SetBranchAddress("MET_RefGamma_4lc_medium_etx", &MET_RefGamma_4lc_medium_etx, &b_MET_RefGamma_4lc_medium_etx);
   fChain->SetBranchAddress("MET_RefGamma_4lc_medium_ety", &MET_RefGamma_4lc_medium_ety, &b_MET_RefGamma_4lc_medium_ety);
   fChain->SetBranchAddress("MET_RefGamma_4lc_medium_phi", &MET_RefGamma_4lc_medium_phi, &b_MET_RefGamma_4lc_medium_phi);
   fChain->SetBranchAddress("MET_RefGamma_4lc_medium_et", &MET_RefGamma_4lc_medium_et, &b_MET_RefGamma_4lc_medium_et);
   fChain->SetBranchAddress("MET_RefGamma_4lc_medium_sumet", &MET_RefGamma_4lc_medium_sumet, &b_MET_RefGamma_4lc_medium_sumet);
   fChain->SetBranchAddress("MET_RefGamma_4lc_loose_etx", &MET_RefGamma_4lc_loose_etx, &b_MET_RefGamma_4lc_loose_etx);
   fChain->SetBranchAddress("MET_RefGamma_4lc_loose_ety", &MET_RefGamma_4lc_loose_ety, &b_MET_RefGamma_4lc_loose_ety);
   fChain->SetBranchAddress("MET_RefGamma_4lc_loose_phi", &MET_RefGamma_4lc_loose_phi, &b_MET_RefGamma_4lc_loose_phi);
   fChain->SetBranchAddress("MET_RefGamma_4lc_loose_et", &MET_RefGamma_4lc_loose_et, &b_MET_RefGamma_4lc_loose_et);
   fChain->SetBranchAddress("MET_RefGamma_4lc_loose_sumet", &MET_RefGamma_4lc_loose_sumet, &b_MET_RefGamma_4lc_loose_sumet);
   fChain->SetBranchAddress("MET_RefGamma_em_medium_photon_etx", &MET_RefGamma_em_medium_photon_etx, &b_MET_RefGamma_em_medium_photon_etx);
   fChain->SetBranchAddress("MET_RefGamma_em_medium_photon_ety", &MET_RefGamma_em_medium_photon_ety, &b_MET_RefGamma_em_medium_photon_ety);
   fChain->SetBranchAddress("MET_RefGamma_em_medium_photon_phi", &MET_RefGamma_em_medium_photon_phi, &b_MET_RefGamma_em_medium_photon_phi);
   fChain->SetBranchAddress("MET_RefGamma_em_medium_photon_et", &MET_RefGamma_em_medium_photon_et, &b_MET_RefGamma_em_medium_photon_et);
   fChain->SetBranchAddress("MET_RefGamma_em_medium_photon_sumet", &MET_RefGamma_em_medium_photon_sumet, &b_MET_RefGamma_em_medium_photon_sumet);
   fChain->SetBranchAddress("MET_RefGamma_em_tight_photon_etx", &MET_RefGamma_em_tight_photon_etx, &b_MET_RefGamma_em_tight_photon_etx);
   fChain->SetBranchAddress("MET_RefGamma_em_tight_photon_ety", &MET_RefGamma_em_tight_photon_ety, &b_MET_RefGamma_em_tight_photon_ety);
   fChain->SetBranchAddress("MET_RefGamma_em_tight_photon_phi", &MET_RefGamma_em_tight_photon_phi, &b_MET_RefGamma_em_tight_photon_phi);
   fChain->SetBranchAddress("MET_RefGamma_em_tight_photon_et", &MET_RefGamma_em_tight_photon_et, &b_MET_RefGamma_em_tight_photon_et);
   fChain->SetBranchAddress("MET_RefGamma_em_tight_photon_sumet", &MET_RefGamma_em_tight_photon_sumet, &b_MET_RefGamma_em_tight_photon_sumet);
   fChain->SetBranchAddress("MET_RefGamma_4lc_tight_photon_etx", &MET_RefGamma_4lc_tight_photon_etx, &b_MET_RefGamma_4lc_tight_photon_etx);
   fChain->SetBranchAddress("MET_RefGamma_4lc_tight_photon_ety", &MET_RefGamma_4lc_tight_photon_ety, &b_MET_RefGamma_4lc_tight_photon_ety);
   fChain->SetBranchAddress("MET_RefGamma_4lc_tight_photon_phi", &MET_RefGamma_4lc_tight_photon_phi, &b_MET_RefGamma_4lc_tight_photon_phi);
   fChain->SetBranchAddress("MET_RefGamma_4lc_tight_photon_et", &MET_RefGamma_4lc_tight_photon_et, &b_MET_RefGamma_4lc_tight_photon_et);
   fChain->SetBranchAddress("MET_RefGamma_4lc_tight_photon_sumet", &MET_RefGamma_4lc_tight_photon_sumet, &b_MET_RefGamma_4lc_tight_photon_sumet);
   fChain->SetBranchAddress("MET_RefGamma_4lc_medium_photon_etx", &MET_RefGamma_4lc_medium_photon_etx, &b_MET_RefGamma_4lc_medium_photon_etx);
   fChain->SetBranchAddress("MET_RefGamma_4lc_medium_photon_ety", &MET_RefGamma_4lc_medium_photon_ety, &b_MET_RefGamma_4lc_medium_photon_ety);
   fChain->SetBranchAddress("MET_RefGamma_4lc_medium_photon_phi", &MET_RefGamma_4lc_medium_photon_phi, &b_MET_RefGamma_4lc_medium_photon_phi);
   fChain->SetBranchAddress("MET_RefGamma_4lc_medium_photon_et", &MET_RefGamma_4lc_medium_photon_et, &b_MET_RefGamma_4lc_medium_photon_et);
   fChain->SetBranchAddress("MET_RefGamma_4lc_medium_photon_sumet", &MET_RefGamma_4lc_medium_photon_sumet, &b_MET_RefGamma_4lc_medium_photon_sumet);
   fChain->SetBranchAddress("MET_RefFinal_em_tight_etx", &MET_RefFinal_em_tight_etx, &b_MET_RefFinal_em_tight_etx);
   fChain->SetBranchAddress("MET_RefFinal_em_tight_ety", &MET_RefFinal_em_tight_ety, &b_MET_RefFinal_em_tight_ety);
   fChain->SetBranchAddress("MET_RefFinal_em_tight_phi", &MET_RefFinal_em_tight_phi, &b_MET_RefFinal_em_tight_phi);
   fChain->SetBranchAddress("MET_RefFinal_em_tight_et", &MET_RefFinal_em_tight_et, &b_MET_RefFinal_em_tight_et);
   fChain->SetBranchAddress("MET_RefFinal_em_tight_sumet", &MET_RefFinal_em_tight_sumet, &b_MET_RefFinal_em_tight_sumet);
   fChain->SetBranchAddress("MET_RefFinal_em_medium_etx", &MET_RefFinal_em_medium_etx, &b_MET_RefFinal_em_medium_etx);
   fChain->SetBranchAddress("MET_RefFinal_em_medium_ety", &MET_RefFinal_em_medium_ety, &b_MET_RefFinal_em_medium_ety);
   fChain->SetBranchAddress("MET_RefFinal_em_medium_phi", &MET_RefFinal_em_medium_phi, &b_MET_RefFinal_em_medium_phi);
   fChain->SetBranchAddress("MET_RefFinal_em_medium_et", &MET_RefFinal_em_medium_et, &b_MET_RefFinal_em_medium_et);
   fChain->SetBranchAddress("MET_RefFinal_em_medium_sumet", &MET_RefFinal_em_medium_sumet, &b_MET_RefFinal_em_medium_sumet);
   fChain->SetBranchAddress("MET_RefFinal_em_loose_etx", &MET_RefFinal_em_loose_etx, &b_MET_RefFinal_em_loose_etx);
   fChain->SetBranchAddress("MET_RefFinal_em_loose_ety", &MET_RefFinal_em_loose_ety, &b_MET_RefFinal_em_loose_ety);
   fChain->SetBranchAddress("MET_RefFinal_em_loose_phi", &MET_RefFinal_em_loose_phi, &b_MET_RefFinal_em_loose_phi);
   fChain->SetBranchAddress("MET_RefFinal_em_loose_et", &MET_RefFinal_em_loose_et, &b_MET_RefFinal_em_loose_et);
   fChain->SetBranchAddress("MET_RefFinal_em_loose_sumet", &MET_RefFinal_em_loose_sumet, &b_MET_RefFinal_em_loose_sumet);
   fChain->SetBranchAddress("MET_RefFinal_4lc_tight_etx", &MET_RefFinal_4lc_tight_etx, &b_MET_RefFinal_4lc_tight_etx);
   fChain->SetBranchAddress("MET_RefFinal_4lc_tight_ety", &MET_RefFinal_4lc_tight_ety, &b_MET_RefFinal_4lc_tight_ety);
   fChain->SetBranchAddress("MET_RefFinal_4lc_tight_phi", &MET_RefFinal_4lc_tight_phi, &b_MET_RefFinal_4lc_tight_phi);
   fChain->SetBranchAddress("MET_RefFinal_4lc_tight_et", &MET_RefFinal_4lc_tight_et, &b_MET_RefFinal_4lc_tight_et);
   fChain->SetBranchAddress("MET_RefFinal_4lc_tight_sumet", &MET_RefFinal_4lc_tight_sumet, &b_MET_RefFinal_4lc_tight_sumet);
   fChain->SetBranchAddress("MET_RefFinal_4lc_medium_etx", &MET_RefFinal_4lc_medium_etx, &b_MET_RefFinal_4lc_medium_etx);
   fChain->SetBranchAddress("MET_RefFinal_4lc_medium_ety", &MET_RefFinal_4lc_medium_ety, &b_MET_RefFinal_4lc_medium_ety);
   fChain->SetBranchAddress("MET_RefFinal_4lc_medium_phi", &MET_RefFinal_4lc_medium_phi, &b_MET_RefFinal_4lc_medium_phi);
   fChain->SetBranchAddress("MET_RefFinal_4lc_medium_et", &MET_RefFinal_4lc_medium_et, &b_MET_RefFinal_4lc_medium_et);
   fChain->SetBranchAddress("MET_RefFinal_4lc_medium_sumet", &MET_RefFinal_4lc_medium_sumet, &b_MET_RefFinal_4lc_medium_sumet);
   fChain->SetBranchAddress("MET_RefFinal_4lc_loose_etx", &MET_RefFinal_4lc_loose_etx, &b_MET_RefFinal_4lc_loose_etx);
   fChain->SetBranchAddress("MET_RefFinal_4lc_loose_ety", &MET_RefFinal_4lc_loose_ety, &b_MET_RefFinal_4lc_loose_ety);
   fChain->SetBranchAddress("MET_RefFinal_4lc_loose_phi", &MET_RefFinal_4lc_loose_phi, &b_MET_RefFinal_4lc_loose_phi);
   fChain->SetBranchAddress("MET_RefFinal_4lc_loose_et", &MET_RefFinal_4lc_loose_et, &b_MET_RefFinal_4lc_loose_et);
   fChain->SetBranchAddress("MET_RefFinal_4lc_loose_sumet", &MET_RefFinal_4lc_loose_sumet, &b_MET_RefFinal_4lc_loose_sumet);
   fChain->SetBranchAddress("MET_RefFinal_em_medium_photon_etx", &MET_RefFinal_em_medium_photon_etx, &b_MET_RefFinal_em_medium_photon_etx);
   fChain->SetBranchAddress("MET_RefFinal_em_medium_photon_ety", &MET_RefFinal_em_medium_photon_ety, &b_MET_RefFinal_em_medium_photon_ety);
   fChain->SetBranchAddress("MET_RefFinal_em_medium_photon_phi", &MET_RefFinal_em_medium_photon_phi, &b_MET_RefFinal_em_medium_photon_phi);
   fChain->SetBranchAddress("MET_RefFinal_em_medium_photon_et", &MET_RefFinal_em_medium_photon_et, &b_MET_RefFinal_em_medium_photon_et);
   fChain->SetBranchAddress("MET_RefFinal_em_medium_photon_sumet", &MET_RefFinal_em_medium_photon_sumet, &b_MET_RefFinal_em_medium_photon_sumet);
   fChain->SetBranchAddress("MET_RefFinal_em_tight_photon_etx", &MET_RefFinal_em_tight_photon_etx, &b_MET_RefFinal_em_tight_photon_etx);
   fChain->SetBranchAddress("MET_RefFinal_em_tight_photon_ety", &MET_RefFinal_em_tight_photon_ety, &b_MET_RefFinal_em_tight_photon_ety);
   fChain->SetBranchAddress("MET_RefFinal_em_tight_photon_phi", &MET_RefFinal_em_tight_photon_phi, &b_MET_RefFinal_em_tight_photon_phi);
   fChain->SetBranchAddress("MET_RefFinal_em_tight_photon_et", &MET_RefFinal_em_tight_photon_et, &b_MET_RefFinal_em_tight_photon_et);
   fChain->SetBranchAddress("MET_RefFinal_em_tight_photon_sumet", &MET_RefFinal_em_tight_photon_sumet, &b_MET_RefFinal_em_tight_photon_sumet);
   fChain->SetBranchAddress("MET_RefFinal_4lc_tight_photon_etx", &MET_RefFinal_4lc_tight_photon_etx, &b_MET_RefFinal_4lc_tight_photon_etx);
   fChain->SetBranchAddress("MET_RefFinal_4lc_tight_photon_ety", &MET_RefFinal_4lc_tight_photon_ety, &b_MET_RefFinal_4lc_tight_photon_ety);
   fChain->SetBranchAddress("MET_RefFinal_4lc_tight_photon_phi", &MET_RefFinal_4lc_tight_photon_phi, &b_MET_RefFinal_4lc_tight_photon_phi);
   fChain->SetBranchAddress("MET_RefFinal_4lc_tight_photon_et", &MET_RefFinal_4lc_tight_photon_et, &b_MET_RefFinal_4lc_tight_photon_et);
   fChain->SetBranchAddress("MET_RefFinal_4lc_tight_photon_sumet", &MET_RefFinal_4lc_tight_photon_sumet, &b_MET_RefFinal_4lc_tight_photon_sumet);
   fChain->SetBranchAddress("MET_RefFinal_4lc_medium_photon_etx", &MET_RefFinal_4lc_medium_photon_etx, &b_MET_RefFinal_4lc_medium_photon_etx);
   fChain->SetBranchAddress("MET_RefFinal_4lc_medium_photon_ety", &MET_RefFinal_4lc_medium_photon_ety, &b_MET_RefFinal_4lc_medium_photon_ety);
   fChain->SetBranchAddress("MET_RefFinal_4lc_medium_photon_phi", &MET_RefFinal_4lc_medium_photon_phi, &b_MET_RefFinal_4lc_medium_photon_phi);
   fChain->SetBranchAddress("MET_RefFinal_4lc_medium_photon_et", &MET_RefFinal_4lc_medium_photon_et, &b_MET_RefFinal_4lc_medium_photon_et);
   fChain->SetBranchAddress("MET_RefFinal_4lc_medium_photon_sumet", &MET_RefFinal_4lc_medium_photon_sumet, &b_MET_RefFinal_4lc_medium_photon_sumet);
   fChain->SetBranchAddress("MET_RefFinal_em_etx", &MET_RefFinal_em_etx, &b_MET_RefFinal_em_etx);
   fChain->SetBranchAddress("MET_RefFinal_em_ety", &MET_RefFinal_em_ety, &b_MET_RefFinal_em_ety);
   fChain->SetBranchAddress("MET_RefFinal_em_phi", &MET_RefFinal_em_phi, &b_MET_RefFinal_em_phi);
   fChain->SetBranchAddress("MET_RefFinal_em_et", &MET_RefFinal_em_et, &b_MET_RefFinal_em_et);
   fChain->SetBranchAddress("MET_RefFinal_em_sumet", &MET_RefFinal_em_sumet, &b_MET_RefFinal_em_sumet);
   fChain->SetBranchAddress("MET_RefFinal_etx", &MET_RefFinal_etx, &b_MET_RefFinal_etx);
   fChain->SetBranchAddress("MET_RefFinal_ety", &MET_RefFinal_ety, &b_MET_RefFinal_ety);
   fChain->SetBranchAddress("MET_RefFinal_phi", &MET_RefFinal_phi, &b_MET_RefFinal_phi);
   fChain->SetBranchAddress("MET_RefFinal_et", &MET_RefFinal_et, &b_MET_RefFinal_et);
   fChain->SetBranchAddress("MET_RefFinal_sumet", &MET_RefFinal_sumet, &b_MET_RefFinal_sumet);
   fChain->SetBranchAddress("el_MET_em_tight_n", &el_MET_em_tight_n, &b_el_MET_em_tight_n);
   fChain->SetBranchAddress("el_MET_em_tight_wpx", &el_MET_em_tight_wpx, &b_el_MET_em_tight_wpx);
   fChain->SetBranchAddress("el_MET_em_tight_wpy", &el_MET_em_tight_wpy, &b_el_MET_em_tight_wpy);
   fChain->SetBranchAddress("el_MET_em_tight_wet", &el_MET_em_tight_wet, &b_el_MET_em_tight_wet);
   fChain->SetBranchAddress("el_MET_em_tight_statusWord", &el_MET_em_tight_statusWord, &b_el_MET_em_tight_statusWord);
   fChain->SetBranchAddress("ph_MET_em_tight_n", &ph_MET_em_tight_n, &b_ph_MET_em_tight_n);
   fChain->SetBranchAddress("ph_MET_em_tight_wpx", &ph_MET_em_tight_wpx, &b_ph_MET_em_tight_wpx);
   fChain->SetBranchAddress("ph_MET_em_tight_wpy", &ph_MET_em_tight_wpy, &b_ph_MET_em_tight_wpy);
   fChain->SetBranchAddress("ph_MET_em_tight_wet", &ph_MET_em_tight_wet, &b_ph_MET_em_tight_wet);
   fChain->SetBranchAddress("ph_MET_em_tight_statusWord", &ph_MET_em_tight_statusWord, &b_ph_MET_em_tight_statusWord);
   fChain->SetBranchAddress("mu_staco_MET_em_tight_n", &mu_staco_MET_em_tight_n, &b_mu_staco_MET_em_tight_n);
   fChain->SetBranchAddress("mu_staco_MET_em_tight_wpx", &mu_staco_MET_em_tight_wpx, &b_mu_staco_MET_em_tight_wpx);
   fChain->SetBranchAddress("mu_staco_MET_em_tight_wpy", &mu_staco_MET_em_tight_wpy, &b_mu_staco_MET_em_tight_wpy);
   fChain->SetBranchAddress("mu_staco_MET_em_tight_wet", &mu_staco_MET_em_tight_wet, &b_mu_staco_MET_em_tight_wet);
   fChain->SetBranchAddress("mu_staco_MET_em_tight_statusWord", &mu_staco_MET_em_tight_statusWord, &b_mu_staco_MET_em_tight_statusWord);
   fChain->SetBranchAddress("mu_muid_MET_em_tight_n", &mu_muid_MET_em_tight_n, &b_mu_muid_MET_em_tight_n);
   fChain->SetBranchAddress("mu_muid_MET_em_tight_wpx", &mu_muid_MET_em_tight_wpx, &b_mu_muid_MET_em_tight_wpx);
   fChain->SetBranchAddress("mu_muid_MET_em_tight_wpy", &mu_muid_MET_em_tight_wpy, &b_mu_muid_MET_em_tight_wpy);
   fChain->SetBranchAddress("mu_muid_MET_em_tight_wet", &mu_muid_MET_em_tight_wet, &b_mu_muid_MET_em_tight_wet);
   fChain->SetBranchAddress("mu_muid_MET_em_tight_statusWord", &mu_muid_MET_em_tight_statusWord, &b_mu_muid_MET_em_tight_statusWord);
   fChain->SetBranchAddress("jet_em_tight_n", &jet_em_tight_n, &b_jet_em_tight_n);
   fChain->SetBranchAddress("jet_em_tight_wpx", &jet_em_tight_wpx, &b_jet_em_tight_wpx);
   fChain->SetBranchAddress("jet_em_tight_wpy", &jet_em_tight_wpy, &b_jet_em_tight_wpy);
   fChain->SetBranchAddress("jet_em_tight_wet", &jet_em_tight_wet, &b_jet_em_tight_wet);
   fChain->SetBranchAddress("jet_em_tight_statusWord", &jet_em_tight_statusWord, &b_jet_em_tight_statusWord);
   fChain->SetBranchAddress("el_MET_em_medium_n", &el_MET_em_medium_n, &b_el_MET_em_medium_n);
   fChain->SetBranchAddress("el_MET_em_medium_wpx", &el_MET_em_medium_wpx, &b_el_MET_em_medium_wpx);
   fChain->SetBranchAddress("el_MET_em_medium_wpy", &el_MET_em_medium_wpy, &b_el_MET_em_medium_wpy);
   fChain->SetBranchAddress("el_MET_em_medium_wet", &el_MET_em_medium_wet, &b_el_MET_em_medium_wet);
   fChain->SetBranchAddress("el_MET_em_medium_statusWord", &el_MET_em_medium_statusWord, &b_el_MET_em_medium_statusWord);
   fChain->SetBranchAddress("ph_MET_em_medium_n", &ph_MET_em_medium_n, &b_ph_MET_em_medium_n);
   fChain->SetBranchAddress("ph_MET_em_medium_wpx", &ph_MET_em_medium_wpx, &b_ph_MET_em_medium_wpx);
   fChain->SetBranchAddress("ph_MET_em_medium_wpy", &ph_MET_em_medium_wpy, &b_ph_MET_em_medium_wpy);
   fChain->SetBranchAddress("ph_MET_em_medium_wet", &ph_MET_em_medium_wet, &b_ph_MET_em_medium_wet);
   fChain->SetBranchAddress("ph_MET_em_medium_statusWord", &ph_MET_em_medium_statusWord, &b_ph_MET_em_medium_statusWord);
   fChain->SetBranchAddress("mu_staco_MET_em_medium_n", &mu_staco_MET_em_medium_n, &b_mu_staco_MET_em_medium_n);
   fChain->SetBranchAddress("mu_staco_MET_em_medium_wpx", &mu_staco_MET_em_medium_wpx, &b_mu_staco_MET_em_medium_wpx);
   fChain->SetBranchAddress("mu_staco_MET_em_medium_wpy", &mu_staco_MET_em_medium_wpy, &b_mu_staco_MET_em_medium_wpy);
   fChain->SetBranchAddress("mu_staco_MET_em_medium_wet", &mu_staco_MET_em_medium_wet, &b_mu_staco_MET_em_medium_wet);
   fChain->SetBranchAddress("mu_staco_MET_em_medium_statusWord", &mu_staco_MET_em_medium_statusWord, &b_mu_staco_MET_em_medium_statusWord);
   fChain->SetBranchAddress("mu_muid_MET_em_medium_n", &mu_muid_MET_em_medium_n, &b_mu_muid_MET_em_medium_n);
   fChain->SetBranchAddress("mu_muid_MET_em_medium_wpx", &mu_muid_MET_em_medium_wpx, &b_mu_muid_MET_em_medium_wpx);
   fChain->SetBranchAddress("mu_muid_MET_em_medium_wpy", &mu_muid_MET_em_medium_wpy, &b_mu_muid_MET_em_medium_wpy);
   fChain->SetBranchAddress("mu_muid_MET_em_medium_wet", &mu_muid_MET_em_medium_wet, &b_mu_muid_MET_em_medium_wet);
   fChain->SetBranchAddress("mu_muid_MET_em_medium_statusWord", &mu_muid_MET_em_medium_statusWord, &b_mu_muid_MET_em_medium_statusWord);
   fChain->SetBranchAddress("jet_em_medium_n", &jet_em_medium_n, &b_jet_em_medium_n);
   fChain->SetBranchAddress("jet_em_medium_wpx", &jet_em_medium_wpx, &b_jet_em_medium_wpx);
   fChain->SetBranchAddress("jet_em_medium_wpy", &jet_em_medium_wpy, &b_jet_em_medium_wpy);
   fChain->SetBranchAddress("jet_em_medium_wet", &jet_em_medium_wet, &b_jet_em_medium_wet);
   fChain->SetBranchAddress("jet_em_medium_statusWord", &jet_em_medium_statusWord, &b_jet_em_medium_statusWord);
   fChain->SetBranchAddress("el_MET_em_loose_n", &el_MET_em_loose_n, &b_el_MET_em_loose_n);
   fChain->SetBranchAddress("el_MET_em_loose_wpx", &el_MET_em_loose_wpx, &b_el_MET_em_loose_wpx);
   fChain->SetBranchAddress("el_MET_em_loose_wpy", &el_MET_em_loose_wpy, &b_el_MET_em_loose_wpy);
   fChain->SetBranchAddress("el_MET_em_loose_wet", &el_MET_em_loose_wet, &b_el_MET_em_loose_wet);
   fChain->SetBranchAddress("el_MET_em_loose_statusWord", &el_MET_em_loose_statusWord, &b_el_MET_em_loose_statusWord);
   fChain->SetBranchAddress("ph_MET_em_loose_n", &ph_MET_em_loose_n, &b_ph_MET_em_loose_n);
   fChain->SetBranchAddress("ph_MET_em_loose_wpx", &ph_MET_em_loose_wpx, &b_ph_MET_em_loose_wpx);
   fChain->SetBranchAddress("ph_MET_em_loose_wpy", &ph_MET_em_loose_wpy, &b_ph_MET_em_loose_wpy);
   fChain->SetBranchAddress("ph_MET_em_loose_wet", &ph_MET_em_loose_wet, &b_ph_MET_em_loose_wet);
   fChain->SetBranchAddress("ph_MET_em_loose_statusWord", &ph_MET_em_loose_statusWord, &b_ph_MET_em_loose_statusWord);
   fChain->SetBranchAddress("mu_staco_MET_em_loose_n", &mu_staco_MET_em_loose_n, &b_mu_staco_MET_em_loose_n);
   fChain->SetBranchAddress("mu_staco_MET_em_loose_wpx", &mu_staco_MET_em_loose_wpx, &b_mu_staco_MET_em_loose_wpx);
   fChain->SetBranchAddress("mu_staco_MET_em_loose_wpy", &mu_staco_MET_em_loose_wpy, &b_mu_staco_MET_em_loose_wpy);
   fChain->SetBranchAddress("mu_staco_MET_em_loose_wet", &mu_staco_MET_em_loose_wet, &b_mu_staco_MET_em_loose_wet);
   fChain->SetBranchAddress("mu_staco_MET_em_loose_statusWord", &mu_staco_MET_em_loose_statusWord, &b_mu_staco_MET_em_loose_statusWord);
   fChain->SetBranchAddress("mu_muid_MET_em_loose_n", &mu_muid_MET_em_loose_n, &b_mu_muid_MET_em_loose_n);
   fChain->SetBranchAddress("mu_muid_MET_em_loose_wpx", &mu_muid_MET_em_loose_wpx, &b_mu_muid_MET_em_loose_wpx);
   fChain->SetBranchAddress("mu_muid_MET_em_loose_wpy", &mu_muid_MET_em_loose_wpy, &b_mu_muid_MET_em_loose_wpy);
   fChain->SetBranchAddress("mu_muid_MET_em_loose_wet", &mu_muid_MET_em_loose_wet, &b_mu_muid_MET_em_loose_wet);
   fChain->SetBranchAddress("mu_muid_MET_em_loose_statusWord", &mu_muid_MET_em_loose_statusWord, &b_mu_muid_MET_em_loose_statusWord);
   fChain->SetBranchAddress("jet_em_loose_n", &jet_em_loose_n, &b_jet_em_loose_n);
   fChain->SetBranchAddress("jet_em_loose_wpx", &jet_em_loose_wpx, &b_jet_em_loose_wpx);
   fChain->SetBranchAddress("jet_em_loose_wpy", &jet_em_loose_wpy, &b_jet_em_loose_wpy);
   fChain->SetBranchAddress("jet_em_loose_wet", &jet_em_loose_wet, &b_jet_em_loose_wet);
   fChain->SetBranchAddress("jet_em_loose_statusWord", &jet_em_loose_statusWord, &b_jet_em_loose_statusWord);
   fChain->SetBranchAddress("el_MET_4lc_loose_n", &el_MET_4lc_loose_n, &b_el_MET_4lc_loose_n);
   fChain->SetBranchAddress("el_MET_4lc_loose_wpx", &el_MET_4lc_loose_wpx, &b_el_MET_4lc_loose_wpx);
   fChain->SetBranchAddress("el_MET_4lc_loose_wpy", &el_MET_4lc_loose_wpy, &b_el_MET_4lc_loose_wpy);
   fChain->SetBranchAddress("el_MET_4lc_loose_wet", &el_MET_4lc_loose_wet, &b_el_MET_4lc_loose_wet);
   fChain->SetBranchAddress("el_MET_4lc_loose_statusWord", &el_MET_4lc_loose_statusWord, &b_el_MET_4lc_loose_statusWord);
   fChain->SetBranchAddress("ph_MET_4lc_loose_n", &ph_MET_4lc_loose_n, &b_ph_MET_4lc_loose_n);
   fChain->SetBranchAddress("ph_MET_4lc_loose_wpx", &ph_MET_4lc_loose_wpx, &b_ph_MET_4lc_loose_wpx);
   fChain->SetBranchAddress("ph_MET_4lc_loose_wpy", &ph_MET_4lc_loose_wpy, &b_ph_MET_4lc_loose_wpy);
   fChain->SetBranchAddress("ph_MET_4lc_loose_wet", &ph_MET_4lc_loose_wet, &b_ph_MET_4lc_loose_wet);
   fChain->SetBranchAddress("ph_MET_4lc_loose_statusWord", &ph_MET_4lc_loose_statusWord, &b_ph_MET_4lc_loose_statusWord);
   fChain->SetBranchAddress("mu_staco_MET_4lc_loose_n", &mu_staco_MET_4lc_loose_n, &b_mu_staco_MET_4lc_loose_n);
   fChain->SetBranchAddress("mu_staco_MET_4lc_loose_wpx", &mu_staco_MET_4lc_loose_wpx, &b_mu_staco_MET_4lc_loose_wpx);
   fChain->SetBranchAddress("mu_staco_MET_4lc_loose_wpy", &mu_staco_MET_4lc_loose_wpy, &b_mu_staco_MET_4lc_loose_wpy);
   fChain->SetBranchAddress("mu_staco_MET_4lc_loose_wet", &mu_staco_MET_4lc_loose_wet, &b_mu_staco_MET_4lc_loose_wet);
   fChain->SetBranchAddress("mu_staco_MET_4lc_loose_statusWord", &mu_staco_MET_4lc_loose_statusWord, &b_mu_staco_MET_4lc_loose_statusWord);
   fChain->SetBranchAddress("mu_muid_MET_4lc_loose_n", &mu_muid_MET_4lc_loose_n, &b_mu_muid_MET_4lc_loose_n);
   fChain->SetBranchAddress("mu_muid_MET_4lc_loose_wpx", &mu_muid_MET_4lc_loose_wpx, &b_mu_muid_MET_4lc_loose_wpx);
   fChain->SetBranchAddress("mu_muid_MET_4lc_loose_wpy", &mu_muid_MET_4lc_loose_wpy, &b_mu_muid_MET_4lc_loose_wpy);
   fChain->SetBranchAddress("mu_muid_MET_4lc_loose_wet", &mu_muid_MET_4lc_loose_wet, &b_mu_muid_MET_4lc_loose_wet);
   fChain->SetBranchAddress("mu_muid_MET_4lc_loose_statusWord", &mu_muid_MET_4lc_loose_statusWord, &b_mu_muid_MET_4lc_loose_statusWord);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_loose_n", &jet_AntiKt4LCTopoJets_4lc_loose_n, &b_jet_AntiKt4LCTopoJets_4lc_loose_n);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_loose_wpx", &jet_AntiKt4LCTopoJets_4lc_loose_wpx, &b_jet_AntiKt4LCTopoJets_4lc_loose_wpx);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_loose_wpy", &jet_AntiKt4LCTopoJets_4lc_loose_wpy, &b_jet_AntiKt4LCTopoJets_4lc_loose_wpy);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_loose_wet", &jet_AntiKt4LCTopoJets_4lc_loose_wet, &b_jet_AntiKt4LCTopoJets_4lc_loose_wet);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_loose_statusWord", &jet_AntiKt4LCTopoJets_4lc_loose_statusWord, &b_jet_AntiKt4LCTopoJets_4lc_loose_statusWord);
   fChain->SetBranchAddress("el_MET_4lc_medium_n", &el_MET_4lc_medium_n, &b_el_MET_4lc_medium_n);
   fChain->SetBranchAddress("el_MET_4lc_medium_wpx", &el_MET_4lc_medium_wpx, &b_el_MET_4lc_medium_wpx);
   fChain->SetBranchAddress("el_MET_4lc_medium_wpy", &el_MET_4lc_medium_wpy, &b_el_MET_4lc_medium_wpy);
   fChain->SetBranchAddress("el_MET_4lc_medium_wet", &el_MET_4lc_medium_wet, &b_el_MET_4lc_medium_wet);
   fChain->SetBranchAddress("el_MET_4lc_medium_statusWord", &el_MET_4lc_medium_statusWord, &b_el_MET_4lc_medium_statusWord);
   fChain->SetBranchAddress("ph_MET_4lc_medium_n", &ph_MET_4lc_medium_n, &b_ph_MET_4lc_medium_n);
   fChain->SetBranchAddress("ph_MET_4lc_medium_wpx", &ph_MET_4lc_medium_wpx, &b_ph_MET_4lc_medium_wpx);
   fChain->SetBranchAddress("ph_MET_4lc_medium_wpy", &ph_MET_4lc_medium_wpy, &b_ph_MET_4lc_medium_wpy);
   fChain->SetBranchAddress("ph_MET_4lc_medium_wet", &ph_MET_4lc_medium_wet, &b_ph_MET_4lc_medium_wet);
   fChain->SetBranchAddress("ph_MET_4lc_medium_statusWord", &ph_MET_4lc_medium_statusWord, &b_ph_MET_4lc_medium_statusWord);
   fChain->SetBranchAddress("mu_staco_MET_4lc_medium_n", &mu_staco_MET_4lc_medium_n, &b_mu_staco_MET_4lc_medium_n);
   fChain->SetBranchAddress("mu_staco_MET_4lc_medium_wpx", &mu_staco_MET_4lc_medium_wpx, &b_mu_staco_MET_4lc_medium_wpx);
   fChain->SetBranchAddress("mu_staco_MET_4lc_medium_wpy", &mu_staco_MET_4lc_medium_wpy, &b_mu_staco_MET_4lc_medium_wpy);
   fChain->SetBranchAddress("mu_staco_MET_4lc_medium_wet", &mu_staco_MET_4lc_medium_wet, &b_mu_staco_MET_4lc_medium_wet);
   fChain->SetBranchAddress("mu_staco_MET_4lc_medium_statusWord", &mu_staco_MET_4lc_medium_statusWord, &b_mu_staco_MET_4lc_medium_statusWord);
   fChain->SetBranchAddress("mu_muid_MET_4lc_medium_n", &mu_muid_MET_4lc_medium_n, &b_mu_muid_MET_4lc_medium_n);
   fChain->SetBranchAddress("mu_muid_MET_4lc_medium_wpx", &mu_muid_MET_4lc_medium_wpx, &b_mu_muid_MET_4lc_medium_wpx);
   fChain->SetBranchAddress("mu_muid_MET_4lc_medium_wpy", &mu_muid_MET_4lc_medium_wpy, &b_mu_muid_MET_4lc_medium_wpy);
   fChain->SetBranchAddress("mu_muid_MET_4lc_medium_wet", &mu_muid_MET_4lc_medium_wet, &b_mu_muid_MET_4lc_medium_wet);
   fChain->SetBranchAddress("mu_muid_MET_4lc_medium_statusWord", &mu_muid_MET_4lc_medium_statusWord, &b_mu_muid_MET_4lc_medium_statusWord);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_medium_n", &jet_AntiKt4LCTopoJets_4lc_medium_n, &b_jet_AntiKt4LCTopoJets_4lc_medium_n);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_medium_wpx", &jet_AntiKt4LCTopoJets_4lc_medium_wpx, &b_jet_AntiKt4LCTopoJets_4lc_medium_wpx);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_medium_wpy", &jet_AntiKt4LCTopoJets_4lc_medium_wpy, &b_jet_AntiKt4LCTopoJets_4lc_medium_wpy);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_medium_wet", &jet_AntiKt4LCTopoJets_4lc_medium_wet, &b_jet_AntiKt4LCTopoJets_4lc_medium_wet);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_medium_statusWord", &jet_AntiKt4LCTopoJets_4lc_medium_statusWord, &b_jet_AntiKt4LCTopoJets_4lc_medium_statusWord);
   fChain->SetBranchAddress("el_MET_4lc_tight_n", &el_MET_4lc_tight_n, &b_el_MET_4lc_tight_n);
   fChain->SetBranchAddress("el_MET_4lc_tight_wpx", &el_MET_4lc_tight_wpx, &b_el_MET_4lc_tight_wpx);
   fChain->SetBranchAddress("el_MET_4lc_tight_wpy", &el_MET_4lc_tight_wpy, &b_el_MET_4lc_tight_wpy);
   fChain->SetBranchAddress("el_MET_4lc_tight_wet", &el_MET_4lc_tight_wet, &b_el_MET_4lc_tight_wet);
   fChain->SetBranchAddress("el_MET_4lc_tight_statusWord", &el_MET_4lc_tight_statusWord, &b_el_MET_4lc_tight_statusWord);
   fChain->SetBranchAddress("ph_MET_4lc_tight_n", &ph_MET_4lc_tight_n, &b_ph_MET_4lc_tight_n);
   fChain->SetBranchAddress("ph_MET_4lc_tight_wpx", &ph_MET_4lc_tight_wpx, &b_ph_MET_4lc_tight_wpx);
   fChain->SetBranchAddress("ph_MET_4lc_tight_wpy", &ph_MET_4lc_tight_wpy, &b_ph_MET_4lc_tight_wpy);
   fChain->SetBranchAddress("ph_MET_4lc_tight_wet", &ph_MET_4lc_tight_wet, &b_ph_MET_4lc_tight_wet);
   fChain->SetBranchAddress("ph_MET_4lc_tight_statusWord", &ph_MET_4lc_tight_statusWord, &b_ph_MET_4lc_tight_statusWord);
   fChain->SetBranchAddress("mu_staco_MET_4lc_tight_n", &mu_staco_MET_4lc_tight_n, &b_mu_staco_MET_4lc_tight_n);
   fChain->SetBranchAddress("mu_staco_MET_4lc_tight_wpx", &mu_staco_MET_4lc_tight_wpx, &b_mu_staco_MET_4lc_tight_wpx);
   fChain->SetBranchAddress("mu_staco_MET_4lc_tight_wpy", &mu_staco_MET_4lc_tight_wpy, &b_mu_staco_MET_4lc_tight_wpy);
   fChain->SetBranchAddress("mu_staco_MET_4lc_tight_wet", &mu_staco_MET_4lc_tight_wet, &b_mu_staco_MET_4lc_tight_wet);
   fChain->SetBranchAddress("mu_staco_MET_4lc_tight_statusWord", &mu_staco_MET_4lc_tight_statusWord, &b_mu_staco_MET_4lc_tight_statusWord);
   fChain->SetBranchAddress("mu_muid_MET_4lc_tight_n", &mu_muid_MET_4lc_tight_n, &b_mu_muid_MET_4lc_tight_n);
   fChain->SetBranchAddress("mu_muid_MET_4lc_tight_wpx", &mu_muid_MET_4lc_tight_wpx, &b_mu_muid_MET_4lc_tight_wpx);
   fChain->SetBranchAddress("mu_muid_MET_4lc_tight_wpy", &mu_muid_MET_4lc_tight_wpy, &b_mu_muid_MET_4lc_tight_wpy);
   fChain->SetBranchAddress("mu_muid_MET_4lc_tight_wet", &mu_muid_MET_4lc_tight_wet, &b_mu_muid_MET_4lc_tight_wet);
   fChain->SetBranchAddress("mu_muid_MET_4lc_tight_statusWord", &mu_muid_MET_4lc_tight_statusWord, &b_mu_muid_MET_4lc_tight_statusWord);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_tight_n", &jet_AntiKt4LCTopoJets_4lc_tight_n, &b_jet_AntiKt4LCTopoJets_4lc_tight_n);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_tight_wpx", &jet_AntiKt4LCTopoJets_4lc_tight_wpx, &b_jet_AntiKt4LCTopoJets_4lc_tight_wpx);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_tight_wpy", &jet_AntiKt4LCTopoJets_4lc_tight_wpy, &b_jet_AntiKt4LCTopoJets_4lc_tight_wpy);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_tight_wet", &jet_AntiKt4LCTopoJets_4lc_tight_wet, &b_jet_AntiKt4LCTopoJets_4lc_tight_wet);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_tight_statusWord", &jet_AntiKt4LCTopoJets_4lc_tight_statusWord, &b_jet_AntiKt4LCTopoJets_4lc_tight_statusWord);
   fChain->SetBranchAddress("el_MET_6lc_tight_n", &el_MET_6lc_tight_n, &b_el_MET_6lc_tight_n);
   fChain->SetBranchAddress("el_MET_6lc_tight_wpx", &el_MET_6lc_tight_wpx, &b_el_MET_6lc_tight_wpx);
   fChain->SetBranchAddress("el_MET_6lc_tight_wpy", &el_MET_6lc_tight_wpy, &b_el_MET_6lc_tight_wpy);
   fChain->SetBranchAddress("el_MET_6lc_tight_wet", &el_MET_6lc_tight_wet, &b_el_MET_6lc_tight_wet);
   fChain->SetBranchAddress("el_MET_6lc_tight_statusWord", &el_MET_6lc_tight_statusWord, &b_el_MET_6lc_tight_statusWord);
   fChain->SetBranchAddress("ph_MET_6lc_tight_n", &ph_MET_6lc_tight_n, &b_ph_MET_6lc_tight_n);
   fChain->SetBranchAddress("ph_MET_6lc_tight_wpx", &ph_MET_6lc_tight_wpx, &b_ph_MET_6lc_tight_wpx);
   fChain->SetBranchAddress("ph_MET_6lc_tight_wpy", &ph_MET_6lc_tight_wpy, &b_ph_MET_6lc_tight_wpy);
   fChain->SetBranchAddress("ph_MET_6lc_tight_wet", &ph_MET_6lc_tight_wet, &b_ph_MET_6lc_tight_wet);
   fChain->SetBranchAddress("ph_MET_6lc_tight_statusWord", &ph_MET_6lc_tight_statusWord, &b_ph_MET_6lc_tight_statusWord);
   fChain->SetBranchAddress("mu_staco_MET_6lc_tight_n", &mu_staco_MET_6lc_tight_n, &b_mu_staco_MET_6lc_tight_n);
   fChain->SetBranchAddress("mu_staco_MET_6lc_tight_wpx", &mu_staco_MET_6lc_tight_wpx, &b_mu_staco_MET_6lc_tight_wpx);
   fChain->SetBranchAddress("mu_staco_MET_6lc_tight_wpy", &mu_staco_MET_6lc_tight_wpy, &b_mu_staco_MET_6lc_tight_wpy);
   fChain->SetBranchAddress("mu_staco_MET_6lc_tight_wet", &mu_staco_MET_6lc_tight_wet, &b_mu_staco_MET_6lc_tight_wet);
   fChain->SetBranchAddress("mu_staco_MET_6lc_tight_statusWord", &mu_staco_MET_6lc_tight_statusWord, &b_mu_staco_MET_6lc_tight_statusWord);
   fChain->SetBranchAddress("mu_muid_MET_6lc_tight_n", &mu_muid_MET_6lc_tight_n, &b_mu_muid_MET_6lc_tight_n);
   fChain->SetBranchAddress("mu_muid_MET_6lc_tight_wpx", &mu_muid_MET_6lc_tight_wpx, &b_mu_muid_MET_6lc_tight_wpx);
   fChain->SetBranchAddress("mu_muid_MET_6lc_tight_wpy", &mu_muid_MET_6lc_tight_wpy, &b_mu_muid_MET_6lc_tight_wpy);
   fChain->SetBranchAddress("mu_muid_MET_6lc_tight_wet", &mu_muid_MET_6lc_tight_wet, &b_mu_muid_MET_6lc_tight_wet);
   fChain->SetBranchAddress("mu_muid_MET_6lc_tight_statusWord", &mu_muid_MET_6lc_tight_statusWord, &b_mu_muid_MET_6lc_tight_statusWord);
   fChain->SetBranchAddress("jet_AntiKt6LCTopoJets_6lc_tight_n", &jet_AntiKt6LCTopoJets_6lc_tight_n, &b_jet_AntiKt6LCTopoJets_6lc_tight_n);
   fChain->SetBranchAddress("jet_AntiKt6LCTopoJets_6lc_tight_wpx", &jet_AntiKt6LCTopoJets_6lc_tight_wpx, &b_jet_AntiKt6LCTopoJets_6lc_tight_wpx);
   fChain->SetBranchAddress("jet_AntiKt6LCTopoJets_6lc_tight_wpy", &jet_AntiKt6LCTopoJets_6lc_tight_wpy, &b_jet_AntiKt6LCTopoJets_6lc_tight_wpy);
   fChain->SetBranchAddress("jet_AntiKt6LCTopoJets_6lc_tight_wet", &jet_AntiKt6LCTopoJets_6lc_tight_wet, &b_jet_AntiKt6LCTopoJets_6lc_tight_wet);
   fChain->SetBranchAddress("jet_AntiKt6LCTopoJets_6lc_tight_statusWord", &jet_AntiKt6LCTopoJets_6lc_tight_statusWord, &b_jet_AntiKt6LCTopoJets_6lc_tight_statusWord);
   fChain->SetBranchAddress("el_MET_em_medium_photon_n", &el_MET_em_medium_photon_n, &b_el_MET_em_medium_photon_n);
   fChain->SetBranchAddress("el_MET_em_medium_photon_wpx", &el_MET_em_medium_photon_wpx, &b_el_MET_em_medium_photon_wpx);
   fChain->SetBranchAddress("el_MET_em_medium_photon_wpy", &el_MET_em_medium_photon_wpy, &b_el_MET_em_medium_photon_wpy);
   fChain->SetBranchAddress("el_MET_em_medium_photon_wet", &el_MET_em_medium_photon_wet, &b_el_MET_em_medium_photon_wet);
   fChain->SetBranchAddress("el_MET_em_medium_photon_statusWord", &el_MET_em_medium_photon_statusWord, &b_el_MET_em_medium_photon_statusWord);
   fChain->SetBranchAddress("ph_MET_em_medium_photon_n", &ph_MET_em_medium_photon_n, &b_ph_MET_em_medium_photon_n);
   fChain->SetBranchAddress("ph_MET_em_medium_photon_wpx", &ph_MET_em_medium_photon_wpx, &b_ph_MET_em_medium_photon_wpx);
   fChain->SetBranchAddress("ph_MET_em_medium_photon_wpy", &ph_MET_em_medium_photon_wpy, &b_ph_MET_em_medium_photon_wpy);
   fChain->SetBranchAddress("ph_MET_em_medium_photon_wet", &ph_MET_em_medium_photon_wet, &b_ph_MET_em_medium_photon_wet);
   fChain->SetBranchAddress("ph_MET_em_medium_photon_statusWord", &ph_MET_em_medium_photon_statusWord, &b_ph_MET_em_medium_photon_statusWord);
   fChain->SetBranchAddress("mu_staco_MET_em_medium_photon_n", &mu_staco_MET_em_medium_photon_n, &b_mu_staco_MET_em_medium_photon_n);
   fChain->SetBranchAddress("mu_staco_MET_em_medium_photon_wpx", &mu_staco_MET_em_medium_photon_wpx, &b_mu_staco_MET_em_medium_photon_wpx);
   fChain->SetBranchAddress("mu_staco_MET_em_medium_photon_wpy", &mu_staco_MET_em_medium_photon_wpy, &b_mu_staco_MET_em_medium_photon_wpy);
   fChain->SetBranchAddress("mu_staco_MET_em_medium_photon_wet", &mu_staco_MET_em_medium_photon_wet, &b_mu_staco_MET_em_medium_photon_wet);
   fChain->SetBranchAddress("mu_staco_MET_em_medium_photon_statusWord", &mu_staco_MET_em_medium_photon_statusWord, &b_mu_staco_MET_em_medium_photon_statusWord);
   fChain->SetBranchAddress("mu_muid_MET_em_medium_photon_n", &mu_muid_MET_em_medium_photon_n, &b_mu_muid_MET_em_medium_photon_n);
   fChain->SetBranchAddress("mu_muid_MET_em_medium_photon_wpx", &mu_muid_MET_em_medium_photon_wpx, &b_mu_muid_MET_em_medium_photon_wpx);
   fChain->SetBranchAddress("mu_muid_MET_em_medium_photon_wpy", &mu_muid_MET_em_medium_photon_wpy, &b_mu_muid_MET_em_medium_photon_wpy);
   fChain->SetBranchAddress("mu_muid_MET_em_medium_photon_wet", &mu_muid_MET_em_medium_photon_wet, &b_mu_muid_MET_em_medium_photon_wet);
   fChain->SetBranchAddress("mu_muid_MET_em_medium_photon_statusWord", &mu_muid_MET_em_medium_photon_statusWord, &b_mu_muid_MET_em_medium_photon_statusWord);
   fChain->SetBranchAddress("jet_em_medium_photon_n", &jet_em_medium_photon_n, &b_jet_em_medium_photon_n);
   fChain->SetBranchAddress("jet_em_medium_photon_wpx", &jet_em_medium_photon_wpx, &b_jet_em_medium_photon_wpx);
   fChain->SetBranchAddress("jet_em_medium_photon_wpy", &jet_em_medium_photon_wpy, &b_jet_em_medium_photon_wpy);
   fChain->SetBranchAddress("jet_em_medium_photon_wet", &jet_em_medium_photon_wet, &b_jet_em_medium_photon_wet);
   fChain->SetBranchAddress("jet_em_medium_photon_statusWord", &jet_em_medium_photon_statusWord, &b_jet_em_medium_photon_statusWord);
   fChain->SetBranchAddress("el_MET_em_tight_photon_n", &el_MET_em_tight_photon_n, &b_el_MET_em_tight_photon_n);
   fChain->SetBranchAddress("el_MET_em_tight_photon_wpx", &el_MET_em_tight_photon_wpx, &b_el_MET_em_tight_photon_wpx);
   fChain->SetBranchAddress("el_MET_em_tight_photon_wpy", &el_MET_em_tight_photon_wpy, &b_el_MET_em_tight_photon_wpy);
   fChain->SetBranchAddress("el_MET_em_tight_photon_wet", &el_MET_em_tight_photon_wet, &b_el_MET_em_tight_photon_wet);
   fChain->SetBranchAddress("el_MET_em_tight_photon_statusWord", &el_MET_em_tight_photon_statusWord, &b_el_MET_em_tight_photon_statusWord);
   fChain->SetBranchAddress("ph_MET_em_tight_photon_n", &ph_MET_em_tight_photon_n, &b_ph_MET_em_tight_photon_n);
   fChain->SetBranchAddress("ph_MET_em_tight_photon_wpx", &ph_MET_em_tight_photon_wpx, &b_ph_MET_em_tight_photon_wpx);
   fChain->SetBranchAddress("ph_MET_em_tight_photon_wpy", &ph_MET_em_tight_photon_wpy, &b_ph_MET_em_tight_photon_wpy);
   fChain->SetBranchAddress("ph_MET_em_tight_photon_wet", &ph_MET_em_tight_photon_wet, &b_ph_MET_em_tight_photon_wet);
   fChain->SetBranchAddress("ph_MET_em_tight_photon_statusWord", &ph_MET_em_tight_photon_statusWord, &b_ph_MET_em_tight_photon_statusWord);
   fChain->SetBranchAddress("mu_staco_MET_em_tight_photon_n", &mu_staco_MET_em_tight_photon_n, &b_mu_staco_MET_em_tight_photon_n);
   fChain->SetBranchAddress("mu_staco_MET_em_tight_photon_wpx", &mu_staco_MET_em_tight_photon_wpx, &b_mu_staco_MET_em_tight_photon_wpx);
   fChain->SetBranchAddress("mu_staco_MET_em_tight_photon_wpy", &mu_staco_MET_em_tight_photon_wpy, &b_mu_staco_MET_em_tight_photon_wpy);
   fChain->SetBranchAddress("mu_staco_MET_em_tight_photon_wet", &mu_staco_MET_em_tight_photon_wet, &b_mu_staco_MET_em_tight_photon_wet);
   fChain->SetBranchAddress("mu_staco_MET_em_tight_photon_statusWord", &mu_staco_MET_em_tight_photon_statusWord, &b_mu_staco_MET_em_tight_photon_statusWord);
   fChain->SetBranchAddress("mu_muid_MET_em_tight_photon_n", &mu_muid_MET_em_tight_photon_n, &b_mu_muid_MET_em_tight_photon_n);
   fChain->SetBranchAddress("mu_muid_MET_em_tight_photon_wpx", &mu_muid_MET_em_tight_photon_wpx, &b_mu_muid_MET_em_tight_photon_wpx);
   fChain->SetBranchAddress("mu_muid_MET_em_tight_photon_wpy", &mu_muid_MET_em_tight_photon_wpy, &b_mu_muid_MET_em_tight_photon_wpy);
   fChain->SetBranchAddress("mu_muid_MET_em_tight_photon_wet", &mu_muid_MET_em_tight_photon_wet, &b_mu_muid_MET_em_tight_photon_wet);
   fChain->SetBranchAddress("mu_muid_MET_em_tight_photon_statusWord", &mu_muid_MET_em_tight_photon_statusWord, &b_mu_muid_MET_em_tight_photon_statusWord);
   fChain->SetBranchAddress("jet_em_tight_photon_n", &jet_em_tight_photon_n, &b_jet_em_tight_photon_n);
   fChain->SetBranchAddress("jet_em_tight_photon_wpx", &jet_em_tight_photon_wpx, &b_jet_em_tight_photon_wpx);
   fChain->SetBranchAddress("jet_em_tight_photon_wpy", &jet_em_tight_photon_wpy, &b_jet_em_tight_photon_wpy);
   fChain->SetBranchAddress("jet_em_tight_photon_wet", &jet_em_tight_photon_wet, &b_jet_em_tight_photon_wet);
   fChain->SetBranchAddress("jet_em_tight_photon_statusWord", &jet_em_tight_photon_statusWord, &b_jet_em_tight_photon_statusWord);
   fChain->SetBranchAddress("el_MET_4lc_medium_photon_n", &el_MET_4lc_medium_photon_n, &b_el_MET_4lc_medium_photon_n);
   fChain->SetBranchAddress("el_MET_4lc_medium_photon_wpx", &el_MET_4lc_medium_photon_wpx, &b_el_MET_4lc_medium_photon_wpx);
   fChain->SetBranchAddress("el_MET_4lc_medium_photon_wpy", &el_MET_4lc_medium_photon_wpy, &b_el_MET_4lc_medium_photon_wpy);
   fChain->SetBranchAddress("el_MET_4lc_medium_photon_wet", &el_MET_4lc_medium_photon_wet, &b_el_MET_4lc_medium_photon_wet);
   fChain->SetBranchAddress("el_MET_4lc_medium_photon_statusWord", &el_MET_4lc_medium_photon_statusWord, &b_el_MET_4lc_medium_photon_statusWord);
   fChain->SetBranchAddress("ph_MET_4lc_medium_photon_n", &ph_MET_4lc_medium_photon_n, &b_ph_MET_4lc_medium_photon_n);
   fChain->SetBranchAddress("ph_MET_4lc_medium_photon_wpx", &ph_MET_4lc_medium_photon_wpx, &b_ph_MET_4lc_medium_photon_wpx);
   fChain->SetBranchAddress("ph_MET_4lc_medium_photon_wpy", &ph_MET_4lc_medium_photon_wpy, &b_ph_MET_4lc_medium_photon_wpy);
   fChain->SetBranchAddress("ph_MET_4lc_medium_photon_wet", &ph_MET_4lc_medium_photon_wet, &b_ph_MET_4lc_medium_photon_wet);
   fChain->SetBranchAddress("ph_MET_4lc_medium_photon_statusWord", &ph_MET_4lc_medium_photon_statusWord, &b_ph_MET_4lc_medium_photon_statusWord);
   fChain->SetBranchAddress("mu_staco_MET_4lc_medium_photon_n", &mu_staco_MET_4lc_medium_photon_n, &b_mu_staco_MET_4lc_medium_photon_n);
   fChain->SetBranchAddress("mu_staco_MET_4lc_medium_photon_wpx", &mu_staco_MET_4lc_medium_photon_wpx, &b_mu_staco_MET_4lc_medium_photon_wpx);
   fChain->SetBranchAddress("mu_staco_MET_4lc_medium_photon_wpy", &mu_staco_MET_4lc_medium_photon_wpy, &b_mu_staco_MET_4lc_medium_photon_wpy);
   fChain->SetBranchAddress("mu_staco_MET_4lc_medium_photon_wet", &mu_staco_MET_4lc_medium_photon_wet, &b_mu_staco_MET_4lc_medium_photon_wet);
   fChain->SetBranchAddress("mu_staco_MET_4lc_medium_photon_statusWord", &mu_staco_MET_4lc_medium_photon_statusWord, &b_mu_staco_MET_4lc_medium_photon_statusWord);
   fChain->SetBranchAddress("mu_muid_MET_4lc_medium_photon_n", &mu_muid_MET_4lc_medium_photon_n, &b_mu_muid_MET_4lc_medium_photon_n);
   fChain->SetBranchAddress("mu_muid_MET_4lc_medium_photon_wpx", &mu_muid_MET_4lc_medium_photon_wpx, &b_mu_muid_MET_4lc_medium_photon_wpx);
   fChain->SetBranchAddress("mu_muid_MET_4lc_medium_photon_wpy", &mu_muid_MET_4lc_medium_photon_wpy, &b_mu_muid_MET_4lc_medium_photon_wpy);
   fChain->SetBranchAddress("mu_muid_MET_4lc_medium_photon_wet", &mu_muid_MET_4lc_medium_photon_wet, &b_mu_muid_MET_4lc_medium_photon_wet);
   fChain->SetBranchAddress("mu_muid_MET_4lc_medium_photon_statusWord", &mu_muid_MET_4lc_medium_photon_statusWord, &b_mu_muid_MET_4lc_medium_photon_statusWord);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_medium_photon_n", &jet_AntiKt4LCTopoJets_4lc_medium_photon_n, &b_jet_AntiKt4LCTopoJets_4lc_medium_photon_n);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_medium_photon_wpx", &jet_AntiKt4LCTopoJets_4lc_medium_photon_wpx, &b_jet_AntiKt4LCTopoJets_4lc_medium_photon_wpx);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_medium_photon_wpy", &jet_AntiKt4LCTopoJets_4lc_medium_photon_wpy, &b_jet_AntiKt4LCTopoJets_4lc_medium_photon_wpy);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_medium_photon_wet", &jet_AntiKt4LCTopoJets_4lc_medium_photon_wet, &b_jet_AntiKt4LCTopoJets_4lc_medium_photon_wet);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_medium_photon_statusWord", &jet_AntiKt4LCTopoJets_4lc_medium_photon_statusWord, &b_jet_AntiKt4LCTopoJets_4lc_medium_photon_statusWord);
   fChain->SetBranchAddress("el_MET_4lc_tight_photon_n", &el_MET_4lc_tight_photon_n, &b_el_MET_4lc_tight_photon_n);
   fChain->SetBranchAddress("el_MET_4lc_tight_photon_wpx", &el_MET_4lc_tight_photon_wpx, &b_el_MET_4lc_tight_photon_wpx);
   fChain->SetBranchAddress("el_MET_4lc_tight_photon_wpy", &el_MET_4lc_tight_photon_wpy, &b_el_MET_4lc_tight_photon_wpy);
   fChain->SetBranchAddress("el_MET_4lc_tight_photon_wet", &el_MET_4lc_tight_photon_wet, &b_el_MET_4lc_tight_photon_wet);
   fChain->SetBranchAddress("el_MET_4lc_tight_photon_statusWord", &el_MET_4lc_tight_photon_statusWord, &b_el_MET_4lc_tight_photon_statusWord);
   fChain->SetBranchAddress("ph_MET_4lc_tight_photon_n", &ph_MET_4lc_tight_photon_n, &b_ph_MET_4lc_tight_photon_n);
   fChain->SetBranchAddress("ph_MET_4lc_tight_photon_wpx", &ph_MET_4lc_tight_photon_wpx, &b_ph_MET_4lc_tight_photon_wpx);
   fChain->SetBranchAddress("ph_MET_4lc_tight_photon_wpy", &ph_MET_4lc_tight_photon_wpy, &b_ph_MET_4lc_tight_photon_wpy);
   fChain->SetBranchAddress("ph_MET_4lc_tight_photon_wet", &ph_MET_4lc_tight_photon_wet, &b_ph_MET_4lc_tight_photon_wet);
   fChain->SetBranchAddress("ph_MET_4lc_tight_photon_statusWord", &ph_MET_4lc_tight_photon_statusWord, &b_ph_MET_4lc_tight_photon_statusWord);
   fChain->SetBranchAddress("mu_staco_MET_4lc_tight_photon_n", &mu_staco_MET_4lc_tight_photon_n, &b_mu_staco_MET_4lc_tight_photon_n);
   fChain->SetBranchAddress("mu_staco_MET_4lc_tight_photon_wpx", &mu_staco_MET_4lc_tight_photon_wpx, &b_mu_staco_MET_4lc_tight_photon_wpx);
   fChain->SetBranchAddress("mu_staco_MET_4lc_tight_photon_wpy", &mu_staco_MET_4lc_tight_photon_wpy, &b_mu_staco_MET_4lc_tight_photon_wpy);
   fChain->SetBranchAddress("mu_staco_MET_4lc_tight_photon_wet", &mu_staco_MET_4lc_tight_photon_wet, &b_mu_staco_MET_4lc_tight_photon_wet);
   fChain->SetBranchAddress("mu_staco_MET_4lc_tight_photon_statusWord", &mu_staco_MET_4lc_tight_photon_statusWord, &b_mu_staco_MET_4lc_tight_photon_statusWord);
   fChain->SetBranchAddress("mu_muid_MET_4lc_tight_photon_n", &mu_muid_MET_4lc_tight_photon_n, &b_mu_muid_MET_4lc_tight_photon_n);
   fChain->SetBranchAddress("mu_muid_MET_4lc_tight_photon_wpx", &mu_muid_MET_4lc_tight_photon_wpx, &b_mu_muid_MET_4lc_tight_photon_wpx);
   fChain->SetBranchAddress("mu_muid_MET_4lc_tight_photon_wpy", &mu_muid_MET_4lc_tight_photon_wpy, &b_mu_muid_MET_4lc_tight_photon_wpy);
   fChain->SetBranchAddress("mu_muid_MET_4lc_tight_photon_wet", &mu_muid_MET_4lc_tight_photon_wet, &b_mu_muid_MET_4lc_tight_photon_wet);
   fChain->SetBranchAddress("mu_muid_MET_4lc_tight_photon_statusWord", &mu_muid_MET_4lc_tight_photon_statusWord, &b_mu_muid_MET_4lc_tight_photon_statusWord);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_tight_photon_n", &jet_AntiKt4LCTopoJets_4lc_tight_photon_n, &b_jet_AntiKt4LCTopoJets_4lc_tight_photon_n);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_tight_photon_wpx", &jet_AntiKt4LCTopoJets_4lc_tight_photon_wpx, &b_jet_AntiKt4LCTopoJets_4lc_tight_photon_wpx);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_tight_photon_wpy", &jet_AntiKt4LCTopoJets_4lc_tight_photon_wpy, &b_jet_AntiKt4LCTopoJets_4lc_tight_photon_wpy);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_tight_photon_wet", &jet_AntiKt4LCTopoJets_4lc_tight_photon_wet, &b_jet_AntiKt4LCTopoJets_4lc_tight_photon_wet);
   fChain->SetBranchAddress("jet_AntiKt4LCTopoJets_4lc_tight_photon_statusWord", &jet_AntiKt4LCTopoJets_4lc_tight_photon_statusWord, &b_jet_AntiKt4LCTopoJets_4lc_tight_photon_statusWord);
   fChain->SetBranchAddress("mb_n", &mb_n, &b_mb_n);
   fChain->SetBranchAddress("mb_E", &mb_E, &b_mb_E);
   fChain->SetBranchAddress("mb_eta", &mb_eta, &b_mb_eta);
   fChain->SetBranchAddress("mb_phi", &mb_phi, &b_mb_phi);
   fChain->SetBranchAddress("mb_time", &mb_time, &b_mb_time);
   fChain->SetBranchAddress("mb_quality", &mb_quality, &b_mb_quality);
   fChain->SetBranchAddress("mb_type", &mb_type, &b_mb_type);
   fChain->SetBranchAddress("mb_module", &mb_module, &b_mb_module);
   fChain->SetBranchAddress("mb_channel", &mb_channel, &b_mb_channel);
   fChain->SetBranchAddress("mbtime_timeDiff", &mbtime_timeDiff, &b_mbtime_timeDiff);
   fChain->SetBranchAddress("mbtime_timeA", &mbtime_timeA, &b_mbtime_timeA);
   fChain->SetBranchAddress("mbtime_timeC", &mbtime_timeC, &b_mbtime_timeC);
   fChain->SetBranchAddress("mbtime_countA", &mbtime_countA, &b_mbtime_countA);
   fChain->SetBranchAddress("mbtime_countC", &mbtime_countC, &b_mbtime_countC);
   fChain->SetBranchAddress("collcand_passCaloTime", &collcand_passCaloTime, &b_collcand_passCaloTime);
   fChain->SetBranchAddress("collcand_passMBTSTime", &collcand_passMBTSTime, &b_collcand_passMBTSTime);
   fChain->SetBranchAddress("collcand_passTrigger", &collcand_passTrigger, &b_collcand_passTrigger);
   fChain->SetBranchAddress("collcand_pass", &collcand_pass, &b_collcand_pass);
   fChain->SetBranchAddress("top_isElectronTriggerPassed", &top_isElectronTriggerPassed, &b_top_isElectronTriggerPassed);
   fChain->SetBranchAddress("top_isMuonTriggerPassed", &top_isMuonTriggerPassed, &b_top_isMuonTriggerPassed);
   fChain->SetBranchAddress("top_isEleMuOverlap", &top_isEleMuOverlap, &b_top_isEleMuOverlap);
   fChain->SetBranchAddress("topMET_etx", &topMET_etx, &b_topMET_etx);
   fChain->SetBranchAddress("topMET_ety", &topMET_ety, &b_topMET_ety);
   fChain->SetBranchAddress("topMET_phi", &topMET_phi, &b_topMET_phi);
   fChain->SetBranchAddress("topMET_et", &topMET_et, &b_topMET_et);
   fChain->SetBranchAddress("topMET_sumet", &topMET_sumet, &b_topMET_sumet);
   fChain->SetBranchAddress("topJet_n", &topJet_n, &b_topJet_n);
   fChain->SetBranchAddress("topJet_use", &topJet_use, &b_topJet_use);
   fChain->SetBranchAddress("topJet_inTrigger", &topJet_inTrigger, &b_topJet_inTrigger);
   fChain->SetBranchAddress("topJet_index", &topJet_index, &b_topJet_index);
   fChain->SetBranchAddress("topJet_overlap_jet_n", &topJet_overlap_jet_n, &b_topJet_overlap_jet_n);
   fChain->SetBranchAddress("topJet_overlap_jet_index", &topJet_overlap_jet_index, &b_topJet_overlap_jet_index);
   fChain->SetBranchAddress("topJet_overlap_mu_n", &topJet_overlap_mu_n, &b_topJet_overlap_mu_n);
   fChain->SetBranchAddress("topJet_overlap_mu_index", &topJet_overlap_mu_index, &b_topJet_overlap_mu_index);
   fChain->SetBranchAddress("topJet_overlap_tau_n", &topJet_overlap_tau_n, &b_topJet_overlap_tau_n);
   fChain->SetBranchAddress("topJet_overlap_tau_index", &topJet_overlap_tau_index, &b_topJet_overlap_tau_index);
   fChain->SetBranchAddress("topMu_n", &topMu_n, &b_topMu_n);
   fChain->SetBranchAddress("topMu_use", &topMu_use, &b_topMu_use);
   fChain->SetBranchAddress("topMu_inTrigger", &topMu_inTrigger, &b_topMu_inTrigger);
   fChain->SetBranchAddress("topMu_index", &topMu_index, &b_topMu_index);
   fChain->SetBranchAddress("topMu_overlap_jet_n", &topMu_overlap_jet_n, &b_topMu_overlap_jet_n);
   fChain->SetBranchAddress("topMu_overlap_jet_index", &topMu_overlap_jet_index, &b_topMu_overlap_jet_index);
   fChain->SetBranchAddress("topMu_overlap_mu_n", &topMu_overlap_mu_n, &b_topMu_overlap_mu_n);
   fChain->SetBranchAddress("topMu_overlap_mu_index", &topMu_overlap_mu_index, &b_topMu_overlap_mu_index);
   fChain->SetBranchAddress("topMu_overlap_tau_n", &topMu_overlap_tau_n, &b_topMu_overlap_tau_n);
   fChain->SetBranchAddress("topMu_overlap_tau_index", &topMu_overlap_tau_index, &b_topMu_overlap_tau_index);
   fChain->SetBranchAddress("topEl_n", &topEl_n, &b_topEl_n);
   fChain->SetBranchAddress("topEl_use", &topEl_use, &b_topEl_use);
   fChain->SetBranchAddress("topEl_inTrigger", &topEl_inTrigger, &b_topEl_inTrigger);
   fChain->SetBranchAddress("topEl_index", &topEl_index, &b_topEl_index);
   fChain->SetBranchAddress("topEl_overlap_jet_n", &topEl_overlap_jet_n, &b_topEl_overlap_jet_n);
   fChain->SetBranchAddress("topEl_overlap_jet_index", &topEl_overlap_jet_index, &b_topEl_overlap_jet_index);
   fChain->SetBranchAddress("topEl_overlap_mu_n", &topEl_overlap_mu_n, &b_topEl_overlap_mu_n);
   fChain->SetBranchAddress("topEl_overlap_mu_index", &topEl_overlap_mu_index, &b_topEl_overlap_mu_index);
   fChain->SetBranchAddress("topEl_overlap_tau_n", &topEl_overlap_tau_n, &b_topEl_overlap_tau_n);
   fChain->SetBranchAddress("topEl_overlap_tau_index", &topEl_overlap_tau_index, &b_topEl_overlap_tau_index);
   fChain->SetBranchAddress("top_phMET_etx", &top_phMET_etx, &b_top_phMET_etx);
   fChain->SetBranchAddress("top_phMET_ety", &top_phMET_ety, &b_top_phMET_ety);
   fChain->SetBranchAddress("top_phMET_phi", &top_phMET_phi, &b_top_phMET_phi);
   fChain->SetBranchAddress("top_phMET_et", &top_phMET_et, &b_top_phMET_et);
   fChain->SetBranchAddress("top_phMET_sumet", &top_phMET_sumet, &b_top_phMET_sumet);
   fChain->SetBranchAddress("top_phJet_n", &top_phJet_n, &b_top_phJet_n);
   fChain->SetBranchAddress("top_phJet_use", &top_phJet_use, &b_top_phJet_use);
   fChain->SetBranchAddress("top_phJet_inTrigger", &top_phJet_inTrigger, &b_top_phJet_inTrigger);
   fChain->SetBranchAddress("top_phJet_index", &top_phJet_index, &b_top_phJet_index);
   fChain->SetBranchAddress("top_phJet_overlap_jet_n", &top_phJet_overlap_jet_n, &b_top_phJet_overlap_jet_n);
   fChain->SetBranchAddress("top_phJet_overlap_jet_index", &top_phJet_overlap_jet_index, &b_top_phJet_overlap_jet_index);
   fChain->SetBranchAddress("top_phJet_overlap_mu_n", &top_phJet_overlap_mu_n, &b_top_phJet_overlap_mu_n);
   fChain->SetBranchAddress("top_phJet_overlap_mu_index", &top_phJet_overlap_mu_index, &b_top_phJet_overlap_mu_index);
   fChain->SetBranchAddress("top_phJet_overlap_trk_n", &top_phJet_overlap_trk_n, &b_top_phJet_overlap_trk_n);
   fChain->SetBranchAddress("top_phJet_overlap_trk_index", &top_phJet_overlap_trk_index, &b_top_phJet_overlap_trk_index);
   fChain->SetBranchAddress("top_phJet_overlap_tau_n", &top_phJet_overlap_tau_n, &b_top_phJet_overlap_tau_n);
   fChain->SetBranchAddress("top_phJet_overlap_tau_index", &top_phJet_overlap_tau_index, &b_top_phJet_overlap_tau_index);
   fChain->SetBranchAddress("top_phMu_n", &top_phMu_n, &b_top_phMu_n);
   fChain->SetBranchAddress("top_phMu_use", &top_phMu_use, &b_top_phMu_use);
   fChain->SetBranchAddress("top_phMu_inTrigger", &top_phMu_inTrigger, &b_top_phMu_inTrigger);
   fChain->SetBranchAddress("top_phMu_index", &top_phMu_index, &b_top_phMu_index);
   fChain->SetBranchAddress("top_phMu_overlap_jet_n", &top_phMu_overlap_jet_n, &b_top_phMu_overlap_jet_n);
   fChain->SetBranchAddress("top_phMu_overlap_jet_index", &top_phMu_overlap_jet_index, &b_top_phMu_overlap_jet_index);
   fChain->SetBranchAddress("top_phMu_overlap_mu_n", &top_phMu_overlap_mu_n, &b_top_phMu_overlap_mu_n);
   fChain->SetBranchAddress("top_phMu_overlap_mu_index", &top_phMu_overlap_mu_index, &b_top_phMu_overlap_mu_index);
   fChain->SetBranchAddress("top_phMu_overlap_trk_n", &top_phMu_overlap_trk_n, &b_top_phMu_overlap_trk_n);
   fChain->SetBranchAddress("top_phMu_overlap_trk_index", &top_phMu_overlap_trk_index, &b_top_phMu_overlap_trk_index);
   fChain->SetBranchAddress("top_phMu_overlap_tau_n", &top_phMu_overlap_tau_n, &b_top_phMu_overlap_tau_n);
   fChain->SetBranchAddress("top_phMu_overlap_tau_index", &top_phMu_overlap_tau_index, &b_top_phMu_overlap_tau_index);
   fChain->SetBranchAddress("top_phEl_n", &top_phEl_n, &b_top_phEl_n);
   fChain->SetBranchAddress("top_phEl_use", &top_phEl_use, &b_top_phEl_use);
   fChain->SetBranchAddress("top_phEl_inTrigger", &top_phEl_inTrigger, &b_top_phEl_inTrigger);
   fChain->SetBranchAddress("top_phEl_index", &top_phEl_index, &b_top_phEl_index);
   fChain->SetBranchAddress("top_phEl_overlap_jet_n", &top_phEl_overlap_jet_n, &b_top_phEl_overlap_jet_n);
   fChain->SetBranchAddress("top_phEl_overlap_jet_index", &top_phEl_overlap_jet_index, &b_top_phEl_overlap_jet_index);
   fChain->SetBranchAddress("top_phEl_overlap_mu_n", &top_phEl_overlap_mu_n, &b_top_phEl_overlap_mu_n);
   fChain->SetBranchAddress("top_phEl_overlap_mu_index", &top_phEl_overlap_mu_index, &b_top_phEl_overlap_mu_index);
   fChain->SetBranchAddress("top_phEl_overlap_trk_n", &top_phEl_overlap_trk_n, &b_top_phEl_overlap_trk_n);
   fChain->SetBranchAddress("top_phEl_overlap_trk_index", &top_phEl_overlap_trk_index, &b_top_phEl_overlap_trk_index);
   fChain->SetBranchAddress("top_phEl_overlap_tau_n", &top_phEl_overlap_tau_n, &b_top_phEl_overlap_tau_n);
   fChain->SetBranchAddress("top_phEl_overlap_tau_index", &top_phEl_overlap_tau_index, &b_top_phEl_overlap_tau_index);
   fChain->SetBranchAddress("top_phPh_n", &top_phPh_n, &b_top_phPh_n);
   fChain->SetBranchAddress("top_phPh_use", &top_phPh_use, &b_top_phPh_use);
   fChain->SetBranchAddress("top_phPh_inTrigger", &top_phPh_inTrigger, &b_top_phPh_inTrigger);
   fChain->SetBranchAddress("top_phPh_index", &top_phPh_index, &b_top_phPh_index);
   fChain->SetBranchAddress("top_phPh_overlap_jet_n", &top_phPh_overlap_jet_n, &b_top_phPh_overlap_jet_n);
   fChain->SetBranchAddress("top_phPh_overlap_jet_index", &top_phPh_overlap_jet_index, &b_top_phPh_overlap_jet_index);
   fChain->SetBranchAddress("top_phPh_overlap_mu_n", &top_phPh_overlap_mu_n, &b_top_phPh_overlap_mu_n);
   fChain->SetBranchAddress("top_phPh_overlap_mu_index", &top_phPh_overlap_mu_index, &b_top_phPh_overlap_mu_index);
   fChain->SetBranchAddress("top_phPh_overlap_trk_n", &top_phPh_overlap_trk_n, &b_top_phPh_overlap_trk_n);
   fChain->SetBranchAddress("top_phPh_overlap_trk_index", &top_phPh_overlap_trk_index, &b_top_phPh_overlap_trk_index);
   fChain->SetBranchAddress("top_phPh_overlap_tau_n", &top_phPh_overlap_tau_n, &b_top_phPh_overlap_tau_n);
   fChain->SetBranchAddress("top_phPh_overlap_tau_index", &top_phPh_overlap_tau_index, &b_top_phPh_overlap_tau_index);
   fChain->SetBranchAddress("trig_Nav_n", &trig_Nav_n, &b_trig_Nav_n);
   fChain->SetBranchAddress("trig_Nav_chain_ChainId", &trig_Nav_chain_ChainId, &b_trig_Nav_chain_ChainId);
   fChain->SetBranchAddress("trig_Nav_chain_RoIType", &trig_Nav_chain_RoIType, &b_trig_Nav_chain_RoIType);
   fChain->SetBranchAddress("trig_Nav_chain_RoIIndex", &trig_Nav_chain_RoIIndex, &b_trig_Nav_chain_RoIIndex);
   fChain->SetBranchAddress("trig_RoI_L2_b_n", &trig_RoI_L2_b_n, &b_trig_RoI_L2_b_n);
   fChain->SetBranchAddress("trig_RoI_L2_b_type", &trig_RoI_L2_b_type, &b_trig_RoI_L2_b_type);
   fChain->SetBranchAddress("trig_RoI_L2_b_active", &trig_RoI_L2_b_active, &b_trig_RoI_L2_b_active);
   fChain->SetBranchAddress("trig_RoI_L2_b_lastStep", &trig_RoI_L2_b_lastStep, &b_trig_RoI_L2_b_lastStep);
   fChain->SetBranchAddress("trig_RoI_L2_b_TENumber", &trig_RoI_L2_b_TENumber, &b_trig_RoI_L2_b_TENumber);
   fChain->SetBranchAddress("trig_RoI_L2_b_roiNumber", &trig_RoI_L2_b_roiNumber, &b_trig_RoI_L2_b_roiNumber);
   fChain->SetBranchAddress("trig_RoI_L2_b_Jet_ROI", &trig_RoI_L2_b_Jet_ROI, &b_trig_RoI_L2_b_Jet_ROI);
   fChain->SetBranchAddress("trig_RoI_L2_b_Jet_ROIStatus", &trig_RoI_L2_b_Jet_ROIStatus, &b_trig_RoI_L2_b_Jet_ROIStatus);
   fChain->SetBranchAddress("trig_RoI_L2_b_Muon_ROI", &trig_RoI_L2_b_Muon_ROI, &b_trig_RoI_L2_b_Muon_ROI);
   fChain->SetBranchAddress("trig_RoI_L2_b_Muon_ROIStatus", &trig_RoI_L2_b_Muon_ROIStatus, &b_trig_RoI_L2_b_Muon_ROIStatus);
   fChain->SetBranchAddress("trig_RoI_L2_b_TrigL2BjetContainer", &trig_RoI_L2_b_TrigL2BjetContainer, &b_trig_RoI_L2_b_TrigL2BjetContainer);
   fChain->SetBranchAddress("trig_RoI_L2_b_TrigL2BjetContainerStatus", &trig_RoI_L2_b_TrigL2BjetContainerStatus, &b_trig_RoI_L2_b_TrigL2BjetContainerStatus);
   fChain->SetBranchAddress("trig_RoI_L2_b_TrigInDetTrackCollection_TrigSiTrack_Jet", &trig_RoI_L2_b_TrigInDetTrackCollection_TrigSiTrack_Jet, &b_trig_RoI_L2_b_TrigInDetTrackCollection_TrigSiTrack_Jet);
   fChain->SetBranchAddress("trig_RoI_L2_b_TrigInDetTrackCollection_TrigSiTrack_JetStatus", &trig_RoI_L2_b_TrigInDetTrackCollection_TrigSiTrack_JetStatus, &b_trig_RoI_L2_b_TrigInDetTrackCollection_TrigSiTrack_JetStatus);
   fChain->SetBranchAddress("trig_RoI_L2_b_TrigInDetTrackCollection_TrigIDSCAN_Jet", &trig_RoI_L2_b_TrigInDetTrackCollection_TrigIDSCAN_Jet, &b_trig_RoI_L2_b_TrigInDetTrackCollection_TrigIDSCAN_Jet);
   fChain->SetBranchAddress("trig_RoI_L2_b_TrigInDetTrackCollection_TrigIDSCAN_JetStatus", &trig_RoI_L2_b_TrigInDetTrackCollection_TrigIDSCAN_JetStatus, &b_trig_RoI_L2_b_TrigInDetTrackCollection_TrigIDSCAN_JetStatus);
   fChain->SetBranchAddress("trig_RoI_EF_b_n", &trig_RoI_EF_b_n, &b_trig_RoI_EF_b_n);
   fChain->SetBranchAddress("trig_RoI_EF_b_type", &trig_RoI_EF_b_type, &b_trig_RoI_EF_b_type);
   fChain->SetBranchAddress("trig_RoI_EF_b_active", &trig_RoI_EF_b_active, &b_trig_RoI_EF_b_active);
   fChain->SetBranchAddress("trig_RoI_EF_b_lastStep", &trig_RoI_EF_b_lastStep, &b_trig_RoI_EF_b_lastStep);
   fChain->SetBranchAddress("trig_RoI_EF_b_TENumber", &trig_RoI_EF_b_TENumber, &b_trig_RoI_EF_b_TENumber);
   fChain->SetBranchAddress("trig_RoI_EF_b_roiNumber", &trig_RoI_EF_b_roiNumber, &b_trig_RoI_EF_b_roiNumber);
   fChain->SetBranchAddress("trig_RoI_EF_b_Jet_ROI", &trig_RoI_EF_b_Jet_ROI, &b_trig_RoI_EF_b_Jet_ROI);
   fChain->SetBranchAddress("trig_RoI_EF_b_Jet_ROIStatus", &trig_RoI_EF_b_Jet_ROIStatus, &b_trig_RoI_EF_b_Jet_ROIStatus);
   fChain->SetBranchAddress("trig_RoI_EF_b_Muon_ROI", &trig_RoI_EF_b_Muon_ROI, &b_trig_RoI_EF_b_Muon_ROI);
   fChain->SetBranchAddress("trig_RoI_EF_b_Muon_ROIStatus", &trig_RoI_EF_b_Muon_ROIStatus, &b_trig_RoI_EF_b_Muon_ROIStatus);
   fChain->SetBranchAddress("trig_RoI_EF_b_TrigEFBjetContainer", &trig_RoI_EF_b_TrigEFBjetContainer, &b_trig_RoI_EF_b_TrigEFBjetContainer);
   fChain->SetBranchAddress("trig_RoI_EF_b_TrigEFBjetContainerStatus", &trig_RoI_EF_b_TrigEFBjetContainerStatus, &b_trig_RoI_EF_b_TrigEFBjetContainerStatus);
   fChain->SetBranchAddress("trig_RoI_EF_b_Rec::TrackParticleContainer", &trig_RoI_EF_b_Rec__TrackParticleContainer, &b_trig_RoI_EF_b_Rec__TrackParticleContainer);
   fChain->SetBranchAddress("trig_RoI_EF_b_Rec::TrackParticleContainerStatus", &trig_RoI_EF_b_Rec__TrackParticleContainerStatus, &b_trig_RoI_EF_b_Rec__TrackParticleContainerStatus);
   fChain->SetBranchAddress("trig_L1_jet_n", &trig_L1_jet_n, &b_trig_L1_jet_n);
   fChain->SetBranchAddress("trig_L1_jet_eta", &trig_L1_jet_eta, &b_trig_L1_jet_eta);
   fChain->SetBranchAddress("trig_L1_jet_phi", &trig_L1_jet_phi, &b_trig_L1_jet_phi);
   fChain->SetBranchAddress("trig_L1_jet_thrNames", &trig_L1_jet_thrNames, &b_trig_L1_jet_thrNames);
   fChain->SetBranchAddress("trig_L1_jet_thrValues", &trig_L1_jet_thrValues, &b_trig_L1_jet_thrValues);
   fChain->SetBranchAddress("trig_L1_jet_thrPattern", &trig_L1_jet_thrPattern, &b_trig_L1_jet_thrPattern);
   fChain->SetBranchAddress("trig_L1_jet_et4x4", &trig_L1_jet_et4x4, &b_trig_L1_jet_et4x4);
   fChain->SetBranchAddress("trig_L1_jet_et6x6", &trig_L1_jet_et6x6, &b_trig_L1_jet_et6x6);
   fChain->SetBranchAddress("trig_L1_jet_et8x8", &trig_L1_jet_et8x8, &b_trig_L1_jet_et8x8);
   fChain->SetBranchAddress("trig_L1_jet_RoIWord", &trig_L1_jet_RoIWord, &b_trig_L1_jet_RoIWord);
   fChain->SetBranchAddress("trig_L1_TAV", &trig_L1_TAV, &b_trig_L1_TAV);
   fChain->SetBranchAddress("trig_L2_passedPhysics", &trig_L2_passedPhysics, &b_trig_L2_passedPhysics);
   fChain->SetBranchAddress("trig_EF_passedPhysics", &trig_EF_passedPhysics, &b_trig_EF_passedPhysics);
   fChain->SetBranchAddress("trig_L1_TBP", &trig_L1_TBP, &b_trig_L1_TBP);
   fChain->SetBranchAddress("trig_L1_TAP", &trig_L1_TAP, &b_trig_L1_TAP);
   fChain->SetBranchAddress("trig_L2_passedRaw", &trig_L2_passedRaw, &b_trig_L2_passedRaw);
   fChain->SetBranchAddress("trig_EF_passedRaw", &trig_EF_passedRaw, &b_trig_EF_passedRaw);
   fChain->SetBranchAddress("trig_L2_truncated", &trig_L2_truncated, &b_trig_L2_truncated);
   fChain->SetBranchAddress("trig_EF_truncated", &trig_EF_truncated, &b_trig_EF_truncated);
   fChain->SetBranchAddress("trig_L2_resurrected", &trig_L2_resurrected, &b_trig_L2_resurrected);
   fChain->SetBranchAddress("trig_EF_resurrected", &trig_EF_resurrected, &b_trig_EF_resurrected);
   fChain->SetBranchAddress("trig_L2_passedThrough", &trig_L2_passedThrough, &b_trig_L2_passedThrough);
   fChain->SetBranchAddress("trig_EF_passedThrough", &trig_EF_passedThrough, &b_trig_EF_passedThrough);
   fChain->SetBranchAddress("trig_L2_bjet_n", &trig_L2_bjet_n, &b_trig_L2_bjet_n);
   fChain->SetBranchAddress("trig_L2_bjet_roiId", &trig_L2_bjet_roiId, &b_trig_L2_bjet_roiId);
   fChain->SetBranchAddress("trig_L2_bjet_valid", &trig_L2_bjet_valid, &b_trig_L2_bjet_valid);
   fChain->SetBranchAddress("trig_L2_bjet_prmVtx", &trig_L2_bjet_prmVtx, &b_trig_L2_bjet_prmVtx);
   fChain->SetBranchAddress("trig_L2_bjet_pt", &trig_L2_bjet_pt, &b_trig_L2_bjet_pt);
   fChain->SetBranchAddress("trig_L2_bjet_eta", &trig_L2_bjet_eta, &b_trig_L2_bjet_eta);
   fChain->SetBranchAddress("trig_L2_bjet_phi", &trig_L2_bjet_phi, &b_trig_L2_bjet_phi);
   fChain->SetBranchAddress("trig_L2_bjet_xComb", &trig_L2_bjet_xComb, &b_trig_L2_bjet_xComb);
   fChain->SetBranchAddress("trig_L2_bjet_xIP1D", &trig_L2_bjet_xIP1D, &b_trig_L2_bjet_xIP1D);
   fChain->SetBranchAddress("trig_L2_bjet_xIP2D", &trig_L2_bjet_xIP2D, &b_trig_L2_bjet_xIP2D);
   fChain->SetBranchAddress("trig_L2_bjet_xIP3D", &trig_L2_bjet_xIP3D, &b_trig_L2_bjet_xIP3D);
   fChain->SetBranchAddress("trig_L2_bjet_xCHI2", &trig_L2_bjet_xCHI2, &b_trig_L2_bjet_xCHI2);
   fChain->SetBranchAddress("trig_L2_bjet_xSV", &trig_L2_bjet_xSV, &b_trig_L2_bjet_xSV);
   fChain->SetBranchAddress("trig_L2_bjet_xMVtx", &trig_L2_bjet_xMVtx, &b_trig_L2_bjet_xMVtx);
   fChain->SetBranchAddress("trig_L2_bjet_xEVtx", &trig_L2_bjet_xEVtx, &b_trig_L2_bjet_xEVtx);
   fChain->SetBranchAddress("trig_L2_bjet_xNVtx", &trig_L2_bjet_xNVtx, &b_trig_L2_bjet_xNVtx);
   fChain->SetBranchAddress("trig_L2_bjet_BSx", &trig_L2_bjet_BSx, &b_trig_L2_bjet_BSx);
   fChain->SetBranchAddress("trig_L2_bjet_BSy", &trig_L2_bjet_BSy, &b_trig_L2_bjet_BSy);
   fChain->SetBranchAddress("trig_L2_bjet_BSz", &trig_L2_bjet_BSz, &b_trig_L2_bjet_BSz);
   fChain->SetBranchAddress("trig_L2_bjet_sBSx", &trig_L2_bjet_sBSx, &b_trig_L2_bjet_sBSx);
   fChain->SetBranchAddress("trig_L2_bjet_sBSy", &trig_L2_bjet_sBSy, &b_trig_L2_bjet_sBSy);
   fChain->SetBranchAddress("trig_L2_bjet_sBSz", &trig_L2_bjet_sBSz, &b_trig_L2_bjet_sBSz);
   fChain->SetBranchAddress("trig_L2_bjet_sBSxy", &trig_L2_bjet_sBSxy, &b_trig_L2_bjet_sBSxy);
   fChain->SetBranchAddress("trig_L2_bjet_BTiltXZ", &trig_L2_bjet_BTiltXZ, &b_trig_L2_bjet_BTiltXZ);
   fChain->SetBranchAddress("trig_L2_bjet_BTiltYZ", &trig_L2_bjet_BTiltYZ, &b_trig_L2_bjet_BTiltYZ);
   fChain->SetBranchAddress("trig_L2_bjet_BSstatus", &trig_L2_bjet_BSstatus, &b_trig_L2_bjet_BSstatus);
   fChain->SetBranchAddress("trig_EF_bjet_n", &trig_EF_bjet_n, &b_trig_EF_bjet_n);
   fChain->SetBranchAddress("trig_EF_bjet_roiId", &trig_EF_bjet_roiId, &b_trig_EF_bjet_roiId);
   fChain->SetBranchAddress("trig_EF_bjet_valid", &trig_EF_bjet_valid, &b_trig_EF_bjet_valid);
   fChain->SetBranchAddress("trig_EF_bjet_prmVtx", &trig_EF_bjet_prmVtx, &b_trig_EF_bjet_prmVtx);
   fChain->SetBranchAddress("trig_EF_bjet_pt", &trig_EF_bjet_pt, &b_trig_EF_bjet_pt);
   fChain->SetBranchAddress("trig_EF_bjet_eta", &trig_EF_bjet_eta, &b_trig_EF_bjet_eta);
   fChain->SetBranchAddress("trig_EF_bjet_phi", &trig_EF_bjet_phi, &b_trig_EF_bjet_phi);
   fChain->SetBranchAddress("trig_EF_bjet_xComb", &trig_EF_bjet_xComb, &b_trig_EF_bjet_xComb);
   fChain->SetBranchAddress("trig_EF_bjet_xIP1D", &trig_EF_bjet_xIP1D, &b_trig_EF_bjet_xIP1D);
   fChain->SetBranchAddress("trig_EF_bjet_xIP2D", &trig_EF_bjet_xIP2D, &b_trig_EF_bjet_xIP2D);
   fChain->SetBranchAddress("trig_EF_bjet_xIP3D", &trig_EF_bjet_xIP3D, &b_trig_EF_bjet_xIP3D);
   fChain->SetBranchAddress("trig_EF_bjet_xCHI2", &trig_EF_bjet_xCHI2, &b_trig_EF_bjet_xCHI2);
   fChain->SetBranchAddress("trig_EF_bjet_xSV", &trig_EF_bjet_xSV, &b_trig_EF_bjet_xSV);
   fChain->SetBranchAddress("trig_EF_bjet_xMVtx", &trig_EF_bjet_xMVtx, &b_trig_EF_bjet_xMVtx);
   fChain->SetBranchAddress("trig_EF_bjet_xEVtx", &trig_EF_bjet_xEVtx, &b_trig_EF_bjet_xEVtx);
   fChain->SetBranchAddress("trig_EF_bjet_xNVtx", &trig_EF_bjet_xNVtx, &b_trig_EF_bjet_xNVtx);
   fChain->SetBranchAddress("trig_EF_pv_n", &trig_EF_pv_n, &b_trig_EF_pv_n);
   fChain->SetBranchAddress("trig_EF_pv_x", &trig_EF_pv_x, &b_trig_EF_pv_x);
   fChain->SetBranchAddress("trig_EF_pv_y", &trig_EF_pv_y, &b_trig_EF_pv_y);
   fChain->SetBranchAddress("trig_EF_pv_z", &trig_EF_pv_z, &b_trig_EF_pv_z);
   fChain->SetBranchAddress("trig_EF_pv_type", &trig_EF_pv_type, &b_trig_EF_pv_type);
   fChain->SetBranchAddress("trig_EF_pv_err_x", &trig_EF_pv_err_x, &b_trig_EF_pv_err_x);
   fChain->SetBranchAddress("trig_EF_pv_err_y", &trig_EF_pv_err_y, &b_trig_EF_pv_err_y);
   fChain->SetBranchAddress("trig_EF_pv_err_z", &trig_EF_pv_err_z, &b_trig_EF_pv_err_z);
   fChain->SetBranchAddress("trig_L1_mu_n", &trig_L1_mu_n, &b_trig_L1_mu_n);
   fChain->SetBranchAddress("trig_L1_mu_pt", &trig_L1_mu_pt, &b_trig_L1_mu_pt);
   fChain->SetBranchAddress("trig_L1_mu_eta", &trig_L1_mu_eta, &b_trig_L1_mu_eta);
   fChain->SetBranchAddress("trig_L1_mu_phi", &trig_L1_mu_phi, &b_trig_L1_mu_phi);
   fChain->SetBranchAddress("trig_L1_mu_thrName", &trig_L1_mu_thrName, &b_trig_L1_mu_thrName);
   fChain->SetBranchAddress("trig_L1_mu_thrNumber", &trig_L1_mu_thrNumber, &b_trig_L1_mu_thrNumber);
   fChain->SetBranchAddress("trig_L1_mu_RoINumber", &trig_L1_mu_RoINumber, &b_trig_L1_mu_RoINumber);
   fChain->SetBranchAddress("trig_L1_mu_sectorAddress", &trig_L1_mu_sectorAddress, &b_trig_L1_mu_sectorAddress);
   fChain->SetBranchAddress("trig_L1_mu_firstCandidate", &trig_L1_mu_firstCandidate, &b_trig_L1_mu_firstCandidate);
   fChain->SetBranchAddress("trig_L1_mu_moreCandInRoI", &trig_L1_mu_moreCandInRoI, &b_trig_L1_mu_moreCandInRoI);
   fChain->SetBranchAddress("trig_L1_mu_moreCandInSector", &trig_L1_mu_moreCandInSector, &b_trig_L1_mu_moreCandInSector);
   fChain->SetBranchAddress("trig_L1_mu_source", &trig_L1_mu_source, &b_trig_L1_mu_source);
   fChain->SetBranchAddress("trig_L1_mu_hemisphere", &trig_L1_mu_hemisphere, &b_trig_L1_mu_hemisphere);
   fChain->SetBranchAddress("trig_L1_mu_charge", &trig_L1_mu_charge, &b_trig_L1_mu_charge);
   fChain->SetBranchAddress("trig_L1_mu_vetoed", &trig_L1_mu_vetoed, &b_trig_L1_mu_vetoed);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_n", &trig_L2_combmuonfeature_n, &b_trig_L2_combmuonfeature_n);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_pt", &trig_L2_combmuonfeature_pt, &b_trig_L2_combmuonfeature_pt);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_eta", &trig_L2_combmuonfeature_eta, &b_trig_L2_combmuonfeature_eta);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_phi", &trig_L2_combmuonfeature_phi, &b_trig_L2_combmuonfeature_phi);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_sigma_pt", &trig_L2_combmuonfeature_sigma_pt, &b_trig_L2_combmuonfeature_sigma_pt);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu10", &trig_L2_combmuonfeature_L2_2mu10, &b_trig_L2_combmuonfeature_L2_2mu10);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu10_empty", &trig_L2_combmuonfeature_L2_2mu10_empty, &b_trig_L2_combmuonfeature_L2_2mu10_empty);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu10_loose", &trig_L2_combmuonfeature_L2_2mu10_loose, &b_trig_L2_combmuonfeature_L2_2mu10_loose);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu10_loose_empty", &trig_L2_combmuonfeature_L2_2mu10_loose_empty, &b_trig_L2_combmuonfeature_L2_2mu10_loose_empty);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu10_loose_noOvlpRm", &trig_L2_combmuonfeature_L2_2mu10_loose_noOvlpRm, &b_trig_L2_combmuonfeature_L2_2mu10_loose_noOvlpRm);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu13_Zmumu_IDTrkNoCut", &trig_L2_combmuonfeature_L2_2mu13_Zmumu_IDTrkNoCut, &b_trig_L2_combmuonfeature_L2_2mu13_Zmumu_IDTrkNoCut);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu4", &trig_L2_combmuonfeature_L2_2mu4, &b_trig_L2_combmuonfeature_L2_2mu4);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu4_Bmumu", &trig_L2_combmuonfeature_L2_2mu4_Bmumu, &b_trig_L2_combmuonfeature_L2_2mu4_Bmumu);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu4_Bmumux", &trig_L2_combmuonfeature_L2_2mu4_Bmumux, &b_trig_L2_combmuonfeature_L2_2mu4_Bmumux);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu4_DiMu", &trig_L2_combmuonfeature_L2_2mu4_DiMu, &b_trig_L2_combmuonfeature_L2_2mu4_DiMu);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu4_DiMu_DY", &trig_L2_combmuonfeature_L2_2mu4_DiMu_DY, &b_trig_L2_combmuonfeature_L2_2mu4_DiMu_DY);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu4_DiMu_DY20", &trig_L2_combmuonfeature_L2_2mu4_DiMu_DY20, &b_trig_L2_combmuonfeature_L2_2mu4_DiMu_DY20);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu4_DiMu_DY_noVtx_noOS", &trig_L2_combmuonfeature_L2_2mu4_DiMu_DY_noVtx_noOS, &b_trig_L2_combmuonfeature_L2_2mu4_DiMu_DY_noVtx_noOS);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu4_DiMu_SiTrk", &trig_L2_combmuonfeature_L2_2mu4_DiMu_SiTrk, &b_trig_L2_combmuonfeature_L2_2mu4_DiMu_SiTrk);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu4_DiMu_noVtx_noOS", &trig_L2_combmuonfeature_L2_2mu4_DiMu_noVtx_noOS, &b_trig_L2_combmuonfeature_L2_2mu4_DiMu_noVtx_noOS);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu4_Jpsimumu", &trig_L2_combmuonfeature_L2_2mu4_Jpsimumu, &b_trig_L2_combmuonfeature_L2_2mu4_Jpsimumu);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu4_Jpsimumu_IDTrkNoCut", &trig_L2_combmuonfeature_L2_2mu4_Jpsimumu_IDTrkNoCut, &b_trig_L2_combmuonfeature_L2_2mu4_Jpsimumu_IDTrkNoCut);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu4_Upsimumu", &trig_L2_combmuonfeature_L2_2mu4_Upsimumu, &b_trig_L2_combmuonfeature_L2_2mu4_Upsimumu);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu4i_DiMu_DY", &trig_L2_combmuonfeature_L2_2mu4i_DiMu_DY, &b_trig_L2_combmuonfeature_L2_2mu4i_DiMu_DY);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu6", &trig_L2_combmuonfeature_L2_2mu6, &b_trig_L2_combmuonfeature_L2_2mu6);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu6_DiMu", &trig_L2_combmuonfeature_L2_2mu6_DiMu, &b_trig_L2_combmuonfeature_L2_2mu6_DiMu);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu6_MSonly_g10_loose", &trig_L2_combmuonfeature_L2_2mu6_MSonly_g10_loose, &b_trig_L2_combmuonfeature_L2_2mu6_MSonly_g10_loose);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu6_MSonly_g10_loose_nonfilled", &trig_L2_combmuonfeature_L2_2mu6_MSonly_g10_loose_nonfilled, &b_trig_L2_combmuonfeature_L2_2mu6_MSonly_g10_loose_nonfilled);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_2mu6_NL", &trig_L2_combmuonfeature_L2_2mu6_NL, &b_trig_L2_combmuonfeature_L2_2mu6_NL);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu0_cal_empty", &trig_L2_combmuonfeature_L2_mu0_cal_empty, &b_trig_L2_combmuonfeature_L2_mu0_cal_empty);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu0_empty_NoAlg", &trig_L2_combmuonfeature_L2_mu0_empty_NoAlg, &b_trig_L2_combmuonfeature_L2_mu0_empty_NoAlg);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu0_firstempty_NoAlg", &trig_L2_combmuonfeature_L2_mu0_firstempty_NoAlg, &b_trig_L2_combmuonfeature_L2_mu0_firstempty_NoAlg);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu0_unpaired_iso_NoAlg", &trig_L2_combmuonfeature_L2_mu0_unpaired_iso_NoAlg, &b_trig_L2_combmuonfeature_L2_mu0_unpaired_iso_NoAlg);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu10", &trig_L2_combmuonfeature_L2_mu10, &b_trig_L2_combmuonfeature_L2_mu10);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu10_Jpsimumu", &trig_L2_combmuonfeature_L2_mu10_Jpsimumu, &b_trig_L2_combmuonfeature_L2_mu10_Jpsimumu);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu10_NL", &trig_L2_combmuonfeature_L2_mu10_NL, &b_trig_L2_combmuonfeature_L2_mu10_NL);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu10_Upsimumu_FS", &trig_L2_combmuonfeature_L2_mu10_Upsimumu_FS, &b_trig_L2_combmuonfeature_L2_mu10_Upsimumu_FS);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu10_Upsimumu_tight_FS", &trig_L2_combmuonfeature_L2_mu10_Upsimumu_tight_FS, &b_trig_L2_combmuonfeature_L2_mu10_Upsimumu_tight_FS);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu10_cal", &trig_L2_combmuonfeature_L2_mu10_cal, &b_trig_L2_combmuonfeature_L2_mu10_cal);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu10_cal_medium", &trig_L2_combmuonfeature_L2_mu10_cal_medium, &b_trig_L2_combmuonfeature_L2_mu10_cal_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu10_loose", &trig_L2_combmuonfeature_L2_mu10_loose, &b_trig_L2_combmuonfeature_L2_mu10_loose);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu10_muCombTag_NoEF", &trig_L2_combmuonfeature_L2_mu10_muCombTag_NoEF, &b_trig_L2_combmuonfeature_L2_mu10_muCombTag_NoEF);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu11_empty_NoAlg", &trig_L2_combmuonfeature_L2_mu11_empty_NoAlg, &b_trig_L2_combmuonfeature_L2_mu11_empty_NoAlg);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu13", &trig_L2_combmuonfeature_L2_mu13, &b_trig_L2_combmuonfeature_L2_mu13);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu13_MG", &trig_L2_combmuonfeature_L2_mu13_MG, &b_trig_L2_combmuonfeature_L2_mu13_MG);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu13_muCombTag_NoEF", &trig_L2_combmuonfeature_L2_mu13_muCombTag_NoEF, &b_trig_L2_combmuonfeature_L2_mu13_muCombTag_NoEF);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu15", &trig_L2_combmuonfeature_L2_mu15, &b_trig_L2_combmuonfeature_L2_mu15);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu15_medium", &trig_L2_combmuonfeature_L2_mu15_medium, &b_trig_L2_combmuonfeature_L2_mu15_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu15_tight", &trig_L2_combmuonfeature_L2_mu15_tight, &b_trig_L2_combmuonfeature_L2_mu15_tight);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu15_xe20_noMu", &trig_L2_combmuonfeature_L2_mu15_xe20_noMu, &b_trig_L2_combmuonfeature_L2_mu15_xe20_noMu);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu15i", &trig_L2_combmuonfeature_L2_mu15i, &b_trig_L2_combmuonfeature_L2_mu15i);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu15i_medium", &trig_L2_combmuonfeature_L2_mu15i_medium, &b_trig_L2_combmuonfeature_L2_mu15i_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu18", &trig_L2_combmuonfeature_L2_mu18, &b_trig_L2_combmuonfeature_L2_mu18);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu18_L1J10", &trig_L2_combmuonfeature_L2_mu18_L1J10, &b_trig_L2_combmuonfeature_L2_mu18_L1J10);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu18_MG", &trig_L2_combmuonfeature_L2_mu18_MG, &b_trig_L2_combmuonfeature_L2_mu18_MG);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu18_MG_L1J10", &trig_L2_combmuonfeature_L2_mu18_MG_L1J10, &b_trig_L2_combmuonfeature_L2_mu18_MG_L1J10);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu18_MG_medium", &trig_L2_combmuonfeature_L2_mu18_MG_medium, &b_trig_L2_combmuonfeature_L2_mu18_MG_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu18_medium", &trig_L2_combmuonfeature_L2_mu18_medium, &b_trig_L2_combmuonfeature_L2_mu18_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu20", &trig_L2_combmuonfeature_L2_mu20, &b_trig_L2_combmuonfeature_L2_mu20);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu20_IDTrkNoCut", &trig_L2_combmuonfeature_L2_mu20_IDTrkNoCut, &b_trig_L2_combmuonfeature_L2_mu20_IDTrkNoCut);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu20_MG", &trig_L2_combmuonfeature_L2_mu20_MG, &b_trig_L2_combmuonfeature_L2_mu20_MG);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu20_MG_medium", &trig_L2_combmuonfeature_L2_mu20_MG_medium, &b_trig_L2_combmuonfeature_L2_mu20_MG_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu20_empty", &trig_L2_combmuonfeature_L2_mu20_empty, &b_trig_L2_combmuonfeature_L2_mu20_empty);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu20_medium", &trig_L2_combmuonfeature_L2_mu20_medium, &b_trig_L2_combmuonfeature_L2_mu20_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu20_muCombTag_NoEF", &trig_L2_combmuonfeature_L2_mu20_muCombTag_NoEF, &b_trig_L2_combmuonfeature_L2_mu20_muCombTag_NoEF);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu20_tight", &trig_L2_combmuonfeature_L2_mu20_tight, &b_trig_L2_combmuonfeature_L2_mu20_tight);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu20i", &trig_L2_combmuonfeature_L2_mu20i, &b_trig_L2_combmuonfeature_L2_mu20i);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu20i_medium", &trig_L2_combmuonfeature_L2_mu20i_medium, &b_trig_L2_combmuonfeature_L2_mu20i_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu22", &trig_L2_combmuonfeature_L2_mu22, &b_trig_L2_combmuonfeature_L2_mu22);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu22_MG", &trig_L2_combmuonfeature_L2_mu22_MG, &b_trig_L2_combmuonfeature_L2_mu22_MG);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu22_MG_medium", &trig_L2_combmuonfeature_L2_mu22_MG_medium, &b_trig_L2_combmuonfeature_L2_mu22_MG_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu22_medium", &trig_L2_combmuonfeature_L2_mu22_medium, &b_trig_L2_combmuonfeature_L2_mu22_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu24_MG_medium", &trig_L2_combmuonfeature_L2_mu24_MG_medium, &b_trig_L2_combmuonfeature_L2_mu24_MG_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu24_MG_tight", &trig_L2_combmuonfeature_L2_mu24_MG_tight, &b_trig_L2_combmuonfeature_L2_mu24_MG_tight);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu24_medium", &trig_L2_combmuonfeature_L2_mu24_medium, &b_trig_L2_combmuonfeature_L2_mu24_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu24_tight", &trig_L2_combmuonfeature_L2_mu24_tight, &b_trig_L2_combmuonfeature_L2_mu24_tight);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu30_MG_medium", &trig_L2_combmuonfeature_L2_mu30_MG_medium, &b_trig_L2_combmuonfeature_L2_mu30_MG_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu30_MG_tight", &trig_L2_combmuonfeature_L2_mu30_MG_tight, &b_trig_L2_combmuonfeature_L2_mu30_MG_tight);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu30_medium", &trig_L2_combmuonfeature_L2_mu30_medium, &b_trig_L2_combmuonfeature_L2_mu30_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu30_tight", &trig_L2_combmuonfeature_L2_mu30_tight, &b_trig_L2_combmuonfeature_L2_mu30_tight);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4", &trig_L2_combmuonfeature_L2_mu4, &b_trig_L2_combmuonfeature_L2_mu4);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu40_MSonly_barrel", &trig_L2_combmuonfeature_L2_mu40_MSonly_barrel, &b_trig_L2_combmuonfeature_L2_mu40_MSonly_barrel);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu40_MSonly_barrel_medium", &trig_L2_combmuonfeature_L2_mu40_MSonly_barrel_medium, &b_trig_L2_combmuonfeature_L2_mu40_MSonly_barrel_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu40_MSonly_empty", &trig_L2_combmuonfeature_L2_mu40_MSonly_empty, &b_trig_L2_combmuonfeature_L2_mu40_MSonly_empty);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu40_MSonly_tight", &trig_L2_combmuonfeature_L2_mu40_MSonly_tight, &b_trig_L2_combmuonfeature_L2_mu40_MSonly_tight);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu40_MSonly_tight_L1MU11", &trig_L2_combmuonfeature_L2_mu40_MSonly_tight_L1MU11, &b_trig_L2_combmuonfeature_L2_mu40_MSonly_tight_L1MU11);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu40_MSonly_tighter", &trig_L2_combmuonfeature_L2_mu40_MSonly_tighter, &b_trig_L2_combmuonfeature_L2_mu40_MSonly_tighter);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu40_slow", &trig_L2_combmuonfeature_L2_mu40_slow, &b_trig_L2_combmuonfeature_L2_mu40_slow);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu40_slow_empty", &trig_L2_combmuonfeature_L2_mu40_slow_empty, &b_trig_L2_combmuonfeature_L2_mu40_slow_empty);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu40_slow_medium", &trig_L2_combmuonfeature_L2_mu40_slow_medium, &b_trig_L2_combmuonfeature_L2_mu40_slow_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu40_slow_outOfTime", &trig_L2_combmuonfeature_L2_mu40_slow_outOfTime, &b_trig_L2_combmuonfeature_L2_mu40_slow_outOfTime);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu40_slow_outOfTime_medium", &trig_L2_combmuonfeature_L2_mu40_slow_outOfTime_medium, &b_trig_L2_combmuonfeature_L2_mu40_slow_outOfTime_medium);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_DiMu", &trig_L2_combmuonfeature_L2_mu4_DiMu, &b_trig_L2_combmuonfeature_L2_mu4_DiMu);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_DiMu_FS_noOS", &trig_L2_combmuonfeature_L2_mu4_DiMu_FS_noOS, &b_trig_L2_combmuonfeature_L2_mu4_DiMu_FS_noOS);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_Jpsimumu", &trig_L2_combmuonfeature_L2_mu4_Jpsimumu, &b_trig_L2_combmuonfeature_L2_mu4_Jpsimumu);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_L1J10_matched", &trig_L2_combmuonfeature_L2_mu4_L1J10_matched, &b_trig_L2_combmuonfeature_L2_mu4_L1J10_matched);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_L1J15_matched", &trig_L2_combmuonfeature_L2_mu4_L1J15_matched, &b_trig_L2_combmuonfeature_L2_mu4_L1J15_matched);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_L1J20_matched", &trig_L2_combmuonfeature_L2_mu4_L1J20_matched, &b_trig_L2_combmuonfeature_L2_mu4_L1J20_matched);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_L1J30_matched", &trig_L2_combmuonfeature_L2_mu4_L1J30_matched, &b_trig_L2_combmuonfeature_L2_mu4_L1J30_matched);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_L1J50_matched", &trig_L2_combmuonfeature_L2_mu4_L1J50_matched, &b_trig_L2_combmuonfeature_L2_mu4_L1J50_matched);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_L1J75_matched", &trig_L2_combmuonfeature_L2_mu4_L1J75_matched, &b_trig_L2_combmuonfeature_L2_mu4_L1J75_matched);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_L1MU11_MSonly_cosmic", &trig_L2_combmuonfeature_L2_mu4_L1MU11_MSonly_cosmic, &b_trig_L2_combmuonfeature_L2_mu4_L1MU11_MSonly_cosmic);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_L1MU11_cosmic", &trig_L2_combmuonfeature_L2_mu4_L1MU11_cosmic, &b_trig_L2_combmuonfeature_L2_mu4_L1MU11_cosmic);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_MSonly_cosmic", &trig_L2_combmuonfeature_L2_mu4_MSonly_cosmic, &b_trig_L2_combmuonfeature_L2_mu4_MSonly_cosmic);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_Trk_Jpsi", &trig_L2_combmuonfeature_L2_mu4_Trk_Jpsi, &b_trig_L2_combmuonfeature_L2_mu4_Trk_Jpsi);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_Trk_Upsi_FS", &trig_L2_combmuonfeature_L2_mu4_Trk_Upsi_FS, &b_trig_L2_combmuonfeature_L2_mu4_Trk_Upsi_FS);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_Upsimumu_FS", &trig_L2_combmuonfeature_L2_mu4_Upsimumu_FS, &b_trig_L2_combmuonfeature_L2_mu4_Upsimumu_FS);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_Upsimumu_SiTrk_FS", &trig_L2_combmuonfeature_L2_mu4_Upsimumu_SiTrk_FS, &b_trig_L2_combmuonfeature_L2_mu4_Upsimumu_SiTrk_FS);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_Upsimumu_tight_FS", &trig_L2_combmuonfeature_L2_mu4_Upsimumu_tight_FS, &b_trig_L2_combmuonfeature_L2_mu4_Upsimumu_tight_FS);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_cosmic", &trig_L2_combmuonfeature_L2_mu4_cosmic, &b_trig_L2_combmuonfeature_L2_mu4_cosmic);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_j10_a4tc_EFFS", &trig_L2_combmuonfeature_L2_mu4_j10_a4tc_EFFS, &b_trig_L2_combmuonfeature_L2_mu4_j10_a4tc_EFFS);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_j40_xe20_loose_noMu", &trig_L2_combmuonfeature_L2_mu4_j40_xe20_loose_noMu, &b_trig_L2_combmuonfeature_L2_mu4_j40_xe20_loose_noMu);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4_j95_L1matched", &trig_L2_combmuonfeature_L2_mu4_j95_L1matched, &b_trig_L2_combmuonfeature_L2_mu4_j95_L1matched);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4imu6i_DiMu_DY", &trig_L2_combmuonfeature_L2_mu4imu6i_DiMu_DY, &b_trig_L2_combmuonfeature_L2_mu4imu6i_DiMu_DY);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4imu6i_DiMu_DY14_noVtx_noOS", &trig_L2_combmuonfeature_L2_mu4imu6i_DiMu_DY14_noVtx_noOS, &b_trig_L2_combmuonfeature_L2_mu4imu6i_DiMu_DY14_noVtx_noOS);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4mu6_Bmumu", &trig_L2_combmuonfeature_L2_mu4mu6_Bmumu, &b_trig_L2_combmuonfeature_L2_mu4mu6_Bmumu);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4mu6_Bmumux", &trig_L2_combmuonfeature_L2_mu4mu6_Bmumux, &b_trig_L2_combmuonfeature_L2_mu4mu6_Bmumux);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4mu6_DiMu", &trig_L2_combmuonfeature_L2_mu4mu6_DiMu, &b_trig_L2_combmuonfeature_L2_mu4mu6_DiMu);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4mu6_DiMu_DY20", &trig_L2_combmuonfeature_L2_mu4mu6_DiMu_DY20, &b_trig_L2_combmuonfeature_L2_mu4mu6_DiMu_DY20);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4mu6_DiMu_noVtx_noOS", &trig_L2_combmuonfeature_L2_mu4mu6_DiMu_noVtx_noOS, &b_trig_L2_combmuonfeature_L2_mu4mu6_DiMu_noVtx_noOS);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4mu6_Jpsimumu", &trig_L2_combmuonfeature_L2_mu4mu6_Jpsimumu, &b_trig_L2_combmuonfeature_L2_mu4mu6_Jpsimumu);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu4mu6_Upsimumu", &trig_L2_combmuonfeature_L2_mu4mu6_Upsimumu, &b_trig_L2_combmuonfeature_L2_mu4mu6_Upsimumu);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu6", &trig_L2_combmuonfeature_L2_mu6, &b_trig_L2_combmuonfeature_L2_mu6);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu6_DiMu_noOS", &trig_L2_combmuonfeature_L2_mu6_DiMu_noOS, &b_trig_L2_combmuonfeature_L2_mu6_DiMu_noOS);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu6_Jpsimumu", &trig_L2_combmuonfeature_L2_mu6_Jpsimumu, &b_trig_L2_combmuonfeature_L2_mu6_Jpsimumu);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu6_Jpsimumu_SiTrk", &trig_L2_combmuonfeature_L2_mu6_Jpsimumu_SiTrk, &b_trig_L2_combmuonfeature_L2_mu6_Jpsimumu_SiTrk);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu6_Jpsimumu_tight", &trig_L2_combmuonfeature_L2_mu6_Jpsimumu_tight, &b_trig_L2_combmuonfeature_L2_mu6_Jpsimumu_tight);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_L2_mu6_Trk_Jpsi_loose", &trig_L2_combmuonfeature_L2_mu6_Trk_Jpsi_loose, &b_trig_L2_combmuonfeature_L2_mu6_Trk_Jpsi_loose);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_mf_pt", &trig_L2_combmuonfeature_mf_pt, &b_trig_L2_combmuonfeature_mf_pt);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_mf_eta", &trig_L2_combmuonfeature_mf_eta, &b_trig_L2_combmuonfeature_mf_eta);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_mf_phi", &trig_L2_combmuonfeature_mf_phi, &b_trig_L2_combmuonfeature_mf_phi);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_mf_mf", &trig_L2_combmuonfeature_mf_mf, &b_trig_L2_combmuonfeature_mf_mf);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_idtrk_algorithmId", &trig_L2_combmuonfeature_idtrk_algorithmId, &b_trig_L2_combmuonfeature_idtrk_algorithmId);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_idtrk_trackStatus", &trig_L2_combmuonfeature_idtrk_trackStatus, &b_trig_L2_combmuonfeature_idtrk_trackStatus);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_idtrk_chi2Ndof", &trig_L2_combmuonfeature_idtrk_chi2Ndof, &b_trig_L2_combmuonfeature_idtrk_chi2Ndof);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_idtrk_nStrawHits", &trig_L2_combmuonfeature_idtrk_nStrawHits, &b_trig_L2_combmuonfeature_idtrk_nStrawHits);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_idtrk_nHighThrHits", &trig_L2_combmuonfeature_idtrk_nHighThrHits, &b_trig_L2_combmuonfeature_idtrk_nHighThrHits);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_idtrk_nPixelSpacePoints", &trig_L2_combmuonfeature_idtrk_nPixelSpacePoints, &b_trig_L2_combmuonfeature_idtrk_nPixelSpacePoints);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_idtrk_nSCT_SpacePoints", &trig_L2_combmuonfeature_idtrk_nSCT_SpacePoints, &b_trig_L2_combmuonfeature_idtrk_nSCT_SpacePoints);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_idtrk_idtrkfitpar_a0", &trig_L2_combmuonfeature_idtrk_idtrkfitpar_a0, &b_trig_L2_combmuonfeature_idtrk_idtrkfitpar_a0);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_idtrk_idtrkfitpar_z0", &trig_L2_combmuonfeature_idtrk_idtrkfitpar_z0, &b_trig_L2_combmuonfeature_idtrk_idtrkfitpar_z0);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_idtrk_idtrkfitpar_phi0", &trig_L2_combmuonfeature_idtrk_idtrkfitpar_phi0, &b_trig_L2_combmuonfeature_idtrk_idtrkfitpar_phi0);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_idtrk_idtrkfitpar_eta", &trig_L2_combmuonfeature_idtrk_idtrkfitpar_eta, &b_trig_L2_combmuonfeature_idtrk_idtrkfitpar_eta);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_idtrk_idtrkfitpar_pt", &trig_L2_combmuonfeature_idtrk_idtrkfitpar_pt, &b_trig_L2_combmuonfeature_idtrk_idtrkfitpar_pt);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_idtrk_idtrkfitpar_hasidtrkfitpar", &trig_L2_combmuonfeature_idtrk_idtrkfitpar_hasidtrkfitpar, &b_trig_L2_combmuonfeature_idtrk_idtrkfitpar_hasidtrkfitpar);
   fChain->SetBranchAddress("trig_L2_combmuonfeature_idtrk_hasidtrk", &trig_L2_combmuonfeature_idtrk_hasidtrk, &b_trig_L2_combmuonfeature_idtrk_hasidtrk);
   fChain->SetBranchAddress("trig_EF_trigmuonef_n", &trig_EF_trigmuonef_n, &b_trig_EF_trigmuonef_n);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu10", &trig_EF_trigmuonef_EF_2mu10, &b_trig_EF_trigmuonef_EF_2mu10);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu10_empty", &trig_EF_trigmuonef_EF_2mu10_empty, &b_trig_EF_trigmuonef_EF_2mu10_empty);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu10_loose", &trig_EF_trigmuonef_EF_2mu10_loose, &b_trig_EF_trigmuonef_EF_2mu10_loose);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu10_loose_empty", &trig_EF_trigmuonef_EF_2mu10_loose_empty, &b_trig_EF_trigmuonef_EF_2mu10_loose_empty);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu10_loose_noOvlpRm", &trig_EF_trigmuonef_EF_2mu10_loose_noOvlpRm, &b_trig_EF_trigmuonef_EF_2mu10_loose_noOvlpRm);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu13_Zmumu_IDTrkNoCut", &trig_EF_trigmuonef_EF_2mu13_Zmumu_IDTrkNoCut, &b_trig_EF_trigmuonef_EF_2mu13_Zmumu_IDTrkNoCut);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu4", &trig_EF_trigmuonef_EF_2mu4, &b_trig_EF_trigmuonef_EF_2mu4);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu4_Bmumu", &trig_EF_trigmuonef_EF_2mu4_Bmumu, &b_trig_EF_trigmuonef_EF_2mu4_Bmumu);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu4_Bmumux", &trig_EF_trigmuonef_EF_2mu4_Bmumux, &b_trig_EF_trigmuonef_EF_2mu4_Bmumux);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu4_DiMu", &trig_EF_trigmuonef_EF_2mu4_DiMu, &b_trig_EF_trigmuonef_EF_2mu4_DiMu);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu4_DiMu_DY", &trig_EF_trigmuonef_EF_2mu4_DiMu_DY, &b_trig_EF_trigmuonef_EF_2mu4_DiMu_DY);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu4_DiMu_DY20", &trig_EF_trigmuonef_EF_2mu4_DiMu_DY20, &b_trig_EF_trigmuonef_EF_2mu4_DiMu_DY20);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu4_DiMu_DY_noVtx_noOS", &trig_EF_trigmuonef_EF_2mu4_DiMu_DY_noVtx_noOS, &b_trig_EF_trigmuonef_EF_2mu4_DiMu_DY_noVtx_noOS);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu4_DiMu_SiTrk", &trig_EF_trigmuonef_EF_2mu4_DiMu_SiTrk, &b_trig_EF_trigmuonef_EF_2mu4_DiMu_SiTrk);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu4_DiMu_noVtx_noOS", &trig_EF_trigmuonef_EF_2mu4_DiMu_noVtx_noOS, &b_trig_EF_trigmuonef_EF_2mu4_DiMu_noVtx_noOS);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu4_Jpsimumu", &trig_EF_trigmuonef_EF_2mu4_Jpsimumu, &b_trig_EF_trigmuonef_EF_2mu4_Jpsimumu);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu4_Jpsimumu_IDTrkNoCut", &trig_EF_trigmuonef_EF_2mu4_Jpsimumu_IDTrkNoCut, &b_trig_EF_trigmuonef_EF_2mu4_Jpsimumu_IDTrkNoCut);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu4_Upsimumu", &trig_EF_trigmuonef_EF_2mu4_Upsimumu, &b_trig_EF_trigmuonef_EF_2mu4_Upsimumu);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu4i_DiMu_DY", &trig_EF_trigmuonef_EF_2mu4i_DiMu_DY, &b_trig_EF_trigmuonef_EF_2mu4i_DiMu_DY);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu6", &trig_EF_trigmuonef_EF_2mu6, &b_trig_EF_trigmuonef_EF_2mu6);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu6_DiMu", &trig_EF_trigmuonef_EF_2mu6_DiMu, &b_trig_EF_trigmuonef_EF_2mu6_DiMu);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu6_MSonly_g10_loose", &trig_EF_trigmuonef_EF_2mu6_MSonly_g10_loose, &b_trig_EF_trigmuonef_EF_2mu6_MSonly_g10_loose);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu6_MSonly_g10_loose_nonfilled", &trig_EF_trigmuonef_EF_2mu6_MSonly_g10_loose_nonfilled, &b_trig_EF_trigmuonef_EF_2mu6_MSonly_g10_loose_nonfilled);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_2mu6_NL", &trig_EF_trigmuonef_EF_2mu6_NL, &b_trig_EF_trigmuonef_EF_2mu6_NL);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu0_empty_NoAlg", &trig_EF_trigmuonef_EF_mu0_empty_NoAlg, &b_trig_EF_trigmuonef_EF_mu0_empty_NoAlg);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu0_firstempty_NoAlg", &trig_EF_trigmuonef_EF_mu0_firstempty_NoAlg, &b_trig_EF_trigmuonef_EF_mu0_firstempty_NoAlg);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu0_unpaired_iso_NoAlg", &trig_EF_trigmuonef_EF_mu0_unpaired_iso_NoAlg, &b_trig_EF_trigmuonef_EF_mu0_unpaired_iso_NoAlg);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu10", &trig_EF_trigmuonef_EF_mu10, &b_trig_EF_trigmuonef_EF_mu10);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu10_Jpsimumu", &trig_EF_trigmuonef_EF_mu10_Jpsimumu, &b_trig_EF_trigmuonef_EF_mu10_Jpsimumu);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu10_NL", &trig_EF_trigmuonef_EF_mu10_NL, &b_trig_EF_trigmuonef_EF_mu10_NL);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu10_Upsimumu_FS", &trig_EF_trigmuonef_EF_mu10_Upsimumu_FS, &b_trig_EF_trigmuonef_EF_mu10_Upsimumu_FS);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu10_Upsimumu_tight_FS", &trig_EF_trigmuonef_EF_mu10_Upsimumu_tight_FS, &b_trig_EF_trigmuonef_EF_mu10_Upsimumu_tight_FS);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu10_loose", &trig_EF_trigmuonef_EF_mu10_loose, &b_trig_EF_trigmuonef_EF_mu10_loose);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu10_muCombTag_NoEF", &trig_EF_trigmuonef_EF_mu10_muCombTag_NoEF, &b_trig_EF_trigmuonef_EF_mu10_muCombTag_NoEF);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu11_empty_NoAlg", &trig_EF_trigmuonef_EF_mu11_empty_NoAlg, &b_trig_EF_trigmuonef_EF_mu11_empty_NoAlg);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu13", &trig_EF_trigmuonef_EF_mu13, &b_trig_EF_trigmuonef_EF_mu13);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu13_MG", &trig_EF_trigmuonef_EF_mu13_MG, &b_trig_EF_trigmuonef_EF_mu13_MG);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu13_muCombTag_NoEF", &trig_EF_trigmuonef_EF_mu13_muCombTag_NoEF, &b_trig_EF_trigmuonef_EF_mu13_muCombTag_NoEF);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu15", &trig_EF_trigmuonef_EF_mu15, &b_trig_EF_trigmuonef_EF_mu15);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu15_mu10_EFFS", &trig_EF_trigmuonef_EF_mu15_mu10_EFFS, &b_trig_EF_trigmuonef_EF_mu15_mu10_EFFS);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu15_mu10_EFFS_medium", &trig_EF_trigmuonef_EF_mu15_mu10_EFFS_medium, &b_trig_EF_trigmuonef_EF_mu15_mu10_EFFS_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu15_mu10_EFFS_tight", &trig_EF_trigmuonef_EF_mu15_mu10_EFFS_tight, &b_trig_EF_trigmuonef_EF_mu15_mu10_EFFS_tight);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu15_xe30_noMu", &trig_EF_trigmuonef_EF_mu15_xe30_noMu, &b_trig_EF_trigmuonef_EF_mu15_xe30_noMu);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu15i", &trig_EF_trigmuonef_EF_mu15i, &b_trig_EF_trigmuonef_EF_mu15i);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu15i_medium", &trig_EF_trigmuonef_EF_mu15i_medium, &b_trig_EF_trigmuonef_EF_mu15i_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu18", &trig_EF_trigmuonef_EF_mu18, &b_trig_EF_trigmuonef_EF_mu18);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu18_L1J10", &trig_EF_trigmuonef_EF_mu18_L1J10, &b_trig_EF_trigmuonef_EF_mu18_L1J10);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu18_MG", &trig_EF_trigmuonef_EF_mu18_MG, &b_trig_EF_trigmuonef_EF_mu18_MG);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu18_MG_L1J10", &trig_EF_trigmuonef_EF_mu18_MG_L1J10, &b_trig_EF_trigmuonef_EF_mu18_MG_L1J10);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu18_MG_medium", &trig_EF_trigmuonef_EF_mu18_MG_medium, &b_trig_EF_trigmuonef_EF_mu18_MG_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu18_medium", &trig_EF_trigmuonef_EF_mu18_medium, &b_trig_EF_trigmuonef_EF_mu18_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu20", &trig_EF_trigmuonef_EF_mu20, &b_trig_EF_trigmuonef_EF_mu20);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu20_IDTrkNoCut", &trig_EF_trigmuonef_EF_mu20_IDTrkNoCut, &b_trig_EF_trigmuonef_EF_mu20_IDTrkNoCut);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu20_IDTrkNoCut_ManyVx", &trig_EF_trigmuonef_EF_mu20_IDTrkNoCut_ManyVx, &b_trig_EF_trigmuonef_EF_mu20_IDTrkNoCut_ManyVx);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu20_MG", &trig_EF_trigmuonef_EF_mu20_MG, &b_trig_EF_trigmuonef_EF_mu20_MG);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu20_MG_medium", &trig_EF_trigmuonef_EF_mu20_MG_medium, &b_trig_EF_trigmuonef_EF_mu20_MG_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu20_empty", &trig_EF_trigmuonef_EF_mu20_empty, &b_trig_EF_trigmuonef_EF_mu20_empty);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu20_medium", &trig_EF_trigmuonef_EF_mu20_medium, &b_trig_EF_trigmuonef_EF_mu20_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu20_mu10_EFFS_tight", &trig_EF_trigmuonef_EF_mu20_mu10_EFFS_tight, &b_trig_EF_trigmuonef_EF_mu20_mu10_EFFS_tight);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu20_muCombTag_NoEF", &trig_EF_trigmuonef_EF_mu20_muCombTag_NoEF, &b_trig_EF_trigmuonef_EF_mu20_muCombTag_NoEF);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu20i", &trig_EF_trigmuonef_EF_mu20i, &b_trig_EF_trigmuonef_EF_mu20i);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu20i_medium", &trig_EF_trigmuonef_EF_mu20i_medium, &b_trig_EF_trigmuonef_EF_mu20i_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu22", &trig_EF_trigmuonef_EF_mu22, &b_trig_EF_trigmuonef_EF_mu22);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu22_MG", &trig_EF_trigmuonef_EF_mu22_MG, &b_trig_EF_trigmuonef_EF_mu22_MG);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu22_MG_medium", &trig_EF_trigmuonef_EF_mu22_MG_medium, &b_trig_EF_trigmuonef_EF_mu22_MG_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu22_medium", &trig_EF_trigmuonef_EF_mu22_medium, &b_trig_EF_trigmuonef_EF_mu22_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu24_MG_medium", &trig_EF_trigmuonef_EF_mu24_MG_medium, &b_trig_EF_trigmuonef_EF_mu24_MG_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu24_MG_tight", &trig_EF_trigmuonef_EF_mu24_MG_tight, &b_trig_EF_trigmuonef_EF_mu24_MG_tight);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu24_medium", &trig_EF_trigmuonef_EF_mu24_medium, &b_trig_EF_trigmuonef_EF_mu24_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu24_tight", &trig_EF_trigmuonef_EF_mu24_tight, &b_trig_EF_trigmuonef_EF_mu24_tight);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu30_MG_medium", &trig_EF_trigmuonef_EF_mu30_MG_medium, &b_trig_EF_trigmuonef_EF_mu30_MG_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu30_MG_tight", &trig_EF_trigmuonef_EF_mu30_MG_tight, &b_trig_EF_trigmuonef_EF_mu30_MG_tight);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu30_medium", &trig_EF_trigmuonef_EF_mu30_medium, &b_trig_EF_trigmuonef_EF_mu30_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu30_tight", &trig_EF_trigmuonef_EF_mu30_tight, &b_trig_EF_trigmuonef_EF_mu30_tight);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4", &trig_EF_trigmuonef_EF_mu4, &b_trig_EF_trigmuonef_EF_mu4);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu40_MSonly_barrel", &trig_EF_trigmuonef_EF_mu40_MSonly_barrel, &b_trig_EF_trigmuonef_EF_mu40_MSonly_barrel);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu40_MSonly_barrel_medium", &trig_EF_trigmuonef_EF_mu40_MSonly_barrel_medium, &b_trig_EF_trigmuonef_EF_mu40_MSonly_barrel_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu40_MSonly_empty", &trig_EF_trigmuonef_EF_mu40_MSonly_empty, &b_trig_EF_trigmuonef_EF_mu40_MSonly_empty);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu40_MSonly_tight", &trig_EF_trigmuonef_EF_mu40_MSonly_tight, &b_trig_EF_trigmuonef_EF_mu40_MSonly_tight);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu40_MSonly_tight_L1MU11", &trig_EF_trigmuonef_EF_mu40_MSonly_tight_L1MU11, &b_trig_EF_trigmuonef_EF_mu40_MSonly_tight_L1MU11);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu40_MSonly_tighter", &trig_EF_trigmuonef_EF_mu40_MSonly_tighter, &b_trig_EF_trigmuonef_EF_mu40_MSonly_tighter);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu40_slow", &trig_EF_trigmuonef_EF_mu40_slow, &b_trig_EF_trigmuonef_EF_mu40_slow);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu40_slow_empty", &trig_EF_trigmuonef_EF_mu40_slow_empty, &b_trig_EF_trigmuonef_EF_mu40_slow_empty);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu40_slow_medium", &trig_EF_trigmuonef_EF_mu40_slow_medium, &b_trig_EF_trigmuonef_EF_mu40_slow_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu40_slow_outOfTime", &trig_EF_trigmuonef_EF_mu40_slow_outOfTime, &b_trig_EF_trigmuonef_EF_mu40_slow_outOfTime);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu40_slow_outOfTime_medium", &trig_EF_trigmuonef_EF_mu40_slow_outOfTime_medium, &b_trig_EF_trigmuonef_EF_mu40_slow_outOfTime_medium);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_DiMu", &trig_EF_trigmuonef_EF_mu4_DiMu, &b_trig_EF_trigmuonef_EF_mu4_DiMu);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_DiMu_FS_noOS", &trig_EF_trigmuonef_EF_mu4_DiMu_FS_noOS, &b_trig_EF_trigmuonef_EF_mu4_DiMu_FS_noOS);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_Jpsimumu", &trig_EF_trigmuonef_EF_mu4_Jpsimumu, &b_trig_EF_trigmuonef_EF_mu4_Jpsimumu);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_L1J10_matched", &trig_EF_trigmuonef_EF_mu4_L1J10_matched, &b_trig_EF_trigmuonef_EF_mu4_L1J10_matched);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_L1J15_matched", &trig_EF_trigmuonef_EF_mu4_L1J15_matched, &b_trig_EF_trigmuonef_EF_mu4_L1J15_matched);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_L1J20_matched", &trig_EF_trigmuonef_EF_mu4_L1J20_matched, &b_trig_EF_trigmuonef_EF_mu4_L1J20_matched);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_L1J30_matched", &trig_EF_trigmuonef_EF_mu4_L1J30_matched, &b_trig_EF_trigmuonef_EF_mu4_L1J30_matched);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_L1J50_matched", &trig_EF_trigmuonef_EF_mu4_L1J50_matched, &b_trig_EF_trigmuonef_EF_mu4_L1J50_matched);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_L1J75_matched", &trig_EF_trigmuonef_EF_mu4_L1J75_matched, &b_trig_EF_trigmuonef_EF_mu4_L1J75_matched);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_L1MU11_MSonly_cosmic", &trig_EF_trigmuonef_EF_mu4_L1MU11_MSonly_cosmic, &b_trig_EF_trigmuonef_EF_mu4_L1MU11_MSonly_cosmic);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_L1MU11_cosmic", &trig_EF_trigmuonef_EF_mu4_L1MU11_cosmic, &b_trig_EF_trigmuonef_EF_mu4_L1MU11_cosmic);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_MSonly_cosmic", &trig_EF_trigmuonef_EF_mu4_MSonly_cosmic, &b_trig_EF_trigmuonef_EF_mu4_MSonly_cosmic);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_Trk_Jpsi", &trig_EF_trigmuonef_EF_mu4_Trk_Jpsi, &b_trig_EF_trigmuonef_EF_mu4_Trk_Jpsi);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_Trk_Upsi_FS", &trig_EF_trigmuonef_EF_mu4_Trk_Upsi_FS, &b_trig_EF_trigmuonef_EF_mu4_Trk_Upsi_FS);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_Upsimumu_FS", &trig_EF_trigmuonef_EF_mu4_Upsimumu_FS, &b_trig_EF_trigmuonef_EF_mu4_Upsimumu_FS);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_Upsimumu_SiTrk_FS", &trig_EF_trigmuonef_EF_mu4_Upsimumu_SiTrk_FS, &b_trig_EF_trigmuonef_EF_mu4_Upsimumu_SiTrk_FS);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_Upsimumu_tight_FS", &trig_EF_trigmuonef_EF_mu4_Upsimumu_tight_FS, &b_trig_EF_trigmuonef_EF_mu4_Upsimumu_tight_FS);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_cosmic", &trig_EF_trigmuonef_EF_mu4_cosmic, &b_trig_EF_trigmuonef_EF_mu4_cosmic);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_j10_a4tc_EFFS", &trig_EF_trigmuonef_EF_mu4_j10_a4tc_EFFS, &b_trig_EF_trigmuonef_EF_mu4_j10_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_j10_a4tc_EFFS_matched", &trig_EF_trigmuonef_EF_mu4_j10_a4tc_EFFS_matched, &b_trig_EF_trigmuonef_EF_mu4_j10_a4tc_EFFS_matched);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_j135_a4tc_EFFS_L1matched", &trig_EF_trigmuonef_EF_mu4_j135_a4tc_EFFS_L1matched, &b_trig_EF_trigmuonef_EF_mu4_j135_a4tc_EFFS_L1matched);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_j180_a4tc_EFFS_L1matched", &trig_EF_trigmuonef_EF_mu4_j180_a4tc_EFFS_L1matched, &b_trig_EF_trigmuonef_EF_mu4_j180_a4tc_EFFS_L1matched);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4_j45_a4tc_EFFS_xe45_loose_noMu", &trig_EF_trigmuonef_EF_mu4_j45_a4tc_EFFS_xe45_loose_noMu, &b_trig_EF_trigmuonef_EF_mu4_j45_a4tc_EFFS_xe45_loose_noMu);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4imu6i_DiMu_DY", &trig_EF_trigmuonef_EF_mu4imu6i_DiMu_DY, &b_trig_EF_trigmuonef_EF_mu4imu6i_DiMu_DY);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4imu6i_DiMu_DY14_noVtx_noOS", &trig_EF_trigmuonef_EF_mu4imu6i_DiMu_DY14_noVtx_noOS, &b_trig_EF_trigmuonef_EF_mu4imu6i_DiMu_DY14_noVtx_noOS);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4mu6_Bmumu", &trig_EF_trigmuonef_EF_mu4mu6_Bmumu, &b_trig_EF_trigmuonef_EF_mu4mu6_Bmumu);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4mu6_Bmumux", &trig_EF_trigmuonef_EF_mu4mu6_Bmumux, &b_trig_EF_trigmuonef_EF_mu4mu6_Bmumux);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4mu6_DiMu", &trig_EF_trigmuonef_EF_mu4mu6_DiMu, &b_trig_EF_trigmuonef_EF_mu4mu6_DiMu);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4mu6_DiMu_DY20", &trig_EF_trigmuonef_EF_mu4mu6_DiMu_DY20, &b_trig_EF_trigmuonef_EF_mu4mu6_DiMu_DY20);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4mu6_DiMu_noVtx_noOS", &trig_EF_trigmuonef_EF_mu4mu6_DiMu_noVtx_noOS, &b_trig_EF_trigmuonef_EF_mu4mu6_DiMu_noVtx_noOS);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4mu6_Jpsimumu", &trig_EF_trigmuonef_EF_mu4mu6_Jpsimumu, &b_trig_EF_trigmuonef_EF_mu4mu6_Jpsimumu);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu4mu6_Upsimumu", &trig_EF_trigmuonef_EF_mu4mu6_Upsimumu, &b_trig_EF_trigmuonef_EF_mu4mu6_Upsimumu);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu6", &trig_EF_trigmuonef_EF_mu6, &b_trig_EF_trigmuonef_EF_mu6);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu6_DiMu_noOS", &trig_EF_trigmuonef_EF_mu6_DiMu_noOS, &b_trig_EF_trigmuonef_EF_mu6_DiMu_noOS);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu6_Jpsimumu", &trig_EF_trigmuonef_EF_mu6_Jpsimumu, &b_trig_EF_trigmuonef_EF_mu6_Jpsimumu);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu6_Jpsimumu_SiTrk", &trig_EF_trigmuonef_EF_mu6_Jpsimumu_SiTrk, &b_trig_EF_trigmuonef_EF_mu6_Jpsimumu_SiTrk);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu6_Jpsimumu_tight", &trig_EF_trigmuonef_EF_mu6_Jpsimumu_tight, &b_trig_EF_trigmuonef_EF_mu6_Jpsimumu_tight);
   fChain->SetBranchAddress("trig_EF_trigmuonef_EF_mu6_Trk_Jpsi_loose", &trig_EF_trigmuonef_EF_mu6_Trk_Jpsi_loose, &b_trig_EF_trigmuonef_EF_mu6_Trk_Jpsi_loose);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_n", &trig_EF_trigmuonef_track_n, &b_trig_EF_trigmuonef_track_n);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_MuonType", &trig_EF_trigmuonef_track_MuonType, &b_trig_EF_trigmuonef_track_MuonType);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_MS_pt", &trig_EF_trigmuonef_track_MS_pt, &b_trig_EF_trigmuonef_track_MS_pt);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_MS_eta", &trig_EF_trigmuonef_track_MS_eta, &b_trig_EF_trigmuonef_track_MS_eta);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_MS_phi", &trig_EF_trigmuonef_track_MS_phi, &b_trig_EF_trigmuonef_track_MS_phi);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_MS_charge", &trig_EF_trigmuonef_track_MS_charge, &b_trig_EF_trigmuonef_track_MS_charge);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_MS_d0", &trig_EF_trigmuonef_track_MS_d0, &b_trig_EF_trigmuonef_track_MS_d0);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_MS_z0", &trig_EF_trigmuonef_track_MS_z0, &b_trig_EF_trigmuonef_track_MS_z0);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_MS_chi2", &trig_EF_trigmuonef_track_MS_chi2, &b_trig_EF_trigmuonef_track_MS_chi2);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_MS_chi2prob", &trig_EF_trigmuonef_track_MS_chi2prob, &b_trig_EF_trigmuonef_track_MS_chi2prob);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_MS_posX", &trig_EF_trigmuonef_track_MS_posX, &b_trig_EF_trigmuonef_track_MS_posX);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_MS_posY", &trig_EF_trigmuonef_track_MS_posY, &b_trig_EF_trigmuonef_track_MS_posY);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_MS_posZ", &trig_EF_trigmuonef_track_MS_posZ, &b_trig_EF_trigmuonef_track_MS_posZ);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_MS_hasMS", &trig_EF_trigmuonef_track_MS_hasMS, &b_trig_EF_trigmuonef_track_MS_hasMS);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_SA_pt", &trig_EF_trigmuonef_track_SA_pt, &b_trig_EF_trigmuonef_track_SA_pt);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_SA_eta", &trig_EF_trigmuonef_track_SA_eta, &b_trig_EF_trigmuonef_track_SA_eta);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_SA_phi", &trig_EF_trigmuonef_track_SA_phi, &b_trig_EF_trigmuonef_track_SA_phi);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_SA_charge", &trig_EF_trigmuonef_track_SA_charge, &b_trig_EF_trigmuonef_track_SA_charge);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_SA_d0", &trig_EF_trigmuonef_track_SA_d0, &b_trig_EF_trigmuonef_track_SA_d0);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_SA_z0", &trig_EF_trigmuonef_track_SA_z0, &b_trig_EF_trigmuonef_track_SA_z0);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_SA_chi2", &trig_EF_trigmuonef_track_SA_chi2, &b_trig_EF_trigmuonef_track_SA_chi2);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_SA_chi2prob", &trig_EF_trigmuonef_track_SA_chi2prob, &b_trig_EF_trigmuonef_track_SA_chi2prob);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_SA_posX", &trig_EF_trigmuonef_track_SA_posX, &b_trig_EF_trigmuonef_track_SA_posX);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_SA_posY", &trig_EF_trigmuonef_track_SA_posY, &b_trig_EF_trigmuonef_track_SA_posY);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_SA_posZ", &trig_EF_trigmuonef_track_SA_posZ, &b_trig_EF_trigmuonef_track_SA_posZ);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_SA_hasSA", &trig_EF_trigmuonef_track_SA_hasSA, &b_trig_EF_trigmuonef_track_SA_hasSA);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_CB_pt", &trig_EF_trigmuonef_track_CB_pt, &b_trig_EF_trigmuonef_track_CB_pt);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_CB_eta", &trig_EF_trigmuonef_track_CB_eta, &b_trig_EF_trigmuonef_track_CB_eta);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_CB_phi", &trig_EF_trigmuonef_track_CB_phi, &b_trig_EF_trigmuonef_track_CB_phi);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_CB_charge", &trig_EF_trigmuonef_track_CB_charge, &b_trig_EF_trigmuonef_track_CB_charge);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_CB_d0", &trig_EF_trigmuonef_track_CB_d0, &b_trig_EF_trigmuonef_track_CB_d0);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_CB_z0", &trig_EF_trigmuonef_track_CB_z0, &b_trig_EF_trigmuonef_track_CB_z0);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_CB_chi2", &trig_EF_trigmuonef_track_CB_chi2, &b_trig_EF_trigmuonef_track_CB_chi2);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_CB_chi2prob", &trig_EF_trigmuonef_track_CB_chi2prob, &b_trig_EF_trigmuonef_track_CB_chi2prob);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_CB_posX", &trig_EF_trigmuonef_track_CB_posX, &b_trig_EF_trigmuonef_track_CB_posX);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_CB_posY", &trig_EF_trigmuonef_track_CB_posY, &b_trig_EF_trigmuonef_track_CB_posY);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_CB_posZ", &trig_EF_trigmuonef_track_CB_posZ, &b_trig_EF_trigmuonef_track_CB_posZ);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_CB_matchChi2", &trig_EF_trigmuonef_track_CB_matchChi2, &b_trig_EF_trigmuonef_track_CB_matchChi2);
   fChain->SetBranchAddress("trig_EF_trigmuonef_track_CB_hasCB", &trig_EF_trigmuonef_track_CB_hasCB, &b_trig_EF_trigmuonef_track_CB_hasCB);
   fChain->SetBranchAddress("trig_L1_esum_thrNames", &trig_L1_esum_thrNames, &b_trig_L1_esum_thrNames);
   fChain->SetBranchAddress("trig_L1_esum_ExMiss", &trig_L1_esum_ExMiss, &b_trig_L1_esum_ExMiss);
   fChain->SetBranchAddress("trig_L1_esum_EyMiss", &trig_L1_esum_EyMiss, &b_trig_L1_esum_EyMiss);
   fChain->SetBranchAddress("trig_L1_esum_energyT", &trig_L1_esum_energyT, &b_trig_L1_esum_energyT);
   fChain->SetBranchAddress("trig_L1_esum_overflowX", &trig_L1_esum_overflowX, &b_trig_L1_esum_overflowX);
   fChain->SetBranchAddress("trig_L1_esum_overflowY", &trig_L1_esum_overflowY, &b_trig_L1_esum_overflowY);
   fChain->SetBranchAddress("trig_L1_esum_overflowT", &trig_L1_esum_overflowT, &b_trig_L1_esum_overflowT);
   fChain->SetBranchAddress("trig_L1_esum_RoIWord0", &trig_L1_esum_RoIWord0, &b_trig_L1_esum_RoIWord0);
   fChain->SetBranchAddress("trig_L1_esum_RoIWord1", &trig_L1_esum_RoIWord1, &b_trig_L1_esum_RoIWord1);
   fChain->SetBranchAddress("trig_L1_esum_RoIWord2", &trig_L1_esum_RoIWord2, &b_trig_L1_esum_RoIWord2);
   fChain->SetBranchAddress("trig_L2_met_MEx", &trig_L2_met_MEx, &b_trig_L2_met_MEx);
   fChain->SetBranchAddress("trig_L2_met_MEy", &trig_L2_met_MEy, &b_trig_L2_met_MEy);
   fChain->SetBranchAddress("trig_L2_met_MEz", &trig_L2_met_MEz, &b_trig_L2_met_MEz);
   fChain->SetBranchAddress("trig_L2_met_sumEt", &trig_L2_met_sumEt, &b_trig_L2_met_sumEt);
   fChain->SetBranchAddress("trig_L2_met_sumE", &trig_L2_met_sumE, &b_trig_L2_met_sumE);
   fChain->SetBranchAddress("trig_L2_met_flag", &trig_L2_met_flag, &b_trig_L2_met_flag);
   fChain->SetBranchAddress("trig_L2_met_nameOfComponent", &trig_L2_met_nameOfComponent, &b_trig_L2_met_nameOfComponent);
   fChain->SetBranchAddress("trig_L2_met_MExComponent", &trig_L2_met_MExComponent, &b_trig_L2_met_MExComponent);
   fChain->SetBranchAddress("trig_L2_met_MEyComponent", &trig_L2_met_MEyComponent, &b_trig_L2_met_MEyComponent);
   fChain->SetBranchAddress("trig_L2_met_MEzComponent", &trig_L2_met_MEzComponent, &b_trig_L2_met_MEzComponent);
   fChain->SetBranchAddress("trig_L2_met_sumEtComponent", &trig_L2_met_sumEtComponent, &b_trig_L2_met_sumEtComponent);
   fChain->SetBranchAddress("trig_L2_met_sumEComponent", &trig_L2_met_sumEComponent, &b_trig_L2_met_sumEComponent);
   fChain->SetBranchAddress("trig_L2_met_componentCalib0", &trig_L2_met_componentCalib0, &b_trig_L2_met_componentCalib0);
   fChain->SetBranchAddress("trig_L2_met_componentCalib1", &trig_L2_met_componentCalib1, &b_trig_L2_met_componentCalib1);
   fChain->SetBranchAddress("trig_L2_met_sumOfSigns", &trig_L2_met_sumOfSigns, &b_trig_L2_met_sumOfSigns);
   fChain->SetBranchAddress("trig_L2_met_usedChannels", &trig_L2_met_usedChannels, &b_trig_L2_met_usedChannels);
   fChain->SetBranchAddress("trig_L2_met_status", &trig_L2_met_status, &b_trig_L2_met_status);
   fChain->SetBranchAddress("trig_EF_met_MEx", &trig_EF_met_MEx, &b_trig_EF_met_MEx);
   fChain->SetBranchAddress("trig_EF_met_MEy", &trig_EF_met_MEy, &b_trig_EF_met_MEy);
   fChain->SetBranchAddress("trig_EF_met_MEz", &trig_EF_met_MEz, &b_trig_EF_met_MEz);
   fChain->SetBranchAddress("trig_EF_met_sumEt", &trig_EF_met_sumEt, &b_trig_EF_met_sumEt);
   fChain->SetBranchAddress("trig_EF_met_sumE", &trig_EF_met_sumE, &b_trig_EF_met_sumE);
   fChain->SetBranchAddress("trig_EF_met_flag", &trig_EF_met_flag, &b_trig_EF_met_flag);
   fChain->SetBranchAddress("trig_EF_met_nameOfComponent", &trig_EF_met_nameOfComponent, &b_trig_EF_met_nameOfComponent);
   fChain->SetBranchAddress("trig_EF_met_MExComponent", &trig_EF_met_MExComponent, &b_trig_EF_met_MExComponent);
   fChain->SetBranchAddress("trig_EF_met_MEyComponent", &trig_EF_met_MEyComponent, &b_trig_EF_met_MEyComponent);
   fChain->SetBranchAddress("trig_EF_met_MEzComponent", &trig_EF_met_MEzComponent, &b_trig_EF_met_MEzComponent);
   fChain->SetBranchAddress("trig_EF_met_sumEtComponent", &trig_EF_met_sumEtComponent, &b_trig_EF_met_sumEtComponent);
   fChain->SetBranchAddress("trig_EF_met_sumEComponent", &trig_EF_met_sumEComponent, &b_trig_EF_met_sumEComponent);
   fChain->SetBranchAddress("trig_EF_met_componentCalib0", &trig_EF_met_componentCalib0, &b_trig_EF_met_componentCalib0);
   fChain->SetBranchAddress("trig_EF_met_componentCalib1", &trig_EF_met_componentCalib1, &b_trig_EF_met_componentCalib1);
   fChain->SetBranchAddress("trig_EF_met_sumOfSigns", &trig_EF_met_sumOfSigns, &b_trig_EF_met_sumOfSigns);
   fChain->SetBranchAddress("trig_EF_met_usedChannels", &trig_EF_met_usedChannels, &b_trig_EF_met_usedChannels);
   fChain->SetBranchAddress("trig_EF_met_status", &trig_EF_met_status, &b_trig_EF_met_status);
   fChain->SetBranchAddress("trig_L1_emtau_n", &trig_L1_emtau_n, &b_trig_L1_emtau_n);
   fChain->SetBranchAddress("trig_L1_emtau_eta", &trig_L1_emtau_eta, &b_trig_L1_emtau_eta);
   fChain->SetBranchAddress("trig_L1_emtau_phi", &trig_L1_emtau_phi, &b_trig_L1_emtau_phi);
   fChain->SetBranchAddress("trig_L1_emtau_thrNames", &trig_L1_emtau_thrNames, &b_trig_L1_emtau_thrNames);
   fChain->SetBranchAddress("trig_L1_emtau_thrValues", &trig_L1_emtau_thrValues, &b_trig_L1_emtau_thrValues);
   fChain->SetBranchAddress("trig_L1_emtau_core", &trig_L1_emtau_core, &b_trig_L1_emtau_core);
   fChain->SetBranchAddress("trig_L1_emtau_EMClus", &trig_L1_emtau_EMClus, &b_trig_L1_emtau_EMClus);
   fChain->SetBranchAddress("trig_L1_emtau_tauClus", &trig_L1_emtau_tauClus, &b_trig_L1_emtau_tauClus);
   fChain->SetBranchAddress("trig_L1_emtau_EMIsol", &trig_L1_emtau_EMIsol, &b_trig_L1_emtau_EMIsol);
   fChain->SetBranchAddress("trig_L1_emtau_hadIsol", &trig_L1_emtau_hadIsol, &b_trig_L1_emtau_hadIsol);
   fChain->SetBranchAddress("trig_L1_emtau_hadCore", &trig_L1_emtau_hadCore, &b_trig_L1_emtau_hadCore);
   fChain->SetBranchAddress("trig_L1_emtau_thrPattern", &trig_L1_emtau_thrPattern, &b_trig_L1_emtau_thrPattern);
   fChain->SetBranchAddress("trig_L1_emtau_L1_2EM10", &trig_L1_emtau_L1_2EM10, &b_trig_L1_emtau_L1_2EM10);
   fChain->SetBranchAddress("trig_L1_emtau_L1_2EM14", &trig_L1_emtau_L1_2EM14, &b_trig_L1_emtau_L1_2EM14);
   fChain->SetBranchAddress("trig_L1_emtau_L1_2EM3", &trig_L1_emtau_L1_2EM3, &b_trig_L1_emtau_L1_2EM3);
   fChain->SetBranchAddress("trig_L1_emtau_L1_2EM3_EM12", &trig_L1_emtau_L1_2EM3_EM12, &b_trig_L1_emtau_L1_2EM3_EM12);
   fChain->SetBranchAddress("trig_L1_emtau_L1_2EM3_EM7", &trig_L1_emtau_L1_2EM3_EM7, &b_trig_L1_emtau_L1_2EM3_EM7);
   fChain->SetBranchAddress("trig_L1_emtau_L1_2EM5", &trig_L1_emtau_L1_2EM5, &b_trig_L1_emtau_L1_2EM5);
   fChain->SetBranchAddress("trig_L1_emtau_L1_2EM5_EM10", &trig_L1_emtau_L1_2EM5_EM10, &b_trig_L1_emtau_L1_2EM5_EM10);
   fChain->SetBranchAddress("trig_L1_emtau_L1_2EM5_MU6", &trig_L1_emtau_L1_2EM5_MU6, &b_trig_L1_emtau_L1_2EM5_MU6);
   fChain->SetBranchAddress("trig_L1_emtau_L1_2EM5_NL", &trig_L1_emtau_L1_2EM5_NL, &b_trig_L1_emtau_L1_2EM5_NL);
   fChain->SetBranchAddress("trig_L1_emtau_L1_2EM7", &trig_L1_emtau_L1_2EM7, &b_trig_L1_emtau_L1_2EM7);
   fChain->SetBranchAddress("trig_L1_emtau_L1_2EM7_EM10", &trig_L1_emtau_L1_2EM7_EM10, &b_trig_L1_emtau_L1_2EM7_EM10);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM10", &trig_L1_emtau_L1_EM10, &b_trig_L1_emtau_L1_EM10);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM10_MU6", &trig_L1_emtau_L1_EM10_MU6, &b_trig_L1_emtau_L1_EM10_MU6);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM10_XE20", &trig_L1_emtau_L1_EM10_XE20, &b_trig_L1_emtau_L1_EM10_XE20);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM10_XE30", &trig_L1_emtau_L1_EM10_XE30, &b_trig_L1_emtau_L1_EM10_XE30);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM10_XS45", &trig_L1_emtau_L1_EM10_XS45, &b_trig_L1_emtau_L1_EM10_XS45);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM10_XS50", &trig_L1_emtau_L1_EM10_XS50, &b_trig_L1_emtau_L1_EM10_XS50);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM12", &trig_L1_emtau_L1_EM12, &b_trig_L1_emtau_L1_EM12);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM14", &trig_L1_emtau_L1_EM14, &b_trig_L1_emtau_L1_EM14);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM14_XE10", &trig_L1_emtau_L1_EM14_XE10, &b_trig_L1_emtau_L1_EM14_XE10);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM14_XE20", &trig_L1_emtau_L1_EM14_XE20, &b_trig_L1_emtau_L1_EM14_XE20);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM16", &trig_L1_emtau_L1_EM16, &b_trig_L1_emtau_L1_EM16);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM3", &trig_L1_emtau_L1_EM3, &b_trig_L1_emtau_L1_EM3);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM30", &trig_L1_emtau_L1_EM30, &b_trig_L1_emtau_L1_EM30);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM3_EMPTY", &trig_L1_emtau_L1_EM3_EMPTY, &b_trig_L1_emtau_L1_EM3_EMPTY);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM3_FIRSTEMPTY", &trig_L1_emtau_L1_EM3_FIRSTEMPTY, &b_trig_L1_emtau_L1_EM3_FIRSTEMPTY);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM3_MU0", &trig_L1_emtau_L1_EM3_MU0, &b_trig_L1_emtau_L1_EM3_MU0);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM3_MU6", &trig_L1_emtau_L1_EM3_MU6, &b_trig_L1_emtau_L1_EM3_MU6);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM3_UNPAIRED_ISO", &trig_L1_emtau_L1_EM3_UNPAIRED_ISO, &b_trig_L1_emtau_L1_EM3_UNPAIRED_ISO);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM3_UNPAIRED_NONISO", &trig_L1_emtau_L1_EM3_UNPAIRED_NONISO, &b_trig_L1_emtau_L1_EM3_UNPAIRED_NONISO);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM5", &trig_L1_emtau_L1_EM5, &b_trig_L1_emtau_L1_EM5);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM5_2MU6", &trig_L1_emtau_L1_EM5_2MU6, &b_trig_L1_emtau_L1_EM5_2MU6);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM5_EMPTY", &trig_L1_emtau_L1_EM5_EMPTY, &b_trig_L1_emtau_L1_EM5_EMPTY);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM5_MU10", &trig_L1_emtau_L1_EM5_MU10, &b_trig_L1_emtau_L1_EM5_MU10);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM5_MU6", &trig_L1_emtau_L1_EM5_MU6, &b_trig_L1_emtau_L1_EM5_MU6);
   fChain->SetBranchAddress("trig_L1_emtau_L1_EM7", &trig_L1_emtau_L1_EM7, &b_trig_L1_emtau_L1_EM7);
   fChain->SetBranchAddress("trig_L2_el_n", &trig_L2_el_n, &b_trig_L2_el_n);
   fChain->SetBranchAddress("trig_L2_el_E", &trig_L2_el_E, &b_trig_L2_el_E);
   fChain->SetBranchAddress("trig_L2_el_Et", &trig_L2_el_Et, &b_trig_L2_el_Et);
   fChain->SetBranchAddress("trig_L2_el_pt", &trig_L2_el_pt, &b_trig_L2_el_pt);
   fChain->SetBranchAddress("trig_L2_el_eta", &trig_L2_el_eta, &b_trig_L2_el_eta);
   fChain->SetBranchAddress("trig_L2_el_phi", &trig_L2_el_phi, &b_trig_L2_el_phi);
   fChain->SetBranchAddress("trig_L2_el_RoIWord", &trig_L2_el_RoIWord, &b_trig_L2_el_RoIWord);
   fChain->SetBranchAddress("trig_L2_el_zvertex", &trig_L2_el_zvertex, &b_trig_L2_el_zvertex);
   fChain->SetBranchAddress("trig_L2_el_charge", &trig_L2_el_charge, &b_trig_L2_el_charge);
   fChain->SetBranchAddress("trig_L2_el_L2_2e10_medium", &trig_L2_el_L2_2e10_medium, &b_trig_L2_el_L2_2e10_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_2e10_medium_mu6", &trig_L2_el_L2_2e10_medium_mu6, &b_trig_L2_el_L2_2e10_medium_mu6);
   fChain->SetBranchAddress("trig_L2_el_L2_2e12T_medium", &trig_L2_el_L2_2e12T_medium, &b_trig_L2_el_L2_2e12T_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_2e12_medium", &trig_L2_el_L2_2e12_medium, &b_trig_L2_el_L2_2e12_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_2e15_medium", &trig_L2_el_L2_2e15_medium, &b_trig_L2_el_L2_2e15_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_2e5_tight", &trig_L2_el_L2_2e5_tight, &b_trig_L2_el_L2_2e5_tight);
   fChain->SetBranchAddress("trig_L2_el_L2_2e5_tight_Jpsi", &trig_L2_el_L2_2e5_tight_Jpsi, &b_trig_L2_el_L2_2e5_tight_Jpsi);
   fChain->SetBranchAddress("trig_L2_el_L2_e10_medium", &trig_L2_el_L2_e10_medium, &b_trig_L2_el_L2_e10_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e10_medium_2mu6", &trig_L2_el_L2_e10_medium_2mu6, &b_trig_L2_el_L2_e10_medium_2mu6);
   fChain->SetBranchAddress("trig_L2_el_L2_e10_medium_mu10", &trig_L2_el_L2_e10_medium_mu10, &b_trig_L2_el_L2_e10_medium_mu10);
   fChain->SetBranchAddress("trig_L2_el_L2_e10_medium_mu6", &trig_L2_el_L2_e10_medium_mu6, &b_trig_L2_el_L2_e10_medium_mu6);
   fChain->SetBranchAddress("trig_L2_el_L2_e10_medium_mu6_topo_medium", &trig_L2_el_L2_e10_medium_mu6_topo_medium, &b_trig_L2_el_L2_e10_medium_mu6_topo_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e11T_medium", &trig_L2_el_L2_e11T_medium, &b_trig_L2_el_L2_e11T_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e11T_medium_2e6T_medium", &trig_L2_el_L2_e11T_medium_2e6T_medium, &b_trig_L2_el_L2_e11T_medium_2e6T_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e11_etcut", &trig_L2_el_L2_e11_etcut, &b_trig_L2_el_L2_e11_etcut);
   fChain->SetBranchAddress("trig_L2_el_L2_e12T_medium_mu6_topo_medium", &trig_L2_el_L2_e12T_medium_mu6_topo_medium, &b_trig_L2_el_L2_e12T_medium_mu6_topo_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e12_medium", &trig_L2_el_L2_e12_medium, &b_trig_L2_el_L2_e12_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e13_etcut_xs45_noMu", &trig_L2_el_L2_e13_etcut_xs45_noMu, &b_trig_L2_el_L2_e13_etcut_xs45_noMu);
   fChain->SetBranchAddress("trig_L2_el_L2_e15_HLTtighter", &trig_L2_el_L2_e15_HLTtighter, &b_trig_L2_el_L2_e15_HLTtighter);
   fChain->SetBranchAddress("trig_L2_el_L2_e15_medium", &trig_L2_el_L2_e15_medium, &b_trig_L2_el_L2_e15_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e15_medium_e12_medium", &trig_L2_el_L2_e15_medium_e12_medium, &b_trig_L2_el_L2_e15_medium_e12_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e15_medium_xe20_noMu", &trig_L2_el_L2_e15_medium_xe20_noMu, &b_trig_L2_el_L2_e15_medium_xe20_noMu);
   fChain->SetBranchAddress("trig_L2_el_L2_e15_medium_xe30_noMu", &trig_L2_el_L2_e15_medium_xe30_noMu, &b_trig_L2_el_L2_e15_medium_xe30_noMu);
   fChain->SetBranchAddress("trig_L2_el_L2_e15_medium_xe35_noMu", &trig_L2_el_L2_e15_medium_xe35_noMu, &b_trig_L2_el_L2_e15_medium_xe35_noMu);
   fChain->SetBranchAddress("trig_L2_el_L2_e15_tight", &trig_L2_el_L2_e15_tight, &b_trig_L2_el_L2_e15_tight);
   fChain->SetBranchAddress("trig_L2_el_L2_e20_etcut_xs45_noMu", &trig_L2_el_L2_e20_etcut_xs45_noMu, &b_trig_L2_el_L2_e20_etcut_xs45_noMu);
   fChain->SetBranchAddress("trig_L2_el_L2_e20_loose", &trig_L2_el_L2_e20_loose, &b_trig_L2_el_L2_e20_loose);
   fChain->SetBranchAddress("trig_L2_el_L2_e20_loose1", &trig_L2_el_L2_e20_loose1, &b_trig_L2_el_L2_e20_loose1);
   fChain->SetBranchAddress("trig_L2_el_L2_e20_looseTrk", &trig_L2_el_L2_e20_looseTrk, &b_trig_L2_el_L2_e20_looseTrk);
   fChain->SetBranchAddress("trig_L2_el_L2_e20_medium", &trig_L2_el_L2_e20_medium, &b_trig_L2_el_L2_e20_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e20_medium1", &trig_L2_el_L2_e20_medium1, &b_trig_L2_el_L2_e20_medium1);
   fChain->SetBranchAddress("trig_L2_el_L2_e20_medium2", &trig_L2_el_L2_e20_medium2, &b_trig_L2_el_L2_e20_medium2);
   fChain->SetBranchAddress("trig_L2_el_L2_e20_medium_IDTrkNoCut", &trig_L2_el_L2_e20_medium_IDTrkNoCut, &b_trig_L2_el_L2_e20_medium_IDTrkNoCut);
   fChain->SetBranchAddress("trig_L2_el_L2_e20_medium_SiTrk", &trig_L2_el_L2_e20_medium_SiTrk, &b_trig_L2_el_L2_e20_medium_SiTrk);
   fChain->SetBranchAddress("trig_L2_el_L2_e20_medium_TRT", &trig_L2_el_L2_e20_medium_TRT, &b_trig_L2_el_L2_e20_medium_TRT);
   fChain->SetBranchAddress("trig_L2_el_L2_e20_tight_e15_NoCut_Zee", &trig_L2_el_L2_e20_tight_e15_NoCut_Zee, &b_trig_L2_el_L2_e20_tight_e15_NoCut_Zee);
   fChain->SetBranchAddress("trig_L2_el_L2_e22_etcut_xs45_noMu", &trig_L2_el_L2_e22_etcut_xs45_noMu, &b_trig_L2_el_L2_e22_etcut_xs45_noMu);
   fChain->SetBranchAddress("trig_L2_el_L2_e22_loose", &trig_L2_el_L2_e22_loose, &b_trig_L2_el_L2_e22_loose);
   fChain->SetBranchAddress("trig_L2_el_L2_e22_loose1", &trig_L2_el_L2_e22_loose1, &b_trig_L2_el_L2_e22_loose1);
   fChain->SetBranchAddress("trig_L2_el_L2_e22_looseTrk", &trig_L2_el_L2_e22_looseTrk, &b_trig_L2_el_L2_e22_looseTrk);
   fChain->SetBranchAddress("trig_L2_el_L2_e22_medium", &trig_L2_el_L2_e22_medium, &b_trig_L2_el_L2_e22_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e22_medium1", &trig_L2_el_L2_e22_medium1, &b_trig_L2_el_L2_e22_medium1);
   fChain->SetBranchAddress("trig_L2_el_L2_e22_medium2", &trig_L2_el_L2_e22_medium2, &b_trig_L2_el_L2_e22_medium2);
   fChain->SetBranchAddress("trig_L2_el_L2_e22_medium_IDTrkNoCut", &trig_L2_el_L2_e22_medium_IDTrkNoCut, &b_trig_L2_el_L2_e22_medium_IDTrkNoCut);
   fChain->SetBranchAddress("trig_L2_el_L2_e22_medium_SiTrk", &trig_L2_el_L2_e22_medium_SiTrk, &b_trig_L2_el_L2_e22_medium_SiTrk);
   fChain->SetBranchAddress("trig_L2_el_L2_e22_medium_TRT", &trig_L2_el_L2_e22_medium_TRT, &b_trig_L2_el_L2_e22_medium_TRT);
   fChain->SetBranchAddress("trig_L2_el_L2_e33_medium", &trig_L2_el_L2_e33_medium, &b_trig_L2_el_L2_e33_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e35_medium", &trig_L2_el_L2_e35_medium, &b_trig_L2_el_L2_e35_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e40_medium", &trig_L2_el_L2_e40_medium, &b_trig_L2_el_L2_e40_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e45_medium", &trig_L2_el_L2_e45_medium, &b_trig_L2_el_L2_e45_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e45_medium1", &trig_L2_el_L2_e45_medium1, &b_trig_L2_el_L2_e45_medium1);
   fChain->SetBranchAddress("trig_L2_el_L2_e5_medium_mu6", &trig_L2_el_L2_e5_medium_mu6, &b_trig_L2_el_L2_e5_medium_mu6);
   fChain->SetBranchAddress("trig_L2_el_L2_e5_medium_mu6_topo_medium", &trig_L2_el_L2_e5_medium_mu6_topo_medium, &b_trig_L2_el_L2_e5_medium_mu6_topo_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e5_tight", &trig_L2_el_L2_e5_tight, &b_trig_L2_el_L2_e5_tight);
   fChain->SetBranchAddress("trig_L2_el_L2_e5_tight_e14_etcut_Jpsi", &trig_L2_el_L2_e5_tight_e14_etcut_Jpsi, &b_trig_L2_el_L2_e5_tight_e14_etcut_Jpsi);
   fChain->SetBranchAddress("trig_L2_el_L2_e5_tight_e4_etcut_Jpsi", &trig_L2_el_L2_e5_tight_e4_etcut_Jpsi, &b_trig_L2_el_L2_e5_tight_e4_etcut_Jpsi);
   fChain->SetBranchAddress("trig_L2_el_L2_e5_tight_e4_etcut_Jpsi_SiTrk", &trig_L2_el_L2_e5_tight_e4_etcut_Jpsi_SiTrk, &b_trig_L2_el_L2_e5_tight_e4_etcut_Jpsi_SiTrk);
   fChain->SetBranchAddress("trig_L2_el_L2_e5_tight_e4_etcut_Jpsi_TRT", &trig_L2_el_L2_e5_tight_e4_etcut_Jpsi_TRT, &b_trig_L2_el_L2_e5_tight_e4_etcut_Jpsi_TRT);
   fChain->SetBranchAddress("trig_L2_el_L2_e5_tight_e5_NoCut", &trig_L2_el_L2_e5_tight_e5_NoCut, &b_trig_L2_el_L2_e5_tight_e5_NoCut);
   fChain->SetBranchAddress("trig_L2_el_L2_e5_tight_e9_etcut_Jpsi", &trig_L2_el_L2_e5_tight_e9_etcut_Jpsi, &b_trig_L2_el_L2_e5_tight_e9_etcut_Jpsi);
   fChain->SetBranchAddress("trig_L2_el_L2_e60_loose", &trig_L2_el_L2_e60_loose, &b_trig_L2_el_L2_e60_loose);
   fChain->SetBranchAddress("trig_L2_el_L2_e6T_medium", &trig_L2_el_L2_e6T_medium, &b_trig_L2_el_L2_e6T_medium);
   fChain->SetBranchAddress("trig_L2_el_L2_e7_tight_e14_etcut_Jpsi", &trig_L2_el_L2_e7_tight_e14_etcut_Jpsi, &b_trig_L2_el_L2_e7_tight_e14_etcut_Jpsi);
   fChain->SetBranchAddress("trig_L2_el_L2_e9_tight_e5_tight_Jpsi", &trig_L2_el_L2_e9_tight_e5_tight_Jpsi, &b_trig_L2_el_L2_e9_tight_e5_tight_Jpsi);
   fChain->SetBranchAddress("trig_L2_el_L2_eb_physics", &trig_L2_el_L2_eb_physics, &b_trig_L2_el_L2_eb_physics);
   fChain->SetBranchAddress("trig_L2_el_L2_eb_physics_empty", &trig_L2_el_L2_eb_physics_empty, &b_trig_L2_el_L2_eb_physics_empty);
   fChain->SetBranchAddress("trig_L2_el_L2_eb_physics_firstempty", &trig_L2_el_L2_eb_physics_firstempty, &b_trig_L2_el_L2_eb_physics_firstempty);
   fChain->SetBranchAddress("trig_L2_el_L2_eb_physics_noL1PS", &trig_L2_el_L2_eb_physics_noL1PS, &b_trig_L2_el_L2_eb_physics_noL1PS);
   fChain->SetBranchAddress("trig_L2_el_L2_eb_physics_unpaired_iso", &trig_L2_el_L2_eb_physics_unpaired_iso, &b_trig_L2_el_L2_eb_physics_unpaired_iso);
   fChain->SetBranchAddress("trig_L2_el_L2_eb_physics_unpaired_noniso", &trig_L2_el_L2_eb_physics_unpaired_noniso, &b_trig_L2_el_L2_eb_physics_unpaired_noniso);
   fChain->SetBranchAddress("trig_L2_el_L2_eb_random", &trig_L2_el_L2_eb_random, &b_trig_L2_el_L2_eb_random);
   fChain->SetBranchAddress("trig_L2_el_L2_eb_random_empty", &trig_L2_el_L2_eb_random_empty, &b_trig_L2_el_L2_eb_random_empty);
   fChain->SetBranchAddress("trig_L2_el_L2_eb_random_firstempty", &trig_L2_el_L2_eb_random_firstempty, &b_trig_L2_el_L2_eb_random_firstempty);
   fChain->SetBranchAddress("trig_L2_el_L2_eb_random_unpaired_iso", &trig_L2_el_L2_eb_random_unpaired_iso, &b_trig_L2_el_L2_eb_random_unpaired_iso);
   fChain->SetBranchAddress("trig_L2_el_L2_em3_empty_larcalib", &trig_L2_el_L2_em3_empty_larcalib, &b_trig_L2_el_L2_em3_empty_larcalib);
   fChain->SetBranchAddress("trig_L2_el_L2_em5_empty_larcalib", &trig_L2_el_L2_em5_empty_larcalib, &b_trig_L2_el_L2_em5_empty_larcalib);
   fChain->SetBranchAddress("trig_L2_ph_n", &trig_L2_ph_n, &b_trig_L2_ph_n);
   fChain->SetBranchAddress("trig_L2_ph_E", &trig_L2_ph_E, &b_trig_L2_ph_E);
   fChain->SetBranchAddress("trig_L2_ph_Et", &trig_L2_ph_Et, &b_trig_L2_ph_Et);
   fChain->SetBranchAddress("trig_L2_ph_pt", &trig_L2_ph_pt, &b_trig_L2_ph_pt);
   fChain->SetBranchAddress("trig_L2_ph_eta", &trig_L2_ph_eta, &b_trig_L2_ph_eta);
   fChain->SetBranchAddress("trig_L2_ph_phi", &trig_L2_ph_phi, &b_trig_L2_ph_phi);
   fChain->SetBranchAddress("trig_L2_ph_RoIWord", &trig_L2_ph_RoIWord, &b_trig_L2_ph_RoIWord);
   fChain->SetBranchAddress("trig_L2_ph_L2_2g15_loose", &trig_L2_ph_L2_2g15_loose, &b_trig_L2_ph_L2_2g15_loose);
   fChain->SetBranchAddress("trig_L2_ph_L2_2g20_loose", &trig_L2_ph_L2_2g20_loose, &b_trig_L2_ph_L2_2g20_loose);
   fChain->SetBranchAddress("trig_L2_ph_L2_g100_etcut_g50_etcut", &trig_L2_ph_L2_g100_etcut_g50_etcut, &b_trig_L2_ph_L2_g100_etcut_g50_etcut);
   fChain->SetBranchAddress("trig_L2_ph_L2_g10_NoCut_cosmic", &trig_L2_ph_L2_g10_NoCut_cosmic, &b_trig_L2_ph_L2_g10_NoCut_cosmic);
   fChain->SetBranchAddress("trig_L2_ph_L2_g11_etcut", &trig_L2_ph_L2_g11_etcut, &b_trig_L2_ph_L2_g11_etcut);
   fChain->SetBranchAddress("trig_L2_ph_L2_g150_etcut", &trig_L2_ph_L2_g150_etcut, &b_trig_L2_ph_L2_g150_etcut);
   fChain->SetBranchAddress("trig_L2_ph_L2_g15_loose", &trig_L2_ph_L2_g15_loose, &b_trig_L2_ph_L2_g15_loose);
   fChain->SetBranchAddress("trig_L2_ph_L2_g20_etcut", &trig_L2_ph_L2_g20_etcut, &b_trig_L2_ph_L2_g20_etcut);
   fChain->SetBranchAddress("trig_L2_ph_L2_g20_etcut_xe30_noMu", &trig_L2_ph_L2_g20_etcut_xe30_noMu, &b_trig_L2_ph_L2_g20_etcut_xe30_noMu);
   fChain->SetBranchAddress("trig_L2_ph_L2_g20_loose", &trig_L2_ph_L2_g20_loose, &b_trig_L2_ph_L2_g20_loose);
   fChain->SetBranchAddress("trig_L2_ph_L2_g40_loose", &trig_L2_ph_L2_g40_loose, &b_trig_L2_ph_L2_g40_loose);
   fChain->SetBranchAddress("trig_L2_ph_L2_g40_loose_EFxe40_noMu", &trig_L2_ph_L2_g40_loose_EFxe40_noMu, &b_trig_L2_ph_L2_g40_loose_EFxe40_noMu);
   fChain->SetBranchAddress("trig_L2_ph_L2_g40_loose_xe30_medium_noMu", &trig_L2_ph_L2_g40_loose_xe30_medium_noMu, &b_trig_L2_ph_L2_g40_loose_xe30_medium_noMu);
   fChain->SetBranchAddress("trig_L2_ph_L2_g40_loose_xe35_medium_noMu", &trig_L2_ph_L2_g40_loose_xe35_medium_noMu, &b_trig_L2_ph_L2_g40_loose_xe35_medium_noMu);
   fChain->SetBranchAddress("trig_L2_ph_L2_g40_tight", &trig_L2_ph_L2_g40_tight, &b_trig_L2_ph_L2_g40_tight);
   fChain->SetBranchAddress("trig_L2_ph_L2_g40_tight_b10_medium", &trig_L2_ph_L2_g40_tight_b10_medium, &b_trig_L2_ph_L2_g40_tight_b10_medium);
   fChain->SetBranchAddress("trig_L2_ph_L2_g5_NoCut_cosmic", &trig_L2_ph_L2_g5_NoCut_cosmic, &b_trig_L2_ph_L2_g5_NoCut_cosmic);
   fChain->SetBranchAddress("trig_L2_ph_L2_g60_loose", &trig_L2_ph_L2_g60_loose, &b_trig_L2_ph_L2_g60_loose);
   fChain->SetBranchAddress("trig_L2_ph_L2_g80_loose", &trig_L2_ph_L2_g80_loose, &b_trig_L2_ph_L2_g80_loose);
   fChain->SetBranchAddress("trig_L2_jet_n", &trig_L2_jet_n, &b_trig_L2_jet_n);
   fChain->SetBranchAddress("trig_L2_jet_E", &trig_L2_jet_E, &b_trig_L2_jet_E);
   fChain->SetBranchAddress("trig_L2_jet_eta", &trig_L2_jet_eta, &b_trig_L2_jet_eta);
   fChain->SetBranchAddress("trig_L2_jet_phi", &trig_L2_jet_phi, &b_trig_L2_jet_phi);
   fChain->SetBranchAddress("trig_L2_jet_RoIWord", &trig_L2_jet_RoIWord, &b_trig_L2_jet_RoIWord);
   fChain->SetBranchAddress("trig_EF_el_n", &trig_EF_el_n, &b_trig_EF_el_n);
   fChain->SetBranchAddress("trig_EF_el_E", &trig_EF_el_E, &b_trig_EF_el_E);
   fChain->SetBranchAddress("trig_EF_el_Et", &trig_EF_el_Et, &b_trig_EF_el_Et);
   fChain->SetBranchAddress("trig_EF_el_pt", &trig_EF_el_pt, &b_trig_EF_el_pt);
   fChain->SetBranchAddress("trig_EF_el_m", &trig_EF_el_m, &b_trig_EF_el_m);
   fChain->SetBranchAddress("trig_EF_el_eta", &trig_EF_el_eta, &b_trig_EF_el_eta);
   fChain->SetBranchAddress("trig_EF_el_phi", &trig_EF_el_phi, &b_trig_EF_el_phi);
   fChain->SetBranchAddress("trig_EF_el_px", &trig_EF_el_px, &b_trig_EF_el_px);
   fChain->SetBranchAddress("trig_EF_el_py", &trig_EF_el_py, &b_trig_EF_el_py);
   fChain->SetBranchAddress("trig_EF_el_pz", &trig_EF_el_pz, &b_trig_EF_el_pz);
   fChain->SetBranchAddress("trig_EF_el_charge", &trig_EF_el_charge, &b_trig_EF_el_charge);
   fChain->SetBranchAddress("trig_EF_el_author", &trig_EF_el_author, &b_trig_EF_el_author);
   fChain->SetBranchAddress("trig_EF_el_isEM", &trig_EF_el_isEM, &b_trig_EF_el_isEM);
   fChain->SetBranchAddress("trig_EF_el_loose", &trig_EF_el_loose, &b_trig_EF_el_loose);
   fChain->SetBranchAddress("trig_EF_el_looseIso", &trig_EF_el_looseIso, &b_trig_EF_el_looseIso);
   fChain->SetBranchAddress("trig_EF_el_medium", &trig_EF_el_medium, &b_trig_EF_el_medium);
   fChain->SetBranchAddress("trig_EF_el_mediumIso", &trig_EF_el_mediumIso, &b_trig_EF_el_mediumIso);
   fChain->SetBranchAddress("trig_EF_el_mediumWithoutTrack", &trig_EF_el_mediumWithoutTrack, &b_trig_EF_el_mediumWithoutTrack);
   fChain->SetBranchAddress("trig_EF_el_mediumIsoWithoutTrack", &trig_EF_el_mediumIsoWithoutTrack, &b_trig_EF_el_mediumIsoWithoutTrack);
   fChain->SetBranchAddress("trig_EF_el_tight", &trig_EF_el_tight, &b_trig_EF_el_tight);
   fChain->SetBranchAddress("trig_EF_el_tightIso", &trig_EF_el_tightIso, &b_trig_EF_el_tightIso);
   fChain->SetBranchAddress("trig_EF_el_tightWithoutTrack", &trig_EF_el_tightWithoutTrack, &b_trig_EF_el_tightWithoutTrack);
   fChain->SetBranchAddress("trig_EF_el_tightIsoWithoutTrack", &trig_EF_el_tightIsoWithoutTrack, &b_trig_EF_el_tightIsoWithoutTrack);
   fChain->SetBranchAddress("trig_EF_el_loosePP", &trig_EF_el_loosePP, &b_trig_EF_el_loosePP);
   fChain->SetBranchAddress("trig_EF_el_loosePPIso", &trig_EF_el_loosePPIso, &b_trig_EF_el_loosePPIso);
   fChain->SetBranchAddress("trig_EF_el_mediumPP", &trig_EF_el_mediumPP, &b_trig_EF_el_mediumPP);
   fChain->SetBranchAddress("trig_EF_el_mediumPPIso", &trig_EF_el_mediumPPIso, &b_trig_EF_el_mediumPPIso);
   fChain->SetBranchAddress("trig_EF_el_tightPP", &trig_EF_el_tightPP, &b_trig_EF_el_tightPP);
   fChain->SetBranchAddress("trig_EF_el_tightPPIso", &trig_EF_el_tightPPIso, &b_trig_EF_el_tightPPIso);
   fChain->SetBranchAddress("trig_EF_el_EF_2e10_medium", &trig_EF_el_EF_2e10_medium, &b_trig_EF_el_EF_2e10_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_2e10_medium_mu6", &trig_EF_el_EF_2e10_medium_mu6, &b_trig_EF_el_EF_2e10_medium_mu6);
   fChain->SetBranchAddress("trig_EF_el_EF_2e12T_medium", &trig_EF_el_EF_2e12T_medium, &b_trig_EF_el_EF_2e12T_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_2e12_medium", &trig_EF_el_EF_2e12_medium, &b_trig_EF_el_EF_2e12_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_2e15_medium", &trig_EF_el_EF_2e15_medium, &b_trig_EF_el_EF_2e15_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_2e5_tight", &trig_EF_el_EF_2e5_tight, &b_trig_EF_el_EF_2e5_tight);
   fChain->SetBranchAddress("trig_EF_el_EF_2e5_tight_Jpsi", &trig_EF_el_EF_2e5_tight_Jpsi, &b_trig_EF_el_EF_2e5_tight_Jpsi);
   fChain->SetBranchAddress("trig_EF_el_EF_e10_medium", &trig_EF_el_EF_e10_medium, &b_trig_EF_el_EF_e10_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e10_medium_2mu6", &trig_EF_el_EF_e10_medium_2mu6, &b_trig_EF_el_EF_e10_medium_2mu6);
   fChain->SetBranchAddress("trig_EF_el_EF_e10_medium_mu10", &trig_EF_el_EF_e10_medium_mu10, &b_trig_EF_el_EF_e10_medium_mu10);
   fChain->SetBranchAddress("trig_EF_el_EF_e10_medium_mu6", &trig_EF_el_EF_e10_medium_mu6, &b_trig_EF_el_EF_e10_medium_mu6);
   fChain->SetBranchAddress("trig_EF_el_EF_e10_medium_mu6_topo_medium", &trig_EF_el_EF_e10_medium_mu6_topo_medium, &b_trig_EF_el_EF_e10_medium_mu6_topo_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e11T_medium", &trig_EF_el_EF_e11T_medium, &b_trig_EF_el_EF_e11T_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e11T_medium_2e6T_medium", &trig_EF_el_EF_e11T_medium_2e6T_medium, &b_trig_EF_el_EF_e11T_medium_2e6T_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e11_etcut", &trig_EF_el_EF_e11_etcut, &b_trig_EF_el_EF_e11_etcut);
   fChain->SetBranchAddress("trig_EF_el_EF_e12T_medium_mu6_topo_medium", &trig_EF_el_EF_e12T_medium_mu6_topo_medium, &b_trig_EF_el_EF_e12T_medium_mu6_topo_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e12_medium", &trig_EF_el_EF_e12_medium, &b_trig_EF_el_EF_e12_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e13_etcut_xs60_noMu", &trig_EF_el_EF_e13_etcut_xs60_noMu, &b_trig_EF_el_EF_e13_etcut_xs60_noMu);
   fChain->SetBranchAddress("trig_EF_el_EF_e13_etcut_xs60_noMu_dphi2j10xe07", &trig_EF_el_EF_e13_etcut_xs60_noMu_dphi2j10xe07, &b_trig_EF_el_EF_e13_etcut_xs60_noMu_dphi2j10xe07);
   fChain->SetBranchAddress("trig_EF_el_EF_e13_etcut_xs70_noMu", &trig_EF_el_EF_e13_etcut_xs70_noMu, &b_trig_EF_el_EF_e13_etcut_xs70_noMu);
   fChain->SetBranchAddress("trig_EF_el_EF_e15_HLTtighter", &trig_EF_el_EF_e15_HLTtighter, &b_trig_EF_el_EF_e15_HLTtighter);
   fChain->SetBranchAddress("trig_EF_el_EF_e15_medium", &trig_EF_el_EF_e15_medium, &b_trig_EF_el_EF_e15_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e15_medium_e12_medium", &trig_EF_el_EF_e15_medium_e12_medium, &b_trig_EF_el_EF_e15_medium_e12_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e15_medium_xe30_noMu", &trig_EF_el_EF_e15_medium_xe30_noMu, &b_trig_EF_el_EF_e15_medium_xe30_noMu);
   fChain->SetBranchAddress("trig_EF_el_EF_e15_medium_xe40_noMu", &trig_EF_el_EF_e15_medium_xe40_noMu, &b_trig_EF_el_EF_e15_medium_xe40_noMu);
   fChain->SetBranchAddress("trig_EF_el_EF_e15_medium_xe50_noMu", &trig_EF_el_EF_e15_medium_xe50_noMu, &b_trig_EF_el_EF_e15_medium_xe50_noMu);
   fChain->SetBranchAddress("trig_EF_el_EF_e15_tight", &trig_EF_el_EF_e15_tight, &b_trig_EF_el_EF_e15_tight);
   fChain->SetBranchAddress("trig_EF_el_EF_e20_etcut_xs60_noMu", &trig_EF_el_EF_e20_etcut_xs60_noMu, &b_trig_EF_el_EF_e20_etcut_xs60_noMu);
   fChain->SetBranchAddress("trig_EF_el_EF_e20_etcut_xs60_noMu_dphi2j10xe07", &trig_EF_el_EF_e20_etcut_xs60_noMu_dphi2j10xe07, &b_trig_EF_el_EF_e20_etcut_xs60_noMu_dphi2j10xe07);
   fChain->SetBranchAddress("trig_EF_el_EF_e20_loose", &trig_EF_el_EF_e20_loose, &b_trig_EF_el_EF_e20_loose);
   fChain->SetBranchAddress("trig_EF_el_EF_e20_loose1", &trig_EF_el_EF_e20_loose1, &b_trig_EF_el_EF_e20_loose1);
   fChain->SetBranchAddress("trig_EF_el_EF_e20_looseTrk", &trig_EF_el_EF_e20_looseTrk, &b_trig_EF_el_EF_e20_looseTrk);
   fChain->SetBranchAddress("trig_EF_el_EF_e20_medium", &trig_EF_el_EF_e20_medium, &b_trig_EF_el_EF_e20_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e20_medium1", &trig_EF_el_EF_e20_medium1, &b_trig_EF_el_EF_e20_medium1);
   fChain->SetBranchAddress("trig_EF_el_EF_e20_medium2", &trig_EF_el_EF_e20_medium2, &b_trig_EF_el_EF_e20_medium2);
   fChain->SetBranchAddress("trig_EF_el_EF_e20_medium_IDTrkNoCut", &trig_EF_el_EF_e20_medium_IDTrkNoCut, &b_trig_EF_el_EF_e20_medium_IDTrkNoCut);
   fChain->SetBranchAddress("trig_EF_el_EF_e20_medium_SiTrk", &trig_EF_el_EF_e20_medium_SiTrk, &b_trig_EF_el_EF_e20_medium_SiTrk);
   fChain->SetBranchAddress("trig_EF_el_EF_e20_medium_TRT", &trig_EF_el_EF_e20_medium_TRT, &b_trig_EF_el_EF_e20_medium_TRT);
   fChain->SetBranchAddress("trig_EF_el_EF_e20_tight_e15_NoCut_Zee", &trig_EF_el_EF_e20_tight_e15_NoCut_Zee, &b_trig_EF_el_EF_e20_tight_e15_NoCut_Zee);
   fChain->SetBranchAddress("trig_EF_el_EF_e22_etcut_xs60_noMu", &trig_EF_el_EF_e22_etcut_xs60_noMu, &b_trig_EF_el_EF_e22_etcut_xs60_noMu);
   fChain->SetBranchAddress("trig_EF_el_EF_e22_etcut_xs60_noMu_dphi2j10xe07", &trig_EF_el_EF_e22_etcut_xs60_noMu_dphi2j10xe07, &b_trig_EF_el_EF_e22_etcut_xs60_noMu_dphi2j10xe07);
   fChain->SetBranchAddress("trig_EF_el_EF_e22_loose", &trig_EF_el_EF_e22_loose, &b_trig_EF_el_EF_e22_loose);
   fChain->SetBranchAddress("trig_EF_el_EF_e22_loose1", &trig_EF_el_EF_e22_loose1, &b_trig_EF_el_EF_e22_loose1);
   fChain->SetBranchAddress("trig_EF_el_EF_e22_looseTrk", &trig_EF_el_EF_e22_looseTrk, &b_trig_EF_el_EF_e22_looseTrk);
   fChain->SetBranchAddress("trig_EF_el_EF_e22_medium", &trig_EF_el_EF_e22_medium, &b_trig_EF_el_EF_e22_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e22_medium1", &trig_EF_el_EF_e22_medium1, &b_trig_EF_el_EF_e22_medium1);
   fChain->SetBranchAddress("trig_EF_el_EF_e22_medium2", &trig_EF_el_EF_e22_medium2, &b_trig_EF_el_EF_e22_medium2);
   fChain->SetBranchAddress("trig_EF_el_EF_e22_medium_IDTrkNoCut", &trig_EF_el_EF_e22_medium_IDTrkNoCut, &b_trig_EF_el_EF_e22_medium_IDTrkNoCut);
   fChain->SetBranchAddress("trig_EF_el_EF_e22_medium_SiTrk", &trig_EF_el_EF_e22_medium_SiTrk, &b_trig_EF_el_EF_e22_medium_SiTrk);
   fChain->SetBranchAddress("trig_EF_el_EF_e22_medium_TRT", &trig_EF_el_EF_e22_medium_TRT, &b_trig_EF_el_EF_e22_medium_TRT);
   fChain->SetBranchAddress("trig_EF_el_EF_e33_medium", &trig_EF_el_EF_e33_medium, &b_trig_EF_el_EF_e33_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e35_medium", &trig_EF_el_EF_e35_medium, &b_trig_EF_el_EF_e35_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e40_medium", &trig_EF_el_EF_e40_medium, &b_trig_EF_el_EF_e40_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e45_medium", &trig_EF_el_EF_e45_medium, &b_trig_EF_el_EF_e45_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e45_medium1", &trig_EF_el_EF_e45_medium1, &b_trig_EF_el_EF_e45_medium1);
   fChain->SetBranchAddress("trig_EF_el_EF_e5_medium_mu6", &trig_EF_el_EF_e5_medium_mu6, &b_trig_EF_el_EF_e5_medium_mu6);
   fChain->SetBranchAddress("trig_EF_el_EF_e5_medium_mu6_topo_medium", &trig_EF_el_EF_e5_medium_mu6_topo_medium, &b_trig_EF_el_EF_e5_medium_mu6_topo_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e5_tight", &trig_EF_el_EF_e5_tight, &b_trig_EF_el_EF_e5_tight);
   fChain->SetBranchAddress("trig_EF_el_EF_e5_tight_e14_etcut_Jpsi", &trig_EF_el_EF_e5_tight_e14_etcut_Jpsi, &b_trig_EF_el_EF_e5_tight_e14_etcut_Jpsi);
   fChain->SetBranchAddress("trig_EF_el_EF_e5_tight_e4_etcut_Jpsi", &trig_EF_el_EF_e5_tight_e4_etcut_Jpsi, &b_trig_EF_el_EF_e5_tight_e4_etcut_Jpsi);
   fChain->SetBranchAddress("trig_EF_el_EF_e5_tight_e4_etcut_Jpsi_SiTrk", &trig_EF_el_EF_e5_tight_e4_etcut_Jpsi_SiTrk, &b_trig_EF_el_EF_e5_tight_e4_etcut_Jpsi_SiTrk);
   fChain->SetBranchAddress("trig_EF_el_EF_e5_tight_e4_etcut_Jpsi_TRT", &trig_EF_el_EF_e5_tight_e4_etcut_Jpsi_TRT, &b_trig_EF_el_EF_e5_tight_e4_etcut_Jpsi_TRT);
   fChain->SetBranchAddress("trig_EF_el_EF_e5_tight_e5_NoCut", &trig_EF_el_EF_e5_tight_e5_NoCut, &b_trig_EF_el_EF_e5_tight_e5_NoCut);
   fChain->SetBranchAddress("trig_EF_el_EF_e5_tight_e9_etcut_Jpsi", &trig_EF_el_EF_e5_tight_e9_etcut_Jpsi, &b_trig_EF_el_EF_e5_tight_e9_etcut_Jpsi);
   fChain->SetBranchAddress("trig_EF_el_EF_e60_loose", &trig_EF_el_EF_e60_loose, &b_trig_EF_el_EF_e60_loose);
   fChain->SetBranchAddress("trig_EF_el_EF_e6T_medium", &trig_EF_el_EF_e6T_medium, &b_trig_EF_el_EF_e6T_medium);
   fChain->SetBranchAddress("trig_EF_el_EF_e7_tight_e14_etcut_Jpsi", &trig_EF_el_EF_e7_tight_e14_etcut_Jpsi, &b_trig_EF_el_EF_e7_tight_e14_etcut_Jpsi);
   fChain->SetBranchAddress("trig_EF_el_EF_e9_tight_e5_tight_Jpsi", &trig_EF_el_EF_e9_tight_e5_tight_Jpsi, &b_trig_EF_el_EF_e9_tight_e5_tight_Jpsi);
   fChain->SetBranchAddress("trig_EF_el_EF_eb_physics", &trig_EF_el_EF_eb_physics, &b_trig_EF_el_EF_eb_physics);
   fChain->SetBranchAddress("trig_EF_el_EF_eb_physics_empty", &trig_EF_el_EF_eb_physics_empty, &b_trig_EF_el_EF_eb_physics_empty);
   fChain->SetBranchAddress("trig_EF_el_EF_eb_physics_firstempty", &trig_EF_el_EF_eb_physics_firstempty, &b_trig_EF_el_EF_eb_physics_firstempty);
   fChain->SetBranchAddress("trig_EF_el_EF_eb_physics_noL1PS", &trig_EF_el_EF_eb_physics_noL1PS, &b_trig_EF_el_EF_eb_physics_noL1PS);
   fChain->SetBranchAddress("trig_EF_el_EF_eb_physics_unpaired_iso", &trig_EF_el_EF_eb_physics_unpaired_iso, &b_trig_EF_el_EF_eb_physics_unpaired_iso);
   fChain->SetBranchAddress("trig_EF_el_EF_eb_physics_unpaired_noniso", &trig_EF_el_EF_eb_physics_unpaired_noniso, &b_trig_EF_el_EF_eb_physics_unpaired_noniso);
   fChain->SetBranchAddress("trig_EF_el_EF_eb_random", &trig_EF_el_EF_eb_random, &b_trig_EF_el_EF_eb_random);
   fChain->SetBranchAddress("trig_EF_el_EF_eb_random_empty", &trig_EF_el_EF_eb_random_empty, &b_trig_EF_el_EF_eb_random_empty);
   fChain->SetBranchAddress("trig_EF_el_EF_eb_random_firstempty", &trig_EF_el_EF_eb_random_firstempty, &b_trig_EF_el_EF_eb_random_firstempty);
   fChain->SetBranchAddress("trig_EF_el_EF_eb_random_unpaired_iso", &trig_EF_el_EF_eb_random_unpaired_iso, &b_trig_EF_el_EF_eb_random_unpaired_iso);
   fChain->SetBranchAddress("trig_EF_el_vertweight", &trig_EF_el_vertweight, &b_trig_EF_el_vertweight);
   fChain->SetBranchAddress("trig_EF_el_hastrack", &trig_EF_el_hastrack, &b_trig_EF_el_hastrack);
   fChain->SetBranchAddress("trig_EF_ph_n", &trig_EF_ph_n, &b_trig_EF_ph_n);
   fChain->SetBranchAddress("trig_EF_ph_E", &trig_EF_ph_E, &b_trig_EF_ph_E);
   fChain->SetBranchAddress("trig_EF_ph_Et", &trig_EF_ph_Et, &b_trig_EF_ph_Et);
   fChain->SetBranchAddress("trig_EF_ph_pt", &trig_EF_ph_pt, &b_trig_EF_ph_pt);
   fChain->SetBranchAddress("trig_EF_ph_m", &trig_EF_ph_m, &b_trig_EF_ph_m);
   fChain->SetBranchAddress("trig_EF_ph_eta", &trig_EF_ph_eta, &b_trig_EF_ph_eta);
   fChain->SetBranchAddress("trig_EF_ph_phi", &trig_EF_ph_phi, &b_trig_EF_ph_phi);
   fChain->SetBranchAddress("trig_EF_ph_px", &trig_EF_ph_px, &b_trig_EF_ph_px);
   fChain->SetBranchAddress("trig_EF_ph_py", &trig_EF_ph_py, &b_trig_EF_ph_py);
   fChain->SetBranchAddress("trig_EF_ph_pz", &trig_EF_ph_pz, &b_trig_EF_ph_pz);
   fChain->SetBranchAddress("trig_EF_ph_EF_2g15_loose", &trig_EF_ph_EF_2g15_loose, &b_trig_EF_ph_EF_2g15_loose);
   fChain->SetBranchAddress("trig_EF_ph_EF_2g20_loose", &trig_EF_ph_EF_2g20_loose, &b_trig_EF_ph_EF_2g20_loose);
   fChain->SetBranchAddress("trig_EF_ph_EF_g100_etcut_g50_etcut", &trig_EF_ph_EF_g100_etcut_g50_etcut, &b_trig_EF_ph_EF_g100_etcut_g50_etcut);
   fChain->SetBranchAddress("trig_EF_ph_EF_g10_NoCut_cosmic", &trig_EF_ph_EF_g10_NoCut_cosmic, &b_trig_EF_ph_EF_g10_NoCut_cosmic);
   fChain->SetBranchAddress("trig_EF_ph_EF_g11_etcut", &trig_EF_ph_EF_g11_etcut, &b_trig_EF_ph_EF_g11_etcut);
   fChain->SetBranchAddress("trig_EF_ph_EF_g11_etcut_larcalib", &trig_EF_ph_EF_g11_etcut_larcalib, &b_trig_EF_ph_EF_g11_etcut_larcalib);
   fChain->SetBranchAddress("trig_EF_ph_EF_g150_etcut", &trig_EF_ph_EF_g150_etcut, &b_trig_EF_ph_EF_g150_etcut);
   fChain->SetBranchAddress("trig_EF_ph_EF_g15_loose", &trig_EF_ph_EF_g15_loose, &b_trig_EF_ph_EF_g15_loose);
   fChain->SetBranchAddress("trig_EF_ph_EF_g15_loose_larcalib", &trig_EF_ph_EF_g15_loose_larcalib, &b_trig_EF_ph_EF_g15_loose_larcalib);
   fChain->SetBranchAddress("trig_EF_ph_EF_g20_etcut", &trig_EF_ph_EF_g20_etcut, &b_trig_EF_ph_EF_g20_etcut);
   fChain->SetBranchAddress("trig_EF_ph_EF_g20_etcut_xe30_noMu", &trig_EF_ph_EF_g20_etcut_xe30_noMu, &b_trig_EF_ph_EF_g20_etcut_xe30_noMu);
   fChain->SetBranchAddress("trig_EF_ph_EF_g20_loose", &trig_EF_ph_EF_g20_loose, &b_trig_EF_ph_EF_g20_loose);
   fChain->SetBranchAddress("trig_EF_ph_EF_g20_loose_larcalib", &trig_EF_ph_EF_g20_loose_larcalib, &b_trig_EF_ph_EF_g20_loose_larcalib);
   fChain->SetBranchAddress("trig_EF_ph_EF_g40_loose", &trig_EF_ph_EF_g40_loose, &b_trig_EF_ph_EF_g40_loose);
   fChain->SetBranchAddress("trig_EF_ph_EF_g40_loose_EFxe40_noMu", &trig_EF_ph_EF_g40_loose_EFxe40_noMu, &b_trig_EF_ph_EF_g40_loose_EFxe40_noMu);
   fChain->SetBranchAddress("trig_EF_ph_EF_g40_loose_larcalib", &trig_EF_ph_EF_g40_loose_larcalib, &b_trig_EF_ph_EF_g40_loose_larcalib);
   fChain->SetBranchAddress("trig_EF_ph_EF_g40_loose_xe45_medium_noMu", &trig_EF_ph_EF_g40_loose_xe45_medium_noMu, &b_trig_EF_ph_EF_g40_loose_xe45_medium_noMu);
   fChain->SetBranchAddress("trig_EF_ph_EF_g40_loose_xe55_medium_noMu", &trig_EF_ph_EF_g40_loose_xe55_medium_noMu, &b_trig_EF_ph_EF_g40_loose_xe55_medium_noMu);
   fChain->SetBranchAddress("trig_EF_ph_EF_g40_tight", &trig_EF_ph_EF_g40_tight, &b_trig_EF_ph_EF_g40_tight);
   fChain->SetBranchAddress("trig_EF_ph_EF_g40_tight_b10_medium", &trig_EF_ph_EF_g40_tight_b10_medium, &b_trig_EF_ph_EF_g40_tight_b10_medium);
   fChain->SetBranchAddress("trig_EF_ph_EF_g5_NoCut_cosmic", &trig_EF_ph_EF_g5_NoCut_cosmic, &b_trig_EF_ph_EF_g5_NoCut_cosmic);
   fChain->SetBranchAddress("trig_EF_ph_EF_g60_loose", &trig_EF_ph_EF_g60_loose, &b_trig_EF_ph_EF_g60_loose);
   fChain->SetBranchAddress("trig_EF_ph_EF_g60_loose_larcalib", &trig_EF_ph_EF_g60_loose_larcalib, &b_trig_EF_ph_EF_g60_loose_larcalib);
   fChain->SetBranchAddress("trig_EF_ph_EF_g80_loose", &trig_EF_ph_EF_g80_loose, &b_trig_EF_ph_EF_g80_loose);
   fChain->SetBranchAddress("trig_EF_ph_EF_g80_loose_larcalib", &trig_EF_ph_EF_g80_loose_larcalib, &b_trig_EF_ph_EF_g80_loose_larcalib);
   fChain->SetBranchAddress("trig_EF_ph_author", &trig_EF_ph_author, &b_trig_EF_ph_author);
   fChain->SetBranchAddress("trig_EF_ph_isRecovered", &trig_EF_ph_isRecovered, &b_trig_EF_ph_isRecovered);
   fChain->SetBranchAddress("trig_EF_ph_isEM", &trig_EF_ph_isEM, &b_trig_EF_ph_isEM);
   fChain->SetBranchAddress("trig_EF_ph_convFlag", &trig_EF_ph_convFlag, &b_trig_EF_ph_convFlag);
   fChain->SetBranchAddress("trig_EF_ph_isConv", &trig_EF_ph_isConv, &b_trig_EF_ph_isConv);
   fChain->SetBranchAddress("trig_EF_ph_nConv", &trig_EF_ph_nConv, &b_trig_EF_ph_nConv);
   fChain->SetBranchAddress("trig_EF_ph_nSingleTrackConv", &trig_EF_ph_nSingleTrackConv, &b_trig_EF_ph_nSingleTrackConv);
   fChain->SetBranchAddress("trig_EF_ph_nDoubleTrackConv", &trig_EF_ph_nDoubleTrackConv, &b_trig_EF_ph_nDoubleTrackConv);
   fChain->SetBranchAddress("trig_EF_ph_loose", &trig_EF_ph_loose, &b_trig_EF_ph_loose);
   fChain->SetBranchAddress("trig_EF_ph_looseIso", &trig_EF_ph_looseIso, &b_trig_EF_ph_looseIso);
   fChain->SetBranchAddress("trig_EF_ph_tight", &trig_EF_ph_tight, &b_trig_EF_ph_tight);
   fChain->SetBranchAddress("trig_EF_ph_tightIso", &trig_EF_ph_tightIso, &b_trig_EF_ph_tightIso);
   fChain->SetBranchAddress("trig_EF_ph_looseAR", &trig_EF_ph_looseAR, &b_trig_EF_ph_looseAR);
   fChain->SetBranchAddress("trig_EF_ph_looseARIso", &trig_EF_ph_looseARIso, &b_trig_EF_ph_looseARIso);
   fChain->SetBranchAddress("trig_EF_ph_tightAR", &trig_EF_ph_tightAR, &b_trig_EF_ph_tightAR);
   fChain->SetBranchAddress("trig_EF_ph_tightARIso", &trig_EF_ph_tightARIso, &b_trig_EF_ph_tightARIso);
   fChain->SetBranchAddress("trig_EF_jet_n", &trig_EF_jet_n, &b_trig_EF_jet_n);
   fChain->SetBranchAddress("trig_EF_jet_emscale_E", &trig_EF_jet_emscale_E, &b_trig_EF_jet_emscale_E);
   fChain->SetBranchAddress("trig_EF_jet_emscale_pt", &trig_EF_jet_emscale_pt, &b_trig_EF_jet_emscale_pt);
   fChain->SetBranchAddress("trig_EF_jet_emscale_m", &trig_EF_jet_emscale_m, &b_trig_EF_jet_emscale_m);
   fChain->SetBranchAddress("trig_EF_jet_emscale_eta", &trig_EF_jet_emscale_eta, &b_trig_EF_jet_emscale_eta);
   fChain->SetBranchAddress("trig_EF_jet_emscale_phi", &trig_EF_jet_emscale_phi, &b_trig_EF_jet_emscale_phi);
   fChain->SetBranchAddress("trig_EF_jet_EF_2b10_medium_4j30_a4tc_EFFS", &trig_EF_jet_EF_2b10_medium_4j30_a4tc_EFFS, &b_trig_EF_jet_EF_2b10_medium_4j30_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_2b10_medium_j75_j30_a4tc_EFFS", &trig_EF_jet_EF_2b10_medium_j75_j30_a4tc_EFFS, &b_trig_EF_jet_EF_2b10_medium_j75_j30_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_3j100_a4tc_EFFS", &trig_EF_jet_EF_3j100_a4tc_EFFS, &b_trig_EF_jet_EF_3j100_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_3j30_a4tc_EFFS", &trig_EF_jet_EF_3j30_a4tc_EFFS, &b_trig_EF_jet_EF_3j30_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_3j40_a4tc_EFFS", &trig_EF_jet_EF_3j40_a4tc_EFFS, &b_trig_EF_jet_EF_3j40_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_3j45_a4tc_EFFS", &trig_EF_jet_EF_3j45_a4tc_EFFS, &b_trig_EF_jet_EF_3j45_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_3j75_a4tc_EFFS", &trig_EF_jet_EF_3j75_a4tc_EFFS, &b_trig_EF_jet_EF_3j75_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_4j30_a4tc_EFFS", &trig_EF_jet_EF_4j30_a4tc_EFFS, &b_trig_EF_jet_EF_4j30_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_4j40_a4tc_EFFS", &trig_EF_jet_EF_4j40_a4tc_EFFS, &b_trig_EF_jet_EF_4j40_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_4j45_a4tc_EFFS", &trig_EF_jet_EF_4j45_a4tc_EFFS, &b_trig_EF_jet_EF_4j45_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_4j55_a4tc_EFFS", &trig_EF_jet_EF_4j55_a4tc_EFFS, &b_trig_EF_jet_EF_4j55_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_4j60_a4tc_EFFS", &trig_EF_jet_EF_4j60_a4tc_EFFS, &b_trig_EF_jet_EF_4j60_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_5j30_a4tc_EFFS", &trig_EF_jet_EF_5j30_a4tc_EFFS, &b_trig_EF_jet_EF_5j30_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_5j40_a4tc_EFFS", &trig_EF_jet_EF_5j40_a4tc_EFFS, &b_trig_EF_jet_EF_5j40_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_5j45_a4tc_EFFS", &trig_EF_jet_EF_5j45_a4tc_EFFS, &b_trig_EF_jet_EF_5j45_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_6j30_a4tc_EFFS", &trig_EF_jet_EF_6j30_a4tc_EFFS, &b_trig_EF_jet_EF_6j30_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_b10_medium_4j30_a4tc_EFFS", &trig_EF_jet_EF_b10_medium_4j30_a4tc_EFFS, &b_trig_EF_jet_EF_b10_medium_4j30_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_fj100_a4tc_EFFS", &trig_EF_jet_EF_fj100_a4tc_EFFS, &b_trig_EF_jet_EF_fj100_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_fj10_a4tc_EFFS", &trig_EF_jet_EF_fj10_a4tc_EFFS, &b_trig_EF_jet_EF_fj10_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_fj135_a4tc_EFFS", &trig_EF_jet_EF_fj135_a4tc_EFFS, &b_trig_EF_jet_EF_fj135_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_fj15_a4tc_EFFS", &trig_EF_jet_EF_fj15_a4tc_EFFS, &b_trig_EF_jet_EF_fj15_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_fj20_a4tc_EFFS", &trig_EF_jet_EF_fj20_a4tc_EFFS, &b_trig_EF_jet_EF_fj20_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_fj30_a4tc_EFFS", &trig_EF_jet_EF_fj30_a4tc_EFFS, &b_trig_EF_jet_EF_fj30_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_fj55_a4tc_EFFS", &trig_EF_jet_EF_fj55_a4tc_EFFS, &b_trig_EF_jet_EF_fj55_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_fj75_a4tc_EFFS", &trig_EF_jet_EF_fj75_a4tc_EFFS, &b_trig_EF_jet_EF_fj75_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j100_a4tc_EFFS", &trig_EF_jet_EF_j100_a4tc_EFFS, &b_trig_EF_jet_EF_j100_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j10_a4tc_EFFS", &trig_EF_jet_EF_j10_a4tc_EFFS, &b_trig_EF_jet_EF_j10_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j135_a4tc_EFFS", &trig_EF_jet_EF_j135_a4tc_EFFS, &b_trig_EF_jet_EF_j135_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j15_a4tc_EFFS", &trig_EF_jet_EF_j15_a4tc_EFFS, &b_trig_EF_jet_EF_j15_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j180_a4tc_EFFS", &trig_EF_jet_EF_j180_a4tc_EFFS, &b_trig_EF_jet_EF_j180_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j20_a4tc_EFFS", &trig_EF_jet_EF_j20_a4tc_EFFS, &b_trig_EF_jet_EF_j20_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j240_a4tc_EFFS", &trig_EF_jet_EF_j240_a4tc_EFFS, &b_trig_EF_jet_EF_j240_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j30_a4tc_EFFS", &trig_EF_jet_EF_j30_a4tc_EFFS, &b_trig_EF_jet_EF_j30_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j30_fj30_a4tc_EFFS", &trig_EF_jet_EF_j30_fj30_a4tc_EFFS, &b_trig_EF_jet_EF_j30_fj30_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j320_a4tc_EFFS", &trig_EF_jet_EF_j320_a4tc_EFFS, &b_trig_EF_jet_EF_j320_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j40_a4tc_EFFS", &trig_EF_jet_EF_j40_a4tc_EFFS, &b_trig_EF_jet_EF_j40_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j40_fj40_a4tc_EFFS", &trig_EF_jet_EF_j40_fj40_a4tc_EFFS, &b_trig_EF_jet_EF_j40_fj40_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j425_a4tc_EFFS", &trig_EF_jet_EF_j425_a4tc_EFFS, &b_trig_EF_jet_EF_j425_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j55_a4tc_EFFS", &trig_EF_jet_EF_j55_a4tc_EFFS, &b_trig_EF_jet_EF_j55_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j55_fj55_a4tc_EFFS", &trig_EF_jet_EF_j55_fj55_a4tc_EFFS, &b_trig_EF_jet_EF_j55_fj55_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j75_a4tc_EFFS", &trig_EF_jet_EF_j75_a4tc_EFFS, &b_trig_EF_jet_EF_j75_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_j75_fj75_a4tc_EFFS", &trig_EF_jet_EF_j75_fj75_a4tc_EFFS, &b_trig_EF_jet_EF_j75_fj75_a4tc_EFFS);
   fChain->SetBranchAddress("trig_EF_jet_EF_mu4_j10_a4tc_EFFS", &trig_EF_jet_EF_mu4_j10_a4tc_EFFS, &b_trig_EF_jet_EF_mu4_j10_a4tc_EFFS);
}

Bool_t BaseTree_ttbar::Notify()
{
   // The Notify() function is called when a new file is opened. This
   // can be either for a new TTree in a TChain or when when a new TTree
   // is started when using PROOF. It is normally not necessary to make changes
   // to the generated code, but the routine can be extended by the
   // user if needed. The return value is currently not used.

   return kTRUE;
}

#endif // #ifdef BaseTree_ttbar_cxx
