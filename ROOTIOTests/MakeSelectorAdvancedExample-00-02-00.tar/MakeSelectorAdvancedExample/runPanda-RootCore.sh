#!/bin/bash

which root


# There are several ways to set up ROOT env:
#
# 1. setup ROOT env at BNL
# ========================
# source /afs/usatlas/scripts/root_set-slc5.sh 5.28.00
#
# 2. set up by prun
#
#    2.1 via prun option --useAthenaPackages --athenaTag=17.0.0
#    ===================================================
#
#    2.2 via prun option --rootVer==5.28/00 but failed because of missing glibc3.4.9
#    =============================


# RootCore and GRL compilation without checking out from SVN
# ============================
source build-GRL-RootCore.sh -n


# input file "input.txt" is created on the fly during panda job submission
#            ==========

#  prun --exec "echo %IN | sed 's/,/\n/g' > input.txt; ./runPanda.sh"

#(1.)   --noBuild
#(2.1)  --useAthenaPackages --athenaTag=17.0.0
#(2.2)  --rootVer==5.28/00

#   --excludeFile=".svn"
#   --nFiles=3 --site=ANALY_LONG_BNL_LOCAL 
#   --inDS=data11_7TeV.00180242.physics_JetTauEtmiss.merge.NTUP_TOP.f368_m812_p530_p532_tid334586_00
#   --outDS=user.yesw.data11_7TeV-00180242-ttbar_D3PD.test.V1
#


root -q -b -l run_chain-ttbarSel-RootCore.C
