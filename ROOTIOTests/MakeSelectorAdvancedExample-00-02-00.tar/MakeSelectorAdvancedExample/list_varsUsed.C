{
  TString incPath(gSystem->GetIncludePath());
  gSystem->AddIncludePath("-DVARS_USED_LIST -I./GRL/");

/*
  // gROOT->Macro("RootCore/scripts/load_packages.C+");  // if using RootCore
  gSystem->AddIncludePath("-I./GRL/");
  gSystem->Load("GRL/libGoodRunsLists.so");
  gROOT->LoadMacro("BaseTree_ttbar/BaseTree_ttbar.C+");
*/

  gROOT->LoadMacro("ttbarSel.C++");

  gSystem->SetIncludePath(incPath.Data());
}

