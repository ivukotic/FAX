This is a D3PD-ntuple-based ttbar reconstruction example to demonstrate:

  - how to write analysis code suitable for running on non-Proof ROOT, 
    ProofLite and Proof.

  - how to communicate between client and Proof master/workers. There are 
    at least 4 ways to achieve that:

      1) via TProof::SetParameter(), but not available for non-Proof ROOT.

      2) via shell environmental variable

      3) via option in TChain::Process or TDSet::Proces()

      4) via a file shipped with TProof::UploadPackage()

    This example manifests all the above ways except the first one.

  - how to write out selected events, create a new tree, and histograms 
    suitable for all cases of non-Proof ROOT, ProofLite and Proof.

  - how to apply GoodRunsLists cut

  - using TProofOutputFile in order to be able to merge a user ROOT 
    file in Proof.

  - how to override ROOT version on Proof master/worker nodes.

  - how to write out the log file on Proof master/worker nodes.


Other useful features:
=====================

  1. ntuple structure class "BaseTree_ttbar" is separted from 
     the main analysis class "ttbarSel". It would be regenerated 
     automatically during running the root script "run_chain-ttbarSel.C" 
     via TTree::MakeSelector(). So your main analysis code is untouched 
     unless the used variables are changed in the ntuple.

  2. convenient way to control the mode among 
     "NonProof","Proof", or "ProofLite".

  3. dynamic generation of list of ntuples variables used in the analysis, 
     and then activate those variables only in event reading.

  4. using TTreeCache after learning with a few events.

  5. showing wall/cpu time consumption on all Proof master/worker nodes
     as well as on client machine.

  6. parameters for event selection criteria are read from a text file via 
     class TEnv and are later written into the output root file for 
     bookkeeping purpose. So you need not change your analysis code 
     to tune event selection cuts.

  7. you can use option in TChain::Process() to control 
     the printout in your code and 
     writing out the old tree "selTree" for selected events.

  8. for someone who does not like package loading in Proof, an option 
     "usePar" is added in run_chain-*.C macros. When it is set false,
     Proof workers will load shared libraries from the same location 
     as client machine.

  9. some indice to jet, leptons in old tree will be written out 
     only when the writing of the old tree "selTree" is enabled.

  10. how to set sub-merger is provided, but is commented out.
     It is quite helpful in case your merging stage takes a long time.
     But some old ROOT versions (<5.28.00) may not work with this option.

  11. the cut of GoodRunsLists is off on default.
     You can turn it on by variable "cut_GRL" in "run_chain*-ttbarSel*.C".
       Please read the GoodRunsLists wiki in "Further reading" section 
     on how to use GoodRunsLists and to create a relevant xml file.


Code components
===============
  - 00ReadMe.txt           # this guide
  - run_chain-ttbarSel.C   # main ROOT control macro
  - ttbarSel.h             # header file of analysis class "ttbarSel"
  - ttbarSel..C            # where main analysis code is
  - BaseTree_ttbar/BaseTree_ttbar.{h,C}
                           # base class defining the input tree structure
  - BaseTree_ttbar/PROOF-INF/SETUP.C
                           # initial macro to load BaseTree_ttbar at Proof workers
  - ttbarSel-Cuts.txt-TEnv # file for cut-related parameters
  - GRL/PROOF-INF/SETUP.C
                           # initial macro to load GRL at Proof workers
  - build-GRL.sh           # used to check out GoodRunsLists package
                           # and build its shared library
  - runPanda.sh            # shell script for run main ROOT macro
  - prun-runPanda.txt      # an example to submit the job via prun
  ------------------------------------------------------------------------
  - build-GRL-RootCore.sh  # for checking out GoodRunsLists and RootCore,
                           # and using RootCore to compile GoodRunsLists
  - run_chain-ttbarSel-RootCore.C  # main ROOT control macro using RootCore
  - runPanda.sh-RootCore   # shell script for run main ROOT macro using RootCore
  ------------------------------------------------------------------------
   # automatic generation of used ntuple variables
  - list_varsUsed.C        # a ROOT macro to list ntuples variables used
  - list_varsUsed.sh       # a shell script to run the above macro
  ------------------------------------------------------------------------
  - list_varsUsed.txt      # list of ntuple variables used, produced 
                           # either from list_varsUsed.sh
                           # or from run_chain-ttbarSel*.C
  - input.txt              # the list of input files, one file per line
                           # which you need provide yourself.


About ttbar reconstruction
==========================
  This analysis reconstructs ttbar via the mode (W_1b)(W_2b), where 
W_1 decays to lepton+neutrino, and W_2 decays to 2 jets. The neutrino is 
constructed using the constraint on W mass and assuming the missing overall 
transverse momentum is neutrino transverse momentum.


Output
======
   This analysis writes out a new TTree for ttbar objects, and related 
histograms. Optinally it also write the old TTree for those survived events, 
which can be turned off via "NO_selTree" in TChain::Process option.
   The cut parameters are also written as TPaveText into the output root file.


Input
=====
  The list of input files are stored in file "input.txt", 
which can be generated by prun via the following submission
  prun --exec "echo %IN | sed 's/,/\n/g' > input.txt; ./runPanda.sh"

  You can use input of ttbar D3PD ntuple such as dataset 
1) PLHC version (r16)
  data10_7TeV.00166198.physics_JetTauEtmiss.merge.NTUP_TOP.r1774_p327_p333_p379_p386_tid242065_00
2) EPS version (r16)
  data11_7TeV.00180149.physics_Egamma.merge.NTUP_TOP.f368_m806_p530_p577_tid367196_00 
3) r17 version
  data11_7TeV.00187811.physics_Egamma.merge.NTUP_TOPEL.r2713_p705_p694_p722_tid528455_00


How to list ntuple variables used in analysis
=============================================
The main ROOT macro "run_chain-ttbarSel*.C" has already included this function.
You can get this list by running "list_varsUsed.sh".


How to run locally
==================
 Step-1:   Set up ROOT environment at client machine
 Step-2.1: Run "build-GRL.sh" (no RootCore)
 Step-2.2: or "build-GRL-RootCore.sh" (using RootCore)
 Step-3:   Get the dataset.
           If your ntuple structure is different from that in BaseTree_ttbar,
            you need recreate BaseTree_ttbar.{h,C}.
 Step-4:   In "run_chain-ttbarSel.C" or "run_chain-ttbarSel-RootCore.C",
           change the name of Proof server, the way to setting up same 
           ROOT version at worker nodes, and the input to TChain.
 Step-5:   Choose your running mode in "run_chain-ttbarSel.C" or 
           "run_chain-ttbarSel-RootCore.C".
           You had better try "NonProof" mode first with a few events.
 Step-6.1: Then run "root -l run_chain-ttbarSel.C" (not using RootCore)
 Step-6.2: Then run "root -l run_chain-ttbarSel-RootCore.C" (using RootCore)

 If you have many different analysis areas used to run on one same Proof farm, 
you need first clear the version of RootCore that is sitting on the Proof 
worker nodes, which can be achieved by running 
   proof->ClearPackage("RootCore.par") 
in "run_chain-ttbarSel-RootCore.C".


How to run via prun
===================
  Check "prun-runPanda.txt" for an example


Note
====

  Many recent ATLAS TTrees are in zero-TreeCacheSize, which can be checked via 
TTree::GetCacheSize() after opening a root file. It triggers a ROOT bug showing 
up in ProofLite or Proof mode. You can find more details in the savannah bug 
report:

https://savannah.cern.ch/bugs/?85673

This bug has been fixed in ROOT-5.28.00f, 5.30.03 and after


Further reading
===============
1. ROOT:  http://root.cern.ch/

2. Proof: http://root.cern.ch/drupal/content/proof

3. GoodRunsLists:
      https://twiki.cern.ch/twiki/bin/viewauth/AtlasProtected/PhysicsAnalysisWorkBookDataConditions#Information_about_GoodRunsLists
      https://twiki.cern.ch/twiki/bin/view/AtlasProtected/GoodRunListsForAnalysis
      https://twiki.cern.ch/twiki/bin/viewauth/Atlas/GoodRunsListsTutorial

4. TopD3PD: https://twiki.cern.ch/twiki/bin/view/AtlasProtected/TopD3PDProduction

5. RootCore: https://twiki.cern.ch/twiki/bin/view/AtlasProtected/RootCore
