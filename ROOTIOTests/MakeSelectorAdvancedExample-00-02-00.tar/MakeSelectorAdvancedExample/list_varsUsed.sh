#!/bin/bash
export LC_ALL=C

which root > /dev/null
if [ $? -ne 0 ]; then
   echo "root not defined, quit now"
   exit 1
fi

varListFile_tmp="tmp-list_varsUsed.txt"
varListFile="list_varsUsed.txt"
rm -f $varListFile_tmp $varListFile

BaseH="BaseTree_ttbar/BaseTree_ttbar.h"

root -q -b -l list_varsUsed.C 2>&1 | grep "was not declared in this scope" \
  |  cut -d"'" -f2 | sort -u > ${varListFile_tmp}

for var in `cat ${varListFile_tmp}`; do
  # grep -q "*b_${var};" ${BaseH} && echo "${var}" >> ${varListFile};
  grep "fChain->SetBranchAddress.*&${var}," ${BaseH} | cut -d '"' -f2  >> ${varListFile}
done

rm -f $varListFile_tmp
