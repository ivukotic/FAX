void SETUP()
{
  gSystem->Load("libGoodRunsLists.so");
}
