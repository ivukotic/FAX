myName=$0
myDir=$PWD

usage_info()
{
[ "X$BASH" = "X" ] || myName=$BASH_SOURCE
cat << EOF
 This script compiles package GoodRunsLists and 
       creates a few sym-links under GRL/.
   It also checks out from SVN unless option -n is on.

 Usage:
        source $myName [ -h ]  [ -n ]
EOF
}

checkOut=yes

while [ $# -gt 0 ]
do
    case "$1" in
        -h)	usage_info; shift
		return 0;;
	-n)	checkOut=no;;
	-*)	usage_info;
		return 1;;
 	*)	break;;		# terminate while loop
    esac
    shift
done


# in case of your username at CERN is DIFFERENT from that at your local 
# machine # and your did not override in your ~/.ssh/config, your need 
# explicitly specify your username in "svn co", e.g.
#  svn co svn+ssh://MyNameAtCern@svn.cern.ch/reps/atlasoff/DataQuality/GoodRunsLists/tags/GoodRunsLists-00-00-96 GoodRunsLists

# check out GoodRunsLists
if [ "$checkOut" = "yes" ]; then
  echo "checking out GoodRunsLists-00-00-96"
  svn co svn+ssh://svn.cern.ch/reps/atlasoff/DataQuality/GoodRunsLists/tags/GoodRunsLists-00-00-96 GoodRunsLists
  # apply some changes to its Makefiles
  cp -p GoodRunsLists-Makefile.Standalone GoodRunsLists/cmt/Makefile.Standalone
  cp -p GoodRunsLists-Makefile.RootCore GoodRunsLists/cmt/Makefile.RootCore
fi

# compile GoodRunsLists
cd GoodRunsLists/cmt
echo "compiling GoodRunsLists"
make -f Makefile.Standalone

# make some sym-links under GRL/
cd $myDir
cd GRL/
rm -f GoodRunsLists libGoodRunsLists.so
ln -s ../GoodRunsLists/GoodRunsLists .
ln -s ../GoodRunsLists/StandAlone/libGoodRunsLists.so .

cd $myDir


#######################
# Please read the Physics workbook for information on GoodRunsLists

# https://twiki.cern.ch/twiki/bin/viewauth/AtlasProtected/PhysicsAnalysisWorkBookDataConditions#Information_about_GoodRunsLists

# There are older tutorials available, which may still work, but BUYER BEWARE
# e.g., https://twiki.cern.ch/twiki/bin/viewauth/Atlas/GoodRunsListsTutorial
