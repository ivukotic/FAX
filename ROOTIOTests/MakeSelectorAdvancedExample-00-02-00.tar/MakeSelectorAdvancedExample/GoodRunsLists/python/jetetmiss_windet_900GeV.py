
from GoodRunsLists.GoodRunsListConfig import GoodRunsListConfig

class jetetmiss_windet_900GeV(GoodRunsListConfig):
  def __init__(self):
    GoodRunsListConfig.__init__(self)

    ## name in GRLB object, and below the xml filename
    self.name            = "jetetmiss_windet_900GeV"
    self.listname        = "jetetmiss_windet_900GeV.xml"

    ## Specify each selection of dq flags here.
    ## The query is interpreted as the logical AND of all elements in the array.

    ## All selection criteria at: Database/CoolRunQuery/python/AtlRunQueryParser.py
    ## possible dq flag colors : 'n.a.', 'unknown', 'green', 'yellow', 'red'
    ## possible detectors (incomplete): pix,sct,em,til,lar,any,... 

    ## See http://atlas-runquery.cern.ch for more user examples.

    self.querydict['run']  = ["140541+"]
    self.querydict['ptag'] = ["data09_900GeV"]
    self.querydict['st']   = ["physics_MinBias"]

    dqflagsquery = [ 'ATLGL  LBSUMM#DetStatusLBSUMM-December09-01 g',
		     'L1CTP  LBSUMM#DetStatusLBSUMM-December09-01 g',
		     'atlsol LBSUMM#DetStatusLBSUMM-December09-01 g',
		     'lar    LBSUMM#DetStatusLBSUMM-December09-01 g',
		     'tile   LBSUMM#DetStatusLBSUMM-December09-01 g',
                     'pix    LBSUMM#DetStatusLBSUMM-December09-01 g',
                     'sct    LBSUMM#DetStatusLBSUMM-December09-01 g',
                     'trtb,trte LBSUMM#DetStatusLBSUMM-December09-01 g',
                     #'jetb yellow+  ',
                     #'jetea yellow+ ',
                     #'jetec yellow+ ', 
                     #'met yellow+   ',
                   ]

    self.querydict['lhc']  = ["stablebeams T"]

    ## Set the dqflags query
    self.querydict['dq'] = dqflagsquery

    #self.querydict['ctag'] = ['DetStatusLBSUMM-December09-01']

