myName=$0
myDir=$PWD

usage_info()
{
[ "X$BASH" = "X" ] || myName=$BASH_SOURCE
cat << EOF
 This script compiles package RootCore and GoodRunsLists.
   It also checks out from SVN unless option -n is on.

 Usage:
        source $myName [ -h ]  [ -n ]
EOF
}

checkOut=yes

while [ $# -gt 0 ]
do
    case "$1" in
        -h)	usage_info; shift
		return 0;;
	-n)	checkOut=no;;
	-*)	usage_info;
		return 1;;
	*)	break;;		# terminate while loop
    esac
    shift
done

# in case of your username at CERN is DIFFERENT from that at your local 
# machine # and your did not override in your ~/.ssh/config, your need 
# explicitly specify your username in "svn co", e.g.
#  svn co svn+ssh://MyNameAtCern@svn.cern.ch/reps/atlasoff/DataQuality/GoodRunsLists/tags/GoodRunsLists-00-00-96 GoodRunsLists

# check out GoodRunsLists
if [ "$checkOut" = "yes" ]; then
  echo "checking out GoodRunsLists"
  svn co svn+ssh://svn.cern.ch/reps/atlasoff/DataQuality/GoodRunsLists/tags/GoodRunsLists-00-00-96 GoodRunsLists
  # apply some changes to its Makefiles
  cp -p GoodRunsLists-Makefile.Standalone GoodRunsLists/cmt/Makefile.Standalone
  cp -p GoodRunsLists-Makefile.RootCore GoodRunsLists/cmt/Makefile.RootCore
fi

# check out RootCore (to manage your packages like GoodRunsLists)
if [ "$checkOut" = "yes" ]; then
  echo "checking out RootCore"
  svn co svn+ssh://svn.cern.ch/reps/atlasoff/PhysicsAnalysis/D3PDTools/RootCore/tags/RootCore-00-01-11 RootCore
fi

# set up RootCore
cd RootCore
./configure
source scripts/setup.sh

# compile packages
cd $myDir
$ROOTCOREDIR/scripts/find_packages.sh
$ROOTCOREDIR/scripts/compile.sh 

# apply a fix to make_par.sh in RootCore
cp -p RootCore-make_par.sh RootCore/scripts/make_par.sh

# make par file for Proof farm
RootCore/scripts/make_par.sh RootCore_ttbar.par


#######################
# Please read the Physics workbook for information on GoodRunsLists

# https://twiki.cern.ch/twiki/bin/viewauth/AtlasProtected/PhysicsAnalysisWorkBookDataConditions#Information_about_GoodRunsLists

# There are older tutorials available, which may still work, but BUYER BEWARE
# e.g., https://twiki.cern.ch/twiki/bin/viewauth/Atlas/GoodRunsListsTutorial


# Information on RootCore tool
# ============================
# https://twiki.cern.ch/twiki/bin/view/AtlasProtected/RootCore
