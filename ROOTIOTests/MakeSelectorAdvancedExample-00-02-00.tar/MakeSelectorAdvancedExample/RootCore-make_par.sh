#!/bin/bash

myName=$0
[ "X$BASH" = "X" ] || myName=$BASH_SOURCE

source "`dirname $myName`/preamble.sh" "$myName"
CurDir=`pwd`

DIR=/tmp/RootCoreBuild-$$

NOBUILD=
if test "$1" == "--nobuild"
then
    NOBUILD=--nobuild
    shift
fi

OUTFILE=`dirname $ROOTCOREDIR`/RootCore.par
test "$1" != "" && OUTFILE=$1
test "${OUTFILE:0:1}" != "/" && OUTFILE=$CurDir/$OUTFILE

MYDIR=$DIR/`basename $OUTFILE | sed 's/.par$//'`

rm -rf $DIR
mkdir -p $MYDIR
$ROOTCOREDIR/scripts/grid_copy.sh $MYDIR $ROOTCOREDIR

for package in `cat $ROOTCOREBIN/packages`
do
    echo using package $package
    $ROOTCOREDIR/scripts/grid_copy.sh $NOBUILD $MYDIR $package
    basename $package >>$MYDIR/packages
done

cd $DIR
ln -s RootCore/PROOF-INF `basename $MYDIR`/PROOF-INF

tar -czf $OUTFILE `basename $MYDIR`

cd $CurDir
rm -rf $DIR
