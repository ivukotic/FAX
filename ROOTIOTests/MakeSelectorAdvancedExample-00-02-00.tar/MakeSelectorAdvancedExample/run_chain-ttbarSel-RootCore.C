{
  TStopwatch timer;
  Int_t cacheSize = 10*1024*1024;

  char *inputList = "input.txt";
  if (gSystem->AccessPathName(inputList)) {
     cout << "Input list file \"" << inputList << "\" does not exist, quit now!" << endl;
     gSystem->Exit(1);
  }

  char *ROOTCOREBIN = gSystem->Getenv("ROOTCOREBIN");
  if (ROOTCOREBIN == NULL) {
     cerr << "ROOTCOREBIN undfined, quit now" << endl;
     gSystem->Exit(1);
  }

  char* workDir(gSystem->WorkingDirectory());

  // filename to list ntuple vars in analysis
  TString varsFilename = TString::Format("%s/list_varsUsed.txt", workDir);

  // filenames for output, GoodRunsLists, and cuts
  TString fout = TString::Format("%s/myOutput.root", workDir);
  TString Cuts_Filename = TString::Format("%s/ttbarSel-Cuts.txt-TEnv", workDir);

  Bool_t cut_GRL = kFALSE;
  TString fxml = TString::Format("%s/myGRL.xml", workDir);


  Bool_t runProof = kFALSE;
  Bool_t usePar = kTRUE;
  const char* server = "";
  Int_t nworkers = 0;

  TString runMode = "NonProof"; // "NonProof","Proof", "ProofLite"

  if (runMode == "Proof") {
    // case-1: PROOF server
    // ====================
    runProof = kTRUE;
    server = "bnlt3s01";
    nworkers = 14;
    // server = "acas1010";
    // nworkers = 12;

  } else if (runMode == "ProofLite") {
    // case-2: PROOF-Lite
    // ====================
    runProof = kTRUE;
    server = "";
    nworkers = 3;

  } else if (runMode == "NonProof") {
    // case-3: Non-Proof
    // ====================
    runProof = kFALSE;
    server = "";
    nworkers = -1;

  } else {
    cout << "Unknown runMode=" << runMode << ", exit now" << endl;
    gSystem->Exit(1);
  }

  TProof* proof = 0;

  TChain* chain = new TChain("physics");
  TFileCollection fc("fc","list of input root files",inputList);
  chain->AddFileInfoList(fc.GetList());

  // chain->Add("root://xrd//data/user.hma.data10_7TeV.00159086.physics_L1Calo.merge.NTUP_JETMET.f275_p191.slimmed.V5.4/user.hma.data10_7TeV.00159086.physics_L1Calo.merge.NTUP_JETMET.f275_p191.slimmed.V5.4._00001.output.root.1");

  // TTreePerfStats perfStat("ioper",chain);

  //+BaseTree
  // you can comment the following block in case of no change on ntuple structure
  chain->MakeSelector("BaseTree_ttbar");
  gSystem->Exec("mv BaseTree_ttbar.h BaseTree_ttbar.C BaseTree_ttbar/");
  //-BaseTree

  //+ListVarsUsed
  // you can comment the following block after the first running and there is 
  //  no new ntuple variables added into the analysis code.
  gSystem->Exec("./list_varsUsed.sh");
  //-ListVarsUsed

  gROOT->LoadMacro("BaseTree_ttbar/BaseTree_ttbar.C+");
  gSystem->AddIncludePath("-I./BaseTree_ttbar/");
  gROOT->Macro("RootCore/scripts/load_packages.C+");

  if (runProof) {

    // force proof server uses the same ROOT version as client
    if (server != "") {
      // TString rootVer_dir = gSystem->Exec("echo $ROOTSYS | sed 's%.*root/\\([0-9].*\\)/.*/root%\\1%'");
      char *rootVer_dir = gSystem->BaseName( gSystem->DirName( gSystem->DirName(gSystem->Getenv("ROOTSYS"))));
      TProof::AddEnvVar("PROOF_INITCMD", TString::Format("%s %s","echo source /usatlas/u/yesw2000/bin/root_set-slc5.sh",rootVer_dir) );
    }

    TProof::AddEnvVar("PROOF_NWORKERS",TString::Format("%d",nworkers));

    if (cut_GRL) TProof::AddEnvVar("XMLFilename",fxml.Data());
    TProof::AddEnvVar("OutFilename",fout.Data());
    TProof::AddEnvVar("Cuts_Filename",Cuts_Filename.Data());
    TProof::AddEnvVar("VARSFilename", varsFilename.Data());

    TString str_server(server);
    Bool_t IsProofLite = kFALSE;
    if (str_server.Length() == 0) {
       IsProofLite = kTRUE;
       if (nworkers>0) {
          str_server = TString::Format("workers=%d",nworkers);
       }
    }
    proof = TProof::Open(str_server.Data());

    // for Proof-Lite
    if (IsProofLite) proof->SetParameter("PROOF_Packetizer","TPacketizer");

    //+Option: sub-mergers
    // you may like to enable sub-mergers in case that the merging process
    // takes a long time, set to Zero for dynamic setting number of sub-mergers.
    //   proof->SetParameter("PROOF_UseMergers", 0);
    //   proof->SetParameter("PROOF_UseMergers", 2);
    //-Option: sub-mergers

    // proof->Exec(".!hostname; echo ROOTSYS=$ROOTSYS");

    if (usePar) {
      // GRL setting for Proof
      // proof->ClearPackage("RootCore_ttbar.par");
      proof->UploadPackage("RootCore_ttbar.par");
      proof->EnablePackage("RootCore_ttbar.par",kTRUE);

      gSystem->Exec("gtar cfz BaseTree_ttbar.par BaseTree_ttbar/");
      proof->UploadPackage("BaseTree_ttbar.par");
      proof->EnablePackage("BaseTree_ttbar.par",kTRUE);
    } else {
      // GRL setting for Proof
      proof->Exec(TString::Format("gSystem->Setenv(\"ROOTCOREBIN\",\"%s\");",ROOTCOREBIN));
      proof->Exec(TString::Format("gROOT->Macro(\"%s/scripts/load_packages.C+\");",ROOTCOREBIN));

      proof->Exec(TString::Format("gSystem->Load(\"%s/BaseTree_ttbar/BaseTree_ttbar_C.so\");",workDir));
      proof->Exec(TString::Format("gSystem->AddIncludePath(\"-I%s/BaseTree_ttbar/\");",workDir));
    }

    // set Proof log level for your debugging
    // proof->SetLogLevel(7);
  }

  gSystem->Setenv("OutFilename",fout.Data());
  gSystem->Setenv("Cuts_Filename",Cuts_Filename.Data());
  gSystem->Setenv("VARSFilename", varsFilename.Data());
  if (cut_GRL) gSystem->Setenv("XMLFilename",fxml.Data());

  timer.Start();
  if (runProof) chain->SetProof();
  else {
    chain->SetCacheSize(cacheSize);
    chain->SetCacheLearnEntries(5);
    // TTreeCache should be enabled by default in Proof mode
    // http://root.cern.ch/drupal/content/list-input-parameters-used-proof#TreeCacheParameters
  }
  // you can use the option to control the printout in your code
  // and writing out the old tree for selected events.
  //   chain->Process("ttbarSel.C+","Debug nPrint=1 No_selTree",5);
  //   chain->Process("ttbarSel.C+","nPrint=200 No_selTree",20001);
  chain->Process("ttbarSel.C++","nPrint=500 No_selTree");
  timer.Stop(); timer.Print();

  // write out log file on Proof master/worker nodes
  if (runProof) {
    TProofLog *pl = proof->GetManager()->GetSessionLogs();
    pl->Save("*", "file_with_all_logs.txt");
  }

  TFile outFile(fout.Data(),"UPDATE");

  // the parameters for event selection criteria are 
  // writen into the same output root file
  TEnv envCuts(Cuts_Filename.Data());
  envCuts.IsA()->SetTitle("Selection criteria parameters");
  envCuts.Write("envCuts");

  chain->PrintCacheStats();
  // perfStat.SaveAs("ttbar_perf.root");

  // gSystem->Exit(0);
}
